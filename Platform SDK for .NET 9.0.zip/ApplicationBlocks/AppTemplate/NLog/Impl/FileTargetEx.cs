//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Genesyslab.Configuration;
using Genesyslab.Platform.Commons.Connection.Timer;
using NLog;
using NLog.Layouts;
using NLog.Targets;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl
{
  internal class FileHeaderLayout:Layout
  {
    protected override string GetFormattedMessage(LogEventInfo logEvent)
    {

      var sb = new StringBuilder();
      var cfg = this.LoggingConfiguration as NLogLoggingConfiguration;
      if ((cfg != null) && (cfg.LoggerConfiguration != null))
      {
        sb.Append("Application Name               : ")
          .AppendLine(string.IsNullOrEmpty(cfg.LoggerConfiguration.ApplicationName)
            ? "<unknown>"
            : cfg.LoggerConfiguration.ApplicationName);
        sb.Append("Application Type               : ")
          .AppendLine(cfg.LoggerConfiguration.ApplicationType.ToString(CultureInfo.InvariantCulture));
        sb.Append("Application Host  (config spec): ")
          .AppendLine(string.IsNullOrEmpty(cfg.LoggerConfiguration.ApplicationHost)
            ? "<unknown>"
            : cfg.LoggerConfiguration.ApplicationHost);
        sb.Append("Application Host (machine name): ").AppendLine(Environment.MachineName);
        sb.Append("Application Id                 : ")
          .AppendLine(cfg.LoggerConfiguration.ApplicationId.ToString(CultureInfo.InvariantCulture));
      }
      else
      {
        sb.Append("Application Host (machine name): ").AppendLine(Environment.MachineName);
      }
      sb.Append("Command line                   : ").AppendLine(Environment.CommandLine);
      sb.Append("Timezone Display name          : ").AppendLine(System.TimeZoneInfo.Local.DisplayName);
      sb.Append("Timezone Standard name         : ").AppendLine(System.TimeZoneInfo.Local.StandardName);
      sb.Append("Timezone Daylight name         : ").AppendLine(System.TimeZoneInfo.Local.DaylightName);
      sb.Append("Timezone UTC offset            : ").AppendLine(System.TimeZoneInfo.Local.BaseUtcOffset.ToString());
      sb.Append("UTC Time                       : ").AppendLine(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fff"));
      sb.Append("Local Time                     : ").AppendLine(DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fff"));
      sb.Append("UTC Start Time                 : ").AppendLine(Process.GetCurrentProcess().StartTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fff"));
      try
      {
        var memoryUsage = Process.GetCurrentProcess().WorkingSet64;
        sb.Append("Process Memory Usage (bytes) : ").AppendLine(memoryUsage.ToString(CultureInfo.InvariantCulture));
      }
      catch (Exception){}
      sb.Append("CLR Memory Usage (bytes)       : ").AppendLine(GC.GetTotalMemory(true).ToString(CultureInfo.InvariantCulture));
      sb.Append("Host Info                      : ")
        .Append(Environment.OSVersion).Append("; .NET CLR Version: ").AppendLine(Environment.Version.ToString());

      
      var assemblies = AppDomain.CurrentDomain.GetAssemblies();
      foreach (Assembly assembly in assemblies)
      {
        var assemblyName = assembly.GetName();
        if (assemblyName.Name.ToLower().Contains("genesyslab.platform.") ||
            assemblyName.Name.ToLower().Contains("genesyslab.core") ||
            assemblyName.Name.ToLower().Equals("nlog"))
        {
          sb.Append("Library: ").AppendLine(assemblyName.FullName);
        }
      }
      return sb.ToString();
    }
  }

  internal class FileTargetEx : FileTarget, ITimerAction
  {
    private readonly IScheduler _scheduler;
    private volatile ITimerActionTicket _timerTicket;
    private int _expirationHours;
    private TimeSpan _maxDelta;

    public string ArchiveDirectoryCheckName { get; set; }
    public string ArchiveFileNamePattern { get; set; }
    internal NLogLoggingConfiguration NLogConfiguration { get; set; }
    public int ExpirationHours
    {
      get { return _expirationHours; }
      set
      {
        lock (_scheduler)
        {
          if (_timerTicket != null)
          {
            _timerTicket.Cancel();
            _timerTicket = null;
          }
          _expirationHours = value;
          if (_expirationHours<=0) return;
          _maxDelta = TimeSpan.FromHours(_expirationHours);
          var interval = Math.Max(2,PsdkCustomization.LogFactory.LogArchivesCheckInterval.Value>>4);

          _timerTicket = _scheduler.Schedule(1000*interval, this);
        }
      }
    }

    public FileTargetEx(string name) : base(name)
    {
      _scheduler = TimerFactory.Scheduler;
      _timerTicket = null;
      Header = new FileHeaderLayout();
    }

    protected override void Dispose(bool disposing)
    {
      lock (_scheduler)
      {
        if (_timerTicket != null)
        {
          _timerTicket.Cancel();
          _timerTicket = null;
        }
      }
      base.Dispose(disposing);
    }
    
    public void OnTimer()
    {
      lock (_scheduler)
      {
        _timerTicket.Cancel();
        _timerTicket = null;
        try
        {
          if (String.IsNullOrEmpty(ArchiveDirectoryCheckName)) return;
          if (String.IsNullOrEmpty(ArchiveFileNamePattern)) return;
          if (!Directory.Exists(ArchiveDirectoryCheckName)) return;
          var files = Directory.GetFiles(ArchiveDirectoryCheckName);
          var now = DateTime.UtcNow;
          foreach (string file in files)
          {
            if (!File.Exists(file)) continue;
            var name = Path.GetFileName(file);
            if (String.IsNullOrEmpty(name)) continue;
            if (!Regex.IsMatch(name, ArchiveFileNamePattern)) continue;
            var fileTime = File.GetLastWriteTimeUtc(file);
            if (now - fileTime > _maxDelta)
              File.Delete(file);
          }
        }
        catch (Exception e)
        {
          Write(new LogEventInfoEx
          {
            Exception = e,
            Message = "[NLog.FileTarget] Can't delete expired files"
          });
        }
        finally
        {
          var interval = Math.Max(5, PsdkCustomization.LogFactory.LogArchivesCheckInterval.Value);
          _timerTicket = _scheduler.Schedule(1000* interval, this);
        }
      }
    }

    protected override void Write(LogEventInfo logEvent)
    {
      var exInfo = logEvent as LogEventInfoEx;
      if ((exInfo == null) || (exInfo.Exception == null))
      {
        base.Write(logEvent);
        return;
      }
      exInfo = exInfo.Copy();
      if (!String.IsNullOrEmpty(exInfo.Message))
      {
        exInfo.Message = String.Format("{0} \n {1}", exInfo.Message, exInfo.Exception);
      }
      else
      {
        exInfo.Message = exInfo.Exception.ToString();
      }
      exInfo.Exception = null;
      base.Write(exInfo);
    }
  }
}

//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System.Collections.Generic;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl
{
  internal class FixedSizeQueue<T> where T:class
  {
    private readonly object _syncObj = new object();
    internal object SyncRoot{ get { return _syncObj; }}
    private Queue<T> _dataQueue;
    private int _limit;
    private readonly bool _endbleUnlimitedQueue;
    private bool _overSize;
    public FixedSizeQueue(int limit):this(limit, false){}
    public FixedSizeQueue(int limit, bool enableUnlimited)
    {
      _limit = limit;
      _endbleUnlimitedQueue = enableUnlimited;
      _dataQueue = new Queue<T>(_limit);
    }

    public int Count
    {
      get
      {
        lock (_syncObj)
        {
          return _dataQueue.Count;
        }
      }
    }
    public bool Empty
    {
      get
      {
        lock (_syncObj)
        {
          return _dataQueue.Count == 0;
        }
      }
    }
    public int Limit
    {
      get { return _limit; }
      set { Resize(value); }
    }
    public void Resize(int newSize)
    {
      lock (_syncObj)
      {
        if (_limit==newSize) return;
        if (!_endbleUnlimitedQueue)
          while (_dataQueue.Count > newSize) _dataQueue.Dequeue();
        var newData = new Queue<T>(newSize);
        while (_dataQueue.Count > 0) newData.Enqueue(_dataQueue.Dequeue());
        _dataQueue = newData;
        _limit = newSize;
      }
    }

    public void Enqueue(T value)
    {
      lock (_syncObj)
      {
        if (!_endbleUnlimitedQueue)
          while (_dataQueue.Count >= _limit) _dataQueue.Dequeue();
        _dataQueue.Enqueue(value);
        if (_dataQueue.Count > _limit) _overSize = true;
      }
    }

    public T Dequeue()
    {
      lock (_syncObj)
      {
        if (_dataQueue.Count == 0) return null;
        T data = _dataQueue.Dequeue();
        if ((_dataQueue.Count < (_limit>>1)) && (_overSize))
        {
          _overSize = false;
          _dataQueue.TrimExcess();
        }
        return data;
      }
    }
    public T Peek()
    {
      lock (_syncObj)
      {
        if (_dataQueue.Count == 0) return null;
        return _dataQueue.Peek();
      }
    }
    public T[] Data
    {
      get
      {
        lock (_syncObj)
        {
          return _dataQueue.ToArray();
        }
      }
    }
    public void Clear()
    {
      lock (_syncObj)
      {
        _dataQueue.Clear();
      }
    }
  }
}

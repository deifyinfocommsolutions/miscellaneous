//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using Genesyslab.Platform.AppTemplate.Configuration.Log;
using Genesyslab.Platform.AppTemplate.Logger;
using Genesyslab.Platform.AppTemplate.Logger.LMS;
using Genesyslab.Platform.Management.Protocols.MessageServer;
using NLog;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl
{
  internal static class LogLevelNameProvider
  {
    public static string FormattedName(this NLog.LogLevel level, MessageFormat format)
    {
      if (format == MessageFormat.Full)
      {
        switch (level.Ordinal)
        {
          case 1: return "Debug";
          case 2: return "Trace";
          case 3: return "Interaction";
          case 4: return "Standard";
          case 5: return "Alarm";
          default: return "Unknown";
        }
      }
      switch (level.Ordinal)
      {
        case 1:
          return "Dbg";
        case 2:
          return "Trc";
        case 3:
          return "Int";
        case 4:
          return "Std";
        case 5:
          return "Alr";
        default:
          return "Unknown";
      }
    }
  }

  /// <summary>
  /// Extension of LogEventInfo
  /// </summary>
  public class LogEventInfoEx : LogEventInfo
  {
    internal LogEventInfoEx Copy()
    {
      return MemberwiseClone() as LogEventInfoEx ?? this;
    }
    /// <exclude/>
    public int ID { get; internal protected set; }
    /// <exclude/>
    public LmsLogCategory Category { get; protected internal set; }
    /// <exclude/>
    public NLogLoggingConfiguration Configuration { get; internal protected set; }
    /// <exclude/>
    public INLogLoggerPolicy LoggerPolicy { get; internal protected set; }
    /// <exclude/>
    public AttributeList Attributes { get; set; }
    /// <exclude/>
    internal LmsLogLevel? LoggingLevel { get; set; }


    internal LmsLogLevel GetLogLevel()
    {
      if (LoggingLevel != null) return LoggingLevel.Value;
      switch (Level.Ordinal)
      {
        case 1: return LmsLogLevel.Debug;
        case 2: return LmsLogLevel.Info;
        case 3: return LmsLogLevel.Interaction;
        case 4: return LmsLogLevel.Standard;
        case 5: return LmsLogLevel.Alarm;
        default: return LmsLogLevel.Unknown;
      }
    }
    internal static NLog.LogLevel GetLogLevel(LmsLogLevel level)
    {
      switch (level)
      {
        case LmsLogLevel.Debug: return NLog.LogLevel.Debug;
        case LmsLogLevel.Info: return NLog.LogLevel.Info;
        case LmsLogLevel.Interaction: return NLog.LogLevel.Warn;
        case LmsLogLevel.Standard: return NLog.LogLevel.Error;
        case LmsLogLevel.Alarm: return NLog.LogLevel.Fatal;
        default: return NLog.LogLevel.Off;
      }
    }
    internal static LmsLogLevel GetLogLevel(NLog.LogLevel level)
    {
      switch (level.Ordinal)
      {
        case 1: return LmsLogLevel.Debug;
        case 2: return LmsLogLevel.Info;
        case 3: return LmsLogLevel.Interaction;
        case 4: return LmsLogLevel.Standard;
        case 5: return LmsLogLevel.Alarm;
        default: return LmsLogLevel.Unknown;
      }
    }

    internal void SetCategory(LmsLogCategory? category)
    {
      if (category != null)
      {
        Category = category.Value;
      }
      else
      {
        Category = (LoggerPolicy == null) ? LmsLogCategory.Default: LoggerPolicy.GetCategoty(Message);
      }
    }

    internal void ProcessLevelReassignment()
    {
      if ((Configuration == null) || (Configuration.LoggerConfiguration == null) ||
          (Configuration.LoggerConfiguration.ExtOptions == null)) return;
      var cfg = Configuration.LoggerConfiguration.ExtOptions;
      var levels = cfg.LevelReassigns;
      if (levels==null) return;
      LmsLogLevel newLevel;
      if (!levels.TryGetValue(ID, out newLevel)) return;
      if (newLevel == LmsLogLevel.Unknown) return;
      LoggingLevel = newLevel;
    }
  }
}

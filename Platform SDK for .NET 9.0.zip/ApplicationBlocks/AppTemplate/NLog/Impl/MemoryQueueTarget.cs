//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Globalization;
using Genesyslab.Configuration;
using NLog;
using NLog.Targets;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl
{
  /// <summary>
  /// Limited memory target
  /// </summary>
  [Target("MemoryQueue")]
  public class MemoryQueueTarget: TargetWithLayout
  {
    private readonly FixedSizeQueue<string> _logs;
    /// <summary>
    /// Default queue size
    /// </summary>
    public static int DefaultQueueSize = 4096;

    /// <summary>
    /// set new limit of queue
    /// </summary>
    public string Limit
    {
      get { return _logs.Limit.ToString(CultureInfo.InvariantCulture); }
      set
      {
        int res;
        if (!Int32.TryParse(value, out res))
          throw new ArgumentException("Memory queue 'Limit' value cannot be parsed into integer value");
        _logs.Limit = Math.Max(res, 32);
      }
    }

    /// <summary>
    /// Default constructor
    /// </summary>
    public MemoryQueueTarget() 
    {
      _logs = new FixedSizeQueue<string>(Math.Max(PsdkCustomization.LogFactory.MemoryQueueSize.GetValue(DefaultQueueSize), 32));
    }
    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="name">name of target</param>
    public MemoryQueueTarget(string name):this()
    {
      Name = name;
    }

    protected override void Write(LogEventInfo logEvent)
    {
        _logs.Enqueue(Layout.Render(logEvent));
    }
    /// <summary>
    /// Returns log data as array of strings.
    /// </summary>
    public string[] Logs
    {
      get { return _logs.Data; }
    }
    /// <summary>
    /// Clears all log data
    /// </summary>
    public void Clear()
    {
      _logs.Clear();
    }
  }
}

//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Text;
using Genesyslab.Platform.AppTemplate.Configuration.Log;
using Genesyslab.Platform.Configuration.Protocols.Types;
using NLog;
using NLog.Config;
using NLog.LayoutRenderers;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl
{
  [LayoutRenderer("MessageHeader")]
  internal class MessageHeaderLayoutRenderer : LayoutRenderer
  {
    private delegate void AppendHeader(StringBuilder builder, LogEventInfo logEvent);
    private delegate void AppendDate(StringBuilder builder, DateTime dateTime);
    private delegate string GetLogLevelName(NLog.LogLevel level);

    private AppendHeader _appendHeader ;
    private AppendDate _appendDate ;
    private GetLogLevelName _getLogLevelName;
    private string _format;
    private string _formatTime;
    private string _timeKind;
    private DateTimeKind _timeKindValue;
    private string _appType;
    private CfgAppType _appTypeId;

    public MessageHeaderLayoutRenderer()
    {
      _appendHeader = AppendShort;
      _appendDate = AppendDateLocale;
      _getLogLevelName = level => level.FormattedName(MessageFormat.Short);
    }

    internal static string PrepareValue(string val, string def)
    {
      return string.IsNullOrEmpty(val) ? def : val.Replace(":", "\\:").Replace("}", "\\}");
    }
    internal static string GetDefaultMessageHeaderDelimiter(IGLoggerConfiguration configuration)
    {
      switch (configuration.Format)
      {
        case MessageFormat.ShortTsv:
          return "\t";
        case MessageFormat.ShortCsv:
          return ",";
        case MessageFormat.ShortDsv:
          return PrepareValue(String.IsNullOrEmpty(configuration.MessageHeaderDelimiter) ? " " : configuration.MessageHeaderDelimiter, "");
        default:
          return " ";
      }
    }

    internal static string CreateConfig(IGLoggerConfiguration config)
    {
      var sb = new StringBuilder();
      var delimiter = PrepareValue(GetDefaultMessageHeaderDelimiter(config), " ");
      sb.Append("${MessageHeader:Format=").Append(config.Format.ToString("F"))
        .Append(":FormatTime=").Append(config.TimeFormatting.ToString("F"))
        .Append(":TimeKind=").Append(config.TimeKind.ToString("F"))
        .Append(":Delimiter=").Append(delimiter)
        .Append(":AppName=").Append(PrepareValue(config.ApplicationName, String.Empty))
        .Append(":AppType=").Append(config.ApplicationType)
        .Append(":AppHost=").Append(PrepareValue(config.ApplicationHost, String.Empty))
        .Append("}");
      return sb.ToString();
    }

    [RequiredParameter]
    public string Format
    {
      get { return _format; }
      set
      {
        _format = value??"short";
        _appendHeader = AppendShort;
        _getLogLevelName = level => level.FormattedName(MessageFormat.Short);
        if (String.Equals(_format, MessageFormat.Medium.ToString("F"), StringComparison.InvariantCultureIgnoreCase)){}
          _appendHeader = AppendMedium;
        if (String.Equals(_format, MessageFormat.Full.ToString("F"), StringComparison.InvariantCultureIgnoreCase))
        {
          _appendHeader = AppendFull;
          _getLogLevelName = level => level.FormattedName(MessageFormat.Full);
        }
        if (String.Equals(_format, MessageFormat.ShortCsv.ToString("F"), StringComparison.InvariantCultureIgnoreCase))
          _appendHeader = AppendShortCsv;
        if (String.Equals(_format, MessageFormat.ShortTsv.ToString("F"), StringComparison.InvariantCultureIgnoreCase))
          _appendHeader = AppendShortTsv;
        if (String.Equals(_format, MessageFormat.ShortDsv.ToString("F"), StringComparison.InvariantCultureIgnoreCase))
          _appendHeader = AppendShortDsv;
      }
    }
    [RequiredParameter]
    public string FormatTime
    {get { return _formatTime; }
      set
      {
        _formatTime = value ?? "locale";
        _appendDate = AppendDateLocale;
        if (String.Equals(_formatTime, TimeFormat.Time.ToString("F"), StringComparison.InvariantCultureIgnoreCase))
          _appendDate = AppendTime;
        if (String.Equals(_formatTime, TimeFormat.Iso8601.ToString("F"), StringComparison.InvariantCultureIgnoreCase))
          _appendDate = AppendDateIso;
      }
    }
    [RequiredParameter]
    public string TimeKind
    {
      get { return _timeKind; }
      set
      {
        _timeKind = value ?? "local";
        _timeKindValue = DateTimeKind.Utc;
        if (String.Equals(_timeKind, DateTimeKind.Utc.ToString("F"), StringComparison.InvariantCultureIgnoreCase))
          _timeKindValue = DateTimeKind.Utc;
      }
    }
    [RequiredParameter]
    public string AppName { get; set; }
    [RequiredParameter]
    public string AppHost { get; set; }
    [RequiredParameter]
    public string Delimiter { get; set; }

    [RequiredParameter]
    public string AppType
    {
      get { return _appType; }
      set
      {
        try
        {
          var result = (CfgAppType) Enum.Parse(typeof (CfgAppType), value);
          _appTypeId = result;
          _appType = value;
          return;
        }
        catch (Exception){}
        int intResult;
        if (Int32.TryParse(value, out intResult))
        {
          try
          {
            _appTypeId = (CfgAppType) intResult;
            if (Enum.IsDefined(typeof(CfgAppType), _appTypeId)) return;
          }
          catch (Exception){}
        }
        throw new ArgumentException("AppType parameter does not contain a valuid value");
      }
    }

    protected override void Append(StringBuilder builder, LogEventInfo logEvent)
    {
      _appendHeader(builder, logEvent);
    }

    #region append header
    private  void AppendShort(StringBuilder builder, LogEventInfo logEvent)
    {
      AppendShort(builder, logEvent, " ");
    }

    private void AppendCommonHeader(StringBuilder builder, LogEventInfo logEvent, string delimiter)
    {
      _appendDate(builder, logEvent.TimeStamp);
      builder.Append(delimiter).Append(_getLogLevelName(logEvent.Level));
    }
    private void AppendShort(StringBuilder builder, LogEventInfo logEvent, string delimiter)
    {
      AppendCommonHeader(builder, logEvent, delimiter);
      var ex = logEvent as LogEventInfoEx;
      if (ex != null)
      {
        builder.Append(delimiter).Append(ex.ID.ToString("D5"));
      }
    }
    private void AppendMedium(StringBuilder builder, LogEventInfo logEvent)
    {
      AppendCommonHeader(builder, logEvent, " ");
      var ex = logEvent as LogEventInfoEx;
      if (ex != null)
      {
        builder.Append(" ").Append(ex.ID.ToString("D5"));
      }
      builder.Append(" ").Append(logEvent.LoggerName);

    }
    private  void AppendFull(StringBuilder builder, LogEventInfo logEvent)
    {
      AppendCommonHeader(builder, logEvent, " ");
      if (!String.IsNullOrEmpty(AppName)) builder.Append(" ").Append(AppName);
      builder.Append(" ").Append("GCTI-").Append(((int)_appTypeId).ToString("D2"));
      var ex = logEvent as LogEventInfoEx;
      if (ex != null)
      {
        builder.Append("-").Append(ex.ID.ToString("D5"));
      }
      if (!String.IsNullOrEmpty(AppHost)) builder.Append(" ").Append(AppHost);
      builder.Append(" ").Append(logEvent.LoggerName);
    }
    private  void AppendShortCsv(StringBuilder builder, LogEventInfo logEvent)
    {
      AppendShort(builder, logEvent, ",");
    }
    private  void AppendShortTsv(StringBuilder builder, LogEventInfo logEvent)
    {
      AppendShort(builder, logEvent, "\t");
    }
    private  void AppendShortDsv(StringBuilder builder, LogEventInfo logEvent)
    {
      AppendShort(builder, logEvent, String.IsNullOrEmpty(Delimiter)?"|":Delimiter);
    }
    #endregion append header
    #region append date
    private  void AppendDateLocale(StringBuilder builder, DateTime dateTime)
    {
      builder.Append(_timeKindValue == DateTimeKind.Local
        ? dateTime.ToLocalTime().ToShortTimeString()
        : dateTime.ToUniversalTime().ToShortTimeString());
    }

    private  void AppendDateIso(StringBuilder builder, DateTime dateTime)
    {
      builder.Append(_timeKindValue == DateTimeKind.Local
        ? dateTime.ToLocalTime().ToString("yyyy-MM-dd'T'HH-mm-ss.fff")
        : dateTime.ToUniversalTime().ToString("yyyy-MM-dd'T'HH-mm-ss.fff"));
    }

    private  void AppendTime(StringBuilder builder, DateTime dateTime)
    {
      builder.Append(_timeKindValue == DateTimeKind.Local
        ? dateTime.ToLocalTime().ToString("HH:mm:ss.fff")
        : dateTime.ToUniversalTime().ToString("HH:mm:ss.fff"));
    }
    #endregion append date
  }
}

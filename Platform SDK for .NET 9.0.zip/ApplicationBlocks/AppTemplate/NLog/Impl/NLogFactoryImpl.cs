//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using Genesyslab.Configuration;
using Genesyslab.Platform.AppTemplate.Configuration.Log;
using Genesyslab.Platform.AppTemplate.Logger;
using Genesyslab.Platform.AppTemplate.Logger.LMS;
using Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.LMS;
using Genesyslab.Platform.Configuration.Protocols.Types;
using NLog;
using NLog.Config;
using NLog.LayoutRenderers;
using NLog.Layouts;
using NLog.Targets;
using ILogger = Genesyslab.Platform.Commons.Logging.ILogger;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl
{
  /// <summary>
  /// Inheritor of <see cref="NLog.LogFactory"/> class.
  /// Incapsulates additional configuration.
  /// </summary>
  public class NLogFactoryImpl:LogFactory, INLogFactory
  {
    private GAppLoggingOptions _configuration;
    private LoggingConfiguration _originalConfiguration;

    private readonly object _syncObject = new object();
    internal GAppLoggingOptions AppLoggerConfig{get { return _configuration; }}
    private INLogLoggerPolicy _loggerPolicy;

    internal INLogLoggerPolicy LoggerPolicy{ get { return _loggerPolicy; }}

    /// <summary>
    /// Default constructor
    /// </summary>
    public NLogFactoryImpl()
    {
      _originalConfiguration = Configuration as LoggingConfiguration;
      Configuration = MergeConfig(new NLogLoggingConfiguration(), Configuration);
      ConfigureMessageServerTarget();
      ReconfigExistingLoggers();
    }

    /// <summary>
    /// Constructor with configuration
    /// </summary>
    /// <param name="config">configuration</param>
    public NLogFactoryImpl(NLogLoggingConfiguration config)
    {
      _originalConfiguration = config;
      Configuration = MergeConfig(CreateTargets(config), config);
      ConfigureMessageServerTarget();
      ReconfigExistingLoggers();
    }

    public void SetPolicy(INLogLoggerPolicy policy)
    {
      _loggerPolicy = policy ?? new NLogDefaultLoggerPolicy();
    }

    protected override void OnConfigurationChanged(LoggingConfigurationChangedEventArgs e)
    {
      base.OnConfigurationChanged(e);
      if (!(e.NewConfiguration is NLogLoggingConfiguration))
      {
        _originalConfiguration = e.NewConfiguration;
        if (_configuration!=null)
          ConfigureFactory(_configuration);
      }
    }

    internal  void ConfigureFactory(GAppLoggingOptions config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      config = config.Clone() as GAppLoggingOptions;  
      if (config == null)
        throw new ArgumentException("wrong config");
      lock (_syncObject)
      {
        var savedConfig = Configuration;
        var reloadedConfig = _originalConfiguration;
        if (!(savedConfig is NLogLoggingConfiguration))
        {
          reloadedConfig = savedConfig;
        }
        //if (ReferenceEquals(savedConfig, reloadedConfig))
        //  reloadedConfig = new NLogLoggingConfiguration(config);
        var createdConfig = CreateTargets(config);
        Configuration = MergeConfig(createdConfig, reloadedConfig);
        _configuration = config;
        ConfigureMessageServerTarget();
      }
      ReconfigExistingLoggers();
    }

    private void ConfigureMessageServerTarget()
    {
      foreach (Target target in Configuration.AllTargets)
      {
        var lmsTarget = target as NLogLmsTarget;
        if (lmsTarget==null) continue;
        lmsTarget.Factory = this;
      }
    }
    private static NLogLoggingConfiguration MergeConfig(NLogLoggingConfiguration newCfg, LoggingConfiguration baseCfg)
    {
      if (baseCfg != null)
      {
        foreach (Target target in baseCfg.AllTargets)
        {
          newCfg.AddTarget(target);
        }
        foreach (var rule in baseCfg.LoggingRules)
        {
          newCfg.LoggingRules.Add(rule);
        }
        foreach (KeyValuePair<string, SimpleLayout> pair in baseCfg.Variables)
        {
          newCfg.Variables.Add(pair.Key, pair.Value);
        }
      }
      return newCfg;
    }

    private static NLogLoggingConfiguration CreateTargets(NLogLoggingConfiguration configuration)
    {
      if (configuration==null)
        return new NLogLoggingConfiguration();
      return CreateTargets(configuration.LoggerConfiguration);
    }
    private static NLogLoggingConfiguration CreateTargets(IGLoggerConfiguration configuration)
    {
      var result = new NLogLoggingConfiguration(configuration);
      if (configuration!=null)
      foreach (TargetConfig target in configuration.Targets)
      {
        if (target.Verbose == VerboseLevel.None) continue;
        var minLevel = GetMinLogLevel(target.Verbose, configuration.Verbose);
        var maxLevel = GetMaxLogLevel(target.Verbose, configuration.Verbose);
        if (minLevel.Ordinal>maxLevel.Ordinal) continue;
        if (maxLevel == LogLevel.Off) continue;
        CreateTargetWithRules(result, configuration, target, minLevel, maxLevel);
      }
      return result;
    }

    private static void CreateTargetWithRules(NLogLoggingConfiguration addConfiguration,
      IGLoggerConfiguration configuration, TargetConfig target, LogLevel min, LogLevel max)
    {
      switch (target.Target)
      {
        case TargetConfig.TargetType.StdOut:
        {
          CreateConsoleTarget(addConfiguration, configuration, target, min, max);
          break; 
        }
        case TargetConfig.TargetType.StdErr:
        {
          CreateConsoleTarget(addConfiguration, configuration, target, min, max);
          break; 
        }
        case TargetConfig.TargetType.Memory:
        {
          CreateMemoryTarget(addConfiguration, configuration, min, max);
          break;
        }
        case TargetConfig.TargetType.FileLogger:
        {
          CreateFileTarget(addConfiguration, configuration, target, min, max);
          break;
        }
        case TargetConfig.TargetType.MessageServer:
        {
          CreateMessageServerTarget(addConfiguration, configuration, min, max);
          break;
        }
      }
    }

    private static void CreateConsoleTarget(NLogLoggingConfiguration addConfiguration,
      IGLoggerConfiguration configuration, TargetConfig target, LogLevel min, LogLevel max)
    {
      var layout = CreateLayout(configuration);
      foreach (Target nLogTarget in addConfiguration.AllTargets)
      {
        var conTarget = nLogTarget as ConsoleTarget;
        if (conTarget==null) continue;
        if (addConfiguration.LoggingRules.Count == 0)
        {
          conTarget.Layout = layout;
          addConfiguration.AddRule(min, max, nLogTarget,"*");
          return;
        }
        // ReSharper disable LoopCanBeConvertedToQuery
        foreach (LoggingRule rule in addConfiguration.LoggingRules)
        // ReSharper restore LoopCanBeConvertedToQuery
        {
          if ((!String.IsNullOrEmpty(rule.LoggerNamePattern)) && (rule.LoggerNamePattern != "*")) continue;
          if (!rule.Targets.Contains(nLogTarget)) continue;
          conTarget.Layout = layout;
          addConfiguration.AddRule(min, max, nLogTarget, "*");
          return;
        }
      }
      var logTarget = new ConsoleTarget(target.Target.ToString("F"))
      {
        Layout = layout
      };
      addConfiguration.AddTarget(logTarget);
      addConfiguration.AddRule(min, max, logTarget, "*");
    }
    private static void CreateMemoryTarget(NLogLoggingConfiguration addConfiguration,
      IGLoggerConfiguration configuration, LogLevel min, LogLevel max)
    {
      var layout = CreateLayout(configuration); 
      foreach (Target nLogTarget in addConfiguration.AllTargets)
      {
        var memoryTarget = nLogTarget as MemoryTarget;
        if (memoryTarget == null) continue;
        if (addConfiguration.LoggingRules.Count == 0)
        {
          memoryTarget.Layout = layout;
          addConfiguration.AddRule(min, max, nLogTarget, "*");
          return;
        }
        // ReSharper disable LoopCanBeConvertedToQuery
        foreach (LoggingRule rule in addConfiguration.LoggingRules)
        // ReSharper restore LoopCanBeConvertedToQuery
        {
          if ((!String.IsNullOrEmpty(rule.LoggerNamePattern)) && (rule.LoggerNamePattern != "*")) continue;
          if (!rule.Targets.Contains(nLogTarget)) continue;
          memoryTarget.Layout = layout;
          addConfiguration.AddRule(min, max, nLogTarget, "*");
          return;
        }
      }
      var logTarget = new MemoryQueueTarget("memoryQueue")
      {
        Layout = layout
      };
      addConfiguration.AddTarget(logTarget);
      addConfiguration.AddRule(min, max, logTarget, "*");
    }
    private static void CreateMessageServerTarget(NLogLoggingConfiguration addConfiguration,
      IGLoggerConfiguration configuration, LogLevel min, LogLevel max)
    {
      if (configuration.ApplicationConfiguration==null) return;
      var connections = configuration.ApplicationConfiguration.AppServers;
      if (connections==null) return;
      var server =
        connections.FirstOrDefault(
          connConfiguration =>
            connConfiguration.TargetServerConfiguration.ApplicationType == CfgAppType.CFGMessageServer);
      if (server==null) return;
      var serverInfo = server.TargetServerConfiguration.ServerInfo;
      if (serverInfo==null) return;
      if (serverInfo.Host == null) return;

      var layout = CreateLayout(configuration);
      var clientHost = configuration.ApplicationHost;
      if (string.IsNullOrEmpty(clientHost)) clientHost = serverInfo.Host.Name;
      if (string.IsNullOrEmpty(clientHost)) clientHost = Dns.GetHostName();
      var clientName = configuration.ApplicationName;
      if (string.IsNullOrEmpty(clientName)) 
        clientName = configuration.ApplicationConfiguration.ApplicationName;
      var logTarget = new NLogLmsTarget
      {
        Name = "messageServer."+configuration.ApplicationName,
        Layout = layout,
        Host = serverInfo.Host.IPAddress,
        Port = serverInfo.Port,
        ClientHost = clientHost,
        ClientName = clientName,
        ClientId = configuration.ApplicationId.ToString(CultureInfo.InvariantCulture),
        Timeout = configuration.MessageServerTimeout.ToString(CultureInfo.InvariantCulture),
        ClientType = configuration.ApplicationType.ToString(CultureInfo.InvariantCulture),
      };
      addConfiguration.AddTarget(logTarget);
      addConfiguration.AddRule(min, max, logTarget, "*");
    }

    private static string CreateLayout(IGLoggerConfiguration configuration)
    {
      var delimiter = MessageHeaderLayoutRenderer.GetDefaultMessageHeaderDelimiter(configuration);
      var layout = new StringBuilder(MessageHeaderLayoutRenderer.CreateConfig(configuration));
      if (configuration.EnableThread)
      {
        layout.Append(delimiter).Append("[${threadid}][${threadname}]");
      }
      layout.Append(delimiter).Append("${message}").Append(delimiter).Append("${exception}");
      if (configuration.StackTrace)
      {
        layout.Append(delimiter).Append(" ${stacktrace}");
      }
      return layout.ToString();
    }
    private static string CreateFileLayout(IGLoggerConfiguration configuration)
    {
      var delimiter = MessageHeaderLayoutRenderer.GetDefaultMessageHeaderDelimiter(configuration);
      var layout = new StringBuilder(MessageHeaderLayoutRenderer.CreateConfig(configuration));
      if (configuration.EnableThread)
      {
        layout.Append(delimiter).Append("[${threadid}][${threadname}]");
      }
      layout.Append(delimiter).Append("${message}");
      if (configuration.StackTrace)
      {
        layout.Append(delimiter).Append(" ${stacktrace}");
      }
      return layout.ToString();
    }
    private static void CreateFileTarget(NLogLoggingConfiguration addConfiguration,
      IGLoggerConfiguration configuration, TargetConfig target, LogLevel min, LogLevel max)
    {
      var tcFile = target as FileTargetConfig;
      if (tcFile==null) return;
      var layout = CreateFileLayout(configuration);
      foreach (Target nLogTarget in addConfiguration.AllTargets)
      {
        var fileTarget = nLogTarget as FileTarget;
        if (fileTarget == null) continue;
        var fName = fileTarget.FileName as SimpleLayout;
        if (fName==null) continue;
        if (!fName.OriginalText.Equals(tcFile.FileName, StringComparison.InvariantCultureIgnoreCase)) continue;
        if (addConfiguration.LoggingRules.Count == 0)
        {
          fileTarget.Layout = layout;
          addConfiguration.AddRule(min, max, nLogTarget, "*");
          return;
        }
// ReSharper disable LoopCanBeConvertedToQuery
        foreach (LoggingRule rule in addConfiguration.LoggingRules)
// ReSharper restore LoopCanBeConvertedToQuery
        {
          if ((!String.IsNullOrEmpty(rule.LoggerNamePattern)) && (rule.LoggerNamePattern != "*")) continue;
          if (!rule.Targets.Contains(nLogTarget)) continue;
          addConfiguration.AddRule(min, max, nLogTarget, "*");
          return;
        }
      }
      var fTarget = new FileTargetEx("fileTarget" + target.Verbose.ToString("F").ToUpper())
      {
        FileName = tcFile.FileName,
        Layout = layout,
        DeleteOldFileOnStartup = configuration.DeleteArchiveFiles,
        ArchiveOldFileOnStartup = true,
        NLogConfiguration = addConfiguration
      };
      var fname = tcFile.FileName;
      var dir = Path.GetDirectoryName(fname);
      var arcDirName = PsdkCustomization.LogFactory.LogArchivesPath.Value;
      if (String.IsNullOrEmpty(arcDirName)) arcDirName = "./archives";
      if (!Path.IsPathRooted(arcDirName))
      {

        dir = (String.IsNullOrEmpty(dir)) ? arcDirName : dir+"/" + arcDirName;
      }
      var ext = Path.GetExtension(fname);
      fname = Path.GetFileName(fname);
      if (!String.IsNullOrEmpty(fname) && !String.IsNullOrEmpty(ext)) fname = fname.Replace(ext,"");
      fTarget.ArchiveFileName = dir + Path.DirectorySeparatorChar + fname + ".{#}" + ext;
      if (configuration.Buffering)
      {
        fTarget.BufferSize = 32*1024;
      }
      else
      {
        fTarget.AutoFlush = true;
      }
      var segmentation = configuration.Segmentation;
      switch (segmentation.Strategy)
      {
        case SegmentationConfig.SegmentationStrategy.SizeKb:
        {
          fTarget.ArchiveNumbering= ArchiveNumberingMode.Rolling;
          fTarget.ArchiveAboveSize = segmentation.Segment * 1024;
          break;
        }
        case SegmentationConfig.SegmentationStrategy.SizeMb:
        {
          fTarget.ArchiveNumbering = ArchiveNumberingMode.Rolling;
          fTarget.ArchiveAboveSize = segmentation.Segment * 1024 * 1024;
          break;
        }
        case SegmentationConfig.SegmentationStrategy.TimeBased:
        {
          fTarget.ArchiveNumbering = ArchiveNumberingMode.Rolling;
          fTarget.ArchiveEvery = FileArchivePeriod.Hour;
          break;
        }
        default:
        {
          break;
        }
      }
      var expiration = configuration.Expiration;
      switch (expiration.Strategy)
      {
        case ExpirationConfig.ExpirationStrategy.NumberOfFiles:
        {
          fTarget.EnableFileDelete = true;
          fTarget.MaxArchiveFiles = expiration.Expire;
          break;
        }
        case ExpirationConfig.ExpirationStrategy.TimeBased:
        {
          fTarget.EnableFileDelete = true;
          fTarget.ArchiveDirectoryCheckName = dir;
          fTarget.ArchiveFileNamePattern = fname + ".(\\d{1,})" + ext;
          fTarget.MaxArchiveFiles = 0;
          fTarget.ExpirationHours = expiration.Expire;
          break;
        }
        default:
        {
          break;
        }
      }
      addConfiguration.AddTarget(fTarget);
      addConfiguration.AddRule(min, max, fTarget, "*");
    }

    private static LogLevel GetMinLogLevel(VerboseLevel level, VerboseLevel levelCommon)
    {
      if (levelCommon == VerboseLevel.None) return LogLevel.Off;
      if (levelCommon == VerboseLevel.All)
      {
        if (level == VerboseLevel.All) return LogLevel.Debug;
        return GetLogLevel(level);
      }
      if (level == VerboseLevel.All) return GetLogLevel(levelCommon);
      var level1 = GetLogLevel(level);
      var level2 = GetLogLevel(levelCommon);
      return (level1.Ordinal > level2.Ordinal) ? level1 : level2;
    }
    private static LogLevel GetMaxLogLevel(VerboseLevel level, VerboseLevel levelCommon)
    {
      if (levelCommon == VerboseLevel.None) return LogLevel.Off;
      if (level == VerboseLevel.All)
      {
        return LogLevel.Fatal;
      }
      return GetLogLevel(level);
    }
    internal static LogLevel GetLogLevel(VerboseLevel level)
    {
      switch (level)
      {
          case VerboseLevel.All: return LogLevel.FromOrdinal(0);
          case VerboseLevel.Debug: return LogLevel.FromOrdinal(1);
          case VerboseLevel.Trace: return LogLevel.FromOrdinal(2);
          case VerboseLevel.Interaction: return LogLevel.FromOrdinal(3);
          case VerboseLevel.Standard: return LogLevel.FromOrdinal(4);
          case VerboseLevel.Alarm: return LogLevel.FromOrdinal(5);
          default: return LogLevel.FromOrdinal(6);
      }
    }

    private static volatile bool _isRegistered;
    internal static void RegisterStructures()
    {
      if (_isRegistered) return;
      lock (typeof (NLogLoggerFactory))
      {
        if (_isRegistered) return;
        Target.Register<NLogLmsTarget>("MessageServer");
        Target.Register<MemoryQueueTarget>("MemoryQueue");
        LayoutRenderer.Register<MessageHeaderLayoutRenderer>("MessageHeader");
        _isRegistered = true;
      }
    }
    static NLogFactoryImpl()
    {
      RegisterStructures();
    }
    /// <exclude/>
    public ILogger GetNullLogger()
    {
      return new NLogLoggerImpl("null", CreateNullLogger());
    }
    /// <exclude/>
    public new ILogger GetLogger(string name)
    {
      return new NLogLoggerImpl(name, base.GetLogger(name));
    }
    /// <exclude/>
    public ILmsEventLogger CreateLmsLogger(string name, LmsMessageConveyor lmsMessageConveyor)
    {
      return new LmsMessageLogger(lmsMessageConveyor, name, base.GetLogger(name));
    }
    public ILmsEventLogger CreateNullLmsLogger(LmsMessageConveyor lmsMessageConveyor)
    {
      return new NullLmsLogger();
    }
    public void Configure(GAppLoggingOptions config)
    {
      ConfigureFactory(config);
    }
  }
}

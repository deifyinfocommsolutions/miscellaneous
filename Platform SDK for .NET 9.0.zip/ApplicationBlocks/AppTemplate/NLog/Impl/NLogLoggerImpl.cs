//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using Genesyslab.Configuration;
using Genesyslab.Platform.AppTemplate.Logger;
using NLog;
using NLog.Targets;
using ILogger = Genesyslab.Platform.Commons.Logging.ILogger;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl
{
  /// <summary>
  /// Extends existing <see cref="ILogger"/> interface in order to have access 
  /// to memory logs
  /// </summary>
  public interface INLogLogger:ILogger
  {
    /// <summary>
    /// returns memory logs of default target 'memory'
    /// </summary>
    /// <returns>list of memory logs</returns>
    IList<string> MemoryLogs();
    /// <summary>
    /// returns memory logs of default target 'memory'
    /// </summary>
    /// <param name="name">name of memory target</param>
    /// <returns>list of memory logs</returns>
    IList<string> MemoryLogs(string name);
    /// <summary>
    /// Clears all memory logs data
    /// </summary>
    void ClearMemoryLogs();
    /// <summary>
    /// Clears all memory logs data for named target
    /// </summary>
    /// <param name="name">target name</param>
    void ClearMemoryLogs(string name);
  }

  /// <summary>
  /// Bridge class between <see cref="Commons.Logging.ILogger"/> and <see cref="NLog.Logger"/>
  /// </summary>
  internal class NLogLoggerImpl : INLogLogger
  {
    private readonly NLog.Logger _logger;
    private readonly string _name;

    internal NLogLoggerImpl(string name, NLog.Logger logger)
    {
      if (logger == null) throw new ArgumentNullException("logger");
      _name = name??String.Empty;
      _logger = logger;
    }

    private LogEventInfoEx CreateLogEvent(LogLevel logLevel, string message)
    {
// ReSharper disable IntroduceOptionalParameters.Local
      return CreateLogEvent(logLevel, message, null);
// ReSharper restore IntroduceOptionalParameters.Local
    }

    private readonly INLogLoggerPolicy _defaultPolicy = new NLogDefaultLoggerPolicy();

    protected string Name { get { return _logger.Name; } }
    protected NLogLoggingConfiguration Configuration
    {
      get { return _logger.Factory.Configuration as NLogLoggingConfiguration; }
    }
    protected INLogLoggerPolicy Policy
    {
      get
      {
        return ((_logger.Factory is NLogAdapter.Logger.Impl.NLogFactoryImpl)
          ? ((NLogAdapter.Logger.Impl.NLogFactoryImpl) _logger.Factory).LoggerPolicy
          : _defaultPolicy) 
          ?? _defaultPolicy;
      }
    }

    protected T GetFactory<T>() where T:LogFactory
    {
      return _logger.Factory as T; 
    }
    protected LogEventInfoEx CreateLogEvent(LogLevel logLevel, string message, Exception exception)
    {
      var result = new LogEventInfoEx
      {
        Message = message,
        Level = logLevel,
        LoggerName = Name,
        Exception = exception,
        Configuration = Configuration,
        LoggerPolicy = Policy,
        ID = Policy.GetEntryId(LogEventInfoEx.GetLogLevel(logLevel), message)
      };
      result.Category = result.LoggerPolicy.GetCategoty(message);
      result.ProcessLevelReassignment();
      return result;
    }

    protected virtual void LogEvent(LogEventInfoEx eventInfo)
    {
      if (eventInfo!=null)
        _logger.Log(eventInfo);
    }

    
    public void Debug(object message)
    {
      LogEvent(CreateLogEvent(LogLevel.Debug, message == null ? "" : message.ToString()));
    }

    public void Debug(object message, Exception exception)
    {
      LogEvent(CreateLogEvent(LogLevel.Debug, message == null ? "" : message.ToString(), exception));
    }

    public void DebugFormat(string format, params object[] args)
    {
      string message = String.Format(format, args);
      LogEvent(CreateLogEvent(LogLevel.Debug, message));
    }



    public bool IsDebugEnabled { get { return _logger.IsDebugEnabled; }}
    public void Info(object message)
    {
      LogEvent(CreateLogEvent(LogLevel.Info, message == null ? "" : message.ToString()));
    }

    public void Info(object message, Exception exception)
    {
      LogEvent(CreateLogEvent(LogLevel.Info, message == null ? "" : message.ToString(), exception));
    }

    public void InfoFormat(string format, params object[] args)
    {
      string message = String.Format(format, args);
      LogEvent(CreateLogEvent(LogLevel.Info, message));
    }

    public bool IsInfoEnabled { get { return _logger.IsInfoEnabled; } }
    public void Warn(object message)
    {
      LogEvent(CreateLogEvent(LogLevel.Warn, message == null ? "" : message.ToString()));
    }

    public void Warn(object message, Exception exception)
    {
      LogEvent(CreateLogEvent(LogLevel.Warn, message == null ? "" : message.ToString(), exception));
    }

    public void WarnFormat(string format, params object[] args)
    {
      string message = String.Format(format, args);
      LogEvent(CreateLogEvent(LogLevel.Warn, message));
    }

    public bool IsWarnEnabled { get { return _logger.IsWarnEnabled; } }
    public void Error(object message)
    {
      LogEvent(CreateLogEvent(LogLevel.Error, message == null ? "" : message.ToString()));
    }

    public void Error(object message, Exception exception)
    {
      LogEvent(CreateLogEvent(LogLevel.Error, message == null ? "" : message.ToString(), exception));
    }

    public void ErrorFormat(string format, params object[] args)
    {
      string message = String.Format(format, args);
      LogEvent(CreateLogEvent(LogLevel.Error, message));
    }

    public bool IsErrorEnabled { get { return _logger.IsErrorEnabled; } }
    public void FatalError(object message)
    {
      LogEvent(CreateLogEvent(LogLevel.Fatal, message == null ? "" : message.ToString()));
    }

    public void FatalError(object message, Exception exception)
    {
      LogEvent(CreateLogEvent(LogLevel.Fatal, message == null ? "" : message.ToString(), exception));
    }

    public void FatalErrorFormat(string format, params object[] args)
    {
      string message = String.Format(format, args);
      LogEvent(CreateLogEvent(LogLevel.Fatal, message));
    }

    public bool IsFatalErrorEnabled { get { return _logger.IsFatalEnabled; } }

    /// <exclude/>
    public ILogger CreateChildLogger(string name)
    {
      if (PsdkCustomization.CustomOption("NLogLogger.ConcatNames", true)) name = _name + "." + name;
      return NLogLoggerFactory.GetLogger(name) ?? this;
    }

    public IList<string> MemoryLogs()
    {
// ReSharper disable IntroduceOptionalParameters.Local
      return MemoryLogs("memory")??MemoryLogs("memoryQueue");
// ReSharper restore IntroduceOptionalParameters.Local
    }
    public IList<string> MemoryLogs(string name)
    {
// ReSharper disable LoopCanBeConvertedToQuery
      foreach (Target target in _logger.Factory.Configuration.AllTargets)
// ReSharper restore LoopCanBeConvertedToQuery
      {
        if (!target.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase)) continue;
        var memTarget = target as MemoryTarget;
        if (memTarget != null)
        {
          var list = memTarget.Logs;
          if (list == null) continue;
          return new List<string>(list);
        }
        var memQ = target as MemoryQueueTarget;
        if (memQ != null) return memQ.Logs;
      }
      return null;
    }

    public void ClearMemoryLogs()
    {
      // ReSharper disable LoopCanBeConvertedToQuery
      foreach (Target target in _logger.Factory.Configuration.AllTargets)
      // ReSharper restore LoopCanBeConvertedToQuery
      {
        var memTarget = target as MemoryTarget;
        if (memTarget != null)
        {
          var list = memTarget.Logs;
          if (list != null) list.Clear();
        }
        var memQ = target as MemoryQueueTarget;
        if (memQ!=null) memQ.Clear();
      }
    }
    public void ClearMemoryLogs(string name)
    {
      // ReSharper disable LoopCanBeConvertedToQuery
      foreach (Target target in _logger.Factory.Configuration.AllTargets)
      // ReSharper restore LoopCanBeConvertedToQuery
      {
        if (!target.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase)) continue;
        var memTarget = target as MemoryTarget;
        if (memTarget != null)
        {
          var list = memTarget.Logs;
          if (list != null) list.Clear();
        }
        var memQ = target as MemoryQueueTarget;
        if (memQ != null) memQ.Clear();
      }
    }
  }
}

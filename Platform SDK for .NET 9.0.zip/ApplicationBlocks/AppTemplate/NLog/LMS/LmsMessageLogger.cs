//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Linq;
using Genesyslab.Platform.AppTemplate.Logger.LMS;
using Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl;
using NLog;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.LMS
{
  /// <summary>
  /// Abstract base implementation of LMS logger.
  /// </summary>
  internal class LmsMessageLogger:NLogLoggerImpl, ILmsEventLogger
  {
    private readonly LmsMessageConveyor _messageConveyor;
    /// <exclude/>
    public LmsMessageLogger(LmsMessageConveyor messageConveyor, string name, NLog.Logger logger)
      : base(name, logger)
    {
      if (messageConveyor == null) throw new ArgumentNullException("messageConveyor");
      _messageConveyor = messageConveyor;
      IsSilent = GetFactory<LogFactory>().Configuration.AllTargets.FirstOrDefault(target => target is NLogLmsTarget) == null;
    }
    protected LogEventInfoEx CreateLogEvent(LogLevel level, LmsLogCategory? category, LmsMessageTemplate key, params object[] args)
    {
      var result = new LogEventInfoEx
      {
        Message = key.GetFormatted(args),
        LoggerName = Name,
        Configuration = Configuration,
        LoggerPolicy = Policy,
        ID = key.Id,
      };
      if (level == null)
      {
        result.LoggingLevel = key.Level;
      }
      else
      {
        result.Level = level;
      }
      if (category == null) category = Policy.GetCategoty(result.Message);
      result.SetCategory(category);
      result.ProcessLevelReassignment();
      if (result.Level == null)
      {
        if (result.LoggingLevel != null)
          result.Level = LogEventInfoEx.GetLogLevel(result.LoggingLevel.Value);
      }
      return result;
    }
    protected LogEventInfoEx CreateLogEvent(LogLevel level, LmsLogCategory? category, int keyCode, params object[] args)
    {
      var key = _messageConveyor.GetMsgTemplate(keyCode);
      if (key == null) 
        throw new LmsTemplateNotFoundException("Template with id="+keyCode+" is not found.");
      return CreateLogEvent(level, category, key, args);
    }

    public bool IsSilent { get; private set; }

    public void Log(LmsLogCategory category, LmsMessageTemplate key, params object[] args)
    {
      if (key == null) throw new ArgumentNullException("key");
      LogEvent(CreateLogEvent(null, category, key, args));
    }

    public void Log(LmsLogCategory category, int key, params object[] args)
    {
      LogEvent(CreateLogEvent(null, category, key, args));
    }

    public void Log(LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(null, null, key, args));
    }

    public void Log(int key, params object[] args)
    {
      LogEvent(CreateLogEvent(null, null, key, args));
    }

    public void Debug(LmsLogCategory category, LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Debug, category, key, args));
    }

    public void Debug(LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Debug, null, key, args));
    }

    public void Info(LmsLogCategory category, LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Info, category, key, args));
    }

    public void Info(LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Info, null, key, args));
    }

    public void Warn(LmsLogCategory category, LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Warn, category, key, args));
    }

    public void Warn(LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Warn, null, key, args));
    }

    public void Error(LmsLogCategory category, LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Error, category, key, args));
    }

    public void Error(LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Error, null, key, args));
    }

    public void Fatal(LmsLogCategory category, LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Fatal, category, key, args));
    }

    public void Fatal(LmsMessageTemplate key, params object[] args)
    {
      LogEvent(CreateLogEvent(LogLevel.Fatal, null, key, args));
    }
  }
}

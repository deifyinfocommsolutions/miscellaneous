//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

#if DEBUG
#endif
using System;
using System.Globalization;
using System.IO;
using System.Threading;
using Genesyslab.Configuration;
using Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Management.Protocols;
using Genesyslab.Platform.Management.Protocols.MessageServer;
using Genesyslab.Platform.Management.Protocols.MessageServer.Requests;
using Genesyslab.Platform.Standby;
using NLog;
using NLog.Config;
using NLog.Targets;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.LMS
{

  /// <summary>
  /// Custom target to write messages into message server.
  /// </summary>
  [Target("MessageServer")]
  public sealed class NLogLmsTarget:TargetWithLayout
  {
    private volatile static StringWriter _duplicateWriterDestination;
    private volatile static bool _duplicateImmediately;
    private string _host;
    private int? _port;
    private int? _timeOut;
    private int? _clientId;
    private int? _clientType;
    private string _clientName;
    private string _clientHost;
    private readonly object _syncObj = new object();
    private readonly FixedSizeQueue<LogEventInfo> _eventQueue;
    private MessageServerProtocol _messageServer;
    private volatile WarmStandby _warmStandby;
    internal NLogFactoryImpl Factory;


    /// <summary>
    /// Use for testing golas.
    /// Sets duplicate output source.
    /// </summary>
    /// <param name="writer"><see cref="StringWriter"/> instance to write log's copy.</param>
    /// <param name="immediately">Set this parameter to true to write log's copy at the moment of writing it by application.<br/>
    /// Set this parameter to false to write log's copy at the moment of writing it to message server.</param>
    public static void SetDuplicateDestination(StringWriter writer, bool immediately)
    {
      StringWriter existing;
      lock (typeof (NLogLmsTarget))
      {
        existing = _duplicateWriterDestination;
        _duplicateWriterDestination = writer;
        _duplicateImmediately = immediately;
      }
      if (existing!=null) existing.Close();
    }

    /// <summary>
    /// Host of message server
    /// </summary>
    [RequiredParameter]
    public string Host { 
      get { return _host; }
      set
      {
         if (String.Equals(value, _host, StringComparison.InvariantCultureIgnoreCase)) return;
        _host = value;
        UpdateServerAddress();
      }
    }
    /// <summary>
    /// Client name
    /// </summary>
    public string ClientName
    {
      get { return _clientName; }
      set
      {
        if (String.Equals(value, _clientName, StringComparison.InvariantCultureIgnoreCase)) return;
        _clientName = value;
        lock (_syncObj)
        {
          if (_messageServer != null)
            _messageServer.ClientName = _clientName;
        }
      }
    }
    /// <summary>
    /// Client name
    /// </summary>
    public string ClientHost
    {
      get { return _clientHost; }
      set
      {
        if (String.Equals(value, _clientHost, StringComparison.InvariantCultureIgnoreCase)) return;
        _clientHost = value;
        lock (_syncObj)
        {
          if (_messageServer != null)
            _messageServer.ClientHost = _clientHost;
        }
      }
    }
    /// <summary>
    /// ClientId
    /// </summary>
    public string ClientType
    {
      get { return _clientType == null ? null : _clientType.Value.ToString(CultureInfo.InvariantCulture); }
      set
      {
        int res;
        if (!Int32.TryParse(value, out res))
          throw new ArgumentException("Client Id value cannot be parsed into integer value");
        _clientType = res;
        lock (_syncObj)
        {
          if (_messageServer != null)
            _messageServer.ClientType = res;
        }
      }
    }
    /// <summary>
    /// ClientId
    /// </summary>
    public string ClientId {
      get { return _clientId == null ? null : _clientId.Value.ToString(CultureInfo.InvariantCulture); }
      set
      {
        int res;
        if (!Int32.TryParse(value, out res))
          throw new ArgumentException("Client Id value cannot be parsed into integer value");
        _clientId = res;
        lock (_syncObj)
        {
          if (_messageServer != null)
            _messageServer.ClientId = res;
        }
      }
    }
    /// <summary>
    /// Port of message server
    /// </summary>
    [RequiredParameter]
    public string Port
    {
      get { return _port == null ? null : _port.Value.ToString(CultureInfo.InvariantCulture); }
      set
      {
        int res;
        if (!Int32.TryParse(value, out res))
          throw new ArgumentException("Port value cannot be parsed into integer value");
        if ((_port!=null) && (_port.Value==res)) return;
        _port = res;
        UpdateServerAddress();
      }
    }
    /// <summary>
    /// Timeout of message server
    /// </summary>
    public string Timeout
    {
      get { return _timeOut == null ? null : _timeOut.Value.ToString(CultureInfo.InvariantCulture); }
      set
      {
        int res;
        if (!Int32.TryParse(value, out res))
          throw new ArgumentException("Timeout value cannot be parsed into integer value");
        if (res<=0)
          throw new ArgumentException("Timeout value cannot be equal or less zero");
        if ((_timeOut != null) && (_timeOut.Value == res)) return;
        _timeOut = res;
        var client = _messageServer;
        if (client != null)
          client.Timeout = TimeSpan.FromSeconds(res);
      }
    }
    /// <summary>
    /// Limit of message queue
    /// </summary>
    public string QueueSize
    {
      get { return _eventQueue.Limit.ToString(CultureInfo.InvariantCulture); }
      set
      {
        int res;
        if (!Int32.TryParse(value, out res))
          throw new ArgumentException("Messages queue 'QueueSize' value cannot be parsed into integer value");
        _eventQueue.Limit = Math.Max(res, 32);
      }
    }
    /// <summary>
    /// Default constructor
    /// </summary>
    public NLogLmsTarget()
    {
      _eventQueue = new FixedSizeQueue<LogEventInfo>(
          PsdkCustomization.LogFactory.MessageServerInitialQueueLimit.Value,
          PsdkCustomization.LogFactory.MessageServerEnableUnlimitedQueue.Value);
    }

    private volatile bool _isClosed;
    protected override void CloseTarget()
    {
      if (_isClosed) return;
      lock (_syncObj)
      {
        if (_isClosed) return;
        var ws = _warmStandby;
        _warmStandby = null;
        if (ws != null) ws.Close();
        base.CloseTarget();
        _isClosed = true;
      }
    }

    ~NLogLmsTarget()
    {
      CloseTarget();
    }

#if DEBUG
    private int _countBusyChannelEvents;
#endif

    private void ProcessSendMessage()
    {
      var channel = _messageServer as IManagedOutputChannel;
      if (channel != null)
      {
        if (channel.IsOutputBufferEmpty)
        {
          SendMessage();
        }
#if DEBUG
        else
        {
          DuplicateOutput(String.Format("Channel is busy: {0}, queue size: {1}",
            Interlocked.Increment(ref _countBusyChannelEvents), _eventQueue.Count));
        }
#endif
      }
    }

    //internal void Log(Management.Protocols.MessageServer.LogLevel level, LogCategory? category, LmsMsgTemplate template, params object[] args)
    //{
    //  if (template==null) return;
    //  var entry = new LogEventInfoEx
    //  {
    //    Message = String.Format(template.Format, args),
    //    LoggingLevel = level,
    //    Configuration = LoggingConfiguration as NLogLoggingConfiguration,
    //    ID = template.Id,
    //  };
    //  if (category != null)
    //    entry.Category = category.Value;
    //  Write(entry);
    //}
    protected override void Write(LogEventInfo logEvent)
    {
      _eventQueue.Enqueue(logEvent);
      AsyncConnectServer();
      ProcessSendMessage();
      if (_duplicateImmediately)
        DuplicateOutput(logEvent);
    }

    private void DuplicateOutput(LogEventInfo logEvent)
    {
      var destination = _duplicateWriterDestination;
      if (destination!=null) 
        destination.WriteLine(Layout.Render(logEvent));
    }
#if DEBUG
    private void DuplicateOutput(string data)
    {
      var destination = _duplicateWriterDestination;
      if (destination == null) return;
      destination.WriteLine(DateTime.Now.ToString("HH:mm:ss.fffff")+" | "+data);
    }
#endif
    private void UpdateServerAddress()
    {
      lock (_syncObj)
      {
        if (_warmStandby==null) return;
        if (_port != null)
          _warmStandby.Configuration.SetEndpoints(new Endpoint(_host, _port.Value));
      }
    }
    private static RequestLogMessage CreateRequestLogMessage(LogEventInfoEx entry, string clientHost)
    {
      RequestLogMessage reqLogMessage = RequestLogMessage.Create();
      reqLogMessage.Level = (Management.Protocols.MessageServer.LogLevel)(int)entry.GetLogLevel(); //
      reqLogMessage.EntryId = entry.ID; //
      reqLogMessage.EntryText = entry.Message; // R E Q U I R E D
      reqLogMessage.Time = entry.TimeStamp; //
      reqLogMessage.EntryCategory = (LogCategory)(int)entry.Category; // all fields are 
      reqLogMessage.ClientHost = clientHost;
      if (entry.Attributes != null && entry.Attributes.Count > 0)
        reqLogMessage.Attributes = entry.Attributes;
      return reqLogMessage;
    }

    private bool WriteEntry(LogEventInfo logEvent)
    {
      try
      {
        var request = CreateRequestLogMessage(logEvent as LogEventInfoEx, _clientHost);
        _messageServer.Send(request);
        if (!_duplicateImmediately)
          DuplicateOutput(logEvent);
      }
      catch (ChannelClosedOnSendException)
      {
        return false;
      }
      return true;
    }
    private void SendMessageEvent(object sender, EventArgs args)
    {
      ProcessSendMessage();
    }
    private void SendMessage()
    {
      lock (_eventQueue.SyncRoot)
      {
        var entry = _eventQueue.Peek();
        if (entry == null) return;
        if (WriteEntry(entry))
        {
          _eventQueue.Dequeue();
        }
      }
    }

    private void AsyncConnectServer()
    {
      if (_warmStandby!=null) return;
      lock (_syncObj)
      {
        if (_warmStandby != null) return;
        try
        {
          if (_port==null) return;
          _messageServer = new MessageServerProtocol
          {
            ClientHost = _clientHost,
            ClientName = _clientName,
          };
          if (_timeOut != null) _messageServer.Timeout = TimeSpan.FromSeconds(_timeOut.Value);
          if (_clientId != null) _messageServer.ClientId = _clientId.Value;
          if (_clientType != null) _messageServer.ClientType = _clientType.Value;
          (_messageServer as IManagedOutputChannel).SetOnEmptyWritePointHandler(SendMessageEvent);
          _warmStandby = new WarmStandby(_messageServer, new Endpoint(_host, _port.Value));
          _warmStandby.ChannelOpened +=  SendMessageEvent;
          _warmStandby.AutoRestore(true);
        }
        catch (Exception){}
      }
    }
  }
}

﻿using Genesyslab.Platform.AppTemplate.Logger;
using Genesyslab.Platform.AppTemplate.Logger.LMS;

namespace Genesyslab.Platform.AppTemplate.NLogAdapter.Logger
{
  /// <summary>
  /// Default implementation of <see cref="INLogLoggerPolicy"/> interface.
  /// </summary>
  public class NLogDefaultLoggerPolicy : INLogLoggerPolicy
  {
    private readonly int _defaultEntryId;
    private readonly LmsLogCategory _defaultCategory;
    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="defaultEntryId">Default message entry ID</param>
    /// <param name="defaultCategory">Default message category</param>
    public NLogDefaultLoggerPolicy(int defaultEntryId, LmsLogCategory defaultCategory)
    {
      _defaultEntryId = defaultEntryId;
      _defaultCategory = defaultCategory;
    }
    /// <summary>
    /// Default constructor.
    /// </summary>
    public NLogDefaultLoggerPolicy():this(9900,LmsLogCategory.Default){}
    public int GetEntryId(LmsLogLevel level, string message)
    {
      return _defaultEntryId;
    }

    public LmsLogCategory GetCategoty(string message)
    {
      return _defaultCategory;
    }
  }
}
//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.AppTemplate.Logger.LMS;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.AppTemplate.Application
{
  /// <summary>
  /// Abstract base class for application configuration manager builders.
  /// It is to share building logic between manager builders.<b/>
  /// Each specific configuration manager class contains own extension of this builder with
  /// required logic for particular manager creation and configuration.
  /// </summary>
  /// <seealso cref="GFApplicationConfigurationManager.Builder"/>
  /// <typeparam name="TBuilder">Type of application configuration builder</typeparam>
  /// <typeparam name="TCfgManager">Type of application configuration manager</typeparam>
  public abstract class AbstractManagerBuilder<TCfgManager , TBuilder>
    where TCfgManager : GFApplicationConfigurationManager
    where TBuilder : AbstractManagerBuilder<TCfgManager, TBuilder>
  {
    /// <summary>
    /// Reference to <see cref="IConfService"/> instcance.
    /// </summary>
    protected IConfService ConfService;
    /// <summary>
    /// List of <see cref="Endpoint"/>.
    /// </summary>
    protected readonly List<Endpoint> CsEndpoints = new List<Endpoint>();
    /// <summary>
    /// The client name. Information for handshake procedure.
    /// </summary>
    protected String ClientName;
    /// <summary>
    /// The client application type. Information for handshake procedure.
    /// </summary>
    protected CfgAppType? ClientType;
    /// <summary>
    /// The user name. Information for handshake procedure.
    /// </summary>
    protected String Username;
    /// <summary>
    /// The password. Information for handshake procedure.
    /// </summary>
    protected String Password;
    /// <exclude/>
    protected bool? DisableSessionUsage;
    /// <exclude/>
    protected bool? DoCSSubscription;
    /// <exclude/>
    protected bool? UseWarmStandby;
    /// <exclude/>
    protected WSConfig WsConfig;
    /// <exclude/>
    protected LmsMessageConveyor LmsConveyor = null;
    /// <exclude/>
    protected bool? ReadTenantsInfo;

    /// <exclude/>
    public TBuilder WithLmsConveyor(LmsMessageConveyor lms)
    {
        LmsConveyor = lms;
        return (TBuilder) this;
    }

    /// <exclude/>
    public TBuilder WithConfService(IConfService confService) {
        if (CsEndpoints.Count > 0 || WsConfig != null) {
            throw new ArgumentException(
                  "GFApplicationConfigurationManager Builder can't use ConfService and Endpoint at the same time");
        }

        if (confService == null) {
            throw new ArgumentException("IConfService is null");
        }

        var protocol = confService.Protocol as ConfServerProtocol;
        if (protocol ==null) {
            throw new ArgumentException("No ConfServerProtocol in the IConfService");
        }

        String applicationName = protocol.ClientName;

        if (String.IsNullOrEmpty(applicationName)) {
            throw new ArgumentException("No client application name provided");
        }

        ConfService = confService;
        ClientName = applicationName;

        return (TBuilder) this;
    }
    /// <exclude/>
    public TBuilder WithCSEndpoint(Endpoint endpoint) {
        if (ConfService != null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager Builder can't use ConfService and Endpoint at the same time");
        }
        CsEndpoints.Add(endpoint);
        return (TBuilder)this;
    }
    /// <exclude/>
    public TBuilder WithClientId(
            CfgAppType clientType,
            String     clientName) {
        if (ConfService != null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager Builder with ConfService initialized "
                    + "does not accept client registration parameters");
        }
        ClientType = clientType;
        ClientName = clientName;
        return (TBuilder)this;
    }
    /// <exclude/>
    public TBuilder WithUserId(String username,String passwd)
    {
        if (ConfService != null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager Builder with ConfService initialized "
                    + "does not accept client registration parameters");
        }
        Username = username;
        Password = passwd;
        return (TBuilder) this;
    }
    /// <exclude/>
    public TBuilder WithSessionDisabled(bool disableSession) {
        if (ConfService != null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager Builder with ConfService initialized "
                    + "does not manage protocol connection");
        }
        DisableSessionUsage = disableSession;
        return (TBuilder) this;
    }
    /// <exclude/>
    public TBuilder WithDoCSSubscription(bool doSubscription) {
        DoCSSubscription = doSubscription;
        return (TBuilder) this;
    }
    /// <exclude/>
    public TBuilder WithTenantsInfoReading(bool readTenantsInfo)
    {
      ReadTenantsInfo = readTenantsInfo;
      return (TBuilder)this;
    }
    /// <exclude/>
    public TBuilder WithWarmStandbyEnabled(bool enableWS) {
        if (ConfService != null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager Builder with ConfService initialized "
                    + "does not manage protocol connection");
        }
        UseWarmStandby = enableWS;
        return (TBuilder) this;
    }
    /// <exclude/>
    public TBuilder WithWarmStandby(
            WSConfig wsConfig) {
        if (ConfService != null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager Builder can't use ConfService and WarmStandby at the same time");
        }
        WsConfig = wsConfig;
        return (TBuilder) this;
    }

    /// <exclude/>
    protected void CheckRequiredParameters() {
        if (ConfService == null && CsEndpoints.Count == 0 && WsConfig == null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager.Builder: no required parameters given "
                    + "('ConfService', 'WSConfig', or 'CSEndpoint' must be provided)");
        }

        if (ConfService == null) {
            if (String.IsNullOrEmpty(ClientName)) {
                throw new ArgumentException("ClientName is required for ConfService initialization");
            }
            if (ClientType == null) {
                throw new ArgumentException("ClientType is required for ConfService initialization");
            }
        }
        if (LmsConveyor==null)
          LmsConveyor = new LmsMessageConveyor();
    }
    /// <exclude/>
    protected virtual GFApplicationConfigurationManager SetupContext(GFApplicationConfigurationManager manager) 
    {
        //if (DoLoggingAutoconfig != null && DoLoggingAutoconfig) {
        //    if (Log4J2Checker.isAvailable() && Log4J2Checker.isCoreAvailable()) {
        //        manager.Register(new GFAppLog4j2Updater());
        //    } else {
        //        throw new ArgumentException(
        //                "Can't initialize LoggingAutoconfig - no Log4j2 available");
        //    }
        //}
        manager.InitLmsFactory(LmsConveyor);
        return manager;
    }

    /// <exclude/>
    protected ConfServerProtocol CreateProtocol() {
        Endpoint csEndpoint = null;
        if (CsEndpoints.Count > 0) {
            csEndpoint = CsEndpoints[0];
        } else if (WsConfig != null) {
            IList<Endpoint> eps = WsConfig.Endpoints;
            if (eps != null && eps.Count > 0) {
                csEndpoint = eps[0];
            }
        }
        if (csEndpoint == null) {
            throw new ArgumentException(
                    "GFApplicationConfigurationManager.Builder: no CS Endpoint given to create ConfService");
        }

        var protocol = new ConfServerProtocol(csEndpoint);
        if (DisableSessionUsage == null || !DisableSessionUsage.Value) {
            protocol.UseSession = true;
        }

        protocol.ClientName = ClientName;
        if (ClientType != null)
        {
          protocol.ClientApplicationType = (int)ClientType.Value;
        }

        if (Username != null) {
            protocol.UserName = Username;
        }
        if (Password != null) {
            protocol.UserPassword = Password;
        }

        return protocol;
    }
    /// <exclude/>
    protected WarmStandby CreateWarmStandby(ConfServerProtocol protocol) {
        if (protocol != null) {
            if (WsConfig != null)
            {
              var warmStandby = new WarmStandby(ClientName + "@WS.CS", protocol)
              {Configuration = WsConfig};
              return warmStandby;
            } 
            if (UseWarmStandby == null || UseWarmStandby.Value) {
                if (CsEndpoints.Count > 0) {
                    return new WarmStandby(ClientName + "@WS.CS", protocol, CsEndpoints);
                }
            }
        }
        return null;
    }
    /// <exclude/>
    public abstract TCfgManager Build();
  
  }
}

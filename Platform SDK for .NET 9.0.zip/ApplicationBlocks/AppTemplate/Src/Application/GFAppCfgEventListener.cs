//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using Genesyslab.Platform.ApplicationBlocks.Commons;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;

namespace Genesyslab.Platform.AppTemplate.Application
{
  /// <summary>
  /// Abstract base class defines subscriber contract for Publish/Subscribe pattern. 
  /// </summary>
  public abstract class GFAppCfgEventListener : ISubscriber<IGFAppCfgEvent>
  {
    /// <summary>
    /// Gets filter predicate that allows checking whether publishing event should be processed or ignored.
    /// </summary>
    public abstract IPredicate<IGFAppCfgEvent> Filter { get; }
    /// <summary>
    /// Processes a publishing event.
    /// </summary>
    /// <param name="obj">Event to be processed by subscribers</param>
    public abstract void Handle(IGFAppCfgEvent obj);
  }

  /// <exclude/>
  public abstract class GFAppCfgOptionsEventListener: GFAppCfgEventListener 
  {
    /// <exclude/>
    private static readonly IPredicate<IGFAppCfgEvent> TheAppConfigdataFilter =
            new TheAppConfigDataFilter();


    /// <exclude/>
    public override IPredicate<IGFAppCfgEvent> Filter
    {
      get {  return TheAppConfigdataFilter;}
    }

    /// <exclude/>
    private class TheAppConfigDataFilter: IPredicate<IGFAppCfgEvent> {
        public bool Invoke(IGFAppCfgEvent @event) {
            if (@event == null) { return false; }
            IGFApplicationContext appCtx = @event.AppContext;
            if (appCtx == null) { return false; }
            AppCfgEventType evType = @event.EventType;
            return AppCfgEventType.AppConfigReceived.Equals(evType)
                    || AppCfgEventType.AppConfigUpdated.Equals(evType);
        }
    }
}

}

//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Threading;
using Genesyslab.Platform.ApplicationBlocks.Commons;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.AppTemplate.Configuration;
using Genesyslab.Platform.AppTemplate.Configuration.Log;
using Genesyslab.Platform.AppTemplate.Logger;
using Genesyslab.Platform.AppTemplate.Logger.LMS;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Protocols.Custom;
using Genesyslab.Platform.Commons.Threading;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests.Objects;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.AppTemplate.Application
{
  /// <summary>
  /// The Application Configuration Management component facade class.<br/>
  /// It monitors given application configuration and configuration
  /// of its connected applications (servers), and notifies the application about changes
  /// of their properties in the Configuration Server.<br/>
  /// The application configuration manager instance may be created by using the builder -
  /// <see cref="GFApplicationConfigurationManager.Builder"/>
  /// </summary>
  public class GFApplicationConfigurationManager : AbstractLogEnabled, ISubscriptionService<IGFAppCfgEvent>
  {
    private readonly String _applicationName;
    private readonly IConfService _confService;

    private readonly bool _doCSSubscribe;
    private readonly bool _readTenantsInfo;
    private readonly bool _doCSDispose;

    /// <exclude/>
    protected GFApplicationContextImpl AppContext;

    /// <exclude/>
    protected readonly object StateLock = new object();

    private readonly List<ISubscriber<IGFAppCfgEvent>> _subscribers =
            new List<ISubscriber<IGFAppCfgEvent>>();

    /// <exclude/>
    protected GCOMApplicationConfiguration AppConfig = null;
    /// <exclude/>
    public GCOMApplicationConfiguration ApplicationConfiguration { get { return AppConfig; } }
    /// <exclude/>
    private NLogLoggerFactory _lmsLogFactory = null;
    /// <exclude/>
    private ILmsEventLogger _lmsEventLogger = null;

    private readonly SingleThreadInvoker _invoker;
    private readonly ManualResetEvent _initialEvent = new ManualResetEvent(false);

    /// <exclude/>
    protected WarmStandby TheWarmStandby = null;
    /// <exclude/>
    protected GFApplicationConfigurationManager(String appName, IConfService confService,
      WarmStandby warmStandby, bool doCSSubscribe, bool readTenatsInfo, bool doCSDispose)
    {
      _applicationName = appName;
      _confService = confService;
      _doCSSubscribe = doCSSubscribe;
      _doCSDispose = doCSDispose;
      _readTenantsInfo = readTenatsInfo;
      TheWarmStandby = warmStandby;
      _invoker = new SingleThreadInvoker("AppManager-" + _applicationName);
    }

    /// <exclude/>
    internal protected void InitLmsFactory(LmsMessageConveyor conveyor)
    {
      _lmsLogFactory = new NLogLoggerFactory(null, conveyor);
      _lmsEventLogger = _lmsLogFactory.CreateLmsLogger(ApplicationName);
    }

    internal void Reconfigure()
    {
      if (_lmsLogFactory==null) return;
      _lmsLogFactory.Configure(new GAppLoggingOptions(AppConfig, Logger));
    }
    #region Properties
    /// <exclude/>
    public string ApplicationName
    {
      get { return _applicationName; }
    }
    /// <exclude/>
    public IGFApplicationContext ApplicationContext
    {
      get { return AppContext; }
    }
    #endregion Properties
    #region API

    /// <exclude/>
    public void Init()
    {
      Init(false, 0);
    }
    /// <exclude/>
    public bool Init(bool wait, int milliseconds)
    {
      lock (StateLock)
      {
        try
        {
          var protocol = _confService.Protocol;
          AddChannelEvents(protocol);
          _confService.Register(ConfServiceHandler);
          var state = protocol.State;
          if (ChannelState.Opened.Equals(state))
          {
            if (_doCSSubscribe)
            {
              DoSubscription();
            }
            ReadTheApplication();
          }
          else if (ChannelState.Closed.Equals(state))
          {
            if (TheWarmStandby != null)
            {
              TheWarmStandby.AutoRestore(false);
              TheWarmStandby.Open();
            }
            else
            {
              protocol.Open();
            }
          }
          if (wait) 
            return _initialEvent.WaitOne(milliseconds);
        }
        catch (Exception exception)
        {
          if ((Logger!=null) && (Logger.IsErrorEnabled))
            Logger.Error("Exception in application configuration manager init()", exception);
        }
        return false;
      }
    }
    /// <exclude/>
    public void Done()
    {
      lock (StateLock)
      {
        if (_doCSDispose)
        {
          if (TheWarmStandby != null)
          {
            TheWarmStandby.Close();
          }
          else
          {
            _confService.Protocol.Close();
          }
        }
        RemoveChannelEvents(_confService.Protocol);
        _confService.Unregister(ConfServiceHandler);
        if (_doCSDispose)
          ConfServiceFactory.ReleaseConfService(_confService);
        _invoker.Dispose();
      }
    }
    #endregion API
    #region private utils

    private void AddChannelEvents(IProtocol protocol)
    {
      protocol.Opened+= ProtocolOnOpened;
      protocol.Closed+= ProtocolOnClosed;
    }

    private void ProtocolOnClosed(object sender, EventArgs eventArgs)
    {
      HandleEvent(new GFAppCfgEventImpl(AppCfgEventType.ConfSrvDisconnected,AppContext, null, null));
    }

    private void ProtocolOnOpened(object sender, EventArgs eventArgs)
    {
      bool sessionIsNew = (AppConfig == null) || !((ConfServerProtocol) _confService.Protocol).Context.IsSessionRestored;
      HandleEvent(new GFAppCfgEventImpl(AppCfgEventType.ConfSrvConnected, AppContext, null, null));
      if (sessionIsNew)
      {
        if (_doCSSubscribe)
        {
          DoSubscription();
        }
        HandleTask(state =>
        {
          try
          {
            ReadTheApplication();
          }
          catch (ConfigurationException ex)
          {
            if ((Logger != null) && (Logger.IsErrorEnabled))
              Logger.Error("Exception reading application configuration", ex);
          }
        });
      }
    }

    private void RemoveChannelEvents(IProtocol protocol)
    {
      protocol.Opened -= ProtocolOnOpened;
      protocol.Closed -= ProtocolOnClosed;
    }

    /// <excluce/>
    protected void ReadTheApplication()
    {
      try
      {
        var cfgApp = _confService.RetrieveObject<CfgApplication>(
          new CfgApplicationQuery{Name = _applicationName});
        if (cfgApp != null)
        {
          var appConf = new GCOMApplicationConfiguration(cfgApp, true, true, _readTenantsInfo);
          HandleEvent(
            new GFAppCfgEventImpl(AppCfgEventType.AppConfigReceived,
              AppContext, appConf, cfgApp),
            () =>
            {
              AppConfig = appConf;
              Reconfigure();
              _initialEvent.Set();
            });
          return;
        }
      }
      catch (Exception ex)
      {
        throw new ConfigurationException("Failed to initialize configuration for '"
                                         + _applicationName + "'", ex);
      }
      throw new ConfigurationException("No application configuration read for '"
                                       + _applicationName + "'");
    }

    /// <excluce/>
    protected void DoSubscription() {
        try {
            var objectFilter = new KeyValueCollection {{"object_type", (int) CfgObjectType.CFGApplication}};
            var subscriptionFilter = new KeyValueCollection {{"subscription", objectFilter}};
            _confService.Protocol.Send(RequestRegisterNotification.Create(subscriptionFilter));
            objectFilter["object_type"] = (int) CfgObjectType.CFGHost;
            _confService.Protocol.Send(RequestRegisterNotification.Create(subscriptionFilter));
        } catch (Exception ex) {
          if ((Logger!=null) && (Logger.IsErrorEnabled))
            Logger.Error("Failed to subscribe for objects update notifications", ex);
        }
    }

    private void UpdateCurrentConfig(CfgApplication cfgApp) {
    	try {
    		AppConfig = new GCOMApplicationConfiguration(cfgApp, true, true, _readTenantsInfo);
        Reconfigure();
    	} catch (Exception ex) {
            throw new ConfigException("Failed to read CME application '"+ _applicationName + "'", ex);
        }
    }
    /// <excluce/>
    protected bool IsCurrentApp(
            IGApplicationConfiguration appConfig,
            int appDbid) {
        int? currAppDbid = appConfig.Dbid;
        return currAppDbid != null && currAppDbid == appDbid;
    }
    /// <excluce/>
    protected bool IsCurrentHost(IGApplicationConfiguration appConfig,int hostDbid) 
    {
        IGServerInfo srvInfo = appConfig.ServerInfo;
        if (srvInfo != null) {
            IGHost host = srvInfo.Host;
            if (host != null) {
                int? srvHostDbid = host.Dbid;
                if (srvHostDbid != null && srvHostDbid == hostDbid) {
                    return true;
                }
            }
        }
        return false;
    }

    /// <excluce/>
    protected GCOMApplicationConfiguration GetNewConfig() {
        try {
            int? appDbid = null;
            CfgApplication cfgApp = null;
            IGApplicationConfiguration currConfig = AppConfig;
            if (currConfig != null) {
                appDbid = currConfig.Dbid;
            }
            if (appDbid != null) {
                cfgApp = (CfgApplication) _confService.RetrieveObject(appDbid.Value, CfgObjectType.CFGApplication);
                if (cfgApp == null) {
                  throw new ConfigException(
                            "No application configuration read DBID=" + appDbid);
                }
            }
            if (cfgApp == null) {
                cfgApp = _confService.RetrieveObject<CfgApplication>(
                        new CfgApplicationQuery{Name = _applicationName});
            }
            if (cfgApp != null) {
                return new GCOMApplicationConfiguration(cfgApp);
            }
        } catch (Exception ex) {
            throw new ConfigException("Failed to read CME application '"
                    + _applicationName + "'", ex);
        }
        throw new ConfigException("No application configuration read for '"
                + _applicationName + "'");
    }
    /// <excluce/>
    protected void HandleEvent(IGFAppCfgEvent appEvent) {
        HandleEvent(appEvent, null);
    }

    /// <excluce/>
    protected void HandleEvent(IGFAppCfgEvent appEvent, Action action)
    {
      HandleTask(state =>
      {
        foreach (ISubscriber<IGFAppCfgEvent> subscriber in _subscribers)
        {
          var filter = subscriber.Filter;
          try
          {
            if ((filter == null) || (filter.Invoke(appEvent)))
            {
              subscriber.Handle(appEvent);
            }
          }
          catch (Exception e)
          {
            if ((Logger != null) && (Logger.IsWarnEnabled))
              Logger.Warn("Exception in GFAppCfgEvent notification", e);
          }
        }
        if (action != null)
        {
          try
          {
            action();
          }
          catch (Exception e)
          {
            if ((Logger != null) && (Logger.IsWarnEnabled))
              Logger.Warn("Exception in GFAppCfgEvent notification", e);
          }
        }
      });
    }

    /// <excluce/>
    protected bool IsAppConnected(
            IGApplicationConfiguration appConfig,
            int appDbid
            ) 
    {    	
    	return IsAppConnected(appConfig, appDbid, true);
    }
    /// <excluce/>
    protected bool IsAppConnected(
      IGApplicationConfiguration appConfig,
      int appDbid, bool checkClusterNodes)
    {
      List<IGAppConnConfiguration> connList = appConfig.AppServers;
      foreach (IGAppConnConfiguration conn in connList)
      {
        IGApplicationConfiguration srv = conn.TargetServerConfiguration;
        if (srv != null)
        {
          int? srvDbid = srv.Dbid;
          if (srvDbid != null && srvDbid == appDbid)
          {
            return true;
          }
          IGServerInfo srvInfo = srv.ServerInfo;
          if (srvInfo != null)
          {
            IGApplicationConfiguration backup = srvInfo.Backup;
            if (backup != null)
            {
              int? backupDbid = backup.Dbid;
              if (backupDbid != null && backupDbid == appDbid)
              {
                return true;
              }
            }
          }
          if (checkClusterNodes && CfgAppType.CFGApplicationCluster.Equals(srv.ApplicationType))
          {
            return IsAppConnected(srv, appDbid, false);
          }
        }
      }
      return false;
    }
    /// <excluce/>
    protected bool IsHostConnected(IGApplicationConfiguration appConfig, int hostDbid, bool checkClusterNodes) 
    {
    	List<IGAppConnConfiguration> connList = appConfig.AppServers;
    	if(connList == null) {
    		return false;
    	}
        foreach (IGAppConnConfiguration conn in connList) {
            IGApplicationConfiguration srv = conn.TargetServerConfiguration;
            if (srv != null) {
                IGServerInfo srvInfo = srv.ServerInfo;
                if (srvInfo != null) {
                    IGHost host = srvInfo.Host;
                    if (host != null) {
                        int? srvHostDbid = host.Dbid;
                        if ((srvHostDbid != null) && (srvHostDbid.Value == hostDbid)) {
                            return true;
                        }
                    }
                    IGApplicationConfiguration backup = srvInfo.Backup;
                    if (backup != null) {
                        IGServerInfo srvBackupInfo = backup.ServerInfo;
                        if (srvBackupInfo != null) {
                            IGHost backupHost = srvBackupInfo.Host;
                            if (backupHost != null) {
                                int? backupHostDbid = backupHost.Dbid;
                                if (backupHostDbid != null && backupHostDbid == hostDbid) {
                                    return true;
                                }
                            }
                        }
                    }
                    if (checkClusterNodes && CfgAppType.CFGApplicationCluster.Equals(srv.ApplicationType)) {
                    	return IsHostConnected(srv, hostDbid, false);
                    }
                }
            }
        }
        return false;
    }
    /// <excluce/>
    protected bool IsHostConnected(IGApplicationConfiguration appConfig, int hostDbid) 
    {
    	return IsHostConnected(appConfig, hostDbid, true);
    }

    /// <excluce/>
    protected void HandleTask(WaitCallback callback)
    {
      _invoker.Invoke(callback, this);
    }

    private void ConfServiceHandler(ConfEvent confEvent)
    {
      IGApplicationConfiguration currentConfig = AppConfig;
      if (currentConfig != null)
      {
        if (!ConfEventType.ObjectUpdated.Equals(confEvent.EventType))
        {
          return;
        }
        var obj = confEvent.Delta as CfgDelta;
        if (obj != null)
        {
          CfgObjectType objType = confEvent.ObjectType;
          GCOMApplicationConfiguration newConfig = null;
          if (CfgObjectType.CFGApplication.Equals(objType))
          {
            if (IsCurrentApp(currentConfig, confEvent.ObjectId))
            {
              newConfig = GetNewConfig();
              HandleEvent(new GFAppCfgEventImpl(AppCfgEventType.AppConfigUpdated,
                AppContext, newConfig, obj));
            }
            else if (IsAppConnected(currentConfig, obj.ObjectDbid))
            {
              newConfig = GetNewConfig();
              HandleEvent(new GFAppCfgEventImpl(AppCfgEventType.ConnSrvUpdated,
                AppContext, newConfig, obj));
            }

          }
          else if (CfgObjectType.CFGHost.Equals(objType))
          {
            if (IsCurrentHost(currentConfig, obj.ObjectDbid))
            {
              newConfig = GetNewConfig();
              HandleEvent(
                new GFAppCfgEventImpl(AppCfgEventType.AppHostUpdated,
                  AppContext, newConfig, obj));
            }
            if (IsHostConnected(currentConfig, obj.ObjectDbid))
            {
              newConfig = GetNewConfig();
              HandleEvent(new GFAppCfgEventImpl(AppCfgEventType.ConnHostUpdated,
                AppContext, newConfig, obj));
            }
          }
          if (newConfig != null)
          {
            UpdateCurrentConfig(newConfig.CfgApplication);
          }
        }

      }
    }


    #endregion
    #region ISubscriber
    /// <excluce/>
    public void Register(ISubscriber<IGFAppCfgEvent> subscriber)
    {
      if (_subscribers.Contains(subscriber))
      {
        throw new ArgumentException("The subscriber is already registered");
      }
      _subscribers.Add(subscriber);
    }

    /// <excluce/>
    public void Register(Action<IGFAppCfgEvent> handler)
    {
      Register(handler, null);
    }

    /// <excluce/>
    public void Register(Action<IGFAppCfgEvent> handler, IPredicate<IGFAppCfgEvent> filter)
    {
      _subscribers.Add(new EventSubscriberWrapper(filter, handler));
    }

    /// <excluce/>
    public void Unregister(ISubscriber<IGFAppCfgEvent> subscriber)
    {
      _subscribers.Remove(subscriber);
    }

    /// <excluce/>
    public void Unregister(Action<IGFAppCfgEvent> handler)
    {
      var index = 0;
      while (index<_subscribers.Count)
      {
        var wrapper = _subscribers[index] as EventSubscriberWrapper;
        if ((wrapper != null) && (wrapper.Action==handler))
        {
          _subscribers.RemoveAt(index);
          continue;
        }
        index++;
      }
    }

    private class EventSubscriberWrapper: ISubscriber<IGFAppCfgEvent> {

        private readonly IPredicate<IGFAppCfgEvent> _filter;
        private  readonly Action<IGFAppCfgEvent> _action;

        internal EventSubscriberWrapper(IPredicate<IGFAppCfgEvent> filter,Action<IGFAppCfgEvent> action) 
        {
            _action = action;
            _filter = filter;
        }

        public IPredicate<IGFAppCfgEvent> Filter {
          get { return _filter; }
        }
        public Action<IGFAppCfgEvent> Action
        {
          get { return _action; }
        }


        public void Handle(IGFAppCfgEvent obj) {
          if (_action!=null)
              _action(obj);
        }
    }

    #endregion ISubscriber
    #region CFAppCfgEvent

    /// <exclude/>
    protected class GFAppCfgEventImpl : IGFAppCfgEvent
    {
      /// <summary>
      /// Internal constructor of event implementation class.
      /// </summary>
      internal protected GFAppCfgEventImpl(AppCfgEventType type, IGFApplicationContext ctx, 
        IGApplicationConfiguration config, ICfgObject confData)
      {
        EventType = type;
        AppContext = ctx;
        AppConfig = config;
        ConfData = confData;
      }

      /// <exclude/>
      public override String ToString()
      {
        return "GFAppCfgEvent[type=" + EventType + ",app="
               + ((AppConfig != null) ? ('"' + AppConfig.ApplicationName + '"') : "null")
               + "]";
      }
      /// <exclude/>
      public AppCfgEventType EventType { get; private set; }
      /// <exclude/>
      public IGFApplicationContext AppContext { get; private set; }
      /// <exclude/>
      public IGApplicationConfiguration AppConfig { get; private set; }
      /// <exclude/>
      public ICfgObject ConfData { get; private set; }
    }

    #endregion CFAppCfgEvent
    #region AppContext
    /// <exclude/>
    protected class GFApplicationContextImpl : IGFApplicationContext
    {
      private readonly GFApplicationConfigurationManager _manager;
      internal GFApplicationContextImpl(GFApplicationConfigurationManager manager)
      {
        _manager = manager;
      }
      /// <excluce/>
      public IConfService ConfService { get { return _manager._confService; }}
      /// <excluce/>
      public IGApplicationConfiguration Configuration { get { return _manager.AppConfig; } }

      /// <excluce/>
      public ILmsLogFactory LmsLoggerFactory { get { return _manager._lmsLogFactory; } }
      /// <excluce/>
      public ILmsEventLogger LmsEventLogger { get { return _manager._lmsEventLogger; } }
    }
    #endregion AppContext
    #region builder

    /// <exclude/>
    public static ManagerBuilder Builder
    {
      get { return new ManagerBuilder(); }
    }

    /// <summary>
    /// Dedicated builder for basic implementation of application configuration manager.<br/>
    /// It provides two main ways of the manager building - with or without pre-configured ConfService instance.
    /// If application provides ConfService, it should also take care on the protocol connection state management
    /// (i.e. WarmStandby configuration, etc), ConfService cache configuration, and CS updates subscriptions.
    /// </summary>
    public class ManagerBuilder :
            AbstractManagerBuilder<GFApplicationConfigurationManager, ManagerBuilder> {

      /// <excluce/>
      protected override GFApplicationConfigurationManager SetupContext(GFApplicationConfigurationManager manager)
      {
        base.SetupContext(manager);
        manager.AppContext = new GFApplicationContextImpl(manager);
        return manager;
      }

      /// <excluce/>
      public override GFApplicationConfigurationManager Build()
      {
            CheckRequiredParameters();

            GFApplicationConfigurationManager mgr = null;
            if (ConfService != null) {
              bool doSubscriptions = (DoCSSubscription != null && DoCSSubscription.Value);
              bool readTenantsInfo = (ReadTenantsInfo != null && ReadTenantsInfo.Value);
              mgr = new GFApplicationConfigurationManager(
                        ClientName, ConfService, null,
                        doSubscriptions, readTenantsInfo, false);
            } else {
                ConfServerProtocol protocol = CreateProtocol();
                if (protocol != null) {
                    WarmStandby warmStandby = CreateWarmStandby(protocol);
                    IConfService cs = ConfServiceFactory.CreateConfService(protocol, true);
                    if (cs != null) {
                      bool doSubscriptions = (DoCSSubscription == null || DoCSSubscription.Value);
                      bool readTenantsInfo = (ReadTenantsInfo == null || ReadTenantsInfo.Value);
                      mgr = new GFApplicationConfigurationManager(
                                ClientName, cs, warmStandby, doSubscriptions, readTenantsInfo, true);
                    }
                }
            }

            if (mgr == null) {
                throw new ArgumentException(
                        "GFApplicationConfigurationManager.Builder: no required parameters given");
            }

            return SetupContext(mgr);
        }
    }
    #endregion builder
  }
}

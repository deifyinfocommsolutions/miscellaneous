//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using Genesyslab.Platform.ApplicationBlocks.WarmStandby;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Helper class for client connection configuration creation.
  /// <para>Also it may create <see cref="WSConfig"/> representing configuration for <see cref="WarmStandby"/>.
  /// </para>
  /// </summary>
  /// <example>
  /// <para>COM AB direct usage example: </para>
  /// <code>
  ///   String appName = "&lt;app-name&gt;";
  ///   CfgApplication cfgApplication = confService.RetrieveObject&lt;CfgApplication&gt;
  ///     (new CfgApplicationQuery(service) { Name = appName });
  ///   GCOMApplicationConfiguration appConfiguration = new GCOMApplicationConfiguration(cfgApplication);
  ///   IGAppConnConfiguration connConfig = appConfiguration.GetAppServer(CfgAppType.CFGStatServer);
  ///   Endpoint epStatSrv = ClientConfigurationHelper.CreateEndpoint(
  ///               appConfiguration, connConfig, connConfig.TargetServerConfiguration);
  ///   StatServerProtocol statProtocol = new StatServerProtocol(epStatSrv){ClientName = clientName};
  ///   statProtocol.Open();
  /// </code></example>
  public static class ClientConfigurationHelper
  {
    #region fields
    /**
     * The id of the default application port.
     */
    private const String DefaultPortID = "default";
    private static readonly ILogger NullLoggerInstance = new NullLogger();
    private static ILogger _logger;
    #endregion fields
    #region public
    /// <summary>
    /// Gets/sets logger instance to log data and assign to instances
    /// </summary>
    public static ILogger Logger
    {
      get { return _logger ?? NullLoggerInstance; }
      set { _logger = value; }
    }

    /// <summary>
    /// It creates configured Endpoint instance with attached connection configuration
    /// using <see cref="IGApplicationConfiguration"/>,<see cref="IGAppConnConfiguration"/> structures.
    /// </summary>
    /// <param name="appConfig">main application configuration</param>
    /// <param name="connConfig">configuration of particular application connection</param>
    /// <param name="targetServerConfig">target server application configuration</param>
    /// <returns></returns>
    public static Endpoint CreateEndpoint(
      IGApplicationConfiguration appConfig,
      IGAppConnConfiguration connConfig,
      IGApplicationConfiguration targetServerConfig)
    {
      return CreateEndpoint(null, appConfig, connConfig, targetServerConfig);
    }
    /// <summary>
    /// It creates configured Endpoint instance with attached connection configuration
    /// using <see cref="IGApplicationConfiguration"/>,<see cref="IGAppConnConfiguration"/> structures.
    /// </summary>
    /// <param name="name">Endpoint's name</param>
    /// <param name="appConfig">main application configuration</param>
    /// <param name="connConfig">configuration of particular application connection</param>
    /// <param name="targetServerConfig">target server application configuration</param>
    /// <returns></returns>
    public static Endpoint CreateEndpoint(
            String name,
            IGApplicationConfiguration appConfig,
            IGAppConnConfiguration connConfig,
            IGApplicationConfiguration targetServerConfig)
    {
      if (appConfig == null || connConfig == null || targetServerConfig == null)
      {
        throw new ConfigurationException(
                "Parameters appConfig, connConfig and targetServerConfig must not be null");
      }

      String epName = name ?? "conn-" + appConfig.ApplicationName+ "-" + targetServerConfig.ApplicationName;

      IGServerInfo srvInfo = targetServerConfig.ServerInfo;
      if (srvInfo == null)
      {
        throw new ConfigurationException(
                "Target application does not contain ServerInfo structure");
      }
      IGHost srvHost = srvInfo.Host;
      if (srvHost == null)
      {
        throw new ConfigurationException(
                "Target application does not contain ServerInfo.Host structure");
      }
      String host = srvHost.Name;

      String portId = connConfig.PortId;
      if (portId == null || portId.Length == 0)
      {
        portId = DefaultPortID;
      }
      List<IGPortInfo> portInfos = targetServerConfig.PortInfos;
      if (portInfos == null || portInfos.Count==0)
      {
        throw new ConfigurationException(
                "No ports information specified in target server configuration");
      }
      IGPortInfo portInfo = GApplicationConfiguration.PortInfo(portInfos, portId);
      if (portInfo == null || portInfo.Port == null)
      {
        throw new ConfigurationException(
                "No '" + portId + "' port information specified in target server configuration");
      }
      int portNum = portInfo.Port.Value;

      var reader = new GConfigTlsPropertyReader(appConfig, connConfig, targetServerConfig);
      var config = TLSConfiguration.ParseTlsConfiguration(new PropertyConfiguration(), reader);

      FillClientCommonOptions(config, appConfig, connConfig, targetServerConfig);
      FillClientIPv6Options(config, appConfig, connConfig, targetServerConfig);
      FillClientAddpOptions(config, connConfig);

      return new Endpoint(epName, host, portNum, config);
    }
    private static void FillClientCommonOptions(IConnectionConfiguration targetConfig,
            IGApplicationConfiguration appConfig,IGAppConnConfiguration connConfig,
            IGApplicationConfiguration targetServerConfig)
    {
        GConfigPropertyReader reader = new GConfigPropertyReader(appConfig, connConfig, "");
      foreach (OptionDescription option in PsdkDefaultOptions.Options)
      {
            String optionValue = reader.GetProperty(option);
            if (null != optionValue) {
                targetConfig.SetOption(option.OptionName, optionValue);
            }
      }
    }
    private const String EnableIpv6Section = "common";
    private const String IpVersion46 = "4,6";
    private const String IpVersion64 = "6,4";
    private const String DefaultIpVersion = IpVersion46;
    private static void FillClientIPv6Options(IConnectionConfiguration targetConfig,
            IGApplicationConfiguration appConfig,IGAppConnConfiguration     connConfig,
            IGApplicationConfiguration targetServerConfig)
    {
        String enableIpv6Str = null;
        KeyValueCollection options = appConfig.Options;
        if (null != options) {
            var common = options[EnableIpv6Section] as KeyValueCollection;
            if (null != common) {
                enableIpv6Str = common[CommonConnection.EnableIPv6Key] as String;
            }
        }

        var ipVersion = DefaultIpVersion;
        if (null != connConfig) {
            String tParams = connConfig.TransportParams;
            if (null != tParams) {
                ipVersion = ConfigurationUtil.FindTransportParameter(
                        tParams, CommonConnection.IpVersionKey);
            }
        }
        targetConfig.SetBoolean(CommonConnection.EnableIPv6Key, ConfigurationUtil.IsTrue(enableIpv6Str));
        targetConfig.SetOption(CommonConnection.IpVersionKey, ipVersion);
    }

    private static void FillClientAddpOptions(
            IConnectionConfiguration targetConfig,
            IGAppConnConfiguration connConfig) {

      targetConfig.SetOption(ConnectionBase.ProtocolNameKey,connConfig.ConnProtocol);
      if (connConfig.TimeoutLocal != null)
        targetConfig.SetOption(AddpInterceptor.TimeoutKey,
          connConfig.TimeoutLocal.Value.ToString(CultureInfo.InvariantCulture));
      if (connConfig.TimeoutRemote != null)
        targetConfig.SetOption(AddpInterceptor.RemoteTimeoutKey,
          connConfig.TimeoutRemote.Value.ToString(CultureInfo.InvariantCulture));
      CfgTraceMode? trMode = connConfig.TraceMode;
      if (trMode != null) {
        targetConfig.SetOption(AddpInterceptor.TraceKey, trMode.Value.ToString("F"));
      }
    }

    /// <summary>
    /// Creates configuration for <see cref="WarmStandbyService"/>. Its' result includes parameters for connection 
    /// to primary and backup servers defined in the specified application configuration information.
    /// TLS configuration WarmStandbyService may be used for automatic connection restoration 
    /// to primary or backup server when it's got lost.
    /// </summary>
    /// <example>
    /// <para>COM AB direct usage example: </para>
    /// <code>
    ///   String appName = "&lt;app-name&gt;";
    ///   var cfgApplication = confService.RetrieveObject&lt;CfgApplication&gt;
    ///     (new CfgApplicationQuery(service) { Name = appName });
    ///   var appConfiguration = new GCOMApplicationConfiguration(cfgApplication);
    ///   var connConfig = appConfiguration.GetAppServer(CfgAppType.CFGStatServer);
    ///   var wsConfig = ClientConfigurationHelper.CreateWarmStandbyConfig(appConfiguration, connConfig);
    ///   var statProtocol = new StatServerProtocol(wsConfig.ActiveEndpoint){ClientName = clientName};
    ///   var wsService = new WarmStandbyService(statProtocol);
    ///   wsService.ApplyConfiguration(wsConfig);
    ///   wsService.Start();
    ///   statProtocol.Open();
    /// </code>
    /// <para>
    /// <b>Note:</b>  This sample contains initialization logic only without proper components dispose functionality.
    /// Do not forget to keep reference to the <see cref="WarmStandbyService"/> instance and to 
    /// perform its dispose when it is not needed any more.
    /// </para>
    /// </example>
    /// <param name="appConfig">main application configuration</param>
    /// <param name="connConfig">configuration of particular application connection</param>
    /// <returns>WarmStandbyConfiguration instance with connection configurations to primary and backup servers' endpoints</returns>
    public static WarmStandbyConfiguration CreateWarmStandbyConfig(
            IGApplicationConfiguration appConfig,
            IGAppConnConfiguration connConfig)
                 {
        if (appConfig == null || connConfig == null) {
            throw new ConfigurationException(
                    "Null argument is not allowed");
        }
        IGApplicationConfiguration targetPrimary = connConfig.TargetServerConfiguration;
        if (targetPrimary == null) {
            throw new ConfigurationException(
                    "Target connection application is not configured");
        }
        if (targetPrimary.ServerInfo == null) {
            throw new ConfigurationException(
                    "Target connection application should have ServerInfo");
        }
        
        try {
            IGApplicationConfiguration targetBackup = targetPrimary.ServerInfo.Backup;
            Endpoint primaryEp = CreateEndpoint(
                    appConfig, connConfig, targetPrimary);
            Endpoint backupEp;
            if (targetBackup != null) {
                backupEp = CreateEndpoint(
                        appConfig, connConfig, targetBackup);
                backupEp = CorrectBackupEndpoint(backupEp);
            } else {
                backupEp = primaryEp; // todo any adjustments if no backup specified?
            }

            WarmStandbyConfiguration ret = new WarmStandbyConfiguration(primaryEp, backupEp);

            ret.Timeout=targetPrimary.ServerInfo.Timeout;

            int? attempts = targetPrimary.ServerInfo.Attempts;
            if (attempts != null)
            {
              ret.Attempts = (short)attempts.Value;
            }
            
            return ret;
        }
        catch(Exception ex) {
            throw new ConfigurationException("Creation of WarmStandbyConfiguration has failed", ex);
        }
    }
    
    #endregion public
    #region private 
    private static int MillisecondsTimout(String optionName, String seconds, int defaultValue)
    {
      int value;
      try
      {
        value = Int32.Parse(seconds) * 1000;
      }
      catch (Exception)
      {
        if ((Logger!=null)&& (Logger.IsWarnEnabled))
          Logger.Warn(optionName + " unexpected value: " + seconds + ". Setting default value: " + defaultValue);
        value = defaultValue;
      }
      if (value < 0)
      {
        if ((Logger != null) && (Logger.IsWarnEnabled))
          Logger.Warn(optionName + " can't be negative: " + value + ". Setting default value: " + defaultValue);
        value = defaultValue;
      }
      return value;
    }

    private static Endpoint CorrectBackupEndpoint(Endpoint endpoint)
    {
      IConnectionConfiguration conf = endpoint.GetConfiguration();

      if (conf != null)
      {
        bool isChanged = false;

        String sPort = conf.GetOption(CommonConnection.BindPortKey);
        String sBPort = conf.GetOption(CommonConnection.BackupBindPortKey);
        if (sPort != null || sBPort != null)
        {
          var mConf = conf as ManagedConnectionConfiguration;
          if (mConf != null)
            conf = mConf.Clone() as IConnectionConfiguration ?? conf;
          else
            conf = conf.Clone() as IConnectionConfiguration ?? conf;
          conf.SetOption(CommonConnection.BindPortKey, sBPort);
          conf.SetOption(CommonConnection.BackupBindPortKey, sPort);
          isChanged = true;
        }

        if (isChanged)
        {
          return new Endpoint(endpoint.Name,
            endpoint.Host, endpoint.Port,
            conf);
        }
      }
      return endpoint;
    }
    /// <summary>
    /// Creates configuration for new implementation of the warm standby: <see cref="WarmStandby"/>. 
    /// Its' result includes parameters for connection to primary and backup servers defined in 
    /// the specified application configuration information.
    /// If TLS configuration specified in CME, result will also include secure connection context. 
    /// <see cref="WarmStandby"/> may be used for automatic connection restoration to primary 
    /// or backup server when it's got lost.
    /// </summary>
    /// <example>
    /// <para>COM AB direct usage example: </para>
    /// <code>
    ///   String appName = "&lt;app-name&gt;";
    ///   var cfgApplication = confService.RetrieveObject&lt;CfgApplication&gt;
    ///     (new CfgApplicationQuery(service) { Name = appName });
    ///   var appConfiguration = new GCOMApplicationConfiguration(cfgApplication);
    ///   IGAppConnConfiguration connConfig = appConfiguration.GetAppServer(CfgAppType.CFGStatServer);
    ///   var wsConfig = ClientConfigurationHelper.CreateWarmStandbyConfigEx(appConfiguration, connConfig);
    ///   var statProtocol = new StatServerProtocol(){ClientName = clientName};
    ///   var warmStandby = new WarmStandby(statProtocol);
    ///   warmStandby.Configuration = wsConfig;
    ///   warmStandby.AutoRestore();
    /// </code>
    /// <para>
    /// <b>Note:</b>  This sample contains initialization logic only without proper components dispose functionality.
    /// Do not forget to keep reference to the <see cref="WarmStandbyService"/> instance and to 
    /// perform its dispose when it is not needed any more.
    /// </para>
    /// </example>
    /// <param name="appConfig">main application configuration</param>
    /// <param name="connConfig">configuration of particular application connection</param>
    /// <returns>WSConfig instance with connection configurations to primary and backup servers' endpoints</returns>
    public static WSConfig CreateWarmStandbyConfigEx(
      IGApplicationConfiguration appConfig,
      IGAppConnConfiguration connConfig)
    {

      if (appConfig == null || connConfig == null)
      {
        throw new ConfigurationException("Null argument is not allowed");
      }
      IGApplicationConfiguration targetPrimary = connConfig.TargetServerConfiguration;
      if (targetPrimary == null)
      {
        throw new ConfigurationException(
          "Target connection application is not configured");
      }
      IGServerInfo primaryServerInfo = targetPrimary.ServerInfo;
      if (primaryServerInfo == null)
      {
        throw new ConfigurationException(
          "Target connection application should have ServerInfo");
      }

      IGApplicationConfiguration targetBackup = targetPrimary.ServerInfo.Backup;
      IGServerInfo backupServerInfo = null;
      if (targetBackup != null)
      {
        backupServerInfo = targetBackup.ServerInfo;
        if (backupServerInfo == null)
        {
          throw new ConfigurationException(
            "Backup Server application should have ServerInfo");
        }
      }

      try
      {
        var endpoints = new List<Endpoint>(2);

        Endpoint primaryEp = CreateEndpoint(appConfig, connConfig, targetPrimary);
        endpoints.Add(primaryEp);
        if (targetBackup != null)
        {
          Endpoint backupEp = CreateEndpoint(appConfig, connConfig,targetBackup);
          backupEp = CorrectBackupEndpoint(backupEp);
          endpoints.Add(backupEp);
        }

        var ret = new WSConfig();
        ret.Endpoints = endpoints;
        FillWSTimouts(ret, connConfig, targetBackup);

        return ret;
      }
      catch (Exception ex)
      {
        throw new ConfigurationException(
          "Creation of WarmStandbyConfiguration has failed", ex);
      }
    }

    
    /// <summary>
    ///Creates configuration for new implementation of the warm standby: see cref="WarmStandby"/>. 
    /// Its' result includes parameters for connection to primary and backup servers
    ///defined in the specified application configuration information.<br/>
    ///WarmStandby may be used for automatic connection
    ///restoration to primary or backup server when it's got lost.
    ///</summary>
    ///<param name="wsconfigName"> name of the WarmStandby configura and it's primary Endpoint</param>
    ///<param name="appConfig"> main application configuration</param>
    ///<param name="connConfig"> configuration of particular application connection</param>
    ///<param name="targetPrimary"> application configuration of the primary server</param>
    ///<returns>WSConfig instance with connection configurations to primary and backup servers' endpoints</returns> 
    public static WSConfig CreateWarmStandbyConfigEx(
            String wsconfigName, IGApplicationConfiguration appConfig,
            IGAppConnConfiguration connConfig, IGApplicationConfiguration targetPrimary)
      {
        if (appConfig == null || connConfig == null || targetPrimary == null ) {
            throw new ConfigurationException("appConfig,  connConfig,  targetPrimary must not be null");
        }
        IGServerInfo primaryServerInfo = targetPrimary.ServerInfo;
        if (primaryServerInfo == null) {
            throw new ConfigurationException(
                    "Target connection application should have ServerInfo");
        }

        IGApplicationConfiguration targetBackup = targetPrimary.ServerInfo.Backup;
        IGServerInfo backupServerInfo = null;
        if (targetBackup != null) {
            backupServerInfo = targetBackup.ServerInfo;
            if (backupServerInfo == null) {
                throw new ConfigurationException(
                        "Backup Server application should have ServerInfo");
            }
        }
        try {
            var endpoints = new List<Endpoint>(2);
            Endpoint primaryEp = CreateEndpoint(wsconfigName, appConfig, connConfig, targetPrimary);
            endpoints.Add(primaryEp);
            if (targetBackup != null) {
                String backupEpName = wsconfigName != null ? targetBackup.ApplicationName : null;
                Endpoint backupEp = CreateEndpoint(backupEpName, appConfig, connConfig, targetBackup);
                backupEp = CorrectBackupEndpoint(backupEp);
                endpoints.Add(backupEp);
            }
            WSConfig ret = wsconfigName != null ? new WSConfig(wsconfigName) : new WSConfig();
            ret.Endpoints = endpoints;
            FillWSTimouts(ret, connConfig, targetBackup);

            return ret;
        } catch (Exception ex) {
            throw new ConfigurationException(
                    "Creation of WarmStandbyConfiguration has failed", ex);
        }
    }

    static void FillWSTimouts(WSConfig config, IGAppConnConfiguration clientConnection, IGApplicationConfiguration backupServer)
    {
      String applicationParameters = clientConnection.AppParams;
      if (applicationParameters != null)
      {
        String retryDelay = ConfigurationUtil.FindAppParameter(applicationParameters, PsdkDefaultOptions.WSRetryDelay);
        if (retryDelay != null)
        {
          String[] strDelays = retryDelay.Split(',');
          int[] intDelays = new int[strDelays.Length];
          for (int i = 0; i < intDelays.Length; i++)
          {
            intDelays[i] = MillisecondsTimout(PsdkDefaultOptions.WSRetryDelay, strDelays[i], 1000);
          }
          if (intDelays.Length > 0)
            config.RetryDelay=intDelays;
        }

        String reconnectRange = ConfigurationUtil.FindAppParameter(applicationParameters,PsdkDefaultOptions.WSReconnectRandDelay);
        if (reconnectRange != null)
        {
          config.ReconnectionRandomDelayRange = MillisecondsTimout(PsdkDefaultOptions.WSReconnectRandDelay, reconnectRange, 0);
        }

        String opentimeout = ConfigurationUtil.FindAppParameter(
                applicationParameters,PsdkDefaultOptions.WSTimeout);
        if (opentimeout != null)
        {
          config.Timeout = MillisecondsTimout(PsdkDefaultOptions.WSTimeout, opentimeout, 0);
        }
      }

      if (backupServer != null)
      {
        KeyValueCollection options = backupServer.Options;
        if (options != null)
        {
          var wsSection = options["warm-standby"] as KeyValueCollection;
          if (wsSection != null)
          {
            String backupDelay = wsSection[PsdkDefaultOptions.WSBackupDelay] as String;
            if (backupDelay != null)
            {
              config.BackupDelay = MillisecondsTimout(PsdkDefaultOptions.WSBackupDelay, backupDelay, 0);
            }
          }
        }
      }
    }

    #endregion private

  }
}

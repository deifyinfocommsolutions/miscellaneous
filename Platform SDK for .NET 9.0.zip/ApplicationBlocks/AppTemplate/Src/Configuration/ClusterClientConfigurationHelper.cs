//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Provides helpers for ClusterProtocol configuration.
  /// </summary>
  public static class ClusterClientConfigurationHelper
  {
    ///<summary>
    /// Creates the list of <see cref="WSConfig"/> for ClusterProtocol.
    /// Transparently supports both Cluster and legacy primary/backup WarmStanby configuration.
    /// If client application is connected to cluster, then WSConfig objects will be created
    /// from cluster application connections. If no servers of the specified found in cluster connections,
    /// helper will try to resolve them directly from client application connections.<br/>
    /// Only servers of the specified type will be included into the result <see cref="WSConfig"/> list.
    ///
    /// <param name="clientApp">The client application that has connection to a cluster of servers or to a single server</param>
    /// <param name="serverType">Type of the server(s) to create connection configuration to</param>
    /// <returns>collection of WSConfig objects</returns>
    ///</summary>
    public static IList<WSConfig> CreateClusterProtocolEndpoints(
            IGApplicationConfiguration clientApp, CfgAppType serverType)
    {
        CheckArgsNotNull(clientApp, "clientApp");
        CheckArgsNotNull(serverType, "serverType");

        var clientConnections = clientApp.AppServers;
        if (clientConnections == null || clientConnections.Count == 0) {
            DebugFormat("Client application ''{0}'' has no connections", clientApp.ApplicationName);
            return new List<WSConfig>();
        }

        var wsconfList =
                ParseClusterConfiguration(clientApp, clientConnections, serverType);
        if (wsconfList.Count == 0) {
            wsconfList = ParseSimpleConfiguration(clientApp, clientConnections, serverType);
            DebugFormat("Client application ''{0}'' connections to ''{1}'' count: {2}",
                        new Object[] { clientApp.ApplicationName, serverType, wsconfList.Count });
        }
        return wsconfList;
    }
    /// <summary>
    /// Creates the list of <see cref="WSConfig"/> for ClusterProtocol.<br/>
    /// It transparently supports both Cluster and legacy primary/backup WarmStanby configurations.
    /// If client application is connected to a cluster, then WSConfig objects will be created 
    /// from cluster application connections. If no servers of the specified type found in cluster connections,
    /// helper will try to resolve them directly from client application connections.<br/>
    /// Only servers of the specified type will be included in the result <see cref="WSConfig"/> list.
    /// </summary>
    /// <param name="clientApp">the client application that has connection to a cluster of servers or to a single server</param>
    /// <param name="clusterConn">connection to the specific cluster</param>
    /// <param name="serverType">type of the server(s) to create connection configuration to</param>
    /// <returns>collection of WSConfig objects</returns>
    public static IList<WSConfig> CreateClusterProtocolEndpoints(
            IGApplicationConfiguration clientApp,IGAppConnConfiguration clusterConn,CfgAppType serverType)
    {
        CheckArgsNotNull(clientApp, "clientApp");
        CheckArgsNotNull(clusterConn, "clusterConn");
        CheckArgsNotNull(serverType, "serverType");

        var wsconfList = ParseClusterConfiguration(clientApp, clusterConn, serverType);
        if (wsconfList.Count == 0) {
            var clientConnections = clientApp.AppServers;
            if (clientConnections != null && clientConnections.Count > 0) {
                wsconfList = ParseSimpleConfiguration(clientApp, clientConnections, serverType);
                DebugFormat("Client application ''{0}'' connections to ''{1}'' count: {2}",
                            new Object[] { clientApp.ApplicationName, serverType, wsconfList.Count });
            } else {
                DebugFormat("Client application ''{0}'' has no connections", clientApp.ApplicationName);
            }
        }
        return wsconfList;
    }
    /// <summary>
    /// Creates the list of <see cref="WSConfig"/> for IClusterProtocol.<br/>
    /// If client application is connected to a cluster, then WSConfig objects will be created 
    /// from cluster nodes of given <code>serverType</code>, which have references (connections)
    /// to this application cluster application object.<br/>
    /// Only servers of the specified type will be included in the result <see cref="WSConfig"/> list.
    /// </summary>
    /// <param name="confService">the Configuration Server API service for reading of cluster nodes</param>
    /// <param name="clientApp">the client application that has connection to a cluster of servers or to a single server</param>
    /// <param name="serverType">type of the server(s) to create connection configuration to</param>
    /// <returns>collection of WSConfig objects</returns>
    public static IList<WSConfig> CreateRefClusterProtocolEndpoints(
            IConfService confService, IGApplicationConfiguration clientApp, CfgAppType serverType)
    {
        CheckArgsNotNull(confService, "confService");
        CheckArgsNotNull(clientApp, "clientApp");
        CheckArgsNotNull(serverType, "serverType");

        var servers = clientApp.AppServers;
        if (servers != null && servers.Count != 0) {
            foreach ( IGAppConnConfiguration conn in servers) {
                if (conn != null) {
                    var srv = conn.TargetServerConfiguration;
                    if (srv != null && CfgAppType.CFGApplicationCluster.Equals(srv.ApplicationType)) {
                        var nodes = CreateRefClusterProtocolEndpoints(confService, clientApp, conn, serverType);
                        if (nodes != null && nodes.Count!=0) {
                            return nodes;
                        }
                    }
                }
            }
        }
        return CreateEmptyList();
    }
    /// <summary>
    /// Creates the list of <see cref="WSConfig"/> for IClusterProtocol.<br/>
    /// If client application is connected to a cluster, then WSConfig objects will be created 
    /// from cluster nodes of given <code>serverType</code>, which have references (connections)
    /// to this application cluster application object.<br/>
    /// Only servers of the specified type will be included in the result <see cref="WSConfig"/> list.
    /// </summary>
    /// <param name="confService">the Configuration Server API service for reading of cluster nodes</param>
    /// <param name="clientApp">the client application that has connection to a cluster of servers or to a single server</param>
    /// <param name="clusterConn">connection to the specific cluster</param>
    /// <param name="serverType">type of the server(s) to create connection configuration to</param>
    /// <returns>collection of WSConfig objects</returns>
    public static List<WSConfig> CreateRefClusterProtocolEndpoints(
            IConfService confService, IGApplicationConfiguration clientApp,
            IGAppConnConfiguration clusterConn, CfgAppType serverType)
    {
        CheckArgsNotNull(confService, "confService");
        CheckArgsNotNull(clientApp, "clientApp");
        CheckArgsNotNull(clusterConn, "clusterConn");
        
        var clusterApp = clusterConn.TargetServerConfiguration;
        CheckArgsNotNull(clusterApp, "clusterApp");
        var clusterDbid = clusterApp.Dbid;
        CheckArgsNotNull(clusterDbid, "clusterApp.DBID");

        var ret = CreateEmptyList();
        if (clusterDbid == null) return ret;
        var servers = ReadRefApplications(confService, clusterDbid.Value, serverType);
        if (servers != null && servers.Count!=0) {
            foreach (CfgApplication server in servers) {
                var srvConfig = new GCOMApplicationConfiguration(server, false);
                try {
                    WSConfig conf = ClientConfigurationHelper.CreateWarmStandbyConfigEx(
                            server.Name, clientApp, clusterConn, srvConfig);
                    if (conf != null) {
                        ret.Add(conf);
                    }
                } catch (ConfigurationException ex) {
                    ErrorFormat("Failed to create WSConfig to cluster node {0}: {1}" , server.Name, ex);
                }
            }
        }

        return ret;
    }

    #region utilites
    private static IList<WSConfig> ParseClusterConfiguration(
            IGApplicationConfiguration clientApp,IGAppConnConfiguration clientConnection,CfgAppType appType)
    {
        IGApplicationConfiguration clusterApp = GetTargetApp(
                clientConnection, CfgAppType.CFGApplicationCluster, CfgObjectState.CFGEnabled);
        if (clusterApp != null) {
            String clusterName = clusterApp.ApplicationName;
            DebugFormat("Read cluster application ''{0}'' connections", clusterName);

            var clusterNodesConnList = clusterApp.AppServers;
            if (clusterNodesConnList != null && !(clusterNodesConnList.Count==0)) {
                var sharedOptsConnList = new List<IGAppConnConfiguration>();
                foreach (IGAppConnConfiguration targetNodeConn in clusterNodesConnList) {
                    if (targetNodeConn != null) {
                        sharedOptsConnList.Add(ApplySharedConnOptions(clientConnection, targetNodeConn));
                    }
                }
                var wsconfList = ParseSimpleConfiguration(clientApp, sharedOptsConnList, appType);
                DebugFormat("Cluster application ''{0}'' connections to ''{1}'' count: {2}",
                            new Object[] { clusterName, appType, wsconfList.Count });
                return wsconfList;
            } 
            DebugFormat("Cluster application ''{0}'' has no connections", clusterName);
        }
        return CreateEmptyList();
    }

    private static IList<WSConfig> ParseClusterConfiguration(
            IGApplicationConfiguration clientApp, ICollection<IGAppConnConfiguration> clientConnections, CfgAppType appType)
    {	
        foreach (IGAppConnConfiguration conn in clientConnections) {
            IGApplicationConfiguration clusterApp = GetTargetApp(
                    conn, CfgAppType.CFGApplicationCluster, CfgObjectState.CFGEnabled);
            if (clusterApp != null) {
                var clusterName = clusterApp.ApplicationName;
                DebugFormat("Read cluster application ''{0}'' connections", clusterName);
                var clusterNodesConnList = clusterApp.AppServers;
                if (clusterNodesConnList == null || clusterNodesConnList.Count == 0) {
                    DebugFormat("Cluster application ''{0}'' has no connections", clusterName);
                    continue;
                }

                var sharedOptsConnList = new List<IGAppConnConfiguration>();
                foreach (IGAppConnConfiguration targetNodeConn in clusterNodesConnList) {
                    if (targetNodeConn != null) {
                        sharedOptsConnList.Add(ApplySharedConnOptions(conn, targetNodeConn));
                    }
                }

                var wsconfList = ParseSimpleConfiguration(clientApp, sharedOptsConnList, appType);
                DebugFormat("Cluster application ''{0}'' connections to ''{1}'' count: {2}",
                            new Object[] { clusterName, appType, wsconfList.Count });
                if (wsconfList.Count > 0) { return wsconfList; }
            }
        }
        return new List<WSConfig>();
    }

    private static IList<WSConfig> ParseSimpleConfiguration(
            IGApplicationConfiguration clientApp, ICollection<IGAppConnConfiguration> targetConnList, CfgAppType appType)
    {
        var wsconfList = new List<WSConfig>();
        foreach (IGAppConnConfiguration targetConn in targetConnList) {
            IGApplicationConfiguration targetApp = GetTargetApp(targetConn, appType, CfgObjectState.CFGEnabled);
            if (targetApp != null) {
                var configName = targetApp.ApplicationName;
                var wsconf = ClientConfigurationHelper.CreateWarmStandbyConfigEx(configName, clientApp, targetConn, targetApp);
                wsconfList.Add(wsconf);
            }
        }
        return wsconfList;
    }
    private static IGAppConnConfiguration ApplySharedConnOptions(
            IGAppConnConfiguration sharedConn, IGAppConnConfiguration targetConn) {		
        var resultConnection = new GAppConnConfiguration(targetConn);
        if (resultConnection.ConnProtocol == null && sharedConn.ConnProtocol != null) {
            resultConnection.ConnProtocol = sharedConn.ConnProtocol;
            resultConnection.TimeoutLocal=sharedConn.TimeoutLocal;
            resultConnection.TimeoutRemote=sharedConn.TimeoutRemote;
            resultConnection.TraceMode=sharedConn.TraceMode;
        }
        if (resultConnection.AppParams == null && sharedConn.AppParams != null) {
            resultConnection.AppParams=sharedConn.AppParams;
        } else 
        if (resultConnection.AppParams != null && sharedConn.AppParams != null) {
            var map = new Dictionary<String, String>();
            PutParams(map, sharedConn.AppParams);
            PutParams(map, resultConnection.AppParams);
            resultConnection.AppParams = PrintParams(map);
        }
        if (resultConnection.TransportParams == null && sharedConn.TransportParams != null) {
            resultConnection.TransportParams=sharedConn.TransportParams;
        } else 
        if (resultConnection.TransportParams != null && sharedConn.TransportParams != null) {
            var map = new Dictionary<String, String>();
            PutParams(map, sharedConn.TransportParams);
            PutParams(map, resultConnection.TransportParams);
            resultConnection.TransportParams = PrintParams(map);
        }
        return resultConnection;
    }

    private static void PutParams(IDictionary<String, String> parameters, String value)
    {
      if (!String.IsNullOrEmpty(value))
      {
        var pairs = value.Split(';');
        foreach (String pair in pairs)
        {
          var kv = pair.Split('=');
          if (kv.Length == 2)
          {
            parameters[kv[0].Trim()] = kv[1].Trim();
          }
          else
          {
            WarnLog("Unexpected configuration option: " + value);
          }
        }
      }
    }

    private static String PrintParams(IDictionary<String, String> parameters)
    {
      if (parameters.Count == 0)
      {
        return String.Empty;
      }
      var sb = new StringBuilder();
      foreach (KeyValuePair<string, string> pair in parameters)
      {
        if (sb.Length > 0) sb.Append(";");
        if ((pair.Key != null) && (pair.Value != null))
        {
          sb.Append(pair.Key).Append("=").Append(pair.Value);
        }
      }
      return sb.ToString();
    }

    private static IGApplicationConfiguration GetTargetApp(
      IGAppConnConfiguration conn, CfgAppType appType, CfgObjectState appState)
    {
      if (conn == null)
      {
        return null;
      }
      IGApplicationConfiguration targetApp = conn.TargetServerConfiguration;
      if (targetApp == null)
      {
        DebugFormat("Target application of existing connection ''{0}'' is null", conn);
        return null;
      }
      if (!appType.Equals(targetApp.ApplicationType))
      {
        return null;
      }
      if (!appState.Equals(targetApp.ObjectState))
      {
        DebugFormat("Skip application ''{0}'' with state ''{1}''",
          new Object[] {targetApp.ApplicationName, targetApp.ObjectState});
        return null;
      }
      return targetApp;
    }

    private static List<CfgApplication> ReadRefApplications(
      IConfService confService, int clusterAppDbid, CfgAppType serverType)
    {
      return ReadRefApplications(confService, clusterAppDbid, serverType, false);
    }

    private static List<CfgApplication> ReadRefApplications(
            IConfService confService, int clusterAppDbid,CfgAppType serverType, bool useCache)
    {
        var cache = confService.Cache;

        // TODO evaluate cached cluster:
        bool readCache = (cache != null) && useCache;

        List<CfgApplication> ret = null;
        if (readCache) {
            var objs = cache.RetrieveMultiple<CfgApplication>();
            if (objs != null) {
                ret = new List<CfgApplication>();
                foreach (CfgApplication app in objs) {
                    if (serverType.Equals(app.Type)
                            && CfgObjectState.CFGEnabled.Equals(app.State)) {
                        var conns = app.AppServers;
                        if (conns != null && conns.Count!=0) {
                            foreach (CfgConnInfo conn in conns) {
                                if (conn.GetAppServerDBID() == clusterAppDbid) {
                                    ret.Add(app);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            var query = new CfgApplicationQuery();
            query.ServerDbid = clusterAppDbid;
            query.AppType = serverType;
            query.State = CfgObjectState.CFGEnabled;

            try {
                var servers = confService.RetrieveMultipleObjects<CfgApplication>(query);
                if (servers != null) {
                    ret = new List<CfgApplication>();
                    ret.AddRange(servers);
                }
            } catch (ConfigException ex) {
                throw new ConfigurationException("Failed to read configuration information", ex);
            } catch (ThreadInterruptedException ex) {
                ErrorFormat("Configuration reading is interrupted: {0}", ex);
                Thread.CurrentThread.Interrupt();
            }
        }
        return ret;
    }

    private static void CheckArgsNotNull(object arg, String name)
    {
      if (arg != null) return;
      throw new ArgumentNullException("'" + name + "' is null");
    }
    private static List<WSConfig> CreateEmptyList()
    {
      return new List<WSConfig>();
    }
    #endregion utilites
    #region Logger

    private static ILogger _logger = new NullLogger();

    /// <summary>
    /// Sets logger
    /// </summary>
    /// <param name="logger"><see cref="ILogger"/> instance</param>
    public static void SetLogger(ILogger logger)
    {
      _logger = logger ?? new NullLogger();
    }

    private static void DebugFormat(string format, params Object[] args)
    {
      var logger = _logger;
      if (logger == null) return;
      if (!logger.IsDebugEnabled) return;
      logger.DebugFormat(format, args);
    }
    private static void ErrorFormat(string format, params Object[] args)
    {
      var logger = _logger;
      if (logger == null) return;
      if (!logger.IsErrorEnabled) return;
      logger.ErrorFormat(format, args);
    }

    private static void WarnLog(string logStr)
    {
      var logger = _logger;
      if (logger == null) return;
      if (!logger.IsWarnEnabled) return;
      logger.Warn(logStr);
    }

    #endregion Logger
  }
}

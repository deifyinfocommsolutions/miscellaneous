//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Globalization;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// The application connection configuration structure reflects COM AB <see cref="CfgConnInfo"/> information. <br/>
  /// It contains reference to connected server with related connection properties.
  /// </summary>
  /// <seealso cref="CfgConnInfo"/>
  [Serializable]
  public class GAppConnConfiguration:AbstractToStringObject, IGAppConnConfiguration
  {
    #region private 

    private IGApplicationConfiguration _targetServerConfiguration;
    #endregion private
    #region Constructors
    /// <summary>
    /// Default empty constructor.
    /// Creates uninitialized configuration object.
    /// </summary>
    public GAppConnConfiguration() { }
    /// <summary>
    /// Coping constructor.
    /// <remarks>It does not clone referred structures like <see cref="TargetServerConfiguration"/>.</remarks>
    /// </summary>
    /// <param name="conf">Original configuration</param>
    public GAppConnConfiguration(IGAppConnConfiguration conf)
    {
      if (conf == null)
        throw new ArgumentNullException("conf");
      PortId = conf.PortId;
      ConnProtocol = conf.ConnProtocol;
      TimeoutLocal = conf.TimeoutLocal;
      TimeoutRemote = conf.TimeoutRemote;
      TraceMode = conf.TraceMode;
      TransportParams = conf.TransportParams;
      AppParams = conf.AppParams;
      ProxyParams = conf.ProxyParams;
      Description = conf.Description;
      _targetServerConfiguration = conf.TargetServerConfiguration;
    }
    #endregion Constructors
    #region public properties
    /// <summary>
    /// Sets/gets reference to application configuration of the connected server.
    /// </summary>
    public IGApplicationConfiguration TargetServerConfiguration
    {
      get { return _targetServerConfiguration; }
      set
      {
        var cCfg = value as ICloneable;
        if (cCfg != null)
        {
          _targetServerConfiguration = cCfg.Clone() as IGApplicationConfiguration ?? value;
        }
        else
        {
          _targetServerConfiguration = value;
        }
      }
    }
    /// <summary>
    /// Sets/gets identifier of the server's listening port.
    /// </summary>
    public string PortId { get; set; }
    /// <summary>
    /// Sets/gets name of the connection control protocol.
    /// </summary>
    public string ConnProtocol { get; set; }
    /// <summary>
    /// Sets/gets the heart-bit polling interval measured in seconds, on client site.
    /// Valuable if connection protocol <see cref="ConnProtocol"/> is "addp".
    /// </summary>
    public int? TimeoutLocal { get; set; }
    /// <summary>
    /// Sets/gets the heart-bit polling interval measured in seconds, on server site.
    /// Valuable if connection protocol <see cref="ConnProtocol"/> is "addp".
    /// </summary>
    public int? TimeoutRemote { get; set; }
    /// <summary>
    /// Sets/gets the ADDP trace mode dedicated for this connection
    /// Valuable if connection protocol <see cref="ConnProtocol"/> is "addp".
    /// </summary>
    public CfgTraceMode? TraceMode { get; set; }
    /// <summary>
    /// Sets/gets connection protocol's transport parameters.
    /// </summary>
    public string TransportParams { get; set; }
    /// <summary>
    /// Sets/gets connection protocol's application parameters.
    /// </summary>
    public string AppParams { get; set; }
    /// <summary>
    /// Sets/gets connection protocol's proxy parameters.
    /// </summary>
    public string ProxyParams { get; set; }
    /// <summary>
    /// Sets/gets optional description of the connection.
    /// </summary>
    public string Description { get; set; }
    #endregion public properties
    #region override
    /// <exclude/>
    public virtual object Clone()
    {
      var result = (GAppConnConfiguration) MemberwiseClone();
      result.TargetServerConfiguration = _targetServerConfiguration == null
        ? null
        : _targetServerConfiguration.Clone() as IGApplicationConfiguration ?? _targetServerConfiguration;
      return result;
    }
    /// <exclude/>
    public override int GetHashCode()
    {
      return CalculateHash();
    }
    private int CalculateHash()
    {
      int hash = GetType().GetHashCode();
      if (PortId != null) hash ^= 17 * PortId.GetHashCode();
      if (ConnProtocol != null) hash ^= 23 * ConnProtocol.GetHashCode();
      if (TimeoutLocal != null) hash ^= 29 * TimeoutLocal.Value.GetHashCode();
      if (TimeoutRemote != null) hash ^= 31 * TimeoutRemote.Value.GetHashCode();
      if (TraceMode != null) hash ^= 37 * TraceMode.Value.GetHashCode();
      if (TransportParams != null) hash ^= 41 * TransportParams.GetHashCode();
      if (AppParams != null) hash ^= 43 * AppParams.GetHashCode();
      if (ProxyParams != null) hash ^= 47 * ProxyParams.GetHashCode();
      if (Description != null) hash ^= 53 * Description.GetHashCode();
      if (_targetServerConfiguration!=null)
        hash ^= 59 * _targetServerConfiguration.GetHashCode();
      return hash;
    }
    /// <exclude/>
    public override bool Equals(object obj)
    {
      var gappCfg = obj as GAppConnConfiguration;

      return (ReferenceEquals(this, obj) ||(
                  (gappCfg != null)
               && (gappCfg.GetType() == GetType())
               && (PortId.EqualsObjects(gappCfg.PortId)) 
               && (ConnProtocol.EqualsObjects(gappCfg.ConnProtocol)) 
               && (TimeoutLocal.EqualsObjects(gappCfg.TimeoutLocal)) 
               && (TimeoutRemote.EqualsObjects(gappCfg.TimeoutRemote)) 
               && (TraceMode.EqualsObjects(gappCfg.TraceMode)) 
               && (TransportParams.EqualsObjects(gappCfg.TransportParams)) 
               && (AppParams.EqualsObjects(gappCfg.AppParams)) 
               && (ProxyParams.EqualsObjects(gappCfg.ProxyParams)) 
               && (Description.EqualsObjects(gappCfg.Description)) 
               && (_targetServerConfiguration.EqualsObjects(gappCfg.TargetServerConfiguration)) 
             ));
    }

    /// <exclude/>
    internal protected override string ContentToString(string prefix)
    {
      var sb = new StringBuilder();
      if (PortId != null)
        sb.Append(prefix).Append("PortId: ").AppendLine(PortId);
      if (ConnProtocol != null)
        sb.Append(prefix).Append("ConnProtocol: ").AppendLine(ConnProtocol);
      if (TimeoutLocal != null)
        sb.Append(prefix).Append("TimeoutLocal: ").AppendLine(TimeoutLocal.Value.ToString(CultureInfo.InvariantCulture));
      if (TimeoutRemote != null)
        sb.Append(prefix).Append("TimeoutRemote: ").AppendLine(TimeoutRemote.Value.ToString(CultureInfo.InvariantCulture));
      if (TraceMode != null)
        sb.Append(prefix).Append("TraceMode: ").AppendLine(TraceMode.Value.ToString("F"));
      if (TransportParams != null)
        sb.Append(prefix).Append("TransportParams: ").AppendLine(TransportParams);
      if (ProxyParams != null)
        sb.Append(prefix).Append("ProxyParams: ").AppendLine(ProxyParams);
      if (Description != null)
        sb.Append(prefix).Append("Description: ").AppendLine(Description);
      if (_targetServerConfiguration != null)
      {
        sb.Append(prefix).Append("TargetServer: ");
        var targetServerCfg = _targetServerConfiguration as IToStringIdent;
        sb.AppendLine(targetServerCfg != null 
          ? targetServerCfg.ToString(prefix) 
          : TargetServerConfiguration.ToString());
      }
      return sb.ToString();
    }

    #endregion override
  }
}

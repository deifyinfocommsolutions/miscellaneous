//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// <para>
  /// This class represents base Genesys CME application options,
  /// which can be loaded from configuration server (with COM AB),
  /// or initialized by some other way like custom user code or
  /// any beans management mechanisms/frameworks.
  /// </para>
  /// <para>
  /// It provides detached properties from COM AB <see cref="CfgApplication">CfgApplication</see> and <see cref="CfgHost">CfgHost</see>
  /// objects without COM AB specific internal XML containers and can be created and filled with or without <see cref="IConfService">IConfService</see> usage.
  /// </para>
  /// </summary>
  /// <seealso cref="GCOMApplicationConfiguration">GCOMApplicationConfiguration</seealso>
  [Serializable]
  public class GApplicationConfiguration : AbstractToStringObject,IGApplicationConfiguration
  {
    #region private properties
    private IGServerInfo _serverInfo;
    #endregion private properties
    #region constructors
    ///<summary>
    /// Default empty constructor.
    /// Creates uninitialized configuration object.
    /// </summary>
    public GApplicationConfiguration()
    {
    }
    /// <summary>
    /// Coping constructor.<br/>
    /// <remarks>It does not clone referred structures like <see cref="ServerInfo"/>.</remarks>
    /// </summary>
    /// <param name="appConfig">Original configuration.</param>
    public GApplicationConfiguration(IGApplicationConfiguration appConfig)
    {
      if (appConfig==null)
        throw new ArgumentNullException("appConfig");
      ApplicationName = appConfig.ApplicationName;
      ApplicationType = appConfig.ApplicationType;
      Dbid = appConfig.Dbid;
      ObjectState = appConfig.ObjectState;
      Version = appConfig.Version;
      IsServer = appConfig.IsServer;
      IsPrimary = appConfig.IsPrimary;
      ServerInfo = appConfig.ServerInfo==null?null:new GServerInfo(appConfig.ServerInfo);
      RedundancyType = appConfig.RedundancyType;
      if (appConfig.PortInfos == null)
      {
        PortInfos = null;
      }
      else
      {
        PortInfos = new List<IGPortInfo>();
        foreach (IGPortInfo info in appConfig.PortInfos)
        {
          PortInfos.Add(new GPortInfo(info));
        }
      }
      Options = appConfig.Options;
      UserProperties = appConfig.UserProperties;
      FlexibleProperties = appConfig.FlexibleProperties;
      if (appConfig.AppServers == null)
      {
        AppServers = null;
      }
      else
      {
        AppServers = new List<IGAppConnConfiguration>();
        foreach (IGAppConnConfiguration appServer in appConfig.AppServers)
        {
          if (appServer!=null)
            AppServers.Add(new GAppConnConfiguration(appServer));
        }
      }
      if (appConfig.Tenants == null)
      {
        Tenants = null;
      }
      else
      {
        Tenants = new List<IGTenantInfo>();
        foreach (IGTenantInfo info in appConfig.Tenants)
        {
          if (info!=null)
            Tenants.Add(new GTenantInfo(info));
        }
      }
    }

    #endregion constructors
    #region public properties
    /// <summary>
    /// Returns/sets the application name.
    /// It represents the correspondent name in Genesys Configuration framework.
    /// </summary>
    public string ApplicationName { get; set; }
    /// <summary>
    /// Returns/sets type of the application in terms of Genesys Configuration framework.
    /// </summary>
    public CfgAppType? ApplicationType{ get; set; }
    /// <summary>
    ///  Returns/sets unique application object identifier in context of Genesys Configuration Database.
    /// </summary>
    public int? Dbid{ get; set; }
    /// <summary>
    /// Returns/sets actual object state in the Genesys Configuration Database.
    /// </summary>
    public CfgObjectState? ObjectState{ get; set; }
    /// <summary>
    /// Returns indicator of whether this application can be a server to some other applications.
    /// This value depends on the application type - <see cref="ApplicationType"/>.
    /// </summary>
    public bool? IsServer{ get; set; }
    /// <summary>
    /// Returns/sets indicator of whether this application can be a server to some other applications.
    /// </summary>
    public bool? IsPrimary{ get; set; }
    /// <summary>
    /// Returns/sets the application version.
    /// </summary>
    public string Version{ get; set; }
    /// <summary>
    /// Returns/sets structure with server type application specific properties.
    /// </summary>
    public IGServerInfo ServerInfo
    {
      get { return _serverInfo; }
      set
      {
        var cServInfo = value as ICloneable;
        if (cServInfo != null)
        {
          _serverInfo = cServInfo.Clone() as IGServerInfo ?? value;
        }
        else
        {
          _serverInfo = value;
        }
      }
    }
    /// <summary>
    /// Returns pointer to the list of structures of type <see cref="IGPortInfo"/> containing information 
    /// about listening ports for this server application.
    /// </summary>
    public List<IGPortInfo> PortInfos{ get; set; }
    /// <summary>
    /// Selects listening port configuration by specified port name (id).
    /// It searches for value in <see cref="PortInfos"/>.
    /// </summary>
    /// <param name="portId">listening port name (id) to look for</param>
    /// <returns>listening port configuration or null</returns>
    /// <seealso cref="PortInfos"/>,<seealso cref="PortInfo(IEnumerable&lt;IGPortInfo&gt;, string)"/>
    public IGPortInfo PortInfo(string portId)
    {
      return PortInfo(PortInfos, portId);
    }
    /// <summary>
    /// Utility method to select listening port configuration by specified port name (id).
    /// </summary>
    /// <param name="portInfos">list of port descriptions to select from</param>
    /// <param name="portId">listening port name (id) to look for</param>
    /// <returns>listening port configuration or null</returns>
    public static IGPortInfo PortInfo(IEnumerable<IGPortInfo> portInfos, string portId)
    {
      if (portInfos == null) return null;
      return portInfos.FirstOrDefault(info => info.Id.Equals(portId));
    }
    /// <summary>
    /// Selects single connected application with specific application type.
    /// It searches for values in <see cref="AppServers"/>.
    /// </summary>
    /// <param name="type"></param>
    /// <returns></returns>
    public IGAppConnConfiguration GetAppServer(CfgAppType type) {
        List<IGAppConnConfiguration> connected = GetAppServers(AppServers, type);
        if (connected == null || connected.Count==0) {
            return null;
        }
        //if (connected.size() > 1) {
            // throw new Configuration exception // todo ?
        //}
        return connected[0];
    }
    /// <summary>
    /// Selects subset of connected applications with specific application type.
    /// It searches for values in <see cref="AppServers"/>.
    /// </summary>
    /// <param name="type"></param>
    /// <returns></returns>
    public List<IGAppConnConfiguration> GetAppServers(CfgAppType type)
    {
      return GetAppServers(AppServers, type);
    }

    /// <summary>
    /// Utility method to select subset of connected applications with specific application type.
    /// </summary>
    /// <param name="allConnections">list of applications connections to select from</param>
    /// <param name="type">application type to look for</param>
    /// <returns>list of connected applications with specific type or null</returns>
    public static List<IGAppConnConfiguration> GetAppServers(
      IEnumerable<IGAppConnConfiguration> allConnections, CfgAppType type)
    {
      List<IGAppConnConfiguration> selectedItems = null;
      if (allConnections != null)
      {
        selectedItems = new List<IGAppConnConfiguration>();
        foreach (IGAppConnConfiguration item in allConnections)
        {
          if (item.TargetServerConfiguration != null
              && item.TargetServerConfiguration.ApplicationType == type)
          {
            selectedItems.Add(item);
          }
        }
      }
      return selectedItems;
    }
    /// <summary>
    /// Returns/sets the HA type if this application is considered as server.
    /// </summary>
    public CfgHAType? RedundancyType{ get; set; }
    /// <summary>
    ///  Returns/sets list of structures describing connected server applications.
    /// </summary>
    public List<IGAppConnConfiguration> AppServers{ get; set; }
    /// <summary>
    ///  Returns/sets list of application-specific configuration options.
    /// </summary>
    public KeyValueCollection Options{ get; set; }
    /// <summary>
    /// Returns/sets list of user-defined properties.
    /// It represents the "Annex" tab of the application object in CME.
    /// </summary>
    public KeyValueCollection UserProperties{ get; set; }
    /// <summary>
    ///  Gets/sets list of additional properties.
    /// </summary>
    public KeyValueCollection FlexibleProperties{ get; set; }
    /// <summary>
    /// Returns/sets list with information about tenants that are served by this application.<br/>
    /// This value may be <code>null</code> if tenants information was not read/requested
    /// (by default it is not requested).
    /// </summary>
    public List<IGTenantInfo> Tenants { get; set; }
    #endregion public properties
    #region override

    private int CalculateHash()
    {
      int hash = GetType().GetHashCode();
      if (ApplicationName != null) hash ^= 17*ApplicationName.GetHashCode();
      if (ApplicationType != null) hash ^= 23*ApplicationType.GetHashCode();
      if (Dbid != null) hash ^= 29*Dbid.Value.GetHashCode();
      if (ObjectState != null) hash ^= 31*ObjectState.GetHashCode();
      if (IsServer != null) hash ^= 37*IsServer.Value.GetHashCode();
      if (IsPrimary != null) hash ^= 41*IsPrimary.Value.GetHashCode();
      if (ServerInfo != null) hash ^= 43*ServerInfo.GetHashCode();
      if (PortInfos != null)
      {
        hash = PortInfos
          .Where(info => info != null)
          .Aggregate(hash, (current, info) => current ^ 47*info.GetHashCode());
      }
      if (RedundancyType != null) hash ^= 53*RedundancyType.Value.GetHashCode();
      if (AppServers != null)
      {
        hash = AppServers
          .Where(appServer => appServer != null)
          .Aggregate(hash, (current, appServer) => current ^ 59*appServer.GetHashCode());
      }
      if (Tenants != null)
      {
        hash = Tenants
          .Where(info => info != null)
          .Aggregate(hash, (current, info) => current ^ 47 * info.GetHashCode());
      }
      if (Options != null) hash ^= 13*Options.GetHashCode();
      if (UserProperties != null) hash ^= 11*UserProperties.GetHashCode();
      if (FlexibleProperties != null) hash ^= 7*FlexibleProperties.GetHashCode();
      return hash;
    }
    /// <exclude/>
    public override int GetHashCode()
    {
      return CalculateHash();
    }
    /// <exclude/>
    public override bool Equals(object obj)
    {
      var gappCfg = obj as GApplicationConfiguration;

      return (ReferenceEquals(this, obj) || (
        (gappCfg != null)
        && (gappCfg.GetType() == GetType())
        && (ApplicationName.EqualsObjects(gappCfg.ApplicationName))
        && (ApplicationType.EqualsObjects(gappCfg.ApplicationType))
        && (Dbid.EqualsObjects(gappCfg.Dbid))
        && (ObjectState.EqualsObjects(gappCfg.ObjectState))
        && (IsServer.EqualsObjects(gappCfg.IsServer))
        && (IsPrimary.EqualsObjects(gappCfg.IsPrimary))
        && (ServerInfo.EqualsObjects(gappCfg.ServerInfo))
        && (PortInfos.EqualsObjects(gappCfg.PortInfos))
        && (Tenants.EqualsObjects(gappCfg.Tenants))
        && (RedundancyType.EqualsObjects(gappCfg.RedundancyType))
        && (AppServers.EqualsObjects(gappCfg.AppServers))
        && (Options.EqualsObjects(gappCfg.Options))
        && (UserProperties.EqualsObjects(gappCfg.UserProperties))
        && (FlexibleProperties.EqualsObjects(gappCfg.FlexibleProperties))
        ));
    }
    /// <exclude/>
    public virtual object Clone()
    {
      var result = (GApplicationConfiguration) MemberwiseClone();
      if (Options != null)
        result.Options = (KeyValueCollection) Options.Clone();
      if (UserProperties != null)
        result.UserProperties = (KeyValueCollection)UserProperties.Clone();
      if (FlexibleProperties != null)
        result.FlexibleProperties = (KeyValueCollection)FlexibleProperties.Clone();
      var serverInfo = _serverInfo as ICloneable;
      if (serverInfo != null)
        result._serverInfo = serverInfo.Clone() as IGServerInfo ?? result._serverInfo;
      if (PortInfos != null)
      {
        result.PortInfos = new List<IGPortInfo>();
        foreach (IGPortInfo info in PortInfos)
        {
          var cloneable = info as ICloneable;
          result.PortInfos.Add((cloneable == null) 
            ? info 
            : cloneable.Clone() as IGPortInfo ?? info);
        }
      }
      if (Tenants != null)
      {
        result.Tenants = new List<IGTenantInfo>();
        foreach (IGTenantInfo info in Tenants)
        {
          var cloneable = info as ICloneable;
          result.Tenants.Add((cloneable == null)
            ? info
            : cloneable.Clone() as IGTenantInfo?? info);
        }
      }
      if (AppServers != null)
      {
        result.AppServers = new List<IGAppConnConfiguration>();
        foreach (IGAppConnConfiguration info in AppServers)
        {
          var cloneable = info as ICloneable;
          result.AppServers.Add((cloneable == null) 
            ? info 
            : cloneable.Clone() as IGAppConnConfiguration ?? info);
        }
      }
      return result;
    }

    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder();
      if (ApplicationName != null)
        sb.Append(prefix).Append("ApplicationName: ").AppendLine(ApplicationName);
      if (ApplicationType != null)
        sb.Append(prefix).Append("ApplicationType: ").AppendLine(ApplicationType.Value.ToString("F"));
      if (Dbid!= null)
        sb.Append(prefix).Append("DBID: ").AppendLine(Dbid.Value.ToString(CultureInfo.InvariantCulture));
      if (ObjectState!= null)
        sb.Append(prefix).Append("ObjectState: ").AppendLine(ObjectState.Value.ToString("F"));
      if (Version != null)
        sb.Append(prefix).Append("Version: ").AppendLine(Version);
      if (IsServer != null)
        sb.Append(prefix).Append("IsServer: ").AppendLine(IsServer.Value.ToString());
      if (IsPrimary != null)
        sb.Append(prefix).Append("IsPrimary: ").AppendLine(IsPrimary.Value.ToString());
      if (RedundancyType != null)
        sb.Append(prefix).Append("RedundancyType: ").AppendLine(RedundancyType.Value.ToString("F"));
      if (ServerInfo != null)
      {
        sb.Append(prefix).Append("ServerInfo: ");
        var si = ServerInfo as IToStringIdent;
        sb.AppendLine(si != null ? si.ToString(prefix) : ServerInfo.ToString());
      }
      if (PortInfos != null)
      {
        sb.Append(prefix).Append("PortInfos: ");
        PortInfos.ToString(sb, prefix);
      }
      if (Options!=null)
        sb.Append(prefix).Append("Options: ").AppendLine(Options.ToString().AddIdent(prefix, false));
      if (UserProperties!= null)
        sb.Append(prefix).Append("UserProperties: ").AppendLine(UserProperties.ToString().AddIdent(prefix, false));
      if (FlexibleProperties!= null)
        sb.Append(prefix).Append("FlexibleProperties: ").AppendLine(FlexibleProperties.ToString().AddIdent(prefix, false));
      if (AppServers != null)
      {
        sb.Append(prefix).Append("AppServers: ");
        AppServers.ToString(sb, prefix);
      }
      if (Tenants != null)
      {
        sb.Append(prefix).Append("Tenants: ");
        Tenants.ToString(sb, prefix);
      }

      return sb.ToString();
    }

    #endregion override
  }

  internal static class EqualsHelper
  {
    public static bool EqualsObjects(this object obj1, object obj2)
    {
      if (obj1 == null) return (obj2 == null) ;
      if (obj2 == null) return false;
      if (ReferenceEquals(obj1, obj2)) return true;
      if (obj1.GetType() != obj2.GetType()) return false;
      var list1 = obj1 as IList;
      if (list1 != null)
      {
        var list2 = obj2 as IList;
        if (list2==null) return false;
        if (list1.Count!=list2.Count) return false;
        for (int i=0;i<list1.Count;i++)
          if (!list1[i].EqualsObjects(list2[i])) return false;
        return true;
      }
      return obj1.Equals(obj2);
    }
  }

  internal static class AppTemplateToStringHelper
  {
    internal const string PrefixString = "    ";
    internal static void ToString<T>(this IEnumerable<T> list, StringBuilder sb, string prefix) where T:class
    {
      if (sb == null) return;
      sb.AppendLine("[");
      int count = 0;
      var basePrefix = prefix;
      prefix = prefix + PrefixString;
      foreach (T obj in list)
      {
        if (obj==null)
          if (count++ != 0) sb.AppendLine(",");
        sb.Append(prefix);
        var idented = obj as IToStringIdent;
        if (idented != null)
          sb.Append(idented.ToString(prefix));
        else
          sb.Append(obj);
      }
      sb.AppendLine().Append(basePrefix).AppendLine("]");
    }
    /*
    internal static string AddIdent(this string value, string ident)
    {
      var sb = new StringBuilder();
      bool first = true;
      foreach (string s in value.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries))
      {
        if (!first) sb.Append('\n');
        first = false;
        sb.Append(ident).Append(s);
      }
      return sb.ToString();
    }
    */
    internal static string AddIdent(this string value, string ident, bool useFirst)
    {
      var sb = new StringBuilder();
      bool first = true;
      foreach (string s in value.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries))
      {
        if (!first) sb.Append('\n');
        first = false;
        if (useFirst) sb.Append(ident);
        useFirst = true;
        sb.Append(s);
      }
      return sb.ToString();
    }
  }
}

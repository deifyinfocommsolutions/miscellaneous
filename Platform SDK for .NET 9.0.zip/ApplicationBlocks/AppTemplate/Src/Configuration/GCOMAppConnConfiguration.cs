//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// This class is an extension of base <see cref="GAppConnConfiguration"/> structure
  /// with logic related to COM AB information extraction as detached configuration data.
  /// <p/>It is designed for usage by <see cref="GCOMApplicationConfiguration"/> container.
  /// </summary>
  [Serializable]
// ReSharper disable once InconsistentNaming
  public class GCOMAppConnConfiguration : GAppConnConfiguration
  {
    [NonSerialized]
    private readonly CfgConnInfo _connInfo;
    /// <summary>
    /// Returns reference to the original COM AB configuration structure.
    /// </summary>
    public CfgConnInfo CfgConnInfo{get { return _connInfo; }}
    /// <summary>
    /// Structure constructor for extraction of configuration data
    /// from Genesys Configuration Server objects and structures
    /// represented with COM AB.
    /// </summary>
    /// <param name="connInfo">COM AB structure with initial information</param>
    public GCOMAppConnConfiguration(CfgConnInfo connInfo):this(connInfo, true){}

    /// <summary>
    /// Structure constructor for extraction of configuration data
    /// from Genesys Configuration Server objects and structures
    /// represented with COM AB.
    /// </summary>
    /// <param name="connInfo">COM AB structure with initial information</param>
    /// <param name="readClusterConnections"></param>
    public GCOMAppConnConfiguration(CfgConnInfo connInfo, bool readClusterConnections):
      this(connInfo, readClusterConnections, false){}

    /// <summary>
    /// Structure constructor for extraction of configuration data
    /// from Genesys Configuration Server objects and structures
    /// represented with COM AB.
    /// </summary>
    /// <param name="connInfo">COM AB structure with initial information</param>
    /// <param name="readClusterConnections"></param>
    /// <param name="readTenantsInfo"></param>
    public GCOMAppConnConfiguration(CfgConnInfo connInfo, bool readClusterConnections, bool readTenantsInfo)
    {
      if (connInfo == null)
      {
        throw new ConfigurationException("CfgConnInfo is null");
      }
      PortId = connInfo.Id;
      ConnProtocol = connInfo.ConnProtocol;
      TimeoutLocal = connInfo.TimoutLocal;
      TimeoutRemote = connInfo.TimoutRemote;
      TraceMode = connInfo.Mode;
      TransportParams = connInfo.TransportParams;
      AppParams = connInfo.AppParams;
      ProxyParams = connInfo.ProxyParams;
      Description = connInfo.Description;
      CfgApplication connApp;
      try
      {
        connApp = connInfo.AppServer;
      }
      catch (Exception e)
      {
        throw new ConfigurationException(
          "Exception while retrieving connected CfgApplication", e);
      }
      if (connApp == null)
      {
        throw new ConfigurationException(
          "Failed to retrieve connected CfgApplication");
      }
      TargetServerConfiguration = new GCOMApplicationConfiguration(connApp,
        readClusterConnections && CfgAppType.CFGApplicationCluster.Equals(connApp.Type),
        false, readTenantsInfo);
      _connInfo = connInfo;
    }
    /// <summary>
    /// Copying constructor.<br/>
    /// Note: It creates new <see cref="GCOMAppConnConfiguration"/> instance,
    /// but does not clone referred structure <see cref="GAppConnConfiguration.TargetServerConfiguration"/>.
    /// </summary>
    /// <param name="conf">original configuration to copy configuration values from</param>
    public GCOMAppConnConfiguration(GCOMAppConnConfiguration conf) : this(conf._connInfo)
    {
      _connInfo = conf._connInfo;
    }
    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder(base.ContentToString(prefix));
      sb.Append(prefix).Append("CfgConnInfo: ").Append(_connInfo==null).AppendLine();
      return sb.ToString();
    }
  }
}

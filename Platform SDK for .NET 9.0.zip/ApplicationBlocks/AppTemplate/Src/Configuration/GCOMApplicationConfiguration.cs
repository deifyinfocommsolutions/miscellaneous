//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// This class represents base Genesys CME application options,
  /// which can be loaded from initialized COM AB <see cref="CfgApplication"/>,
  /// its' related objects and structures.
  /// <para>It extends base class <see cref="IGApplicationConfiguration"/> with only one feature -
  /// constructor, which can initialize the application configuration properties with 
  /// information retrieved from COM AB application object.
  /// </para>
  /// <para>COM AB direct usage example: 
  /// <example><code>
  ///   String appName = "&lt;app-name&gt;";
  ///   CfgApplication cfgApplication = confService.RetrieveObject&lt;CfgApplication&gt;
  ///     (new CfgApplicationQuery(service) { Name = appName });
  ///   GCOMApplicationConfiguration appConfiguration =
  ///          new GCOMApplicationConfiguration(cfgApplication);
  /// </code></example>
  /// </para>
  /// </summary>
  [Serializable]
  public class GCOMApplicationConfiguration : GApplicationConfiguration
  {
    [NonSerialized]
    private readonly CfgApplication _cfgApplication;
    /// <summary>
    /// Returns reference to the original COM AB configuration structure.
    /// </summary>
    public CfgApplication CfgApplication{get { return _cfgApplication; }}

    /// <summary>
    /// Loads application configuration properties from given COM AB CfgApplication
    /// object including configuration of connected CfgApplication's and CfgHost's.
    /// </summary>
    /// <param name="cfgApplication">application properties represented as COM AB application object</param>
    /// <seealso cref="GCOMApplicationConfiguration">GCOMApplicationConfiguration</seealso>
    /// <seealso cref="GCOMApplicationConfiguration(CfgApplication, bool)">GCOMApplicationConfiguration(CfgApplication, bool)</seealso>
    public GCOMApplicationConfiguration(CfgApplication cfgApplication) : this(cfgApplication, true) { }

    /// <summary>
    /// Loads application configuration properties from given COM AB CfgApplication
    /// object including configuration of connected CfgApplication's and CfgHost's.
    /// </summary>
    /// <param name="cfgApplication">application properties represented as COM AB application object</param>
    /// <param name="readConnection">flag indicating needs to read connected applications configuration</param>
    /// <seealso cref="GCOMApplicationConfiguration">GCOMApplicationConfiguration</seealso>
    public GCOMApplicationConfiguration(CfgApplication cfgApplication, bool readConnection)
      : this(cfgApplication, readConnection, readConnection)
    {}

    /// <summary>
    /// Loads application configuration properties from given COM AB CfgApplication
    /// object including configuration of connected CfgApplication's and CfgHost's.
    /// </summary>
    /// <param name="cfgApplication">application properties represented as COM AB application object</param>
    /// <param name="readConnection">flag indicating needs to read connected applications configuration</param>
    /// <param name="readClusterConnections">flag indicating needs to read connected applications clusters configuration</param>
    /// <seealso cref="GCOMApplicationConfiguration">GCOMApplicationConfiguration</seealso>
    public GCOMApplicationConfiguration(CfgApplication cfgApplication, bool readConnection, bool readClusterConnections)
      :this(cfgApplication, readConnection, readClusterConnections, false)
    {
    }

    /// <summary>
    /// Loads application configuration properties from given COM AB CfgApplication
    /// object including configuration of connected CfgApplication's and CfgHost's.
    /// </summary>
    /// <param name="cfgApplication">application properties represented as COM AB application object</param>
    /// <param name="readConnection">flag indicating needs to read connected applications configuration</param>
    /// <param name="readClusterConnections">flag indicating needs to read connected applications clusters configuration</param>
    /// <param name="readTenantsInfo">flag indicating needs to read applications tenants information</param>
    /// <seealso cref="GCOMApplicationConfiguration">GCOMApplicationConfiguration</seealso>
    public GCOMApplicationConfiguration(CfgApplication cfgApplication, bool readConnection, bool readClusterConnections, bool readTenantsInfo)
    {
      if (cfgApplication==null)
        throw new ArgumentNullException("cfgApplication");
      ApplicationName = cfgApplication.Name;
      ApplicationType = cfgApplication.Type;
      Dbid = cfgApplication.DBID;
      ObjectState = cfgApplication.State;
      Version = cfgApplication.Version;
      IsServer = EnumFactory.CfgFlag2Boolean(cfgApplication.IsServer);
      if ((IsServer != null) && (IsServer.Value))
      {
        IsPrimary = EnumFactory.CfgFlag2Boolean(cfgApplication.IsPrimary);
        var srvInfo = cfgApplication.ServerInfo;
        if (srvInfo != null)
        {
          ServerInfo = new GCOMServerInfo(srvInfo);
        }
        RedundancyType = cfgApplication.RedundancyType;
        var portInfos = cfgApplication.PortInfos;
        if (portInfos != null)
        {
          PortInfos = portInfos.Select(info => new GCOMPortInfo(info))
            .Cast<IGPortInfo>().ToList();
        }
      }
      Options = cfgApplication.Options;
      UserProperties = cfgApplication.UserProperties;
      FlexibleProperties = cfgApplication.FlexibleProperties;
      if (readTenantsInfo) {
            var tenants = cfgApplication.Tenants;
            if (tenants != null)
            {
              Tenants = tenants.Select(tenant => new GCOMTenantInfo(tenant)).Cast<IGTenantInfo>().ToList();
            }
        }
      if (readConnection)
      {
        var connInfos = cfgApplication.AppServers;
        if (connInfos != null)
        {
           var connections = new List<IGAppConnConfiguration>();
           var thisIsCluster = CfgAppType.CFGApplicationCluster.Equals(cfgApplication.Type);
           foreach (CfgConnInfo connInfo in connInfos) {
                    CfgApplication cfgConn = connInfo.AppServer;
                    if (cfgConn != null) {
                        connections.Add(new GCOMAppConnConfiguration(connInfo,
                                readClusterConnections && !thisIsCluster,
                                readTenantsInfo));
                    }
                }

          //var connections =
          //  connInfos.Select(info => new GCOMAppConnConfiguration(info))
          //  .Cast<IGAppConnConfiguration>().ToList();
          AppServers = connections;
        }
      }
      _cfgApplication = cfgApplication;

    }
    /// <summary>
    /// Copying constructor.<br/>
    /// Note: It creates new <see cref="GCOMApplicationConfiguration"/> instance,
    /// but does not clone referred structures like <see cref="CfgApplication"/>,
    /// <see cref="GApplicationConfiguration.GetAppServers(CfgAppType)"/>,<see cref="GApplicationConfiguration.PortInfos"/>,
    /// <see cref="CfgApplication"/>
    /// </summary>
    /// <param name="conf">original configuration to copy configuration values from</param>
    /// <seealso cref="GCOMApplicationConfiguration">GCOMApplicationConfiguration</seealso>
    public GCOMApplicationConfiguration(GCOMApplicationConfiguration conf)
      : this(conf.CfgApplication)
    {}

    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder(base.ContentToString(prefix));
      sb.Append(prefix).Append("CfgApplication: ").Append(ApplyIdent(_cfgApplication.ToString(),prefix)).AppendLine();
      return sb.ToString();
    }
  }
}

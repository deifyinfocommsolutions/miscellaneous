//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// This class is an extension of base <see cref="GPortInfo"/> structure
  /// with logic related to COM AB information extraction as detached configuration data.
  /// It is designed for usage by <see cref="GCOMApplicationConfiguration"/> container.
  /// </summary>
  /// <seealso cref="GPortInfo"/>,<seealso cref="CfgPortInfo"/>
  [Serializable]
  public class GCOMPortInfo : GPortInfo
  {
    [NonSerialized]
    private readonly CfgPortInfo _portInfo;

    /// <summary>
    /// Returns reference to the original COM AB configuration structure.
    /// </summary>
    public CfgPortInfo PortInfo { get { return _portInfo; } }

    /// <summary>
    /// Structure constructor for extraction of configuration data
    /// from Genesys Configuration Server objects and structures
    /// represented with COM AB.
    /// </summary>
    /// <param name="portInfo">COM AB structure with initial information</param>
    public GCOMPortInfo(CfgPortInfo portInfo)
    {
      if (portInfo == null)
      {
        throw new ConfigurationException("CfgPortInfo");
      }
      Id = portInfo.Id;
      Port = Int32.Parse(portInfo.Port);
      ConnProtocol = portInfo.ConnProtocol;
      TransportParams = portInfo.TransportParams;
      AppParams = portInfo.AppParams;
      Description = portInfo.Description;
      _portInfo = portInfo;
    }
    /// <summary>
    /// Copying constructor.
    /// </summary>
    /// <param name="info">original configuration to copy configuration values from</param>
    public GCOMPortInfo(GCOMPortInfo info) : this(info.PortInfo)
    {
    }

    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder(base.ContentToString(prefix));
      sb.Append(prefix).Append("CfgPortInfo: ").Append(_portInfo!=null).AppendLine();
      return sb.ToString();
    }
  }
}

//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// This class is an extension of base <see cref="GServerInfo"/> structure
  /// with logic related to COM AB information extraction as detached configuration data.
  /// <br/>It is designed for usage by <see cref="GCOMApplicationConfiguration"/> container.
  /// </summary>
  /// <seealso cref="GServerInfo"/>,<seealso cref="CfgServer"/>
  [Serializable]
  public class GCOMServerInfo:GServerInfo
  {
    [NonSerialized]
    private readonly CfgServer _serverInfo;

    /// <summary>
    /// Returns reference to the original COM AB configuration structure.
    /// </summary>
    public CfgServer CfgServerInfo { get { return _serverInfo; } }
    /// <summary>
    /// Structure constructor for extraction of configuration data
    /// from Genesys Configuration Server objects and structures
    /// represented with COM AB.
    /// </summary>
    /// <param name="serverInfo">COM AB structure with initial information</param>
    public GCOMServerInfo(CfgServer serverInfo)
    {
      if (serverInfo == null)
      {
        throw new ConfigurationException("CfgServerInfo is null");
      }
      CfgHost cfgHost;
      try
      {
        cfgHost = serverInfo.Host;
      }
      catch (Exception e)
      {
        throw new ConfigurationException(
          "Exception retrieving referred CfgHost", e);
      }
      if (cfgHost != null)
      {
        Host = new GCOMHost(cfgHost);
      }
      Port = serverInfo.Port;
      Timeout = serverInfo.Timeout;
      Attempts = serverInfo.Attempts;
      CfgApplication backupApp;
      try
      {
        backupApp = serverInfo.BackupServer;
      }
      catch (Exception e)
      {
        throw new ConfigurationException(
          "Exception retrieving referred backup CfgApplication", e);
      }
      if (backupApp != null)
      {
        Backup = new GCOMApplicationConfiguration(backupApp, false);
      }
      _serverInfo = serverInfo;
    }

    /// <summary>
    /// Copying constructor.
    /// </summary>
    /// <param name="info">original configuration to copy configuration values from</param>
    public GCOMServerInfo(GCOMServerInfo info)
      : this(info.CfgServerInfo)
    {
      
    }
    /// <exclude/>
    internal protected override string ContentToString(string prefix)
    {
      var sb = new StringBuilder(base.ContentToString(prefix));
      sb.Append(prefix).Append("CfgServerInfo: ").Append(_serverInfo!=null).AppendLine();
      return sb.ToString();
    }

  }
}

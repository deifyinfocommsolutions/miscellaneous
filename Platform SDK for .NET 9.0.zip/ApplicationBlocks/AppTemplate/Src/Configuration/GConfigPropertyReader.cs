//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Connection.Configuration;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Property reader that extracts option values from configuration objects. 
  /// </summary>
  public class GConfigPropertyReader : IPropertyReader
  {
    private const String KeyTargetServerHost = "psdk-internal-target-server-host";

    private readonly String _defaultSectionName;

    /// <exclude/>
    protected readonly IGApplicationConfiguration AppConfig;
    /// <exclude/>
    protected readonly IGPortInfo PortConfig;
    /// <exclude/>
    protected readonly IGAppConnConfiguration ConnConfig;
    /// <exclude/>
    protected readonly IGHost HostConfig;

    private readonly IGApplicationConfiguration _targetServerConfig;

    /// <summary>
    /// Creates configuration reader for server application. Host configuration object is taken from
    /// Application object property.
    /// </summary>
    /// <param name="appConfig">Server Application configuration object</param>
    /// <param name="portConfig">Port configuration object</param>
    /// <param name="defaultSectionName">Name of section to look into for options, must not be null, can be empty string</param>
    public GConfigPropertyReader(IGApplicationConfiguration appConfig,
      IGPortInfo portConfig, String defaultSectionName)
    {
      AppConfig = appConfig;
      PortConfig = portConfig;
      if ((null != appConfig) && (null != appConfig.ServerInfo))
      {
        HostConfig = appConfig.ServerInfo.Host;
      }
      _defaultSectionName = defaultSectionName;
    }

    /// <summary>
    /// Creates configuration reader for client application. 
    /// </summary>
    /// <param name="appConfig">Client Application configuration object</param>
    /// <param name="connConfig">Connection configuration object, which connects Client to target Server</param>
    /// <param name="defaultSectionName">Name of section to look into for options, must not be null, can be empty string</param>
    public GConfigPropertyReader(IGApplicationConfiguration appConfig,
      IGAppConnConfiguration connConfig, String defaultSectionName)
    {
      AppConfig = appConfig;
      ConnConfig = connConfig;
      if ((null != appConfig) && (null != appConfig.ServerInfo))
      {
        HostConfig = appConfig.ServerInfo.Host;
      }
      _defaultSectionName = defaultSectionName;
    }

    /// <summary>
    /// Creates configuration reader for server application. Host configuration object is taken from Application object property.
    /// </summary>
    /// <param name="appConfig">Client Application configuration object</param>
    /// <param name="connConfig">Connection configuration object, which connects Client to target Server</param>
    /// <param name="targetServerConfig">Target server configuration.</param>
    /// <param name="defaultSectionName">Name of section to look into for options, must not be null, can be empty string</param>
    public GConfigPropertyReader(IGApplicationConfiguration appConfig, IGAppConnConfiguration connConfig,
      IGApplicationConfiguration targetServerConfig, String defaultSectionName)
    {
      AppConfig = appConfig;
      ConnConfig = connConfig;
      if ((null != appConfig) && (null != appConfig.ServerInfo))
      {
        HostConfig = appConfig.ServerInfo.Host;
      }
      _defaultSectionName = defaultSectionName;
      _targetServerConfig = targetServerConfig;
    }
    /// <exclude/>
    public object Clone()
    {
      return new GConfigPropertyReader(AppConfig, ConnConfig, _targetServerConfig, _defaultSectionName);
    }

    ///<summary>
    /// Combined code for both client and server cases.
    /// For client, it is expected that only <see cref="ConnConfig"/> and <see cref="AppConfig"/> are non-null;
    /// for server, only <see cref="PortConfig"/>, <see cref="AppConfig"/> and <see cref="HostConfig"/>.
    /// </summary>
    /// <param name="optionName">Name of option to find in the specified configuration objects</param>
    /// <returns>Option value</returns>
    public virtual String GetProperty(String optionName)
    {
      String optionValue = null;
      if (KeyTargetServerHost.Equals(optionName))
      {
        if (ConnConfig != null)
        {
          var targetServerConfiguration = _targetServerConfig ?? ConnConfig.TargetServerConfiguration;
          if (targetServerConfiguration != null)
          {
            IGServerInfo srvInfo = targetServerConfiguration.ServerInfo;
            if (srvInfo != null)
            {
              var host = srvInfo.Host;
              if (host != null)
              {
                optionValue = host.Name;
              }
            }
          }
        }
      }
        
        // 1. portConfig/connConfig
      else if (null != PortConfig)
      {
        optionValue = GetPortOption(optionName, PortConfig);
      }
      else if (null != ConnConfig)
      {
        optionValue = GetConnOption(optionName, ConnConfig);
      }

      if (null != AppConfig)
      {
        // 2. appConfig options/section
        if (null == optionValue)
        {
          optionValue = GetAppOption(optionName, _defaultSectionName, AppConfig);
        }

        // 3. appConfig Annex/section
        if (null == optionValue)
        {
          optionValue = GetAppAnnexOption(optionName, _defaultSectionName, AppConfig);
        }
      }

      // 4. hostConfig Annex/section
      if (null == optionValue)
      {
        if (null != HostConfig)
        {
          optionValue = GetHostAnnexOption(optionName, _defaultSectionName, HostConfig);
        }
      }

      return optionValue;
    }

    /// <exclude/>
    public String GetProperty(OptionDescription optionDescription)
    {
      String optionValue = null;

      String optionName = optionDescription.ConfigOptionName;
      String sectionName = optionDescription.SectionName;
      List<OptionDescription.OptionLocation> locations = optionDescription.Locations;

      if (locations.Contains(OptionDescription.OptionLocation.PortParams) && (null != PortConfig))
      {
        optionValue = GetPortOption(optionName, PortConfig);
        if (null != optionValue) return optionValue;
      }

      if (locations.Contains(OptionDescription.OptionLocation.ConnParams) && (null != ConnConfig))
      {
        optionValue = GetConnOption(optionName, ConnConfig);
        if (null != optionValue) return optionValue;
      }

      if (locations.Contains(OptionDescription.OptionLocation.AppOptions) && (null != AppConfig))
      {
        optionValue = GetAppOption(optionName, sectionName, AppConfig);
        if (null != optionValue) return optionValue;
      }

      if (locations.Contains(OptionDescription.OptionLocation.AppAnnex) && (null != AppConfig))
      {
        optionValue = GetAppAnnexOption(optionName, sectionName, AppConfig);
        if (null != optionValue) return optionValue;
      }

      if (locations.Contains(OptionDescription.OptionLocation.HostAnnex) && (null != HostConfig))
      {
        optionValue = GetHostAnnexOption(optionName, sectionName, HostConfig);
      }
      return optionValue;
    }

    ///<summary>
    /// First, looks into options for an entry with given section name and value of type <see cref="KeyValueCollection"/>.
    /// Then looks in that collection for an entry with name specified in 'optionName' parameter and returns value from the entry.
    /// </summary>
    /// <param name="optionName">Name of option to find</param>
    /// <param name="sectionName"></param>
    /// <param name="options">KeyValueCollection containing specific section with options</param>
    /// <returns>Value for the specified option</returns>
    public static String FindSectionOption(String optionName, String sectionName, KeyValueCollection options)
    {
      String result = null;
      if (null != options)
      {
        var section = options.Get(sectionName) as KeyValueCollection;
        if (null != section)
        {
          result = section.GetAsString(optionName);
        }
      }
      return result;
    }

    /// <exclude/>
    public static String GetPortOption(String optionName, IGPortInfo portConfig)
    {
      return ConfigurationUtil.FindTransportParameter(portConfig.TransportParams, optionName);
    }

    /// <exclude/>
    public static String GetConnOption(String optionName, IGAppConnConfiguration connConfig)
    {
      return ConfigurationUtil.FindTransportParameter(connConfig.TransportParams, optionName);
    }

    /// <exclude/>
    public static String GetAppOption(String optionName, String sectionName,
      IGApplicationConfiguration appConfig)
    {
      return FindSectionOption(optionName, sectionName, appConfig.Options);
    }

    /// <exclude/>
    public static String GetAppAnnexOption(String optionName, String sectionName,
      IGApplicationConfiguration appConfig)
    {
      return FindSectionOption(optionName, sectionName, appConfig.UserProperties);
    }

    /// <exclude/>
    public static String GetHostAnnexOption(String optionName, String sectionName, IGHost hostConfig)
    {
      return FindSectionOption(optionName, sectionName, hostConfig.UserProperties);
    }
  }

  /// <summary>
  /// Property reader that extracts TLS-related option values from configuration objects. 
  /// </summary>
  /// <example>
  /// <code>
  /// String appName = "&lt;my-app-name&gt;";
  /// var cfgApplication = confService.RetrieveObject&lt;CfgApplication&gt;(new CfgApplicationQuery(){Name=appName});
  /// var appConfiguration = new GCOMApplicationConfiguration(cfgApplication);
  /// var portConfig =  appConfiguration.PortInfo("secure");
  /// var tlsConfiguration = new TLSConfiguration(new GConfigTlsPropertyReader(appConfiguration, portConfig));
  /// </code>
  /// </example>
  public class GConfigTlsPropertyReader : GConfigPropertyReader
  {
    private const String SecuritySectionName = "security";
    private const String TLSKeyName = "tls";

    /// <summary>
    /// Creates configuration reader for client application. Host configuration object, if available,
    /// is taken from Application object property.
    /// </summary>
    /// <param name="appConfig">Client Application configuration object</param>
    /// <param name="connConfig">Connection configuration object, which connects Client to target Server</param>
    public GConfigTlsPropertyReader(IGApplicationConfiguration appConfig, IGAppConnConfiguration connConfig)
      : base(appConfig, connConfig, SecuritySectionName)
    {
    }

    /// <summary>
    /// Creates configuration reader for server application. Host configuration object is taken from
    /// Application object property.
    /// </summary>
    /// <param name="appConfig">Server Application configuration object</param>
    /// <param name="portConfig">Port configuration object</param>
    public GConfigTlsPropertyReader(IGApplicationConfiguration appConfig, IGPortInfo portConfig)
      : base(appConfig, portConfig, SecuritySectionName)
    {
    }

    /// <summary>
    /// Creates configuration reader for client application. Host configuration object, if available,
    /// is taken from Application object property.
    /// </summary>
    /// <param name="appConfig">Client Application configuration object</param>
    /// <param name="connConfig">Connection configuration object, which connects Client to target Server</param>
    /// <param name="targetServerConfig">Target server configuration.</param>
    public GConfigTlsPropertyReader(IGApplicationConfiguration appConfig,
      IGAppConnConfiguration connConfig,
      IGApplicationConfiguration targetServerConfig) :
        base(appConfig, connConfig, targetServerConfig, SecuritySectionName)
    {
    }
    /// <summary>
    /// Combined code for both client and server cases.
    /// For client, it is expected that only connConfig and appConfig are non-null; for server, only portConfig, appConfig and hostConfig.
    /// </summary>
    /// <param name="optionName"></param>
    /// <returns></returns>
    public override String GetProperty(String optionName)
    {
      String value = base.GetProperty(optionName);

      if (TLSKeyName.Equals(optionName, StringComparison.InvariantCultureIgnoreCase))
      {
        bool tls = ConfigurationUtil.IsTrue(value) || IsTargetPortSecure();
        value = tls.ToString();
      }
      return value;
    }

    private bool IsTargetPortSecure()
    {
      if (null == ConnConfig) return false;
      IGApplicationConfiguration server = ConnConfig.TargetServerConfiguration;
      if (null == server) return false;
      List<IGPortInfo> ports = server.PortInfos;
      if (null == ports) return false;
      var portId = ConnConfig.PortId;
      if (portId == null) return false;
      IGPortInfo port = ports.FirstOrDefault(info => info.Id.Equals(portId));
      return (null != port) && ConfigurationUtil.IsTrue(
        ConfigurationUtil.FindTransportParameter(port.TransportParams, TLSKeyName));
    }

  }
}

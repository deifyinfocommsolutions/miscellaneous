//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Globalization;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Structure describing host where server is configured to run.
  /// It reflects detached information from COM AB <see cref="CfgHost"/>.
  /// </summary>
  /// <seealso cref="CfgHost"/>
  [Serializable]
  public class GHost : AbstractToStringObject, IGHost
  {
    #region constructors
    /// <summary>
    /// Default empty constructor.
    /// Creates uninitialized configuration object.
    /// </summary>
    public GHost(){}
    /// <summary>
    /// Coping constructor.
    /// <remarks>It does not clone referred structures like <see cref="UserProperties"/>.</remarks>
    /// </summary>
    /// <param name="conf"></param>
    public GHost(IGHost conf)
    {
      if (conf==null)
        throw new ArgumentNullException("conf");
      Name = conf.Name;
      Dbid = conf.Dbid;
      IPAddress = conf.IPAddress;
      LCAPort = conf.LCAPort;
      ObjectState = conf.ObjectState;
      UserProperties = conf.UserProperties;
    }
    #endregion constructors
    #region public properties
    /// <summary>
    /// Gets/sets the host name.
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// Gets/sets the host DBID.
    /// </summary>
    public int? Dbid { get; set; }
    /// <summary>
    /// Gets/sets the host TCP/IP address.
    /// </summary>
    public string IPAddress { get; set; }
    /// <summary>
    /// Gets/sets port number on which the Local Control Agent for this host is supposed to be running.
    /// </summary>
    public string LCAPort { get; set; }
    /// <summary>
    /// Gets/sets actual object state in the Genesys Configuration Database.
    /// </summary>
    public CfgObjectState? ObjectState { get; set; }
    /// <summary>
    /// Gets/sets pointer to the list of user-defined properties.
    /// It represents the "Annex" tab of the host object in CME.
    /// </summary>
    public KeyValueCollection UserProperties { get; set; }
    #endregion public properties
    #region override
    /// <exclude/>
    public virtual object Clone()
    {
      var result = (GHost) MemberwiseClone();
      if (UserProperties != null)
        result.UserProperties = (KeyValueCollection) result.UserProperties.Clone();
      return result;
    }
    /// <exclude/>
    public override int GetHashCode()
    {
      return CaclulateHash();
    }
    private int CaclulateHash()
    {
      var hash = GetType().GetHashCode();
      if (Name != null) hash ^= 7 * Name.GetHashCode();
      if (Dbid != null) hash ^= 11 * Dbid.Value.GetHashCode();
      if (IPAddress != null) hash ^= 13 * IPAddress.GetHashCode();
      if (LCAPort != null) hash ^= 17 * LCAPort.GetHashCode();
      if (ObjectState != null) hash ^= 19 * ObjectState.GetHashCode();
      if (UserProperties != null) hash ^= 23 * UserProperties.GetHashCode();
      return hash;
    }

    /// <exclude/>
    public override bool Equals(object obj)
    {
      var gHost = obj as GHost;
      return (ReferenceEquals(this, obj) || (
           (gHost != null)
        && (gHost.GetType() == GetType())
        && (Name.EqualsObjects(gHost.Name))
        && (Dbid.EqualsObjects(gHost.Dbid))
        && (IPAddress.EqualsObjects(gHost.IPAddress))
        && (LCAPort.EqualsObjects(gHost.LCAPort))
        && (ObjectState.EqualsObjects(gHost.ObjectState))
        && (UserProperties.EqualsObjects(gHost.UserProperties))
        ));

    }
    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder();
      if (Name != null)
        sb.Append(prefix).Append("Name: ").AppendLine(Name);
      if (Dbid != null)
        sb.Append(prefix).Append("DBID: ").AppendLine(Dbid.Value.ToString(CultureInfo.InvariantCulture));
      if (IPAddress != null)
        sb.Append(prefix).Append("IPAddress: ").AppendLine(IPAddress);
      if (LCAPort != null)
        sb.Append(prefix).Append("LCAPort: ").AppendLine(LCAPort);
      if (ObjectState != null)
      {
        sb.Append(prefix).Append("ObjectState: ").AppendLine(ObjectState.Value.ToString("F"));
      }
      if (UserProperties != null)
        sb.Append(prefix).Append("UserProperties: ").AppendLine(UserProperties.ToString().AddIdent(prefix, false));
      return sb.ToString();
    }

    #endregion override
  }
}

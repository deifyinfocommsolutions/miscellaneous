//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// This structure contains properties for listening port of server type application.
  /// </summary>
  /// <seealso cref="CfgPortInfo"/>
  [Serializable]
  public class GPortInfo:AbstractToStringObject, IGPortInfo
  {
    #region public properties
    /// <summary>
    /// Gets/sets servers' port name/identifier.
    /// </summary>
    public string Id { get; set; }
    /// <summary>
    /// Gets/sets TCP/IP port number for listening on by "this" application.
    /// </summary>
    public int? Port { get; set; }
    /// <summary>
    /// Gets/sets name of the connection control protocol.
    /// </summary>
    public string ConnProtocol { get; set; }
    /// <summary>
    /// Gets/sets transport parameters for the listening port.
    /// </summary>
    public string TransportParams { get; set; }
    /// <summary>
    /// Gets/sets application parameters for the listening port.
    /// </summary>
    public string AppParams { get; set; }
    /// <summary>
    /// Gets/sets description of the listening port.
    /// </summary>
    public string Description { get; set; }
    #endregion public properties
    #region Constructors
    /// <summary>
    /// Default empty constructor.
    /// Creates uninitialized configuration object.
    /// </summary>
    public GPortInfo(){}
    /// <summary>
    /// Coping constructor.
    /// </summary>
    /// <param name="conf">original configuration</param>
    public GPortInfo(IGPortInfo conf)
    {
      if (conf == null)
        throw new ArgumentNullException("conf");
      Id = conf.Id;
      Port = conf.Port;
      ConnProtocol = conf.ConnProtocol;
      TransportParams = conf.TransportParams;
      AppParams = conf.AppParams;
      Description = conf.Description;
    }
    #endregion Constructors
    #region override
    /// <exclude/>
    public virtual object Clone()
    {
      return MemberwiseClone();
    }
    /// <exclude/>
    public override int GetHashCode()
    {
      return CaclulateHash();
    }
    private int CaclulateHash()
    {
      var hash = GetType().GetHashCode();
      if (Id != null) hash ^= 7 * Id.GetHashCode();
      if (Port != null) hash ^= 11 * Port.Value.GetHashCode();
      if (ConnProtocol != null) hash ^= 13 * ConnProtocol.GetHashCode();
      if (TransportParams != null) hash ^= 17 * TransportParams.GetHashCode();
      if (AppParams != null) hash ^= 19 * AppParams.GetHashCode();
      if (Description != null) hash ^= 23 * Description.GetHashCode();
      return hash;
    }

    /// <exclude/>
    public override bool Equals(object obj)
    {
      var gPortInfo = obj as GPortInfo;
      return (ReferenceEquals(this, obj) || (
        (gPortInfo != null)
        && (gPortInfo.GetType() == GetType())
        && (Id.EqualsObjects(gPortInfo.Id))
        && (Port.EqualsObjects(gPortInfo.Port))
        && (ConnProtocol.EqualsObjects(gPortInfo.ConnProtocol))
        && (TransportParams.EqualsObjects(gPortInfo.TransportParams))
        && (AppParams.EqualsObjects(gPortInfo.AppParams))
        && (Description.EqualsObjects(gPortInfo.Description))
        ));
    }
    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder();
      if (Id != null)
        sb.Append(prefix).Append("Id: ").AppendLine(Id);
      if (Port != null)
        sb.Append(prefix).Append("Port: ").AppendLine(Port.Value.ToString(CultureInfo.InvariantCulture));
      if (ConnProtocol!= null)
        sb.Append(prefix).Append("ConnProtocol: ").AppendLine(ConnProtocol);
      if (TransportParams != null)
        sb.Append(prefix).Append("TransportParams: ").AppendLine(TransportParams);
      if (AppParams != null)
        sb.Append(prefix).Append("AppParams: ").AppendLine(AppParams);
      if (Description != null)
        sb.Append(prefix).Append("Description: ").AppendLine(Description);
      return sb.ToString();
    }

    #endregion override
  }
}

//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Globalization;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// This structure represents group of server type specific application properties.
  /// </summary>
  /// <seealso cref="CfgServer"/>
  [Serializable]
  public class GServerInfo:AbstractToStringObject,IGServerInfo
  {
    #region private fields
    private IGHost _host;
    private IGApplicationConfiguration _backup;
    #endregion private fields
    #region constructors
    /// <summary>
    /// Default empty constructor.
    /// Creates uninitialized configuration object.
    /// </summary>
    public GServerInfo(){}
    /// <summary>
    /// Coping constructor.
    /// <remarks>It does not clone referred structures like <see cref="Host"/>.</remarks>
    /// </summary>
    /// <param name="conf">Original configuration.</param>
    public GServerInfo(IGServerInfo conf)
    {
      if (conf==null)
        throw new ArgumentNullException("conf");
      _host = conf.Host == null ? null : new GHost(conf.Host);
      Port = conf.Port;
      Attempts = conf.Attempts;
      Timeout = conf.Timeout;
      _backup = conf.Backup == null
        ? conf.Backup
        : (conf.Backup.GetType() == typeof (GApplicationConfiguration)
          ? new GApplicationConfiguration(conf.Backup)
          : conf.Backup);
    }
    #endregion constructors
    #region public properties
    /// <summary>
    /// Gets/sets reference to structure describing host where this server resides.
    /// The 'set' method tries to clone source object.
    /// </summary>
    public IGHost Host
    {
      get { return _host; }
      set
      {
        var cHost = value as ICloneable;
        if (cHost != null)
        {
          _host = cHost.Clone() as IGHost ?? value;
        }
        else
        {
          _host = value;
        }
      }
    }

    /// <summary>
    /// Gets/sets name of the port to connect to on the target server.
    /// </summary>
    public string Port { get; set; }
    /// <summary>
    /// Gets/sets reconnect timeout for connection to the target application.
    /// </summary>
    public int? Timeout { get; set; }
    /// <summary>
    /// Gets/sets number of attempts to connect to this server before trying to connect to the backup server.
    /// </summary>
    public int? Attempts { get; set; }
    /// <summary>
    /// Gets/sets description of server which is to be contacted if connection to this server fails.
    /// The 'set' method tries to clone source object.
    /// </summary>
    public IGApplicationConfiguration Backup 
    {
      get { return _backup; }
      set
      {
        var cCfg = value as ICloneable;
        if (cCfg != null)
        {
          _backup = cCfg.Clone() as IGApplicationConfiguration ?? value;
        }
        else
        {
          _backup = value;
        }
      }
    }
    #endregion public properties
    #region override

    private int CaclulateHash()
    {
      var hash = GetType().GetHashCode();
      if (_host != null) hash ^= 7*_host.GetHashCode();
      if (Port != null) hash ^= 11 * Port.GetHashCode();
      if (Timeout != null) hash ^= 13 * Timeout.Value.GetHashCode();
      if (Attempts != null) hash ^= 17 * Attempts.Value.GetHashCode();
      if (_backup != null) hash ^= 19*_backup.GetHashCode();

      return hash;
    }

    /// <exclude/>
    public override int GetHashCode()
    {
      return CaclulateHash();
    }
    /// <exclude/>
    public override bool Equals(object obj)
    {
      var gServer = obj as GServerInfo;
      return (ReferenceEquals(this, obj) || (
           (gServer != null)
        && (gServer.GetType() == GetType())
        && (Host.EqualsObjects(gServer.Host))
        && (Port.EqualsObjects(gServer.Port))
        && (Attempts.EqualsObjects(gServer.Attempts))
        && (Timeout.EqualsObjects(gServer.Timeout))
        && (Backup.EqualsObjects(gServer.Backup))
        ));
    }
    /// <exclude/>
    public virtual object Clone()
    {
      var result = (GServerInfo)MemberwiseClone();
      var cHost = _host as ICloneable;
      result._host = cHost == null 
        ? _host 
        : cHost.Clone() as IGHost ?? _host;
      var cBackup = _backup as ICloneable;
      result._backup = cBackup == null 
        ? _backup 
        : cBackup.Clone() as IGApplicationConfiguration ?? _backup;
      return result;
    }

    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder();
      if (Host != null)
      {
        sb.Append(prefix).Append("Host: ");
        var gCfg = Host as IToStringIdent;
        sb.AppendLine(gCfg != null ? gCfg.ToString(prefix) : Host.ToString());
      }
      if (Port != null)
        sb.Append(prefix).Append("Port: ").AppendLine(Port);
      if (Attempts != null)
        sb.Append(prefix).Append("Attempts: ").AppendLine(Attempts.Value.ToString(CultureInfo.InvariantCulture));
      if (Timeout != null)
        sb.Append(prefix).Append("Timeout: ").AppendLine(Timeout.Value.ToString(CultureInfo.InvariantCulture));
      if (Backup != null)
      {
        sb.Append(prefix).Append("Backup: ");
        var gCfg = Backup as IToStringIdent;
        sb.AppendLine(gCfg != null ? gCfg.ToString(prefix) : Backup.ToString());
      }
      return sb.ToString();
    }
    #endregion
  }
}

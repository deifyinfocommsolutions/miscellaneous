//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using System.Globalization;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Structure describing Tenant which is referred in the server application configuration.<br/>
  /// It reflects detached information from COM AB <see cref="CfgTenant"/>
  /// </summary>
  [Serializable]
  public class GTenantInfo : AbstractToStringObject, IGTenantInfo, ICloneable
  {
    #region public properties
    /// <summary>
    /// Returns the tenant name.
    /// </summary>
    /// <seealso cref="CfgTenant.Name"/>
    public string Name { get; set; }
    /// <summary>
    /// Returns the tenant DBID.
    /// </summary>
    /// <seealso cref="CfgTenant.DBID"/>
    public int? Dbid { get; set; }
    /// <summary>
    /// An indicator of whether the tenant belongs to the Service Provider.
    /// </summary>
    /// <see cref="CfgTenant.IsServiceProvider"/>
    public bool? IsServiceProvider { get; set; }
    /// <summary>
    /// Returns actual object state in the Genesys Configuration Database.
    /// </summary>
    /// <see cref="CfgTenant.State"/>
    public CfgObjectState? ObjectState { get; set; }
    /// <summary>
    /// Returns actual object state in the Genesys Configuration Database.
    /// </summary>
    /// <see cref="CfgTenant.State"/>
    [Obsolete("Use 'ObjectState' property instead of this")]
    public CfgObjectState? State { get { return ObjectState; } set { ObjectState = value; } }
    /// <summary>
    /// The tenant password.
    /// </summary>
    /// <seealso cref="CfgTenant.Password"/>
    public string Password { get; set; }
    #endregion public properties
    #region Constructors
    /// <summary>
    /// Default empty constructor
    /// </summary>
    public GTenantInfo(){}
    /// <summary>
    /// Copying construtor.
    /// </summary>
    /// <param name="conf">original configuration</param>
    public GTenantInfo(IGTenantInfo conf)
    {
      Name = conf.Name;
      Dbid = conf.Dbid;
      ObjectState = conf.ObjectState;
      IsServiceProvider = conf.IsServiceProvider;
      Password = conf.Password;
    }

    #endregion Constructors
    #region Override
    public virtual object Clone()
    {
      var result = (GTenantInfo)MemberwiseClone();
      return result;
    }
    /// <exclude/>
    public override int GetHashCode()
    {
      return CaclulateHash();
    }
    private int CaclulateHash()
    {
      var hash = GetType().GetHashCode();
      if (Name != null) hash ^= 7 * Name.GetHashCode();
      if (Dbid != null) hash ^= 11 * Dbid.Value.GetHashCode();
      if (IsServiceProvider != null) hash ^= 13 * IsServiceProvider.Value.GetHashCode();
      if (ObjectState != null) hash ^= 17 * ObjectState.Value.GetHashCode();
      if (Password != null) hash ^= 19 * Password.GetHashCode();
      return hash;
    }

    /// <exclude/>
    public override bool Equals(object obj)
    {
      var gHost = obj as GTenantInfo;
      return (ReferenceEquals(this, obj) || (
           (gHost != null)
        && (gHost.GetType() == GetType())
        && (Name.EqualsObjects(gHost.Name))
        && (Dbid.EqualsObjects(gHost.Dbid))
        && (IsServiceProvider.EqualsObjects(gHost.IsServiceProvider))
        && (ObjectState.EqualsObjects(gHost.ObjectState))
        && (Password.EqualsObjects(gHost.Password))
        ));

    }
    /// <exclude/>
    protected internal override string ContentToString(string prefix)
    {
      var sb = new StringBuilder();
      if (Name != null)
        sb.Append(prefix).Append("Name: ").AppendLine(Name);
      if (Dbid != null)
        sb.Append(prefix).Append("DBID: ").AppendLine(Dbid.Value.ToString(CultureInfo.InvariantCulture));
      if (IsServiceProvider != null)
        sb.Append(prefix).Append("IsServiceProvider: ").AppendLine(IsServiceProvider.Value.ToString());
      if (ObjectState != null)
        sb.Append(prefix).Append("State: ").AppendLine(ObjectState.Value.ToString("F"));
      return sb.ToString();
    }
    #endregion Override
  }
}

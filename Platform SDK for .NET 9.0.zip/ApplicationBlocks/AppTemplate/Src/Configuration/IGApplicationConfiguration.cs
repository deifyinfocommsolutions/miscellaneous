//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  internal interface IToStringIdent
  {
    string ToString(string ident);
  }

  /// <exclude/>
  [Serializable]
  public abstract class AbstractToStringObject : IToStringIdent
  {
    /// <summary>
    /// This method is used from <see cref="ToString"/> to build
    /// string representation of the internal content (configuration properties names and values).
    /// </summary>
    /// <param name="prefix">line ident</param>
    /// <returns>string representation of the configuration content</returns>
    protected internal abstract string ContentToString(string prefix);
    /// <exclude/>
    public override string ToString()
    {
      return ((IToStringIdent)this).ToString(String.Empty);
    }
    string IToStringIdent.ToString(string prefix)
    {
      string basePref = (String.IsNullOrEmpty(prefix)) ? String.Empty : prefix;
      prefix = (String.IsNullOrEmpty(prefix))
        ? AppTemplateToStringHelper.PrefixString
        : AppTemplateToStringHelper.PrefixString + prefix;
      var sb =
        new StringBuilder().Append(GetType().Name)
          .AppendLine("{")
          .Append(ContentToString(prefix))
          .Append(basePref)
          .Append("}");
      return sb.ToString();
    }

    private static readonly string[] _splitter = new string[] {Environment.NewLine,"\n"};
    /// <exclude/>
    protected string ApplyIdent(string source, string ident)
    {
      var sb = new StringBuilder();
      foreach (string s in source.Split(_splitter,StringSplitOptions.RemoveEmptyEntries))
      {
        sb.Append(ident).AppendLine(s);
      }
      return sb.ToString(ident.Length,sb.Length-ident.Length);
    }
  }

  /// <summary>
  /// <para>This interface represents base Genesys CME application options,
  /// which can be loaded from configuration server (with COM AB),
  /// or initialized by some other way like custom user code or
  /// any beans management mechanisms/frameworks.</para>
  /// <para>It provides detached properties from COM AB <see cref="CfgApplication"/> and <see cref="CfgHost"/> 
  /// objects without COM AB specific internal XML containers and can be created and filled with or without <see cref="IConfService"/> usage.
  /// </para>
  /// </summary>
  public interface IGApplicationConfiguration:ICloneable
  {
    ///<summary>
    /// Returns the application name.<br/> 
    /// It represents the correspondent name in Genesys Configuration framework.
    ///</summary>
    ///<seealso cref="CfgApplication.Name">CfgApplication.Name</seealso>
    String ApplicationName { get; }
    ///<summary>
    /// Returns type of the application in terms of Genesys Configuration framework.
    ///</summary>
    ///<seealso cref="CfgApplication.Type">CfgApplication.Type</seealso>
    CfgAppType? ApplicationType { get; }
    ///<summary>
    /// Returns unique application object identifier in context of Genesys Configuration Database.
    ///</summary>
    ///<seealso cref="CfgApplication.DBID">CfgApplication.DBID</seealso>
    int? Dbid { get; }
    ///<summary>
    /// Returns actual object state in the Genesys Configuration Database.
    ///</summary>
    ///<seealso cref="CfgApplication.State">CfgApplication.State</seealso>
    CfgObjectState? ObjectState { get; }
    ///<summary>
    /// Returns indicator of whether this application can be a server to some other applications.<br/>
    /// This value depends on the application type <see cref="ApplicationType"/>.
    ///</summary>
    ///<seealso cref="CfgApplication.IsServer">CfgApplication.IsServer</seealso>
    bool? IsServer { get; }
    ///<summary>
    /// Returns value meaning role of application within HA/redundancy group.
    ///</summary>
    ///<seealso cref="CfgApplication.IsPrimary">CfgApplication.IsPrimary</seealso>
    bool? IsPrimary { get; }
    ///<summary>
    /// Returns the application version.
    ///</summary>
    ///<seealso cref="CfgApplication.Version">CfgApplication.Version</seealso>
    String Version { get; }
    ///<summary>
    /// Returns structure with server type application specific properties.<br/>
    /// It should be null for client type applications.
    ///</summary>
    ///<seealso cref="CfgApplication.ServerInfo">CfgApplication.ServerInfo</seealso>
    ///<seealso cref="CfgServer">CfgServer</seealso>
    IGServerInfo ServerInfo { get; }
    ///<summary>
    /// Returns pointer to the list of structures of type <see cref="CfgPortInfo"/>
    /// containing information about listening ports for this server application.
    ///</summary>
    /// <returns>list of structures or null</returns>
    ///<seealso cref="CfgApplication.PortInfos">CfgApplication.PortInfos</seealso>
    List<IGPortInfo> PortInfos { get; }
    ///<summary>
    /// Returns the HA type if this application is considered as server.
    ///</summary>
    /// <returns>the application HA type or null</returns>
    ///<seealso cref="CfgApplication.RedundancyType">CfgApplication.RedundancyType</seealso>
    CfgHAType? RedundancyType { get; }
    ///<summary>
    /// Returns list of structures describing connected server applications.
    ///</summary>
    /// <returns>List of structures or null</returns>
    ///<seealso cref="IGAppConnConfiguration">IGAppConnConfiguration</seealso>
    ///<seealso cref="CfgApplication.AppServers">CfgApplication.AppServers</seealso>
    ///<seealso cref="CfgConnInfo">CfgConnInfo</seealso>
    List<IGAppConnConfiguration> AppServers { get; }
    ///<summary>
    /// Returns pointer to the list of application-specific configuration options.
    ///</summary>
    /// <returns>Collection of options' sections or null</returns>
    ///<seealso cref="KeyValueCollection">KeyValueCollection</seealso>
    ///<seealso cref="CfgApplication.Options">CfgApplication.Options</seealso>
    KeyValueCollection Options { get; }
    ///<summary>
    /// Returns pointer to the list of user-defined properties.<br/>
    /// It represents the "Annex" tab of the application object in CME.
    ///</summary>
    /// <returns>Collection of properties sections or null</returns>
    ///<seealso cref="KeyValueCollection">KeyValueCollection</seealso>
    ///<seealso cref="CfgApplication.UserProperties">CfgApplication.UserProperties</seealso>
    KeyValueCollection UserProperties { get; }
    ///<summary>
    /// Returns pointer to the list of additional properties.
    ///</summary>
    /// <returns>Collection of additional properties or null</returns>
    ///<seealso cref="KeyValueCollection">KeyValueCollection</seealso>
    ///<seealso cref="CfgApplication.FlexibleProperties">CfgApplication.FlexibleProperties</seealso>
    KeyValueCollection FlexibleProperties { get; }
    /// <summary>
    /// Returns list with information about tenants that are served by this application.<br/>
    /// This value may be <i>null</i> if tenants information was not read/requested
    /// (by default it is not requested).
    /// </summary>
    /// <returns>list with tenants information or null</returns>
    List<IGTenantInfo> Tenants { get; }
  }
  /// <summary>
  /// This structure represents group of server type specific application properties.
  /// </summary>
  /// <seealso cref="CfgServer"/>
  public interface IGServerInfo : ICloneable
  {
    ///<summary>
    /// Returns reference to structure describing host where this server resides.
    /// </summary>
    /// <seealso cref="IGHost">IGHost</seealso>
    /// <seealso cref="CfgServer.Host">CfgServer.Host</seealso>
    IGHost Host { get; }
    ///<summary>
    /// Returns name of the port to connect to on the target server.
    /// </summary>
    /// <returns>target port name/id</returns>
    /// <seealso cref="CfgServer.Port">CfgServer.Port</seealso>
    String Port { get; }
    ///<summary>
    /// Returns reconnect timeout for connection to the target application.
    /// </summary>
    /// <returns>reconnect timeout in seconds</returns>
    /// <seealso cref="CfgServer.Timeout">CfgServer.Timeout</seealso>
    int? Timeout { get; }
    ///<summary>
    /// Returns number of attempts to connect to this server before trying
    /// to connect to the backup server.
    /// </summary>
    /// <returns>reconnect attempts number or null</returns>
    /// <seealso cref="CfgServer.Attempts">CfgServer.Attempts</seealso>
    int? Attempts { get; }
    ///<summary>
    /// Returns description of server which is to be contacted if connection to this server fails.
    /// </summary>
    /// <returns>reference to description of backup server application or null</returns>
    /// <seealso cref="CfgServer.BackupServer">CfgServer.BackupServer</seealso>
    IGApplicationConfiguration Backup { get; }

  }

  /// <summary>
  /// This structure contains properties for listening port of server type application.
  /// </summary>
  /// <seealso cref="CfgPortInfo">CfgPortInfo</seealso>
  public interface IGPortInfo : ICloneable
  {
    ///<summary>
    /// Returns servers' port name/identifier.
    /// </summary>
    /// <returns>Port identifier</returns>
    /// <seealso cref="CfgPortInfo.Id">CfgPortInfo.Id</seealso>
    String Id { get; }
    ///<summary>
    /// Returns TCP/IP port number for listening on by "this" application.
    /// </summary>
    /// <returns>Port number</returns>
    /// <seealso cref="CfgPortInfo.Port">CfgPortInfo.Port</seealso>
    int? Port { get; }
    ///<summary>
    /// Returns name of the connection control protocol.
    /// Available values: "addp". Default: none.
    /// </summary>
    /// <returns>Control protocol name or null</returns>
    /// <seealso cref="CfgPortInfo.ConnProtocol">CfgPortInfo.ConnProtocol</seealso>
    String ConnProtocol { get; }
    ///<summary>
    /// Returns transport parameters for the listening port.
    /// </summary>
    /// <returns>Transport parameters or null</returns>
    /// <seealso cref="CfgPortInfo.TransportParams">CfgPortInfo.TransportParams</seealso>
    String TransportParams { get; }
    ///<summary>
    /// Returns application parameters for the listening port.
    /// </summary>
    /// <returns>Application parameters or null</returns>
    /// <seealso cref="CfgPortInfo.AppParams">CfgPortInfo.AppParams</seealso>
    String AppParams { get; }
    ///<summary>
    /// Returns description of the listening port.
    /// </summary>
    /// <returns>Port description or null</returns>
    /// <seealso cref="CfgPortInfo.Description">CfgPortInfo.Description</seealso>
    String Description { get; }
    
  }

  ///<summary>
  /// The application connection configuration structure reflects COM AB <see cref="CfgConnInfo"/> information.<br/>
  /// It contains reference to connected server with related connection properties.
  ///</summary>
  /// <seealso cref="CfgConnInfo">CfgConnInfo</seealso>
  public interface IGAppConnConfiguration : ICloneable
  {
    ///<summary>
    /// Returns application configuration of the connected server.
    /// </summary>
    /// <returns>Application configuration of the connected server</returns>
    /// <seealso cref="CfgConnInfo.AppServer">CfgConnInfo.AppServer</seealso>
    IGApplicationConfiguration TargetServerConfiguration { get; }

    ///<summary>
    /// Returns application configuration of the connected server.
    /// </summary>
    /// <returns>Application configuration of the connected server</returns>
    /// <seealso cref="CfgConnInfo.Id">CfgConnInfo.Id</seealso>
    String PortId { get; }
    ///<summary>
    /// Returns name of the connection control protocol.<br/>
    /// Available values: "addp". Default: none.
    /// </summary>
    /// <returns>Name of the connection control protocol</returns>
    /// <seealso cref="CfgConnInfo.ConnProtocol">CfgConnInfo.ConnProtocol</seealso>
    String ConnProtocol { get; }
    ///<summary>
    /// Returns the heart-bit polling interval measured in seconds, on client site.<br/>
    /// Valuable if connection protocol <see cref="ConnProtocol"/> is "addp".
    /// </summary>
    /// <returns>Local ADDP timeout or null</returns>
    /// <seealso cref="CfgConnInfo.TimoutLocal">CfgConnInfo.TimoutLocal</seealso>
    int? TimeoutLocal { get; }
    ///<summary>
    /// Returns the heart-bit polling interval measured in seconds, on server site.<br/>
    /// Valuable if connection protocol <see cref="ConnProtocol"/> is "addp".
    /// </summary>
    /// <returns>Remote ADDP timeout or null</returns>
    /// <seealso cref="CfgConnInfo.TimoutRemote">CfgConnInfo.TimoutRemote</seealso>
    int? TimeoutRemote { get; }
    ///<summary>
    /// Returns the ADDP trace mode dedicated for this connection.<br/>
    /// Default value is CFGTMNoTraceMode ("no addp trace logs").
    /// </summary>
    /// <returns>Trace mode or null</returns>
    /// <seealso cref="CfgConnInfo.Mode">CfgConnInfo.Mode</seealso>
    CfgTraceMode? TraceMode { get; }
    ///<summary>
    /// Returns connection protocol's transport parameters.
    /// </summary>
    /// <returns>The connection transport parameters</returns>
    /// <seealso cref="CfgConnInfo.TransportParams">CfgConnInfo.TransportParams</seealso>
    String TransportParams { get; }
    ///<summary>
    /// Returns connection protocol's application parameters.
    /// </summary>
    /// <returns>The connection application parameters</returns>
    /// <seealso cref="CfgConnInfo.AppParams">CfgConnInfo.AppParams</seealso>
    String AppParams { get; }
    ///<summary>
    /// Returns connection protocol's proxy parameters.
    /// </summary>
    /// <returns>The connection proxy parameters</returns>
    /// <seealso cref="CfgConnInfo.ProxyParams">CfgConnInfo.ProxyParams</seealso>
    String ProxyParams { get; }
    ///<summary>
    /// Returns optional description of the connection.
    /// </summary>
    /// <returns>Connection description or null</returns>
    /// <seealso cref="CfgConnInfo.Description">CfgConnInfo.Description</seealso>
    String Description { get; }
  }
  /// <summary>
  /// Structure describing host where server is configured to run.<br/>
  /// It reflects detached information from COM AB <see cref="CfgHost"/>
  /// </summary>
  /// <seealso cref="CfgHost">CfgHost</seealso>
  public interface IGHost : ICloneable
  {
    ///<summary>
    /// Returns the host name.
    /// </summary>
    /// <returns>The host name.</returns>
    /// <seealso cref="CfgHost.Name">CfgHost.Name</seealso>
    String Name { get; }
    ///<summary>
    /// Returns the host DBID.
    /// </summary>
    /// <returns>The host object DBID.</returns>
    /// <seealso cref="CfgHost.DBID">CfgHost.DBID</seealso>
    int? Dbid { get; }
    ///<summary>
    /// Returns the host TCP/IP address
    /// </summary>
    /// <returns>The host object TCP/IP address.</returns>
    /// <seealso cref="CfgHost.IPaddress">CfgHost.IPaddress</seealso>
    String IPAddress { get; }
    ///<summary>
    /// Returns port number on which the Local Control Agent for this host is supposed to be running.
    /// </summary>
    /// <returns>The LCA port number.</returns>
    /// <seealso cref="CfgHost.LCAPort">CfgHost.LCAPort</seealso>
    String LCAPort { get; }
    ///<summary>
    /// Returns actual object state in the Genesys Configuration Database.
    /// </summary>
    /// <returns>Actual object state.</returns>
    /// <seealso cref="CfgHost.State">CfgHost.State</seealso>
    CfgObjectState? ObjectState { get; }
    ///<summary>
    /// Returns pointer to the list of user-defined properties.<br/>
    /// It represents the "Annex" tab of the host object in CME.
    /// </summary>
    /// <returns>Collection of properties sections or null.</returns>
    /// <seealso cref="CfgHost.UserProperties">CfgHost.UserProperties</seealso>
    /// <seealso cref="KeyValueCollection">KeyValueCollection</seealso>
    KeyValueCollection UserProperties { get; }
  }
  /// <summary>
  /// Structure describing Tenant which is referred in the server application configuration.<br/>
  /// It reflects detached information from COM AB <see cref="CfgTenant"/>.
  /// </summary>
  public interface IGTenantInfo: ICloneable
  {
    /// <summary>
    /// Returns the tenant name.
    /// </summary>
    /// <seealso cref="CfgTenant.Name"/>
    String Name { get; }
    /// <summary>
    /// Returns the tenant DBID.
    /// </summary>
    /// <seealso cref="CfgTenant.DBID"/>
    int? Dbid { get; }
    /// <summary>
    /// An indicator of whether the tenant belongs to the Service Provider.
    /// </summary>
    /// <see cref="CfgTenant.IsServiceProvider"/>
    bool? IsServiceProvider { get; }
    /// <summary>
    /// Returns actual object state in the Genesys Configuration Database.
    /// </summary>
    /// <see cref="CfgTenant.State"/>
    CfgObjectState? ObjectState { get; }
    /// <summary>
    /// Returns actual object state in the Genesys Configuration Database.
    /// </summary>
    /// <see cref="CfgTenant.State"/>
    [Obsolete("Use the property 'ObjectState' instead of this")]
    CfgObjectState? State { get; }
    /// <summary>
    /// The tenant password.
    /// </summary>
    /// <seealso cref="CfgTenant.Password"/>
    String Password { get; }
  }
}

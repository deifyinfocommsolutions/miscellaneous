//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Commons.Logging;

namespace Genesyslab.Platform.AppTemplate.Configuration.Log
{
  /// <summary>
  /// This class is used for configuring the expiration of log files (and log segments).
  /// </summary>
  public class ExpirationConfig
  {
    /// <summary>
    /// Describes the possible type of log file expiration strategy.
    /// </summary>
    public enum ExpirationStrategy
    {
      /// <summary>
      /// The expiration is turned off. No limit either for log file number or for log file age is set.
      /// </summary>
      Off,
      /// <summary>
      /// The expiration is based on the number of files with the same log name in
      /// the folder. I.e. the number of files with pattern <b><i>"&lt;logfilename&gt;.*.log"</i></b> is counted.<br/>
      /// If the number of such files exceeds the value, set via <see cref="ExpirationConfig.Expire"/>
      /// the oldest files will be deleted. The number of deleted file is equal
      /// to 'currentFilesNumber - maxAllowedFilesNumber'.
      /// </summary>
      NumberOfFiles,
      /// <summary>
      /// The expiration is based on the file age. I.e. among all files with
      /// pattern 'logfilename'.*.log the inactive files which are older than
      /// <see cref="ExpirationConfig.Expire"/> days are deleted.
      /// </summary>
      TimeBased
    }

    private readonly ExpirationStrategy _expirationStrategy;
    private readonly int _expire;
    /// <summary>
    /// Returns expiration strategy
    /// </summary>
    public ExpirationStrategy Strategy {get { return _expirationStrategy; }}
    /// <summary>
    /// Returns expiration period
    /// </summary>
    public int Expire {get { return _expire; }}

    /// <summary>
    /// No expiration configuration
    /// </summary>
    public static readonly ExpirationConfig NoExpiration = new ExpirationConfig(ExpirationStrategy.Off, -1);
    /// <summary>
    /// Default expiration - 10 files
    /// </summary>
    public static readonly ExpirationConfig DefaultExpiration = new ExpirationConfig(ExpirationStrategy.NumberOfFiles, 10);
    /// <summary>
    /// Constructor.
    /// </summary>
    /// <param name="strategy">the expiration strategy.</param>
    /// <param name="expire">the expiration value.</param>
    public ExpirationConfig(ExpirationStrategy strategy, int expire)
    {
      _expirationStrategy = strategy;
      if (_expirationStrategy != ExpirationStrategy.Off)
      {
        if (expire<1)
          throw new ArgumentException("Log Expiration value is invalid: " + expire);
        _expire = expire;
      }
      else
      {
        _expire = 1;
      }
    }

    /// <exclude/>
    public override string ToString()
    {
      return String.Format("ExpirationConfig(Strategy='{0}',Expire='{1}')", _expirationStrategy.ToString("F"), _expire);
    }

    /// <exclude/>
    public override bool Equals(object obj)
    {
      if (ReferenceEquals(this, obj)) return true;
      var ec = obj as ExpirationConfig;
      if (ec==null) return false;
      return ((_expirationStrategy == ec._expirationStrategy) && (_expire == ec._expire));
    }

    /// <exclude/>
    public override int GetHashCode()
    {
      unchecked
      {
        return GetType().GetHashCode() ^ 59 * ((int)_expirationStrategy) ^ 61 * _expire;
      }
    }
    /// <summary>
    /// Parses option value into expiration configuration
    /// </summary>
    /// <param name="optionValue"></param>
    /// <param name="logger"></param>
    /// <returns></returns>
    public static ExpirationConfig Parse(string optionValue, ILogger logger)
    {
      if (string.IsNullOrEmpty(optionValue)) return null;
      optionValue = optionValue.Trim().ToLowerInvariant();
      if (string.IsNullOrEmpty(optionValue)) return null;
      if (ConfigurationUtil.IsFalse(optionValue)) return NoExpiration;
      int expireValue = 0;
      if (SegmentationConfig.TryGetIntValue(optionValue, "day", "days", ref expireValue, logger, 1, 100, 10, "expiration"))
        return new ExpirationConfig(ExpirationStrategy.TimeBased, expireValue);
      if (SegmentationConfig.TryGetIntValue(optionValue, "file", "file", ref expireValue, logger, 1, 1000, 10, "expiration"))
        return new ExpirationConfig(ExpirationStrategy.NumberOfFiles, expireValue);
      if (SegmentationConfig.TryGetIntValue(optionValue, null, "file", ref expireValue, logger, 1, 1000, -1, "expiration"))
        return new ExpirationConfig(ExpirationStrategy.NumberOfFiles, expireValue);
      return NoExpiration;
    }
  }
}

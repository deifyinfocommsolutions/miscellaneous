//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

namespace Genesyslab.Platform.AppTemplate.Configuration.Log
{
  /// <summary>
  /// Base logging target description extension for file logging target type to support filename property.
  /// </summary>
  public class FileTargetConfig: TargetConfig
  {
    private readonly string _fileName;
    /// <summary>
    /// Returns the log file name as it was defined in the log options configuration.
    /// </summary>
    public string FileName{get { return _fileName; }}
    /// <summary>
    /// Constructor.
    /// </summary>
    /// <param name="fileName">File name</param>
    /// <param name="verbose">log level</param>
    public FileTargetConfig(string fileName, VerboseLevel verbose):base(TargetType.FileLogger, verbose)
    {
      if (String.IsNullOrEmpty(fileName))
        throw new ArgumentException("The name of file cannot be empty or null");
      _fileName = fileName;
    }

    /// <exclude/>
    public override string ToString()
    {
      return String.Format("LoggingTarget(type={0},level={1},filename={2}", 
        Target.ToString("F"), Verbose.ToString("F"), _fileName);
    }

    /// <exclude/>
    public override bool Equals(object obj)
    {
      if (!base.Equals(obj)) return false;
      var fConf = obj as FileTargetConfig;
      if (fConf==null) return false;
      return String.Equals(_fileName, fConf._fileName, StringComparison.InvariantCultureIgnoreCase);
    }
    /// <exclude/>
    public override int GetHashCode()
    {
      unchecked
      {
        return base.GetHashCode() ^ 31 * _fileName.GetHashCode();
      }
    }
  }
}

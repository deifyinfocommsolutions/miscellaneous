//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.AppTemplate.Logger.LMS;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Logging;

namespace Genesyslab.Platform.AppTemplate.Configuration.Log
{
  /// <summary>
  /// Platform SDK specific extended logging configuration option for applying of custom properties
  /// on loggers configuration.<br/>
  /// It represents single logger configuration record in "log-extended" section of CME Application Options.
  /// <br/>
  /// For example:<code>
  /// [log-extended]
  ///     "logger-&lt;ID&gt;" = "&lt;logger.name&gt;: level=debug, additivity=false"
  /// </code>
  /// It's included in <see cref="GAppLogExtOptions"/>, which may contain list of such descriptions,
  /// and is a part of <see cref="GAppLoggingOptions"/>.<br/>
  /// The custom logger declaration supports following custom properties:
  /// <list type="bullet">
  ///  <item><b>level</b> - the Level to be associated with the Logger;</item>
  ///  <item><b>additivity</b> ("<i>true</i>"/"<i>false</i>") - true if the logger should be additive, false otherwise;</item>
  /// <item><b>includeLocation</b> ("<i>true</i>"/"<i>false</i>") - whether location should be passed downstream.</item>
  /// </list>
  /// </summary>
  public class CustomLoggerExtConfig: ICloneable
  {
    private readonly String _loggerId;
    private readonly String _loggerName;
    private readonly Dictionary<String, String> _properties;
    private readonly IDictionary<String, String> _readOnlyPoperties;

    /// <summary>
    /// Creates extended logger configuration options description structure.
    /// </summary>
    /// <param name="loggerId">the ID of the logger customization record.</param>
    /// <param name="loggerExtOpts">the logger extended options.</param>
    public CustomLoggerExtConfig(string loggerId, String loggerExtOpts)
    {
      if (loggerId == null) throw new ArgumentNullException("loggerId");
      _loggerId = loggerId;
      if (String.IsNullOrEmpty(loggerExtOpts)) throw new ArgumentException("loggerExtOptions can't be empty or null");
      int pos = loggerExtOpts.IndexOf(':');
      if (pos <= 0)
        throw new ArgumentException("loggerExtOpts does not contain logger name");
      _loggerName = loggerExtOpts.Substring(0, pos).Trim();
      if (String.IsNullOrEmpty(_loggerName))
        throw new ArgumentException("loggerExtOpts contains empty logger name");
      _properties = new Dictionary<string, string>();
      var loggerDef = loggerExtOpts.Substring(pos + 1).Trim();
      var opts = loggerDef.Split(',');
      if (opts.Length > 0)
      {
        foreach (String opt in opts)
        {
          pos = opt.IndexOf('=');
          if (pos > 0)
          {
            var optName = opt.Substring(0, pos).Trim();
            var optVal = opt.Substring(pos + 1).Trim();
            if ((String.IsNullOrEmpty(optName) || (String.IsNullOrEmpty(optVal)))) continue;
            _properties.Add(optName, optVal);
          }
        }
      }
      if (_properties.Count == 0)
      {
        throw new ArgumentException("loggerExtOpts does not contain properties declarations");
      }
      _readOnlyPoperties = new ReadOnlyDictionary<string, string>(_properties);
    }
    /// <summary>
    /// Returns the custom logger configuration properties. (Read only)
    /// </summary>
    public IDictionary<string, string> Properties { get { return _readOnlyPoperties; }}
    /// <summary>
    /// Returns property value of the custom logger configuration.
    /// </summary>
    /// <param name="key">the property name.</param>
    /// <returns>value of the logger configuration property or null if it does not exist</returns>
    public string Property(string key)
    {
      return _readOnlyPoperties[key];
    }
    /// <summary>
    /// Returns identifier of the custom logger record.
    /// </summary>
    public string Id{ get { return _loggerId; }}
    /// <summary>
    /// Returns the custom logger name.
    /// </summary>
    public string Name { get { return _loggerName; } }

    private CustomLoggerExtConfig(CustomLoggerExtConfig source)
    {
      _loggerId = source._loggerId;
      _loggerName = source._loggerName;
      if (source._properties != null)
      {
        _properties  = new Dictionary<string, string>();
        foreach (KeyValuePair<string, string> pair in source._properties)
        {
          _properties.Add(pair.Key, pair.Value);
        }
        _readOnlyPoperties = new ReadOnlyDictionary<string, string>(_properties);
      }
    }
    /// <exclude/>
    public object Clone()
    {
      return new CustomLoggerExtConfig(this);
    }
  }

  /// <summary>
  /// Extended configuration of logger
  /// </summary>
  public class GAppLogExtOptions:ICloneable
  {
    /// <exclude/>
    public const String LevelReassignOptPrefix = "level-reassign-";
    /// <exclude/>
    public const String LevelReassignDisableExtOpt = "level-reassign-disable";
    /// <exclude/>
    public const String LogExtLoggerPrefix = "logger-";

    private readonly IDictionary<int, LmsLogLevel> _levelReassigns;
    private readonly IDictionary<int, LmsLogLevel> _levelReassignsReadOnly;
    private readonly IDictionary<String, CustomLoggerExtConfig> _customLoggers;
    private readonly IDictionary<String, CustomLoggerExtConfig> _customLoggersReadOnly;
    private readonly ILogger _logger;

    /// <exclude/>
    public IDictionary<String, CustomLoggerExtConfig> CustomLoggers{get { return _customLoggersReadOnly; }}
    /// <exclude/>
    public IDictionary<int, LmsLogLevel> LevelReassigns { get { return _levelReassignsReadOnly; } }
    /// <summary>
    /// Parsing constructor of "log-extended" section of application Options.<code>
    ///   KeyValueCollection logExtSection = new KeyValueCollection();
    ///   logExtSection.Add("level-reassign-14005", "ALARM");
    ///   logExtSection.Add("level-reassign-14006", "ALARM");
    ///   logExtSection.Add("logger-psdk", "Genesyslab.Platform: level=debug");
    ///   var logExtOpts = new GAppLoggerExtConfiguration(logExtSection, null);
    /// </code>
    /// </summary>
    /// <param name="logExtOptions">the application "log-extended" Options section.</param>
    /// <param name="logger">optional "status" logger to print errors of options parsing methods.</param>
    public GAppLogExtOptions(KeyValueCollection logExtOptions, ILogger logger)
    {
      _logger = logger ?? NullLogger.Singleton;
      if (logExtOptions != null)
      {
        _levelReassigns = ParseLevelReassignments(logExtOptions);
        _customLoggers = ParseCustomLoggers(logExtOptions);
      }
      else
      {
        _levelReassigns = null;
        _customLoggers = null;
      }
      _levelReassignsReadOnly = _levelReassigns == null
        ? null
        : new ReadOnlyDictionary<int, LmsLogLevel>(_levelReassigns);
      _customLoggersReadOnly = _customLoggers == null
        ? null
        : new ReadOnlyDictionary<string, CustomLoggerExtConfig>(_customLoggers);
    }
    private GAppLogExtOptions(GAppLogExtOptions source)
    {
      _logger = source._logger;
      if (source._levelReassigns != null)
      {
        _levelReassigns = new Dictionary<int, LmsLogLevel>();
        foreach (KeyValuePair<int, LmsLogLevel> pair in source._levelReassigns)
          _levelReassigns.Add(pair.Key, pair.Value);
      }
      if (source._customLoggers != null)
      {
        _customLoggers = new Dictionary<string, CustomLoggerExtConfig>();
        foreach (KeyValuePair<string, CustomLoggerExtConfig> pair in source._customLoggers)
        {
          var val = pair.Value.Clone() as CustomLoggerExtConfig;
          if (val!=null)
            _customLoggers.Add(pair.Key, val);
        }
      }
      _levelReassignsReadOnly = _levelReassigns == null
        ? null
        : new ReadOnlyDictionary<int, LmsLogLevel>(_levelReassigns);
      _customLoggersReadOnly = _customLoggers == null
        ? null
        : new ReadOnlyDictionary<string, CustomLoggerExtConfig>(_customLoggers);
    }

    public object Clone()
    {
      return new GAppLogExtOptions(this);
    }
    /// <summary>
    /// Extracts map of LMS events level reassignment configuration from "log-extended" section
    /// of the application configuration object.
    /// </summary>
    /// <param name="optsLogExt">the extended log options of the application.</param>
    /// <returns>filled map, or null if there are no reassignment declarations or reassignment is disabled.</returns>
    protected IDictionary<int, LmsLogLevel> ParseLevelReassignments(KeyValueCollection optsLogExt)
    {
      Dictionary<int, LmsLogLevel> result = null;
      var disableReassign = optsLogExt[LevelReassignDisableExtOpt] as String;
      if ((disableReassign == null) || (!ConfigurationUtil.IsTrue(disableReassign)))
      {
        foreach (DictionaryEntry entry in optsLogExt)
        {
          var key = entry.Key as string;
          if (String.IsNullOrEmpty(key)) continue;
          if (key.StartsWith(LevelReassignOptPrefix, StringComparison.InvariantCultureIgnoreCase) &&
              (!key.Equals(LevelReassignOptPrefix, StringComparison.InvariantCultureIgnoreCase)))
          {
            var sid = key.Substring(LevelReassignOptPrefix.Length);
            var lvl = entry.Value as string;
            if (String.IsNullOrEmpty(lvl))
            {
              if (_logger.IsWarnEnabled)
                _logger.Warn("Unknown reassignment log level for '" + sid + "' = '" + lvl + "'");
              continue;
            }
            int level;
            if (!Int32.TryParse(sid, out level))
            {
              if (_logger.IsErrorEnabled)
                _logger.Warn("Error parsing reassignment log level for '" + sid + "' = '" + lvl + "'");
              continue;
            }
            LmsLogLevel? logLevel = GetLogLevel(lvl);
            if (logLevel==null)
            {
              if (_logger.IsWarnEnabled)
                _logger.Warn("Unknown reassignment log level for '" + sid + "' = '" + lvl + "'");
              continue;
            }
            if (result==null)
              result = new Dictionary<int, LmsLogLevel>();
            result.Add(level, logLevel.Value);
          }
        }
      }
      return result;
    }

    internal static LmsLogLevel? GetLogLevel(string lvl)
    {
      if (lvl != null) lvl = lvl.ToLowerInvariant();
      if (lvl == null)
      {
        return null;
      }
      if (lvl.Equals("alarm"))
      {
        return LmsLogLevel.Alarm;
      }
      if (lvl.Equals("standard") || lvl.Equals("error"))
      {
        return LmsLogLevel.Standard;
      }
      if (lvl.Equals("warn") || lvl.Equals("interaction"))
      {
        return LmsLogLevel.Interaction;
      }
      if (lvl.Equals("trace") || lvl.Equals("info"))
      {
        return LmsLogLevel.Info;
      }
      if (lvl.Equals("debug"))
      {
        return LmsLogLevel.Debug;
      }
      if (lvl.Equals("none") || lvl.Equals("unknown"))
      {
        return LmsLogLevel.Unknown;
      }
      return null;
    }
    /// <summary>
    /// Parsing method for custom loggers declarations.
    /// </summary>
    /// <param name="optsLogExt">the extended log options of the application.</param>
    /// <returns>Dictionary with parsed loggers customization options.</returns>
    protected IDictionary<String, CustomLoggerExtConfig> ParseCustomLoggers(KeyValueCollection optsLogExt)
    {
      IDictionary<String, CustomLoggerExtConfig> result = null;
      foreach (DictionaryEntry entry in optsLogExt)
      {
        var name = entry.Key as string;
        if (String.IsNullOrEmpty(name)) continue;
        if (name.StartsWith(LogExtLoggerPrefix, StringComparison.InvariantCultureIgnoreCase))
        {
          var loggerId = name.Substring(LogExtLoggerPrefix.Length);
          try
          {
            var logConf = new CustomLoggerExtConfig(loggerId, entry.Value as string);
            if (result==null)
              result = new Dictionary<string, CustomLoggerExtConfig>();
            result.Add(logConf.Name, logConf);
          }
          catch (Exception ex)
          {
            if (_logger.IsErrorEnabled)
              _logger.Error("Exception parsing custom logger configuration \"" + loggerId + "\"", ex);
          }
        }
      }
      return result;
    }
  }

  /// <summary>
  /// Configuration of logger
  /// </summary>
  public class GAppLoggingOptions: ICloneable, IGLoggerConfiguration
  {
    /// <summary>
    /// Name of the section of <see cref="CfgApplication.Options"/> list that contains logger configuration.
    /// </summary>
    public const string LogSectionName = "log";
    /// <summary>
    /// Name of the section of <see cref="CfgApplication.Options"/> list that contains extended logger configuration.
    /// </summary>
    public const string LogExtSectionName = "log-extended";
    /// <exclude/>
    public const string TargetTypeStdOut = "stdout";
    /// <exclude/>
    public const string TargetTypeStdErr = "stderr";
    /// <exclude/>
    public const string TargetTypeNetwork = "network";
    /// <exclude/>
    public const string TargetTypeMemory = "memory";

    private readonly KeyValueCollection _options = new KeyValueCollection
    {
      KeyComparer = StringComparer.InvariantCultureIgnoreCase
    };
    private readonly GAppLogExtOptions _extOptions;
    private readonly IGApplicationConfiguration _applicationConfiguration;
    /// <exclude/>
    public IGApplicationConfiguration ApplicationConfiguration { get { return _applicationConfiguration; } }

    private readonly ILogger _logger;

    /// <summary>
    /// Creates logging options parsing helper class instance by given application configuration.<br/>
    /// Simple application configuration usage:<code>
    ///   var theApp = confService.RetrieveObject&lt;CfgApplication&gt;(new CfgApplicationQuery(myAppName));
    ///   var appConfig = new GCOMApplicationConfiguration(theApp);
    ///   var logConfig = new GAppLoggerConfiguration(appconfig, null);
    /// </code>
    /// <param name="appConfig">the application configuration.</param>
    /// <param name="logger">optional "status" logger to print errors of options parsing methods.</param>
    /// </summary>
    public GAppLoggingOptions(IGApplicationConfiguration appConfig, ILogger logger)
      : this(GetLogSection(appConfig, LogSectionName), GetLogSection(appConfig, LogExtSectionName), logger)
    {

      _applicationConfiguration = appConfig==null? null : appConfig.Clone() as IGApplicationConfiguration;
    }

    /// <summary>
    /// Creates logging options parsing helper class instance by given logging configuration options.<br/>
    /// Or simple initialization without application configuration reading (without ConfService usage):
    /// <code>
    ///   var logSection = new KeyValueCollection();
    ///   logSection.Add("verbose", "all");
    ///   logSection.Add("message-format", "full");
    ///   logSection.Add("standard", "Log4j2ConfiguratorTest-std");
    ///   logSection.Add("all", "stdout, Log4j2ConfiguratorTest-all");
    ///   var logConfig = new GAppLoggingOptions(logSection, null);
    /// </code>
    /// </summary>
    /// <param name="logOptions"><see cref="KeyValueCollection"/> of logger configuration</param>
    /// <param name="logger">optional "status" logger to print errors of options parsing methods.</param>
    public GAppLoggingOptions(KeyValueCollection logOptions, ILogger logger) 
      : this(logOptions, null, logger){}

    /// <summary>
    /// Creates logging options parsing helper class instance by given logging configuration options.<br/>
    /// Or simple initialization without application configuration reading (without ConfService usage):
    /// <code>
    ///   var logSection = new KeyValueCollection();
    ///   logSection.Add("verbose", "all");
    ///   logSection.Add("message-format", "full");
    ///   logSection.Add("standard", "Log4j2ConfiguratorTest-std");
    ///   logSection.Add("all", "stdout, Log4j2ConfiguratorTest-all");
    ///   var logExtSection = new KeyValueCollection();
    ///   logExtSection.Add("level-reassign-14005", "ALARM");
    ///   logExtSection.Add("level-reassign-14006", "ALARM");
    ///   logExtSection.Add("logger-psdk", "com.genesyslab.platform: level=debug");
    ///   logExtSection.Add("logger-apache", "org.apache: level=error");
    ///   var logConfig = new GAppLoggingOptions(logSection, logExtSection, null);
    /// </code>
    /// </summary>
    /// <param name="logOptions"><see cref="KeyValueCollection"/> of logger configuration</param>
    /// <param name="extOptions"><see cref="KeyValueCollection"/> of extended logger configuration</param>
    /// <param name="logger">optional "status" logger to print errors of options parsing methods.</param>
    public GAppLoggingOptions(KeyValueCollection logOptions, KeyValueCollection extOptions, ILogger logger)
    {
      _logger = logger ?? NullLogger.Singleton;
      if (logOptions != null)
      {
        foreach (DictionaryEntry entry in logOptions)
        {
          var key = entry.Key as string;
          var value = entry.Value as string;
          if (String.IsNullOrEmpty(key) || String.IsNullOrEmpty(value)) continue;
          var opt = LogOptions.OptionsMap[key];
          if (opt != null)
          {
            var optName = opt.Name;
            if (!_options.ContainsKey(optName))
            {
              _options.Add(optName, value);
            }
            else
            {
              if (_logger.IsWarnEnabled)
              {
                _logger.Warn("Given log options contain duplication for option "
                                + optName + ", ignoring duplicated option");
              }
            }
          }
          else
          {
            _options.Add(key, value);
          }
        }
        _extOptions = (extOptions != null) ? new GAppLogExtOptions(extOptions, logger) : null;
      }
    }

    private GAppLoggingOptions(GAppLoggingOptions source)
    {
      _options = source._options.Clone() as KeyValueCollection;
      _extOptions = source._extOptions==null?null:source._extOptions.Clone() as GAppLogExtOptions;
      _applicationConfiguration = source._applicationConfiguration == null
        ? null
        : source._applicationConfiguration.Clone() as IGApplicationConfiguration;
      _logger = source._logger;
    }
    public object Clone()
    {
      return new GAppLoggingOptions(this);
    }
    public override bool Equals(object obj)
    {
      if (ReferenceEquals(this, obj)) return true;
      var cfg = obj as GAppLoggingOptions;
      if (cfg==null) return false;
      return _options.Equals(cfg._options);
    }

    public override int GetHashCode()
    {
      return GetType().GetHashCode() ^ _options.GetHashCode();
    }

    public override string ToString()
    {
      var sb = new StringBuilder("GAppLoggerConfig(verbose=").Append(Verbose);
      var targets = Targets;
      if (targets != null)
      {
        foreach (TargetConfig target in targets)
        {
          sb.Append(",").Append(target.Target).Append("/").Append(target.Verbose);
        }
      }

      return sb.Append(")").ToString();
    }


    #region properties

    /// <exclude/>
    public GAppLogExtOptions ExtOptions{ get { return _extOptions; } }
    /// <exclude/>
    public bool EnableThread{ get { return GetBooleanOptionValue(LogOptions.EnableThread); }}
    /// <exclude/>
    public bool Buffering { get { return GetBooleanOptionValue(LogOptions.Buffering); } }
    /// <exclude/>
    public bool DeleteArchiveFiles { get { return GetBooleanOptionValue(LogOptions.DeleteArchiveFiles); } }
    /// <exclude/>
    public bool StackTrace { get { return GetBooleanOptionValue(LogOptions.StackTrace); } }
    /// <exclude/>
    public MessageFormat Format { get { return GetEnumOptionValue(LogOptions.MessageFormat); } }
    /// <exclude/>
    public string MessageHeaderDelimiter { get { return GetFirstOptionValue(LogOptions.MessageHeaderDelimiter); } }
    /// <exclude/>
    public TimeFormat TimeFormatting { get { return GetEnumOptionValue(LogOptions.TimeFormat); } }
    /// <exclude/>
    public DateTimeKind TimeKind { get { return GetEnumOptionValue(LogOptions.TimeConvert); } }
    /// <exclude/>
    public VerboseLevel Verbose { get { return GetEnumOptionValue(LogOptions.Verbose); } }

    private string _applicationName;
    ///<summary>
    /// The name of application to be used in the logs.
    ///</summary>
    public string ApplicationName
    {
      get
      {
        var appName = _applicationName ?? GetFirstOptionValue(LogOptions.ApplicationName);
        if (appName != null) return appName;
        if ((_applicationConfiguration != null) && (!String.IsNullOrEmpty(_applicationConfiguration.ApplicationName)))
        {
          return _applicationConfiguration.ApplicationName;
        }
        return String.Empty;
      }
      set { _applicationName = value; }
    }

    private string _applicationHost;
    ///<summary>
    /// The host of application to be used in the logs.
    ///</summary>
    public string ApplicationHost
    {
      get
      {
        var applicationHost = _applicationHost ?? GetFirstOptionValue(LogOptions.ApplicationHost);
        if (applicationHost != null) return applicationHost;
        if ((_applicationConfiguration != null) && (_applicationConfiguration.ServerInfo != null)
            && (_applicationConfiguration.ServerInfo.Host != null) &&
            (!String.IsNullOrEmpty(_applicationConfiguration.ServerInfo.Host.Name)))
        {
          return _applicationConfiguration.ServerInfo.Host.Name;
        }
        return String.Empty;
      }
      set { _applicationHost = value; }
    }

    private int? _applicationType;
    ///<summary>
    /// The type of application to be used in the logs.
    ///</summary>
    public int ApplicationType
    {
      get
      {
        if (_applicationType != null) return _applicationType.Value;
        int? defValue = null;
        if ((_applicationConfiguration != null) && (_applicationConfiguration.ApplicationType!=null))
        {
          defValue = (int)_applicationConfiguration.ApplicationType.Value;
        }
        return GetIntOptionValue(LogOptions.ApplicationType, LogOptions.ApplicationTypeId, defValue);
      }
      set
      {
        if (value >= 0)
        {
          _applicationType = value;
        }
        else
        {
          _applicationType = null;
        }
      }
    }

    private int? _applicationId;
    ///<summary>
    /// The ID of application to be used in the logs.
    ///</summary>
    public int ApplicationId
    {
      get
      {
        return
          (_applicationId != null)
            ? _applicationId.Value
            : GetIntOptionValue(LogOptions.ApplicationId);

      }
      set
      {
        if (value >= 0)
        {
          _applicationId = value;
        }
        else
        {
          _applicationId = null;
        }

      }
    }

    private int? _messageServerTimeout;
    ///<summary>
    /// Protocol timeout of Message Server Protocol, seconds
    ///</summary>
    public int MessageServerTimeout
    {
      get
      {
        return
          (_messageServerTimeout != null)
            ? _messageServerTimeout.Value
            : GetIntOptionValue(LogOptions.MessageServerTimeout);

      }
      set
      {
        if (value >= 0)
        {
          _messageServerTimeout = value;
        }
        else
        {
          _messageServerTimeout = null;
        }
      }
    }

    #endregion properties
    #region api
    /// <summary>
    /// Returns configuration of targets
    /// </summary>
    public IList<TargetConfig> Targets
    {
      get
      {
        var result = new List<TargetConfig>();
        foreach (VerboseLevel level in Enum.GetValues(typeof (VerboseLevel)))
        {
          result.AddRange(GetOutputDescriptorsForVerboseLevel(level, _logger));
        }
        return ConsolidateOutputDescriptors(result);
      }
    }

    /// <exclude/>
    public SegmentationConfig Segmentation
    {
      get
      {
        var val = GetFirstOptionValue(LogOptions.Segmentation);
        if (!String.IsNullOrEmpty(val))
        {
          try
          {
            var res = SegmentationConfig.Parse(val, _logger);
            if (res != null) return res;
          }
          catch (Exception)
          {
            if ((_logger != null) && (_logger.IsErrorEnabled))
              _logger.ErrorFormat("Error parsing segment option [{0}]: set default - no segmentattion", val);
          }
        }
        return LogOptions.Segmentation.DevaultValue;
      }
    }
    /// <exclude/>
    public ExpirationConfig Expiration
    {
      get
      {
        var val = GetFirstOptionValue(LogOptions.Expiration);
        if (!String.IsNullOrEmpty(val))
        {
          try
          {
            var res = ExpirationConfig.Parse(val, _logger);
            if (res != null) return res;
          }
          catch (Exception)
          {
            if ((_logger != null) && (_logger.IsErrorEnabled))
              _logger.ErrorFormat("Error parsing expire option [{0}]: set default - 10 files", val);
          }
        }
        return LogOptions.Expiration.DevaultValue;
      }
    }
    #endregion api
    #region utils
    private static KeyValueCollection GetLogSection(IGApplicationConfiguration appConfig, String sectionName)
    {
      if (appConfig == null) return null;
      KeyValueCollection opts = appConfig.Options;
      return (opts != null) ? opts[sectionName] as KeyValueCollection : null;
    }
    /// <exclude/>
    private String GetFirstOptionValue(LogOptions.LogOptionDescription description)
    {
      var val = _options[description.Name] as String;
      return (val != null) ? val.Trim() : null;
    }

    private bool GetBooleanOptionValue(LogOptions.LogOptionDescription<bool> optDescr)
    {
      String val = GetFirstOptionValue(optDescr);
      if (string.IsNullOrEmpty(val))
        return optDescr.DevaultValue;
      if (ConfigurationUtil.IsTrue(val)) return true;
      if (ConfigurationUtil.IsFalse(val)) return false;
      bool defVal = optDescr.DevaultValue;
      if (_logger.IsErrorEnabled)
      {
        _logger.ErrorFormat("Error parsing {0} option value '{1}'. Using default '{2}'.", optDescr.Name, val, defVal);
      }
      return defVal;
    }
    private int GetIntOptionValue(LogOptions.LogOptionDescription<int> optDescr)
    {
      String val = GetFirstOptionValue(optDescr);
      if (string.IsNullOrEmpty(val))
        return optDescr.DevaultValue;
      int intVal;
      if (Int32.TryParse(val, out intVal)) return intVal;
      int defVal = optDescr.DevaultValue;
      if (_logger.IsErrorEnabled)
      {
        _logger.ErrorFormat("Error parsing {0} option value '{1}'. Using default '{2}'.", optDescr.Name, val, defVal);
      }
      return defVal;
    }
    private int GetIntOptionValue<TValue>(LogOptions.LogOptionDescription<TValue> optDescr, LogOptions.LogOptionDescription<int> optDescr2, int? defValueRef)where TValue : struct
    {
      String val = GetFirstOptionValue(optDescr);
      if (!string.IsNullOrEmpty(val))
      {
        var result = ConfigurationUtil.GetEnumValue<TValue>(val);
        if (result != null)
        {
          return (int)(object) result.Value;
        }
      }
      int intVal;
      if (Int32.TryParse(val, out intVal)) return intVal;
      int defVal = optDescr2.DevaultValue;
      if (_logger.IsErrorEnabled)
      {
        _logger.ErrorFormat("Error parsing {0} option value '{1}'. Using default '{2}'.", optDescr.Name, val, defVal);
      }
      return defValueRef == null ? defVal : defValueRef.Value;
    }
    private TValue GetEnumOptionValue<TValue>(LogOptions.LogOptionDescription<TValue> optDescr) where TValue : struct
    {
      String val = GetFirstOptionValue(optDescr);
      if (string.IsNullOrEmpty(val))
        return optDescr.DevaultValue;
      var result = ConfigurationUtil.GetEnumValue<TValue>(val);
      if (result != null) return result.Value;
      TValue defVal = optDescr.DevaultValue;
      if (_logger.IsErrorEnabled)
      {
        _logger.ErrorFormat("Error parsing {0} option value '{1}'. Using default '{2}'.", optDescr.Name, val, defVal);
      }
      return defVal;
    }

    private IEnumerable<TargetConfig> GetOutputDescriptorsForVerboseLevel(VerboseLevel level, ILogger logger)
    {
      var optionName = level.ToString("F").ToLower(CultureInfo.InvariantCulture);
      var optionValue = _options[optionName] as string;
      var delimitedOptions = ParseOutputOptionValue(optionValue);
      return
        delimitedOptions.Select(option => CreateOutputConfigFromString(option, level, logger))
          .Where(config => config != null)
          .ToList();
    }

    private static TargetConfig CreateOutputConfigFromString(String targetString, VerboseLevel level, ILogger logger)
    {
      if (TargetTypeStdOut.Equals(targetString, StringComparison.InvariantCultureIgnoreCase))
      {
        return new TargetConfig(TargetConfig.TargetType.StdOut, level);
      }
      if (TargetTypeStdErr.Equals(targetString, StringComparison.InvariantCultureIgnoreCase))
      {
        return new TargetConfig(TargetConfig.TargetType.StdErr, level);
      }
      if (TargetTypeNetwork.Equals(targetString, StringComparison.InvariantCultureIgnoreCase))
      {
        return new TargetConfig(TargetConfig.TargetType.MessageServer, level);
      } 
      if (TargetTypeMemory.Equals(targetString, StringComparison.InvariantCultureIgnoreCase)) 
      {
        return new TargetConfig(TargetConfig.TargetType.Memory, level);
      }
      try
      {
        if (String.IsNullOrEmpty(targetString)) return null;
        targetString = targetString.Trim();
        if (String.IsNullOrEmpty(targetString)) return null;
        var path = Path.GetDirectoryName(targetString);
        var name = Path.GetFileName(targetString);
        if (String.IsNullOrEmpty(path)) path = Directory.GetCurrentDirectory();
        if (!Directory.Exists(path))
        {
          if ((logger != null) && (logger.IsWarnEnabled))
            logger.WarnFormat("Invalid file name is set as target name: {0}", targetString);
        }
        String filename = path + Path.DirectorySeparatorChar + name;
        return new FileTargetConfig(filename, level);
      }
      catch (Exception)
      {
        return null;
      }
    }

    private static IEnumerable<string> ParseOutputOptionValue(String outputOptionValue) {
        var result = new List<String>();
        if (String.IsNullOrEmpty(outputOptionValue)) 
            return result;
        bool inquote = false;
        int previousCommaPos = -1;
      for (int i = 0; i < outputOptionValue.Length; ++i) {
            if (outputOptionValue[i] == '"') {
                inquote = !inquote;
            }
            if (inquote) {
                continue;
            }
            if (outputOptionValue[i] == ',') { //here we are at the position of comma
                int currentCommaPos = i;
                if (currentCommaPos - previousCommaPos <= 1) {
                    previousCommaPos = currentCommaPos;
                    continue; //no sense in adding empty string
                }
                if (previousCommaPos == -1) {
                    previousCommaPos = 0;
                }
                AddTruncatedString(result, outputOptionValue.Substring(previousCommaPos, currentCommaPos - previousCommaPos));
                previousCommaPos = currentCommaPos;
            }
        }
        if (previousCommaPos < 0) {
            result.Clear();
            AddTruncatedString(result, outputOptionValue);
        } else {
          AddTruncatedString(result, outputOptionValue.Substring(previousCommaPos, outputOptionValue.Length - previousCommaPos));
        }
        return result;
    }
    private const string TruncPattern = "^[\\s,\"]*(.*?)[\\s,\"]*$";
    private static void AddTruncatedString(List<String> result, String val) 
    {
        if (!String.IsNullOrEmpty(val))
        {
          var match = Regex.Match(val, TruncPattern);
          if (match.Success)
          {
            var str = match.Groups[1].Value;
            if (!String.IsNullOrEmpty(str)) { result.Add(str);}
          }
        }
    }

    private static List<TargetConfig> ConsolidateOutputDescriptors(List<TargetConfig> list2Consolidate)
    {
      var consolidatesList = new List<TargetConfig>();
      if (list2Consolidate == null || list2Consolidate.Count == 0)
      {
        return consolidatesList;
      }
      foreach (TargetConfig config in list2Consolidate)
      {
        int index = -1;
        for (int i = 0; i < consolidatesList.Count; i++)
        {
          if (config.Equals(consolidatesList[i]))
          {
            index = i;
            break;
          }
        }
        if (index < 0)
        {
          consolidatesList.Add(config);
        }
        else
        {
          if ((int) consolidatesList[index].Verbose > (int) config.Verbose)
          {
            consolidatesList[index] = config;
          }
        }
      }
      return consolidatesList;
    }

    #endregion utils
  }
}

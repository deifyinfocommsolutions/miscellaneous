//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;

namespace Genesyslab.Platform.AppTemplate.Configuration.Log
{
  ///<summary>
  /// Describes the format of the log string to be written into the log file.
  ///</summary>
  public enum MessageFormat
  {
    ///<summary>
    /// Short message header to be written to the log file.
    ///</summary>
    Short,
    ///<summary>
    /// Short message header with LoggerName information to be written to the log file.
    ///</summary>
    Medium,
    ///<summary>
    /// Full message header to be written to the log file.
    ///</summary>
    Full,
    /// <summary>
    /// Short message header to be written to the log file. 
    /// Fields are separated by commas.
    /// </summary>
    ShortCsv,
    /// <summary>
    /// Short message header to be written to the log file. 
    /// Fields are separated by tabs.
    /// </summary>
    ShortTsv,
    /// <summary>
    /// Short message header to be written to the log file. 
    /// Fields are separated by defined delimiter.
    /// </summary>
    ShortDsv
  }
  /// <summary>
  /// Describes the way of time string formatting.
  /// </summary>
  public enum TimeFormat
  {
    /// <summary>
    /// Time in format: <code>"HH:mm:ss.SSS"</code>.
    /// </summary>
    Time,
    /// <summary>
    /// Default formatting by thread locale.
    /// </summary>
    Locale,
    /// <summary>
    /// Time in format: <code>"yyyy-MM-dd'T'HH-mm-ss.SSS"</code>.
    /// </summary>
    Iso8601
  }
  /// <summary>
  /// The verbose level for logger.
  /// </summary>
  public enum VerboseLevel
  {
    /// <summary>
    /// Log all messages.
    /// </summary>
    All,
    /// <summary>
    /// Log messages with priority not lower than debug.
    /// </summary>
    Debug,
    /// <summary>
    /// Log messages with priority not lower than trace.
    /// </summary>
    Trace,
    /// <summary>
    /// Log messages with priority not lower than interaction.
    /// </summary>
    Interaction,
    /// <summary>
    /// Log messages with priority not lower than standard.
    /// </summary>
    Standard,
    /// <summary>
    /// Log messages with priority not lower than alarm.
    /// </summary>
    Alarm,
    /// <summary>
    /// Do not log any messages.
    /// </summary>
    None
  }

  /// <summary>
  /// Interface describes logger configuration
  /// </summary>
  public interface IGLoggerConfiguration
  {
    /// <summary>
    /// Application configuration
    /// </summary>
    IGApplicationConfiguration ApplicationConfiguration { get; }
    /// <summary>
    /// Extended configuration
    /// </summary>
    GAppLogExtOptions ExtOptions { get; }
    ///<summary>
    /// The name of application to be used in the logs.
    ///</summary>
    string ApplicationName { get; }

    ///<summary>
    /// The host of application to be used in the logs.
    ///</summary>
    string ApplicationHost { get;  }

    ///<summary>
    /// The type of application to be used in the logs.
    ///</summary>
    int ApplicationType { get; }

    ///<summary>
    /// The ID of application to be used in the logs.
    ///</summary>
    int ApplicationId { get; }
    ///<summary>
    /// Protocol timeout of Message Server Protocol, seconds
    ///</summary>
    int MessageServerTimeout { get; }
    /// <summary>
    /// Enable write into log information about thread.
    /// </summary>
    bool EnableThread { get; }
    /// <summary>
    /// Enable write into log partial stack trace information.
    /// </summary>
    bool StackTrace { get; }
    /// <summary>
    /// Selects message format
    /// </summary>
    MessageFormat Format { get; }
    /// <summary>
    /// Returns delimiter in message header
    /// </summary>
    String MessageHeaderDelimiter { get; }
    /// <summary>
    /// Selects time format
    /// </summary>
    TimeFormat TimeFormatting { get; }
    /// <summary>
    /// Selects date time kind (Local/UTC)
    /// </summary>
    DateTimeKind TimeKind { get; }
    /// <summary>
    /// Selects verbose level
    /// </summary>
    VerboseLevel Verbose { get; }
    /// <summary>
    /// Returns collections of targers
    /// </summary>
    IList<TargetConfig> Targets { get; }
    /// <summary>
    /// Returns the log segmentation configuration.
    /// </summary>
    SegmentationConfig Segmentation { get; }
    /// <summary>
    /// Returns the log expiration configuration.
    /// </summary>
    ExpirationConfig Expiration { get; }
    /// <summary>
    /// Enables/disables buffering log file
    /// </summary>
    bool Buffering { get; }
    /// <summary>
    /// Enables/disables delete archive files
    /// </summary>
    bool DeleteArchiveFiles { get; }
  }
}

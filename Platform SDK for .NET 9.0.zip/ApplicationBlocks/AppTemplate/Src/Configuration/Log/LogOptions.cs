//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Net;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.AppTemplate.Configuration.Log
{
  internal class LogOptions
  {
    private static readonly Dictionary<string, LogOptionDescription> Options = new Dictionary<string, LogOptionDescription>();
    public static readonly IDictionary<string, LogOptionDescription> OptionsMap = new Utilites.ReadOnlyDictionary<string, LogOptionDescription>(Options); 

    internal abstract class LogOptionDescription
    {
      private readonly string _name;
      public string Name { get { return _name; } } 
      private readonly IList<string> _names;
      private IList<string> OptionNames {get { return _names; }}
      /// <exclude/>
      public LogOptionDescription(string[] names)
      {
        if (names==null) 
          throw new ArgumentNullException("names");
        if (names.Length == 0)
          throw new ArgumentException("names");
        _name = names[0];
        _names = new ReadOnlyCollection<string>(names); 
      }
    }
    internal class LogOptionDescription<TValue>:LogOptionDescription
    {
      private readonly TValue _defValue;
      public LogOptionDescription(string[] names, TValue defValue):base(names)
      {
        _defValue = defValue;
        foreach (string name in names)
        {
          if (!Options.ContainsKey(name.ToLower(CultureInfo.InvariantCulture)))
            Options.Add(name.ToLower(CultureInfo.InvariantCulture), this);
        }
      }
      public TValue DevaultValue{get { return _defValue; }}
    }
    /// <summary>
    /// Platform SDK AppTemplate AB specific property to let user applications be able
    /// to override the applications' host name in log files and message server events.
    /// The log option name (case insensitive): <c>EventLogHost</c>,<c>event-log-host</c>,<c>event_log_host</c><br/>
    /// For example:<code>event-log-host = node-1-virtual-host</code>
    /// 
    /// </summary>
    public static readonly LogOptionDescription<string> EventLogHost = 
      new LogOptionDescription<string>(new []{"EventLogHost", "event-log-host", "event_log_host"},
        ConfigurationUtil.GetLocalhostName());
    /// <summary>
    /// Specifies the file name for application-specific log events. The name must be
    /// valid for the operating system on which the application is running. The option
    /// value can also contain the absolute path to the application-specific *.lms file.
    /// Otherwise, an application looks for the file in its working directory. <br/>
    /// <i><b>Warning:</b>An application that does not find its *.lms file at startup cannot
    /// generate application-specific log events and send them to Message Server.</i>
    /// The log option name (case insensitive): <c>MessageFile</c>,<c>message-file</c>,<c>message_file</c><br/>
    /// For example:<code>message_file = mymsg.lms</code>
    /// </summary>
    public static readonly LogOptionDescription<string> MessageFile =
      new LogOptionDescription<string>(new[] { "MessageFile", "message-file", "message_file" },
        null);
    /// <summary>
    /// Specifies if log output is created, and if so, the minimum level of log events
    /// generated. Log event levels, starting with the highest priority level, are
    /// Standard, Interaction, Trace, and Debug.
    /// You must separate the log output types by a comma when you are configuring
    /// more than one output for the same log level.
    /// The log option name (case insensitive): <c>Verbose</c><br/>
    /// </summary>
    public static readonly LogOptionDescription<VerboseLevel> Verbose =
      new LogOptionDescription<VerboseLevel>(new[] { "Verbose" }, VerboseLevel.All);
    /// <summary>
    /// Specifies whether there is a segmentation limit for a log file. If there is, sets the
    /// mode of measurement, along with the maximum size. If the current log
    /// segment exceeds the size set by this option, the file is closed and a new one is
    /// created. This option is ignored if log output is not configured to be sent to a log file.
    /// <list type="table">
    /// <listheader><term>Value</term><description>Description</description></listheader>
    /// <item><term>false</term><description>No segmentation</description></item>
    /// <item><term>5 MB</term><description>Sets the maximum segment size, in megabytes. (Minimum value = 1 MB)</description></item>
    /// <item><term>200 KB</term><description>Sets the maximum segment size, in kilobytes. (Minimum value = 100 KB)</description></item>
    /// <item><term>3 hr</term><description>Sets the number of hours for the segment to stay open. The minimum number is 1 hour.</description></item>
    /// <item><term>100</term><description>Sets the maximum segment size, in kilobytes. (Minimum value = 100 KB)</description></item>
    /// </list>
    /// The log option name (case insensitive): <c>Segment</c><br/>
    /// For example:<code> Segment = 100 KB</code>
    /// </summary>
    public static readonly LogOptionDescription<SegmentationConfig> Segmentation =
      new LogOptionDescription<SegmentationConfig>(new[] { "Segment" }, SegmentationConfig.DefaultSegmentation);
    /// <summary>
    /// Determines whether log files expire. If they do, sets the measurement for
    /// determining when they expire, along with the maximum number of files
    /// (segments) or days before the files are removed. This option is ignored if log
    /// output is not configured to be sent to a log file.
    /// <list type="table">
    /// <listheader><term>Value</term><description>Description</description></listheader>
    /// <item><term>false</term><description>No expiration; all generated segments are stored.</description></item>
    /// <item><term>&lt;number&gt;[ file]</term><description>Sets the maximum number of log files to store. Specify a number from 1 to 1000.</description></item>
    /// <item><term>&lt;number&gt;[ day]</term><description> Sets the maximum number of days before log files are deleted. Specify a number from 1 to 100.</description></item>
    /// </list>
    /// <i><b>Note:</b>If an option’s value is set incorrectly (out of the range of valid values), it will be automatically reset to 10.</i>
    /// The log option name (case insensitive): <c>Expire</c><br/>
    /// </summary>
    public static readonly LogOptionDescription<ExpirationConfig> Expiration =
      new LogOptionDescription<ExpirationConfig>(new[] { "Expire" }, ExpirationConfig.DefaultExpiration);
    /// <summary>
    /// Specifies the system in which an application calculates the log record time
    /// when generating a log file. The time is converted from the time in seconds
    /// since "00:00:00 UTC, January 1, 1970".
    /// The log option name (case insensitive): <c>TimeConvert</c>,<c>time-convert</c>,<c>time_convert</c>.
    /// </summary>
    public static readonly LogOptionDescription<DateTimeKind> TimeConvert =
      new LogOptionDescription<DateTimeKind>(new[] { "TimeConvert","time-convert","time_convert" }, DateTimeKind.Local);
    /// <summary>
    /// Specifies how to represent, in a log file, the time when an application generates
    /// log records.
    /// A log record’s time field in the ISO 8601 format looks like this: "<code>2001-07-24T04:58:10.123</code>".
    /// Default Value: Time
    /// <list type="table">
    /// <listheader><term>Value</term><description>Description</description></listheader>
    /// <item><term>Time</term><description>The time string is formatted according to HH:MM:SS.sss (hours, minutes, seconds, and milliseconds) format.</description></item>
    /// <item><term>Locale</term><description>The time string is formatted according to the system’s locale.</description></item>
    /// <item><term>Iso8601</term><description> The date in the time string is formatted according to the ISO 8601 format. Fractional seconds are given in milliseconds.</description></item>
    /// </list>
    /// The log option name (case insensitive): <c>TimeFormat</c>,<c>time-format</c>,<c>time_format</c>.
    /// </summary>
    public static readonly LogOptionDescription<TimeFormat> TimeFormat =
      new LogOptionDescription<TimeFormat>(new[] { "TimeFormat", "time-format", "time_format" }, Log.TimeFormat.Time);
    /// <summary>
    /// Specifies the format of log record headers that an application uses when
    /// writing logs in the log file. Using compressed log record headers improves
    /// application performance and reduces the log file's size.
    /// With the value set to '<b>Short</b>':
    /// <list type="bullet">
    ///   <item>A header of the log file or the log file segment contains information about
    /// the application (such as the application name, application type, host type,
    /// and time zone), whereas single log records within the file or segment omit
    /// this information.</item>
    /// <item>A log message priority is abbreviated to Std, Int, Trc, or Dbg, for Standard,
    /// Interaction, Trace, or Debug messages, respectively.</item>
    /// <item>The message ID does not contain the prefix GCTI or the application type ID.</item>
    /// </list>
    /// A log record in the <b>full</b> format looks like this: 
    /// <code>2002-05-07T18:11:38.196 Standard localhost cfg_dbserver GCTI-00-05060 Application started</code>
    /// A log record in the <b>short</b> format looks like this:
    /// <code>2002-05-07T18:15:33.952 Std 05060 Application started</code>
    /// <list type="table">
    /// <listheader><term>Value</term><description>Description</description></listheader>
    /// <item><term>short</term><description>An application uses compressed headers when writing log records in its log file.</description></item>
    /// <item><term>medium</term><description>An application uses medium size headers when writing log records in its log file.</description></item>
    /// <item><term>full</term><description>An application uses complete headers when writing log records in its log file.</description></item>
    /// <item><term>shortcsv</term><description>An application uses compressed headers with comma delimiter when writing log records in its log file.</description></item>
    /// <item><term>shorttsv</term><description>An application uses compressed headers with tab char delimiter when writing log records in its log file.</description></item>
    /// <item><term>shortdsv</term><description>An application uses compressed headers with <see cref="MessageHeaderDelimiter"/> delimiter when writing log records in its log file.</description></item>
    /// </list>
    /// The log option name (case insensitive): <c>MessageFormat</c>,<c>message-format</c>,<c>message_format</c>.
    /// </summary>
    public static readonly LogOptionDescription<MessageFormat> MessageFormat =
      new LogOptionDescription<MessageFormat>(new[] { "MessageFormat", "message-format", "message_format" }, Log.MessageFormat.Short);
    /// <summary>
    /// Platform SDK AppTemplate AB specific property as a parameter for <see cref="Log.MessageFormat.ShortDsv"/>
    /// The log option name (case insensitive): <c>MessageHeaderDelimiter</c>,<c>message-header-delimiter</c>,<c>message_header_delimiter</c>.
    /// </summary>
    public static readonly LogOptionDescription<String> MessageHeaderDelimiter =
      new LogOptionDescription<String>(new[] { "MessageHeaderDelimiter", "message-header-delimiter", "message_header_delimiter" }, "|");
    /// <summary>
    /// Application name
    /// The log option name (case insensitive): <c>ApplicationName</c>,<c>application-name</c>,<c>application_name</c>.
    /// </summary>
    public static readonly LogOptionDescription<String> ApplicationName =
      new LogOptionDescription<String>(new[] { "ApplicationName", "application-name", "application_name" }, "");
    /// <summary>
    /// Application host
    /// The log option name (case insensitive): <c>ApplicationHost</c>,<c>application-host</c>,<c>application_host</c>.
    /// </summary>
    public static readonly LogOptionDescription<String> ApplicationHost =
      new LogOptionDescription<String>(new[] { "ApplicationHost", "application-host", "application_host" }, Dns.GetHostName());
    /// <summary>
    /// Application ID
    /// The log option name (case insensitive): <c>ApplicationId</c>,<c>application-id</c>,<c>application_id</c>.
    /// </summary>
    public static readonly LogOptionDescription<int> ApplicationId =
      new LogOptionDescription<int>(new[] { "ApplicationId", "application-id", "application_id" }, 0);
    /// <summary>
    /// Message server timeout, seconds
    /// The log option name (case insensitive): <c>MessageServerTimeout</c>,<c>message-server-timeout</c>,<c>message_server_timeout</c>.
    /// </summary>
    public static readonly LogOptionDescription<int> MessageServerTimeout =
      new LogOptionDescription<int>(new[] { "MessageServerTimeout", "message-server-timeout", "message_server_timeout" }, 30);
    /// <summary>
    /// Application Type
    /// The log option name (case insensitive): <c>ApplicationType</c>,<c>application-type</c>,<c>application_type</c>.
    /// </summary>
    public static readonly LogOptionDescription<CfgAppType> ApplicationType =
      new LogOptionDescription<CfgAppType>(new[] { "ApplicationType", "application-type", "application_type" }, CfgAppType.CFGNoApplication);
    /// <summary>
    /// Application Type
    /// The log option name (case insensitive): <c>ApplicationTypeId</c>,<c>ApplicationType</c>,<c>application-type</c>,<c>application_type</c>.
    /// </summary>
    public static readonly LogOptionDescription<int> ApplicationTypeId =
      new LogOptionDescription<int>(new[] { "ApplicationTypeId", "ApplicationType", "application-type", "application_type" }, 0);
    /// <summary>
    /// Platform SDK AppTemplate AB specific property for configuration of the log files encoding.<br/>
    /// Its default value is "UTF-8"
    /// The log option name (case insensitive): <c>FileEncoding</c>,<c>file-encoding</c>,<c>file_encoding</c>.
    /// </summary>
    public static readonly LogOptionDescription<String> LogFileEncoding =
      new LogOptionDescription<String>(new[] { "FileEncoding", "file-encoding", "file_encoding" }, "UTF-8");
    /// <summary>
    /// Platform SDK AppTemplate AB specific property for customization of the log files header content.
    /// Its default value is 'Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl.FileHeaderLayout'/>.
    /// The log option name (case insensitive): <c>FileHeaderProvider</c>,<c>file-header-provider</c>,<c>file_header_provider</c>.
    /// </summary>
    public static readonly LogOptionDescription<String> FileHeaderProvider =
      new LogOptionDescription<String>(new[] { "FileHeaderProvider", "file-header-provider", "file_header_provider" },
        "Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl.FileHeaderLayout");
    /// <summary>
    /// Turns on/off operating system file buffering. The option is applicable only to Console output.
    /// Setting this option to true increases the output performance.
    /// The log option name (case insensitive): <c>Buffering</c>.
    /// </summary>
    public static readonly LogOptionDescription<bool> Buffering =
      new LogOptionDescription<bool>(new[] { "Buffering" }, true);
    /// <summary>
    /// Turns on/off operating system file buffering. The option is applicable only to Console output.
    /// Setting this option to true increases the output performance.
    /// The log option name (case insensitive): <c>DeleteArchiveFiles</c>,<c>delete-archive-files</c>,<c>delete_archive_files</c>.
    /// </summary>
    public static readonly LogOptionDescription<bool> DeleteArchiveFiles =
      new LogOptionDescription<bool>(new[] { "DeleteArchiveFiles", "delete-archive-files", "delete_archive_files" }, false);
    /// <summary>
    /// Specifies, in hours, how often the application generates a check point log
    /// event, to divide the log into sections of equal time. By default, the application
    /// generates this log event every hour. Setting the option to 0 prevents the
    /// generation of check-point events.
    /// The log option name (case insensitive): <c>CheckPoint</c>,<c>check-point</c>,<c>check_point</c>.
    /// </summary>
    public static readonly LogOptionDescription<Int32> CheckPoint =
      new LogOptionDescription<Int32>(new[] { "CheckPoint", "check-point", "check_point" }, 1);
    /// <summary>
    /// Specifies whether to enable or disable the logging thread. If set to true (the
    /// logging thread is enabled), the logs are stored in an internal queue to be written
    /// to the specified output by a dedicated logging thread. This setting also enables
    /// the log throttling feature, which allows the verbose level to be dynamically
    /// reduced when a logging performance issue is detected. Refer to the Framework
    /// 8.5 Management Framework User’s Guide for more information about the log
    /// throttling feature.<br/>
    /// If this option is set to false (the logging thread is disabled), each log is written
    /// directly to the outputs by the thread that initiated the log request. This setting
    /// also disables the log throttling feature.
    /// The log option name (case insensitive): <c>EnableThread</c>,<c>enable-thread</c>,<c>enable_thread</c>.
    /// </summary>
    public static readonly LogOptionDescription<bool> EnableThread =
      new LogOptionDescription<bool>(new[] { "EnableThread", "enable-thread", "enable_thread" }, false);
    /// <summary>
    /// Platform SDK AppTemplate AB specific option to enable the call location information passing
    /// to the Log4j2 logging thread, which was enabled with option <see cref="EnableThread"/>.
    /// This is an expensive operation: 1.3 - 5 times slower for synchronous loggers.
    /// Synchronous loggers wait as long as possible before they take this stack snapshot.
    /// If no location is required, the snapshot will never be taken.<br/>
    /// However, asynchronous loggers need to make this decision before passing the log message
    /// to another thread; the location information will be lost after that point. The performance impact
    /// of taking a stack trace snapshot is even higher for asynchronous loggers: logging with location is
    /// 4 - 20 times slower than without location. For this reason, asynchronous loggers
    /// do not include location information by default.
    /// The log option name (case insensitive): <c>EnableLocationForThread</c>,<c>enable-location-for-thread</c>,<c>enable_location_for_thread</c>.
    /// </summary>
    public static readonly LogOptionDescription<bool> StackTrace =
      new LogOptionDescription<bool>(new[] { "EnableLocationForThread", "enable-location-for-thread", "enable_location_for_thread" }, false);

  }
}

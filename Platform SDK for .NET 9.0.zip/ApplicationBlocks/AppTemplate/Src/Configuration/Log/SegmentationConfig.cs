//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Globalization;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Commons.Logging;

namespace Genesyslab.Platform.AppTemplate.Configuration.Log
{
  /// <summary>
  /// Describes the rule of segmentation of log files.
  /// </summary>
  public sealed class SegmentationConfig
  {
    /// <summary>
    /// Describes types of segmentation
    /// </summary>
    public enum SegmentationStrategy
    {
      /// <summary>
      /// No segmentation
      /// </summary>
      Off,
      /// <summary>
      /// The log file is divided into segments by size in KB. Get function: <see cref="SegmentationConfig.Segment"/>.
      /// </summary>
      SizeKb,
      /// <summary>
      /// The log file is divided into segments by size in MB. Get function: <see cref="SegmentationConfig.Segment"/>.
      /// </summary>
      SizeMb,
      /// <summary>
      /// The log file is divided into segments by time , the old segment is closed
      /// and new is started each <see cref="SegmentationConfig.Segment"/> hours.
      /// </summary>
      TimeBased
    }

    /// <exclude/>
    public static readonly SegmentationConfig NoSegmentation = new SegmentationConfig(SegmentationStrategy.Off, -1);
    /// <exclude/>
    public static readonly SegmentationConfig DefaultSegmentation = new SegmentationConfig(SegmentationStrategy.SizeMb, 100);

    private readonly SegmentationStrategy _strategy;
    private readonly int _segmentSize;
    /// <summary>
    /// Constructor.
    /// </summary>
    /// <param name="strategy">the value for <see cref="IGLoggerConfiguration.Segmentation"/></param>
    /// <param name="segmentSize">the value for <see cref="IGLoggerConfiguration.Segmentation"/></param>
    public SegmentationConfig(SegmentationStrategy strategy, int segmentSize)
    {
      _strategy = strategy;
      if (_strategy != SegmentationStrategy.Off)
      {
        if (segmentSize<1)
          throw new ArgumentException("Log segment value is invalid: "+segmentSize);
        _segmentSize = segmentSize;
      }
      else
      {
        _segmentSize = -1;
      }
    }
    /// <exclude/>
    public SegmentationStrategy Strategy { get { return _strategy; } }
    /// <exclude/>
    public int Segment { get { return _segmentSize; } }

    internal static bool TryGetIntValue(string optionValue, string prefix, string prefixLog, ref int value, ILogger log, int minValue, int maxValue, int setValue, string optName)
    {
      int index = optionValue.Length;
      if (!String.IsNullOrEmpty(prefix))
      {
        index = optionValue.IndexOf(prefix, StringComparison.InvariantCultureIgnoreCase);
        if (index < 0) return false;
      }
      if (!Int32.TryParse(optionValue.Substring(0, index).Trim(), out value))
      {
        if ((log != null) && (log.IsErrorEnabled))
          log.ErrorFormat("The {1} option has invalid value {0}", optionValue, optName);
        return false;
      }
      if ((value < minValue) || ((maxValue>minValue) && (value>maxValue)))
      {
        if (setValue > 0)
        {
          if ((log != null) && (log.IsErrorEnabled))
            log.ErrorFormat("The {3} option has invalid value {0} {1}, set to {4} {1})", value, prefixLog, minValue, optName, setValue);
          value = setValue;
          return true;
        }
        if ((log != null) && (log.IsErrorEnabled))
          log.ErrorFormat("The {3} option has invalid value {0} {1}. (min is {2} {1})", value, prefixLog, minValue, optName);
        return false;
      }
      return true;
    }
    /// <exclude/>
    public static SegmentationConfig Parse(String optionValue, ILogger logger)
    {
      if (String.IsNullOrEmpty(optionValue)) return null;
      optionValue = optionValue.Trim().ToLower(CultureInfo.InvariantCulture);
      if (String.IsNullOrEmpty(optionValue)) return null;
      if (ConfigurationUtil.IsFalse(optionValue)) return NoSegmentation;
      int segmentValue=0;
      if (TryGetIntValue(optionValue, "kb", "KBs", ref segmentValue, logger, 100, 0, -1, "segment"))
        return new SegmentationConfig(SegmentationStrategy.SizeKb, segmentValue);
      if (TryGetIntValue(optionValue, "mb", "MBs", ref segmentValue, logger, 1, 0, -1, "segment"))
        return new SegmentationConfig(SegmentationStrategy.SizeMb, segmentValue);
      if (TryGetIntValue(optionValue, "hr", "hrs", ref segmentValue, logger, 1, 0, -1, "segment"))
        return new SegmentationConfig(SegmentationStrategy.TimeBased, segmentValue);
      if (TryGetIntValue(optionValue, null, "KBs", ref segmentValue, logger, 100, 0, 100, "segment"))
        return new SegmentationConfig(SegmentationStrategy.SizeKb, segmentValue);
      return DefaultSegmentation;
    }

    public override string ToString()
    {
      return String.Format("SegmentationConfig(Strategy='{0}',Segment='{1}')", _strategy.ToString("F"), _segmentSize);
    }

    public override bool Equals(object obj)
    {
      if (ReferenceEquals(this, obj)) return true;
      var cfg = obj as SegmentationConfig;
      if (cfg==null) return false;
      return ((cfg._strategy==_strategy) && (cfg._segmentSize!=_segmentSize));
    }

    public override int GetHashCode()
    {
      unchecked
      {
        return GetType().GetHashCode() ^ 59*_segmentSize ^ 61*((int) _strategy);
      }
    }
  }
}

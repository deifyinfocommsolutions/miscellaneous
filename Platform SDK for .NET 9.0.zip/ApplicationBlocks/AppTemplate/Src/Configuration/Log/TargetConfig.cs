//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

namespace Genesyslab.Platform.AppTemplate.Configuration.Log
{
  /// <summary>
  /// Base class for description of a configured logging target.
  /// </summary>
  public class TargetConfig
  {
    /// <summary>
    /// Enumeration of logging target types, which are supported by PSDK AppTemplate Application Block.<br/>
    /// It reflects possible values in the "Log Output Options": "all", "debug", "trace", "interaction", "standard", and "alarm".
    /// </summary>
    public enum TargetType
    {
      /// <summary>
      /// Console output target type.
      /// </summary>
      StdOut,
      /// <summary>
      /// Console output target type.
      /// </summary>
      StdErr,
      /// <summary>
      /// Plain log file output target type.<br/>
      /// This target type is described with separate structure to handle log file name - <see cref="FileTargetConfig.FileName"/> 
      /// </summary>
      FileLogger,
      /// <summary>
      /// Message Server output target type.
      /// </summary>
      MessageServer,
      /// <summary>
      /// Memory output target
      /// </summary>
      Memory
    }
    private readonly TargetType _targetType;
    private readonly VerboseLevel _supportedVerboseLevel;
    /// <summary>
    /// The target description object constructor.
    /// </summary>
    /// <param name="target">the logging target type.</param>
    /// <param name="verbose">the verbose level for the logging target.</param>
    public TargetConfig(TargetType target, VerboseLevel verbose)
    {
      _targetType = target;
      _supportedVerboseLevel = verbose;
    }
    /// <summary>
    /// Returns logging target type.
    /// </summary>
    public TargetType Target { get { return _targetType; }}
    /// <summary>
    /// Returns verbose level for the log target.
    /// </summary>
    public VerboseLevel Verbose { get { return _supportedVerboseLevel; } }
    /// <summary>
    /// Returns readable string representation of the logging target.
    /// </summary>
    /// <returns>string representation of the logging target</returns>
    public override string ToString()
    {
      return String.Format("LoggingTarget(type={0},level={1})", _targetType.ToString("F"),
        _supportedVerboseLevel.ToString("F"));
    }
    /// <summary>
    /// Compares types of logging targets. It does not take into account logging verbose level -
    /// it is required for targets consolidation (normalization) functions.
    /// </summary>
    /// <param name="obj"></param>
    /// <returns></returns>
    public override bool Equals(object obj)
    {
      if (ReferenceEquals(this, obj)) return true;
      var tc = obj as TargetConfig;
      if (tc == null) return false;
      return (_targetType == tc._targetType);
    }

    public override int GetHashCode()
    {
      unchecked
      {
        return GetType().GetHashCode() ^ 61*((int) _targetType);
      }
    }
  }
}

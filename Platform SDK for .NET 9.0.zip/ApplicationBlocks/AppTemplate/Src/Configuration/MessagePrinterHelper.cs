//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using System.Collections;
using System.Collections.Generic;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Protocols.Internal;
using Genesyslab.Platform.Commons.Protocols.Internal.Custom;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Helper to hide message attributes or complex type attributes from <see cref="IMessage.ToString()"/> output.<br/>
  /// Supported complex types: attributes that extend <see cref="IComplexClass"/> or <see cref="ICustomPrintable"/>.<br/>
  /// This helper parses application options and apply result for <see cref="ToStringHelper"/>.<br/>
  /// Option format:
  /// <code>
  /// [log-hidden-attributes]
  /// &lt;ProtocolName&gt;.&lt;Message Name | Complex Attribute Name&gt; = &lt;Attributes List&gt;
  /// </code>
  /// For example:
  /// <code>
  /// [log-hidden-attributes]
  ///   ContactServer.InteractionContent = "Text, StructuredText"
  /// </code>
  /// If another options format required, use <see cref="ToStringHelper"/> directly. 
  /// </summary>
  public static class MessagePrinterHelper
  {
    /// <summary>
    /// Applies new hidden attributes configuration:
    /// </summary>
    /// <example>
    /// Usage:
    /// <code>
    ///   MessagePrinterHelper.SetHiddenAttributes(cfgApp.Options["log-hidden-attributes"] as KeyValueCollection);
    /// </code>
    /// or 
    /// <code>
    ///   MessagePrinterHelper.SetHiddenAttributes(cfgApp.Options);
    /// </code>
    /// </example>
    /// <param name="configSection">application options or the options section with the name 'log-hidden-attributes'</param>
    public static void SetHiddenAttributes(KeyValueCollection configSection)
    {
      if (configSection == null)
      {
        ToStringHelper.SetHiddenAttributes(null);
      }
      else
      {
        configSection = configSection["log-hidden-attributes"] as KeyValueCollection ?? configSection;
        ToStringHelper.SetHiddenAttributes(ParseOptions(configSection));
      }
    }
    /// <summary>
    /// Applies new hidden attributes configuration:
    /// </summary>
    /// <example>
    /// Usage:
    /// <code>
    ///   MessagePrinterHelper.SetHiddenAttributes(cfgApplication);
    /// </code>
    /// </example>
    /// <param name="cfgApplication">application</param>
    public static void SetHiddenAttributesA(CfgApplication cfgApplication)
    {
      if (cfgApplication == null)
      {
        ToStringHelper.SetHiddenAttributes(null);
      }
      else
      {
        SetHiddenAttributes(cfgApplication.Options);
      }
    }

    /// <summary>
    /// Checks if <see cref="CfgDeltaApplication"/> has changes in hidden attributes section.
    /// </summary>
    /// <param name="delta">application delta, received from Config Server. </param>
    /// <param name="sectionName">section name in application options, i.e. "log-hidden-attributes".</param>
    /// <returns>true if <see cref="CfgDeltaApplication"/> has changes in hidden attributes section. </returns>
    public static bool IsConfigurationChanged(CfgDeltaApplication delta, String sectionName)
    {
      if (sectionName == null)
      {
        throw new ArgumentNullException("sectionName", "sectionName is null");
      }
      return delta != null && (HasSection(delta.AddedOptions, sectionName)
                               || HasSection(delta.ChangedOptions, sectionName)
                               || HasSection(delta.DeletedOptions, sectionName));
    }

    #region private
    private readonly static HashSet<string> EmptyAttributes = new HashSet<string>();

    private static bool HasSection(KeyValueCollection options, String sectionName)
    {
      return options != null && options.ContainsKey(sectionName);
    }
    private static LogHiddenAttributes ParseOptions(KeyValueCollection logSection)
    {
      var config = new LogHiddenAttributes();
      foreach (DictionaryEntry entry in logSection)
      {
        var key = entry.Key as String;
        if (String.IsNullOrEmpty(key)) continue;
        if ((entry.Value != null) && (!(entry.Value is string))) continue;
        var value = entry.Value as String;
        var keyParts = key.Split(new[] {'.'});
        if (keyParts.Length >= 2)
        {
          var protocolName = keyParts[0].Trim();
          var className = keyParts[1].Trim();
          if (String.IsNullOrEmpty(value))
          {
            config.Set(protocolName, className, EmptyAttributes);
          }
          else
          {
            var attributeSet = new HashSet<String>();
            String[] valueParts = value.Split(new[] {',', ';'});
            foreach (string s in valueParts)
            {
              attributeSet.Add(s.Trim());
            }
            config.Set(protocolName, className, attributeSet);
          }
        }
      }
      return config;
    }

    #endregion
  }
}

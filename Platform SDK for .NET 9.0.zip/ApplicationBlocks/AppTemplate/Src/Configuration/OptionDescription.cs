//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Contains definition of application option, including option name in ConnectionConfiguration, option name in
  /// Config Object options list, section in Config Object option list, and a list of Configuration Objects which
  /// may contain the option.
  /// Immutable.
  /// </summary>
  public class OptionDescription
  {
    /// <summary>
    /// Supported locations for options.<br/>
    /// Precedence of option locations:<br/>
    /// 1. CONN_PARAMS/PORT_PARAMS <br/>
    /// 2. APP_OPTIONS<br/>
    /// 3. APP_ANNEX<br/>
    /// 4. HOST_ANNEX<br/>
    /// </summary>
    public enum OptionLocation
    {
      /// <exclude/>
      HostAnnex,
      /// <exclude/>
      AppOptions,
      /// <exclude/>
      AppAnnex,
      /// <exclude/>
      PortParams,
      /// <exclude/>
      ConnParams
    }
    /// <summary>
    /// Option's name as appears in Config objects
    /// </summary>
    public string ConfigOptionName { get; private set; }
    /// <summary>
    /// Option's name as appears in ConnectionConfiguration
    /// </summary>
    public string OptionName { get; private set; }
    /// <summary>
    /// Section of Options or Annex to look into for the option
    /// </summary>
    public string SectionName { get; private set; }
    /// <summary>
    /// List of possible locations of the option. OptionDescription makes a copy of the list.
    /// </summary>
    public List<OptionLocation> Locations { get; private set; }

    /// <summary>
    /// Constructor of class
    /// </summary>
    /// <param name="configOptionName">Name of option as appears in Config objects</param>
    /// <param name="optionName">Name of option as appears in ConnectionConfiguration</param>
    /// <param name="sectionName">Section of Options or Annex to look into for the option</param>
    /// <param name="locations">List of possible locations of the option. OptionDescription makes a copy of the list.</param>
    public OptionDescription(String configOptionName, String optionName, String sectionName,
        IEnumerable<OptionLocation> locations)
    {
      ConfigOptionName = configOptionName;
      OptionName = optionName;
      SectionName = sectionName;
      Locations = new List<OptionLocation>(locations);
    }
  }
}

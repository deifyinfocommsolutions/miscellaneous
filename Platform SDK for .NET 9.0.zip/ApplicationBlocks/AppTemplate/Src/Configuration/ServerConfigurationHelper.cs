//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.AppTemplate.Configuration
{
  /// <summary>
  /// Helper class for <see cref="ServerChannel"/> connection configuration initialization.
  /// </summary>
  /// <example>
  /// <para><b>Usage sample is following:</b></para>
  /// <code>
  /// String appName = "&lt;my-app-name&gt;";
  /// var cfgApplication = confService.RetrieveObject&lt;CfgApplication&gt;(new CfgApplicationQuery(){ Name = appName});
  /// var appConfig = new GCOMApplicationConfiguration(cfgApplication);
  /// var endpoint = ServerConfigurationHelper.CreateListeningEndpoint(appConfig, appConfig.PortInfo("default"));
  /// var serverChannel = new ExternalServiceProtocolListener(endpoint);
  /// // TODO: Initialization of handlers
  /// serverChannel.Open();
  /// </code>
  /// </example>
  public static class ServerConfigurationHelper
  {
    private const String EnableIpv6Section = "common";

    /// <summary>
    /// Builds server channel configuration from the given application configuration information.<br/>
    /// </summary>
    /// <param name="application">main application configuration</param>
    /// <param name="portInfo">configuration of particular port from the application</param>
    /// <returns>new instance of "local" Endpoint to listen on with attached connection configuration</returns>
    public static Endpoint CreateListeningEndpoint(IGApplicationConfiguration application, IGPortInfo portInfo)
    {
      if (application == null)
      {
        throw new ConfigurationException(
          "ServerChannelConfiguration requires non-null application configuration");
      }
      var serverInfo = application.ServerInfo;
      if (serverInfo == null)
      {
        throw new ConfigurationException(
          "ServerChannelConfiguration requires non-null serverInfo configuration");
      }
      if (portInfo == null)
      {
        throw new ConfigurationException(
          "No proper listening port info specified");
      }
      int? portNum = portInfo.Port;
      if (portNum == null)
      {
        throw new ConfigurationException(
          "No listening port value specified");
      }

      String endpointName = "srv-" + application.ApplicationName + "-" + portNum;

      // null means 'listen on all available network interfaces'
      String nicName = ConfigurationUtil.FindTransportParameter(
        portInfo.TransportParams,
        // todo proper option name/value in "transport params" for this:
        "listening-nicname");

      var config = new PropertyConfiguration();
      var tlsReader = new GConfigTlsPropertyReader(application, portInfo);
      TLSConfiguration.ParseTlsConfiguration(config, tlsReader);

      FillServerCommonOptions(config, application, portInfo);
      FillServerIPv6Options(config, application, portInfo);
      FillServerAddpOptions(config, application, portInfo);

      if (nicName != null)
      {
        return new Endpoint(endpointName, nicName, portNum.Value, config);
      }
      return new WildcardEndpoint(endpointName, portNum.Value, config);
    }

    private static void FillServerCommonOptions(
      AbstractConnectionConfiguration targetConfig, IGApplicationConfiguration appConfig, IGPortInfo portConfig)
    {
      var reader = new GConfigPropertyReader(appConfig, portConfig, "");
      foreach (OptionDescription od in PsdkDefaultOptions.Options)
      {
        String optionValue = reader.GetProperty(od);
        if (null != optionValue)
        {
          targetConfig.SetOption(od.OptionName, optionValue);
        }
      }
    }

    private static void FillServerAddpOptions(IClientConnectionOptions targetConfig,
      IGApplicationConfiguration appConfig, IGPortInfo portConfig)
    {
      targetConfig.UseAddp = true; // todo disable ADDP by some option?
    }

    private static void FillServerIPv6Options(IClientConnectionOptions targetConfig,
      IGApplicationConfiguration appConfig, IGPortInfo portConfig)
    {
      String enableIpv6Str = CommonConnection.DefaultEnableIpV6;
      var options = appConfig.Options;
      if (null != options)
      {
        var common = options[EnableIpv6Section] as KeyValueCollection;
        if (null != common)
        {
          enableIpv6Str = common[CommonConnection.EnableIPv6Key] as string;
        }
      }
      targetConfig.IPv6Enabled = ConfigurationUtil.IsTrue(enableIpv6Str);
    }

  }
}

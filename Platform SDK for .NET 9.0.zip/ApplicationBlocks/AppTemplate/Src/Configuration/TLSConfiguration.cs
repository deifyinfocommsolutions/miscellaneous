//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genesyslab.Platform.AppTemplate.Utilites;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Connection.Configuration;

namespace Genesyslab.Platform.AppTemplate.Configuration
{

  /// <summary>
  /// Represents configuration's property value
  /// </summary>
  /// <typeparam name="T">Type of property value. The following types are supported: <see cref="String"/>, <see cref="int"/>, <see cref="bool"/>. <br/>
  /// Any try to create property with another type leads to <see cref="ConfigurationException"/>.
  /// </typeparam>
  public class ConfigurationProperty<T>
  {
    /// <summary>
    /// Returns property's value
    /// </summary>
    public T Value { get; internal set; }
    /// <summary>
    /// Returns property key
    /// </summary>
    public string Key { get; private set; }
    /// <summary>
    /// Creates configuration's property value represents value in configuration's snapshot.
    /// </summary>
    /// <param name="cfg">Connection's configuration</param>
    /// <param name="key">Property's name</param>
    public ConfigurationProperty(IConnectionConfiguration cfg, string key)
    {
      Key = key;
      if (typeof (T) == typeof (string))
      {
        Value = (T)Convert.ChangeType(cfg.GetOption(key),typeof(T));
      }
      else if (typeof (T) == typeof (int))
      {
        Value = (T)Convert.ChangeType(cfg.GetInteger(key), typeof(T));
      } else
      if (typeof (T) == typeof (bool))
      {
        Value = (T) Convert.ChangeType(cfg.GetBoolean(key), typeof (T));
      }
      else
      {
        throw new ConfigurationException("Configuration type is not supported");
      }
    }
  }
  /// <summary>
  /// Represents snapshot of configuration's properties related to TLS.
  /// </summary>
  public class TLSConfiguration
  {
    /// <exclude/>
    public ConfigurationProperty<bool> TlsEnabled { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<string> Certificate { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<string> CertificateName { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<string> CertificatePassword { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<bool> CheckRevocation { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<bool> Mutual { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<string> TlsVersion { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<string> TlsProtocols { get; private set; }
    /// <exclude/>
    public ConfigurationProperty<bool> TargetNameCheck { get; private set; }
    /// <exclude/>
    public TLSConfiguration(IConnectionConfiguration config)
    {
      TlsEnabled = new ConfigurationProperty<bool>(config, CommonConnection.TlsKey);
      Certificate = new ConfigurationProperty<string>(config, CommonConnection.CertificateKey);
      CertificateName = new ConfigurationProperty<string>(config, CommonConnection.CertificateNameKey);
      CertificatePassword = new ConfigurationProperty<string>(config, CommonConnection.CertificatePwdKey);
      CheckRevocation = new ConfigurationProperty<bool>(config, CommonConnection.TlsCheckCertificateRevocation);
      Mutual = new ConfigurationProperty<bool>(config, CommonConnection.TlsMutualKey);
      TlsVersion = new ConfigurationProperty<string>(config, CommonConnection.TlsVersionKey);
      TlsProtocols = new ConfigurationProperty<string>(config, CommonConnection.TlsProtocolListKey);
      TargetNameCheck = new ConfigurationProperty<bool>(config, CommonConnection.TlsTargetNameCheckKey);
    }
    /// <exclude/>
    public TLSConfiguration(IPropertyReader reader) :
      this(ParseTlsConfiguration(null, reader)){}

  	private const String TargetCheckHost = "host";
	  private const String KeyTargetServerHost = "psdk-internal-target-server-host";
    internal static IConnectionConfiguration ParseTlsConfiguration(IConnectionConfiguration config, IPropertyReader reader)
    {
      if (config==null)
        config = new PropertyConfiguration();
      config.SetBoolean(CommonConnection.TlsKey, ConfigurationUtil.IsTrue(reader.GetProperty(CommonConnection.TlsKey)));
      config.SetOption(CommonConnection.CertificateKey, reader.GetProperty("certificate"));
      config.SetOption(CommonConnection.CertificateNameKey, reader.GetProperty(CommonConnection.CertificateNameKey));
      config.SetOption(CommonConnection.CertificatePwdKey, reader.GetProperty(CommonConnection.CertificatePwdKey));
      config.SetBoolean(CommonConnection.TlsCheckCertificateRevocation,
        ConfigurationUtil.IsTrue(reader.GetProperty(CommonConnection.TlsCheckCertificateRevocation)));
      config.SetBoolean(CommonConnection.TlsMutualKey,
        ConfigurationUtil.IsTrue(reader.GetProperty(CommonConnection.TlsMutualKey)));
      config.SetOption(CommonConnection.TlsVersionKey, reader.GetProperty(CommonConnection.TlsVersionKey));
      config.SetOption(CommonConnection.TlsProtocolListKey, reader.GetProperty(CommonConnection.TlsProtocolListKey));

      var checkHost = reader.GetProperty(CommonConnection.TlsTargetNameCheckKey);
      config.SetBoolean(CommonConnection.TlsTargetNameCheckKey,
        TargetCheckHost.Equals(checkHost, StringComparison.InvariantCultureIgnoreCase) ||
        "true".Equals(checkHost, StringComparison.InvariantCultureIgnoreCase));
      if (config.GetBoolean(CommonConnection.TlsTargetNameCheckKey, false))
      {
        var certName = reader.GetProperty(KeyTargetServerHost);
        if (!String.IsNullOrEmpty(certName))
          config.SetOption(CommonConnection.CertificateNameKey, reader.GetProperty(KeyTargetServerHost));
      }
      // not supported options (it is used only in order to put warnings in log)
      config.SetOption("fips140-enabled", reader.GetProperty("fips140-enabled"));
      config.SetOption("cipher-list", reader.GetProperty("cipher-list"));
      config.SetOption("tls-trusted-ca", reader.GetProperty("tls-trusted-ca"));
      config.SetOption("tls-cert-key", reader.GetProperty("tls-cert-key"));
      return config;
    }
  }


}

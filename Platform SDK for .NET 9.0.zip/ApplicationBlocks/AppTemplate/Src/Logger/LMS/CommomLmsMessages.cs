//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//This file is generatred by LoggerClassGenerator.
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Genesyslab.Platform.AppTemplate.Utilites;


namespace Genesyslab.Platform.AppTemplate.Logger.LMS
{
    ///<summary>
    /// This enum contains the id of messages from the common.lms file with next header:
    /// 64e77fb5|LMS|1.0|common.lms|7.5.000|
    ///</summary>
    [SuppressMessage("Microsoft.Design","CA1008:EnumsShouldHaveZeroValue")]
    public enum CommonLmsMessagesIds
    {
        // ReSharper disable once InconsistentNaming
        ///<summary>1000 is the code for GCTI_EXIT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_EXIT = 1000,

        // ReSharper disable once InconsistentNaming
        ///<summary>2000 is the code for GCTI_REGISTRY message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_REGISTRY = 2000,

        // ReSharper disable once InconsistentNaming
        ///<summary>2001 is the code for GCTI_STDLIB message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_STDLIB = 2001,

        // ReSharper disable once InconsistentNaming
        ///<summary>2002 is the code for GCTI_LOAD_RESOURCE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOAD_RESOURCE = 2002,

        // ReSharper disable once InconsistentNaming
        ///<summary>2003 is the code for GCTI_MEMORY message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_MEMORY = 2003,

        // ReSharper disable once InconsistentNaming
        ///<summary>2024 is the code for GCTI_SIGNAL message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SIGNAL = 2024,

        // ReSharper disable once InconsistentNaming
        ///<summary>2004 is the code for GCTI_DISK_SPACE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DISK_SPACE = 2004,

        // ReSharper disable once InconsistentNaming
        ///<summary>2005 is the code for GCTI_DISK_PERMISSION message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DISK_PERMISSION = 2005,

        // ReSharper disable once InconsistentNaming
        ///<summary>2006 is the code for GCTI_FILE_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_NOT_FOUND = 2006,

        // ReSharper disable once InconsistentNaming
        ///<summary>2007 is the code for GCTI_PATH_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PATH_NOT_FOUND = 2007,

        // ReSharper disable once InconsistentNaming
        ///<summary>2008 is the code for GCTI_DRIVE_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DRIVE_NOT_FOUND = 2008,

        // ReSharper disable once InconsistentNaming
        ///<summary>2009 is the code for GCTI_LOCK_FILE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOCK_FILE = 2009,

        // ReSharper disable once InconsistentNaming
        ///<summary>2010 is the code for GCTI_CREATE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CREATE = 2010,

        // ReSharper disable once InconsistentNaming
        ///<summary>2011 is the code for GCTI_FILE_NAME message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_NAME = 2011,

        // ReSharper disable once InconsistentNaming
        ///<summary>2012 is the code for GCTI_FILE_HANDLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_HANDLE = 2012,

        // ReSharper disable once InconsistentNaming
        ///<summary>2013 is the code for GCTI_INVALID_NAME message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_INVALID_NAME = 2013,

        // ReSharper disable once InconsistentNaming
        ///<summary>2014 is the code for GCTI_DIR_NOT_EMPTY message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DIR_NOT_EMPTY = 2014,

        // ReSharper disable once InconsistentNaming
        ///<summary>2015 is the code for GCTI_PIPE_BROKEN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PIPE_BROKEN = 2015,

        // ReSharper disable once InconsistentNaming
        ///<summary>2016 is the code for GCTI_FILE_UNABLE_TO_OPEN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_UNABLE_TO_OPEN = 2016,

        // ReSharper disable once InconsistentNaming
        ///<summary>2017 is the code for GCTI_FILE_UNABLE_TO_CLOSE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_UNABLE_TO_CLOSE = 2017,

        // ReSharper disable once InconsistentNaming
        ///<summary>2018 is the code for GCTI_FILE_UNABLE_TO_READ message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_UNABLE_TO_READ = 2018,

        // ReSharper disable once InconsistentNaming
        ///<summary>2019 is the code for GCTI_FILE_UNABLE_TO_WRITE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_UNABLE_TO_WRITE = 2019,

        // ReSharper disable once InconsistentNaming
        ///<summary>2020 is the code for GCTI_FILE_UNABLE_TO_CREATE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_UNABLE_TO_CREATE = 2020,

        // ReSharper disable once InconsistentNaming
        ///<summary>2021 is the code for GCTI_FILE_UNABLE_TO_DELETE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_FILE_UNABLE_TO_DELETE = 2021,

        // ReSharper disable once InconsistentNaming
        ///<summary>2100 is the code for GCTI_WRONG_COMMAND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_WRONG_COMMAND = 2100,

        // ReSharper disable once InconsistentNaming
        ///<summary>2101 is the code for GCTI_NET_READ message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_READ = 2101,

        // ReSharper disable once InconsistentNaming
        ///<summary>2102 is the code for GCTI_NET_SEND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_SEND = 2102,

        // ReSharper disable once InconsistentNaming
        ///<summary>2200 is the code for GCTI_PROCESS_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROCESS_START = 2200,

        // ReSharper disable once InconsistentNaming
        ///<summary>2201 is the code for GCTI_PROCESS_STOP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROCESS_STOP = 2201,

        // ReSharper disable once InconsistentNaming
        ///<summary>2202 is the code for GCTI_THREAD_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_THREAD_START = 2202,

        // ReSharper disable once InconsistentNaming
        ///<summary>2203 is the code for GCTI_THREAD_LIMIT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_THREAD_LIMIT = 2203,

        // ReSharper disable once InconsistentNaming
        ///<summary>2204 is the code for GCTI_MEM_HANDLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_MEM_HANDLE = 2204,

        // ReSharper disable once InconsistentNaming
        ///<summary>2205 is the code for GCTI_CREATE_MUTEX message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CREATE_MUTEX = 2205,

        // ReSharper disable once InconsistentNaming
        ///<summary>2206 is the code for GCTI_CREATE_SEMAPHORE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CREATE_SEMAPHORE = 2206,

        // ReSharper disable once InconsistentNaming
        ///<summary>2207 is the code for GCTI_ACCESS_VIOLATION message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_ACCESS_VIOLATION = 2207,

        // ReSharper disable once InconsistentNaming
        ///<summary>3000 is the code for GCTI_CFG_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_NOT_FOUND = 3000,

        // ReSharper disable once InconsistentNaming
        ///<summary>3001 is the code for GCTI_CFG_WRONG_PROTOCOL message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_WRONG_PROTOCOL = 3001,

        // ReSharper disable once InconsistentNaming
        ///<summary>3002 is the code for GCTI_CFG_WRONG_MSG message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_WRONG_MSG = 3002,

        // ReSharper disable once InconsistentNaming
        ///<summary>3003 is the code for GCTI_OBJECT_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OBJECT_NOT_FOUND = 3003,

        // ReSharper disable once InconsistentNaming
        ///<summary>3004 is the code for GCTI_CFG_LIST message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_LIST = 3004,

        // ReSharper disable once InconsistentNaming
        ///<summary>3005 is the code for GCTI_CFG_UNIQ message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_UNIQ = 3005,

        // ReSharper disable once InconsistentNaming
        ///<summary>3006 is the code for GCTI_CFG_INCOMPLETE_DATA message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_INCOMPLETE_DATA = 3006,

        // ReSharper disable once InconsistentNaming
        ///<summary>3007 is the code for GCTI_APPLICATION_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APPLICATION_NOT_FOUND = 3007,

        // ReSharper disable once InconsistentNaming
        ///<summary>3008 is the code for GCTI_APPLICATION_LOCKED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APPLICATION_LOCKED = 3008,

        // ReSharper disable once InconsistentNaming
        ///<summary>3009 is the code for GCTI_OPTION_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_NOT_FOUND = 3009,

        // ReSharper disable once InconsistentNaming
        ///<summary>3010 is the code for GCTI_OPTION_VALUE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_VALUE = 3010,

        // ReSharper disable once InconsistentNaming
        ///<summary>3100 is the code for GCTI_TO_MANY_CNTS message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_TO_MANY_CNTS = 3100,

        // ReSharper disable once InconsistentNaming
        ///<summary>3101 is the code for GCTI_SELECT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SELECT = 3101,

        // ReSharper disable once InconsistentNaming
        ///<summary>3102 is the code for GCTI_HOST_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_HOST_NOT_FOUND = 3102,

        // ReSharper disable once InconsistentNaming
        ///<summary>3103 is the code for GCTI_NET_INIT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_INIT = 3103,

        // ReSharper disable once InconsistentNaming
        ///<summary>3200 is the code for GCTI_NO_LOGIN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NO_LOGIN = 3200,

        // ReSharper disable once InconsistentNaming
        ///<summary>3201 is the code for GCTI_LOGIN_EXP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOGIN_EXP = 3201,

        // ReSharper disable once InconsistentNaming
        ///<summary>3202 is the code for GCTI_PERMISSIONS message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PERMISSIONS = 3202,

        // ReSharper disable once InconsistentNaming
        ///<summary>3203 is the code for GCTI_LOGIN_DISABLED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOGIN_DISABLED = 3203,

        // ReSharper disable once InconsistentNaming
        ///<summary>3204 is the code for GCTI_TOO_MANY_USERS message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_TOO_MANY_USERS = 3204,

        // ReSharper disable once InconsistentNaming
        ///<summary>4001 is the code for GCTI_SERVICE_SUSPEND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVICE_SUSPEND = 4001,

        // ReSharper disable once InconsistentNaming
        ///<summary>4002 is the code for GCTI_SERVICE_CONTINUE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVICE_CONTINUE = 4002,

        // ReSharper disable once InconsistentNaming
        ///<summary>4003 is the code for GCTI_SERVICE_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVICE_START = 4003,

        // ReSharper disable once InconsistentNaming
        ///<summary>4004 is the code for GCTI_SERVICE_STOP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVICE_STOP = 4004,

        // ReSharper disable once InconsistentNaming
        ///<summary>4005 is the code for GCTI_PROC_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROC_START = 4005,

        // ReSharper disable once InconsistentNaming
        ///<summary>4006 is the code for GCTI_PROC_STOP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROC_STOP = 4006,

        // ReSharper disable once InconsistentNaming
        ///<summary>4100 is the code for GCTI_LOG_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_START = 4100,

        // ReSharper disable once InconsistentNaming
        ///<summary>4101 is the code for GCTI_LOG_SEGMENT_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_SEGMENT_START = 4101,

        // ReSharper disable once InconsistentNaming
        ///<summary>4102 is the code for GCTI_LOG_OPT_LEVEL message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPT_LEVEL = 4102,

        // ReSharper disable once InconsistentNaming
        ///<summary>4103 is the code for GCTI_LOG_OPT_SEGMENT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPT_SEGMENT = 4103,

        // ReSharper disable once InconsistentNaming
        ///<summary>4104 is the code for GCTI_LOG_OPT_WRONG_VALUE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPT_WRONG_VALUE = 4104,

        // ReSharper disable once InconsistentNaming
        ///<summary>4105 is the code for GCTI_LOG_OPT_NOT_SUPPORTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPT_NOT_SUPPORTED = 4105,

        // ReSharper disable once InconsistentNaming
        ///<summary>4106 is the code for GCTI_LOG_MSGFILELOADED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_MSGFILELOADED = 4106,

        // ReSharper disable once InconsistentNaming
        ///<summary>4107 is the code for GCTI_LOG_MSGFILELOADERROR message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_MSGFILELOADERROR = 4107,

        // ReSharper disable once InconsistentNaming
        ///<summary>4108 is the code for GCTI_LOG_OPT_EXPIRATION message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPT_EXPIRATION = 4108,

        // ReSharper disable once InconsistentNaming
        ///<summary>4109 is the code for GCTI_LOG_STOP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_STOP = 4109,

        // ReSharper disable once InconsistentNaming
        ///<summary>4110 is the code for GCTI_LOG_OPTSET message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPTSET = 4110,

        // ReSharper disable once InconsistentNaming
        ///<summary>4111 is the code for GCTI_LOG_OPTDEL message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPTDEL = 4111,

        // ReSharper disable once InconsistentNaming
        ///<summary>4112 is the code for GCTI_LOG_OUTCREATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OUTCREATED = 4112,

        // ReSharper disable once InconsistentNaming
        ///<summary>4113 is the code for GCTI_LOG_OUTDELETED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OUTDELETED = 4113,

        // ReSharper disable once InconsistentNaming
        ///<summary>4114 is the code for GCTI_LOG_OPTDUMP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_OPTDUMP = 4114,

        // ReSharper disable once InconsistentNaming
        ///<summary>4115 is the code for GCTI_LOG_ALARM message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_ALARM = 4115,

        // ReSharper disable once InconsistentNaming
        ///<summary>4116 is the code for GCTI_LOG_SUSPENDED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_SUSPENDED = 4116,

        // ReSharper disable once InconsistentNaming
        ///<summary>4117 is the code for GCTI_LOG_RESUMED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_RESUMED = 4117,

        // ReSharper disable once InconsistentNaming
        ///<summary>4118 is the code for GCTI_LOG_NETFILE_WARNING message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_NETFILE_WARNING = 4118,

        // ReSharper disable once InconsistentNaming
        ///<summary>4119 is the code for GCTI_LOG_MMAP_ON_NETWORK_WARNING message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_MMAP_ON_NETWORK_WARNING = 4119,

        // ReSharper disable once InconsistentNaming
        ///<summary>4120 is the code for GCTI_LOG_CHECK_POINT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LOG_CHECK_POINT = 4120,

        // ReSharper disable once InconsistentNaming
        ///<summary>4200 is the code for GCTI_ALARM_CREATION message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_ALARM_CREATION = 4200,

        // ReSharper disable once InconsistentNaming
        ///<summary>4210 is the code for GCTI_ALARM_CLEARANCE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_ALARM_CLEARANCE = 4210,

        // ReSharper disable once InconsistentNaming
        ///<summary>4500 is the code for GCTI_CLIENT_CONNECTING message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CLIENT_CONNECTING = 4500,

        // ReSharper disable once InconsistentNaming
        ///<summary>4501 is the code for GCTI_CLIENT_CONTACTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CLIENT_CONTACTED = 4501,

        // ReSharper disable once InconsistentNaming
        ///<summary>4502 is the code for GCTI_CLIENT_UNABLE_CONNECT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CLIENT_UNABLE_CONNECT = 4502,

        // ReSharper disable once InconsistentNaming
        ///<summary>4503 is the code for GCTI_CLIENT_CONNECTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CLIENT_CONNECTED = 4503,

        // ReSharper disable once InconsistentNaming
        ///<summary>4504 is the code for GCTI_CLIENT_CONNECTION_LOST message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CLIENT_CONNECTION_LOST = 4504,

        // ReSharper disable once InconsistentNaming
        ///<summary>4505 is the code for GCTI_CLIENT_DISCONNECTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CLIENT_DISCONNECTED = 4505,

        // ReSharper disable once InconsistentNaming
        ///<summary>4520 is the code for GCTI_SERVER_NEW_CLIENT_CONNECTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_NEW_CLIENT_CONNECTED = 4520,

        // ReSharper disable once InconsistentNaming
        ///<summary>4521 is the code for GCTI_SERVER_NEW_CLIENT_CONNECTED_FROM message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_NEW_CLIENT_CONNECTED_FROM = 4521,

        // ReSharper disable once InconsistentNaming
        ///<summary>4522 is the code for GCTI_SERVER_CLIENT_AUTHORIZED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_CLIENT_AUTHORIZED = 4522,

        // ReSharper disable once InconsistentNaming
        ///<summary>4523 is the code for GCTI_SERVER_CONNECTION_CLOSED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_CONNECTION_CLOSED = 4523,

        // ReSharper disable once InconsistentNaming
        ///<summary>4524 is the code for GCTI_SERVER_CLIENT_DISCONNECTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_CLIENT_DISCONNECTED = 4524,

        // ReSharper disable once InconsistentNaming
        ///<summary>4525 is the code for GCTI_SERVER_PORT_OPENED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_PORT_OPENED = 4525,

        // ReSharper disable once InconsistentNaming
        ///<summary>4526 is the code for GCTI_SERVER_PORT_UNABLE_TO_OPEN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_PORT_UNABLE_TO_OPEN = 4526,

        // ReSharper disable once InconsistentNaming
        ///<summary>4527 is the code for GCTI_SERVER_CLIENT_VERSION_INCOMPATIBLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SERVER_CLIENT_VERSION_INCOMPATIBLE = 4527,

        // ReSharper disable once InconsistentNaming
        ///<summary>4528 is the code for GCTI_AUTHORIZATION_MESSAGE_RECEIVED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_AUTHORIZATION_MESSAGE_RECEIVED = 4528,

        // ReSharper disable once InconsistentNaming
        ///<summary>4540 is the code for GCTI_COMMUNICATION_UNKNOWN_MESSAGE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_COMMUNICATION_UNKNOWN_MESSAGE = 4540,

        // ReSharper disable once InconsistentNaming
        ///<summary>4541 is the code for GCTI_COMMUNICATION_MESSAGE_RECEIVED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_COMMUNICATION_MESSAGE_RECEIVED = 4541,

        // ReSharper disable once InconsistentNaming
        ///<summary>4542 is the code for GCTI_COMMUNICATION_MESSAGE_SENT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_COMMUNICATION_MESSAGE_SENT = 4542,

        // ReSharper disable once InconsistentNaming
        ///<summary>4543 is the code for GCTI_INTERACTION_MESSAGE_RECEIVED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_INTERACTION_MESSAGE_RECEIVED = 4543,

        // ReSharper disable once InconsistentNaming
        ///<summary>4544 is the code for GCTI_INTERACTION_MESSAGE_GENERATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_INTERACTION_MESSAGE_GENERATED = 4544,

        // ReSharper disable once InconsistentNaming
        ///<summary>4545 is the code for GCTI_INTERACTION_MESSAGE_SENT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_INTERACTION_MESSAGE_SENT = 4545,

        // ReSharper disable once InconsistentNaming
        ///<summary>4546 is the code for GCTI_INVALID_MESSAGE_RECEIVED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_INVALID_MESSAGE_RECEIVED = 4546,

        // ReSharper disable once InconsistentNaming
        ///<summary>4560 is the code for GCTI_REDUNDANCY_WARM_STANDBY_BACKUP_ACTIVATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_REDUNDANCY_WARM_STANDBY_BACKUP_ACTIVATED = 4560,

        // ReSharper disable once InconsistentNaming
        ///<summary>4561 is the code for GCTI_REDUNDANCY_HOT_STANDBY_BACKUP_ACTIVATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_REDUNDANCY_HOT_STANDBY_BACKUP_ACTIVATED = 4561,

        // ReSharper disable once InconsistentNaming
        ///<summary>4562 is the code for GCTI_REDUNDANCY_WARM_STANDBY_PRIMARY_ACTIVATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_REDUNDANCY_WARM_STANDBY_PRIMARY_ACTIVATED = 4562,

        // ReSharper disable once InconsistentNaming
        ///<summary>4563 is the code for GCTI_REDUNDANCY_HOT_STANDBY_PRIMARY_ACTIVATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_REDUNDANCY_HOT_STANDBY_PRIMARY_ACTIVATED = 4563,

        // ReSharper disable once InconsistentNaming
        ///<summary>4580 is the code for GCTI_REDUNDANCY_CONNECTED_HOT_STANDBY message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_REDUNDANCY_CONNECTED_HOT_STANDBY = 4580,

        // ReSharper disable once InconsistentNaming
        ///<summary>4581 is the code for GCTI_REDUNDANCY_PRIMARY_NOT_AVAILABLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_REDUNDANCY_PRIMARY_NOT_AVAILABLE = 4581,

        // ReSharper disable once InconsistentNaming
        ///<summary>5000 is the code for GCTI_ACCESS_NT_REGISTRY message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_ACCESS_NT_REGISTRY = 5000,

        // ReSharper disable once InconsistentNaming
        ///<summary>5020 is the code for GCTI_PROCESS_CANNOT_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROCESS_CANNOT_START = 5020,

        // ReSharper disable once InconsistentNaming
        ///<summary>5021 is the code for GCTI_PROCESS_CANNOT_STOP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROCESS_CANNOT_STOP = 5021,

        // ReSharper disable once InconsistentNaming
        ///<summary>5022 is the code for GCTI_PROCESS_STARTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROCESS_STARTED = 5022,

        // ReSharper disable once InconsistentNaming
        ///<summary>5023 is the code for GCTI_PROCESS_STOPPED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROCESS_STOPPED = 5023,

        // ReSharper disable once InconsistentNaming
        ///<summary>5024 is the code for GCTI_PROCESS_ABNORMALLY_TERMINATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PROCESS_ABNORMALLY_TERMINATED = 5024,

        // ReSharper disable once InconsistentNaming
        ///<summary>5040 is the code for GCTI_THREAD_CANNOT_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_THREAD_CANNOT_START = 5040,

        // ReSharper disable once InconsistentNaming
        ///<summary>5041 is the code for GCTI_THREAD_CANNOT_CREATE_MUTEX message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_THREAD_CANNOT_CREATE_MUTEX = 5041,

        // ReSharper disable once InconsistentNaming
        ///<summary>5042 is the code for GCTI_THREAD_CANNOT_CREATE_SEMAPHORE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_THREAD_CANNOT_CREATE_SEMAPHORE = 5042,

        // ReSharper disable once InconsistentNaming
        ///<summary>5060 is the code for GCTI_APP_STARTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_STARTED = 5060,

        // ReSharper disable once InconsistentNaming
        ///<summary>5061 is the code for GCTI_APP_INIT_COMPLETED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_INIT_COMPLETED = 5061,

        // ReSharper disable once InconsistentNaming
        ///<summary>5062 is the code for GCTI_APP_INIT_FAILED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_INIT_FAILED = 5062,

        // ReSharper disable once InconsistentNaming
        ///<summary>5063 is the code for GCTI_APP_STOPPED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_STOPPED = 5063,

        // ReSharper disable once InconsistentNaming
        ///<summary>5064 is the code for GCTI_APP_TERMINATED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_TERMINATED = 5064,

        // ReSharper disable once InconsistentNaming
        ///<summary>5065 is the code for GCTI_APP_FAILED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_FAILED = 5065,

        // ReSharper disable once InconsistentNaming
        ///<summary>5066 is the code for GCTI_APP_INIT_COMPONENT_FAILED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_INIT_COMPONENT_FAILED = 5066,

        // ReSharper disable once InconsistentNaming
        ///<summary>5080 is the code for GCTI_NT_SERVICE_CANNOT_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NT_SERVICE_CANNOT_START = 5080,

        // ReSharper disable once InconsistentNaming
        ///<summary>5090 is the code for GCTI_SCS_APP_START message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_START = 5090,

        // ReSharper disable once InconsistentNaming
        ///<summary>5091 is the code for GCTI_SCS_APP_PLANNED_STOP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_PLANNED_STOP = 5091,

        // ReSharper disable once InconsistentNaming
        ///<summary>5092 is the code for GCTI_SCS_APP_INITIALIZING message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_INITIALIZING = 5092,

        // ReSharper disable once InconsistentNaming
        ///<summary>5093 is the code for GCTI_SCS_APP_SERVICE_AVAILABLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_SERVICE_AVAILABLE = 5093,

        // ReSharper disable once InconsistentNaming
        ///<summary>5094 is the code for GCTI_SCS_APP_SERVICE_UNAVAILABLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_SERVICE_UNAVAILABLE = 5094,

        // ReSharper disable once InconsistentNaming
        ///<summary>5095 is the code for GCTI_SCS_APP_STATUS_UNKNOWN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_STATUS_UNKNOWN = 5095,

        // ReSharper disable once InconsistentNaming
        ///<summary>5096 is the code for GCTI_SCS_APP_SUSPENDING message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_SUSPENDING = 5096,

        // ReSharper disable once InconsistentNaming
        ///<summary>5097 is the code for GCTI_SCS_APP_SUSPENDED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_SUSPENDED = 5097,

        // ReSharper disable once InconsistentNaming
        ///<summary>5150 is the code for GCTI_SCS_APP_RUNMODE_CHANGED_TO_PRIMARY message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_RUNMODE_CHANGED_TO_PRIMARY = 5150,

        // ReSharper disable once InconsistentNaming
        ///<summary>5151 is the code for GCTI_SCS_APP_RUNMODE_CHANGED_TO_BACKUP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SCS_APP_RUNMODE_CHANGED_TO_BACKUP = 5151,

        // ReSharper disable once InconsistentNaming
        ///<summary>5200 is the code for GCTI_VERSION message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_VERSION = 5200,

        // ReSharper disable once InconsistentNaming
        ///<summary>5201 is the code for GCTI_COPYRIGHT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_COPYRIGHT = 5201,

        // ReSharper disable once InconsistentNaming
        ///<summary>6020 is the code for GCTI_SYSLIB_INIT_FAILED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SYSLIB_INIT_FAILED = 6020,

        // ReSharper disable once InconsistentNaming
        ///<summary>6040 is the code for GCTI_CFG_DATA_NOT_AVAILABLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_DATA_NOT_AVAILABLE = 6040,

        // ReSharper disable once InconsistentNaming
        ///<summary>6041 is the code for GCTI_CFG_DATA_READ message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_DATA_READ = 6041,

        // ReSharper disable once InconsistentNaming
        ///<summary>6042 is the code for GCTI_CFG_DATA_READ_ERROR message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_DATA_READ_ERROR = 6042,

        // ReSharper disable once InconsistentNaming
        ///<summary>6043 is the code for GCTI_CFG_DATA_WRITE_ERROR message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_DATA_WRITE_ERROR = 6043,

        // ReSharper disable once InconsistentNaming
        ///<summary>6044 is the code for GCTI_CFG_DATA_ITEM_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_DATA_ITEM_NOT_FOUND = 6044,

        // ReSharper disable once InconsistentNaming
        ///<summary>6045 is the code for GCTI_CFG_DATA_SPECIFIC_ITEM_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_DATA_SPECIFIC_ITEM_NOT_FOUND = 6045,

        // ReSharper disable once InconsistentNaming
        ///<summary>6046 is the code for GCTI_CFG_MANDATORY_ENTITY_MISSING message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_MANDATORY_ENTITY_MISSING = 6046,

        // ReSharper disable once InconsistentNaming
        ///<summary>6047 is the code for GCTI_CFG_OPTIONAL_ENTITY_MISSING message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_OPTIONAL_ENTITY_MISSING = 6047,

        // ReSharper disable once InconsistentNaming
        ///<summary>6048 is the code for GCTI_CFG_ENTITY_INVALID_VALUE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_ENTITY_INVALID_VALUE = 6048,

        // ReSharper disable once InconsistentNaming
        ///<summary>6049 is the code for GCTI_CFG_ENTITY_SET message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_ENTITY_SET = 6049,

        // ReSharper disable once InconsistentNaming
        ///<summary>6050 is the code for GCTI_CFG_OBJECT_ADDED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_OBJECT_ADDED = 6050,

        // ReSharper disable once InconsistentNaming
        ///<summary>6051 is the code for GCTI_CFG_OBJECT_DELETED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_OBJECT_DELETED = 6051,

        // ReSharper disable once InconsistentNaming
        ///<summary>6052 is the code for GCTI_NO_CFG_APP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NO_CFG_APP = 6052,

        // ReSharper disable once InconsistentNaming
        ///<summary>6053 is the code for GCTI_CFG_APP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_APP = 6053,

        // ReSharper disable once InconsistentNaming
        ///<summary>6054 is the code for GCTI_CFG_REGISTERFAILED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_CFG_REGISTERFAILED = 6054,

        // ReSharper disable once InconsistentNaming
        ///<summary>6080 is the code for GCTI_OPTION_MANDATORY_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_MANDATORY_NOT_FOUND = 6080,

        // ReSharper disable once InconsistentNaming
        ///<summary>6081 is the code for GCTI_APP_OPTION_NOT_FOUND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_APP_OPTION_NOT_FOUND = 6081,

        // ReSharper disable once InconsistentNaming
        ///<summary>6082 is the code for GCTI_OPTION_MANDATORY_INVALID_VALUE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_MANDATORY_INVALID_VALUE = 6082,

        // ReSharper disable once InconsistentNaming
        ///<summary>6083 is the code for GCTI_OPTION_INVALID_VALUE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_INVALID_VALUE = 6083,

        // ReSharper disable once InconsistentNaming
        ///<summary>6084 is the code for GCTI_OPTION_SET message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_SET = 6084,

        // ReSharper disable once InconsistentNaming
        ///<summary>6085 is the code for GCTI_OPTION_SET_DEFAULT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_SET_DEFAULT = 6085,

        // ReSharper disable once InconsistentNaming
        ///<summary>6086 is the code for GCTI_OPTION_CHANGED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_OPTION_CHANGED = 6086,

        // ReSharper disable once InconsistentNaming
        ///<summary>7000 is the code for GCTI_DB_UNABLE_TO_OPEN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DB_UNABLE_TO_OPEN = 7000,

        // ReSharper disable once InconsistentNaming
        ///<summary>7001 is the code for GCTI_DB_OPENED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DB_OPENED = 7001,

        // ReSharper disable once InconsistentNaming
        ///<summary>7002 is the code for GCTI_DB_EXECUTION_FAILURE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DB_EXECUTION_FAILURE = 7002,

        // ReSharper disable once InconsistentNaming
        ///<summary>7020 is the code for GCTI_PERMISSION_DENIED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_PERMISSION_DENIED = 7020,

        // ReSharper disable once InconsistentNaming
        ///<summary>7040 is the code for GCTI_ADDP_NO_RESPONSE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_ADDP_NO_RESPONSE = 7040,

        // ReSharper disable once InconsistentNaming
        ///<summary>7041 is the code for GCTI_ADDP_NO_RESPONSE_FROM_SOCKET message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_ADDP_NO_RESPONSE_FROM_SOCKET = 7041,

        // ReSharper disable once InconsistentNaming
        ///<summary>7060 is the code for GCTI_TLIBRARY_UNABLE_TO_REGISTER_DN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_TLIBRARY_UNABLE_TO_REGISTER_DN = 7060,

        // ReSharper disable once InconsistentNaming
        ///<summary>7100 is the code for GCTI_LICENSE_FAIL message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LICENSE_FAIL = 7100,

        // ReSharper disable once InconsistentNaming
        ///<summary>7101 is the code for GCTI_LICENSE_CHECKED_OUT message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LICENSE_CHECKED_OUT = 7101,

        // ReSharper disable once InconsistentNaming
        ///<summary>7102 is the code for GCTI_LICENSE_CONNECTION_LOST message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LICENSE_CONNECTION_LOST = 7102,

        // ReSharper disable once InconsistentNaming
        ///<summary>7103 is the code for GCTI_LICENSE_CONNECTION_RESTORED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LICENSE_CONNECTION_RESTORED = 7103,

        // ReSharper disable once InconsistentNaming
        ///<summary>7104 is the code for GCTI_LICENSE_FILE_CHANGED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LICENSE_FILE_CHANGED = 7104,

        // ReSharper disable once InconsistentNaming
        ///<summary>7105 is the code for GCTI_LICENSE_RESTORED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_LICENSE_RESTORED = 7105,

        // ReSharper disable once InconsistentNaming
        ///<summary>8000 is the code for GCTI_HOST_DOWN message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_HOST_DOWN = 8000,

        // ReSharper disable once InconsistentNaming
        ///<summary>8001 is the code for GCTI_HOST_UP message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_HOST_UP = 8001,

        // ReSharper disable once InconsistentNaming
        ///<summary>8002 is the code for GCTI_HOST_UNAVAILABLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_HOST_UNAVAILABLE = 8002,

        // ReSharper disable once InconsistentNaming
        ///<summary>8003 is the code for GCTI_HOST_UNREACHABLE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_HOST_UNREACHABLE = 8003,

        // ReSharper disable once InconsistentNaming
        ///<summary>8100 is the code for GCTI_SECURITY_CERTIFICATE_EXPIRED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SECURITY_CERTIFICATE_EXPIRED = 8100,

        // ReSharper disable once InconsistentNaming
        ///<summary>8101 is the code for GCTI_SECURITY_CERTIFCATE_ERROR message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SECURITY_CERTIFCATE_ERROR = 8101,

        // ReSharper disable once InconsistentNaming
        ///<summary>8102 is the code for GCTI_SECURITY_ERROR message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SECURITY_ERROR = 8102,

        // ReSharper disable once InconsistentNaming
        ///<summary>8103 is the code for GCTI_SECURITY_ESTABLISHED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_SECURITY_ESTABLISHED = 8103,

        // ReSharper disable once InconsistentNaming
        ///<summary>9000 is the code for GCTI_NET_NEW_CONNECTION message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_NEW_CONNECTION = 9000,

        // ReSharper disable once InconsistentNaming
        ///<summary>9001 is the code for GCTI_NET_COMMAND message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_COMMAND = 9001,

        // ReSharper disable once InconsistentNaming
        ///<summary>9002 is the code for GCTI_NET_DATA message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_DATA = 9002,

        // ReSharper disable once InconsistentNaming
        ///<summary>9003 is the code for GCTI_NET_TRANS message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_TRANS = 9003,

        // ReSharper disable once InconsistentNaming
        ///<summary>9004 is the code for GCTI_NET_BUF message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_BUF = 9004,

        // ReSharper disable once InconsistentNaming
        ///<summary>9005 is the code for GCTI_NET_CONNECTION_CLOSE message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_NET_CONNECTION_CLOSE = 9005,

        // ReSharper disable once InconsistentNaming
        ///<summary>9500 is the code for GCTI_STUCK_CALLS_DETECTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_STUCK_CALLS_DETECTED = 9500,

        // ReSharper disable once InconsistentNaming
        ///<summary>9501 is the code for GCTI_STUCK_CALLS_NOT_DETECTED message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_STUCK_CALLS_NOT_DETECTED = 9501,

        // ReSharper disable once InconsistentNaming
        ///<summary>9900 is the code for GCTI_DEBUG message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_DEBUG = 9900,

        // ReSharper disable once InconsistentNaming
        ///<summary>9999 is the code for GCTI_INTERNAL message</summary>
        [SuppressMessage("Microsoft.Naming","CA1709:IdentifiersShouldBeCasedCorrectly")]
        [SuppressMessage("Microsoft.Naming","CA1707:IdentifiersShouldNotContainUnderscores")]
        [SuppressMessage("Microsoft.Naming","CA1726:UsePreferredTerms")]
        GCTI_INTERNAL = 9999
    }
}

namespace Genesyslab.Platform.AppTemplate.Logger.LMS
{
    ///<summary>
    /// This class contains the templates of messages from the common.lms file with next header:
    /// 64e77fb5|LMS|1.0|common.lms|7.5.000|
    ///</summary>
    public static class CommonLmsMessages
    {
      private static readonly IDictionary<int, LmsMessageTemplate> MsgTemplates = new Dictionary<int, LmsMessageTemplate>();
      private static readonly IDictionary<int, LmsMessageTemplate> MsgTemplatesReadOnly;
      /// <summary>
      /// Returns templates
      /// </summary>
      public static IDictionary<int, LmsMessageTemplate> Templates { get { return MsgTemplatesReadOnly; }}
      /// <summary>
      /// Returns header
      /// </summary>
      public static readonly LmsFileHeader Header = new LmsFileHeader("64e77fb5", "LMS", "1.0", "common.lms", "7.5.000");
      static CommonLmsMessages()
      {
        MsgTemplatesReadOnly = new ReadOnlyDictionary<int, LmsMessageTemplate>(MsgTemplates);
      }
      private static LmsMessageTemplate CreateTemplate(int id, LmsLogLevel level, string name, string format)
      {
        var template = new LmsMessageTemplate(id, level, name, format);
        if (!MsgTemplates.ContainsKey(template.Id))
          MsgTemplates.Add(template.Id, template);
        return template;
      }

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_EXIT message</summary> 
      public static readonly LmsMessageTemplate GCTI_EXIT = CreateTemplate( 1000, LmsLogLevel.Standard, "GCTI_EXIT", "%s Exiting" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_REGISTRY message</summary> 
      public static readonly LmsMessageTemplate GCTI_REGISTRY = CreateTemplate( 2000, LmsLogLevel.Standard, "GCTI_REGISTRY", "Unable to obtain registry key: '%s', subkey: '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_STDLIB message</summary> 
      public static readonly LmsMessageTemplate GCTI_STDLIB = CreateTemplate( 2001, LmsLogLevel.Standard, "GCTI_STDLIB", "Standard library '%s' initialization failed" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOAD_RESOURCE message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOAD_RESOURCE = CreateTemplate( 2002, LmsLogLevel.Standard, "GCTI_LOAD_RESOURCE", "Unable to load resource '%s', error code '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_MEMORY message</summary> 
      public static readonly LmsMessageTemplate GCTI_MEMORY = CreateTemplate( 2003, LmsLogLevel.Standard, "GCTI_MEMORY", "Insufficient memory" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SIGNAL message</summary> 
      public static readonly LmsMessageTemplate GCTI_SIGNAL = CreateTemplate( 2024, LmsLogLevel.Standard, "GCTI_SIGNAL", "OS signal '%s' received" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DISK_SPACE message</summary> 
      public static readonly LmsMessageTemplate GCTI_DISK_SPACE = CreateTemplate( 2004, LmsLogLevel.Standard, "GCTI_DISK_SPACE", "Not enough disk space" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DISK_PERMISSION message</summary> 
      public static readonly LmsMessageTemplate GCTI_DISK_PERMISSION = CreateTemplate( 2005, LmsLogLevel.Standard, "GCTI_DISK_PERMISSION", "Not enough permissions to perform disk operation" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_NOT_FOUND = CreateTemplate( 2006, LmsLogLevel.Standard, "GCTI_FILE_NOT_FOUND", "File '%s' not found" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PATH_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_PATH_NOT_FOUND = CreateTemplate( 2007, LmsLogLevel.Standard, "GCTI_PATH_NOT_FOUND", "Path '%s' not found" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DRIVE_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_DRIVE_NOT_FOUND = CreateTemplate( 2008, LmsLogLevel.Standard, "GCTI_DRIVE_NOT_FOUND", "Drive '%s' not found" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOCK_FILE message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOCK_FILE = CreateTemplate( 2009, LmsLogLevel.Standard, "GCTI_LOCK_FILE", "Cannot access file '%s', it is locked" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CREATE message</summary> 
      public static readonly LmsMessageTemplate GCTI_CREATE = CreateTemplate( 2010, LmsLogLevel.Standard, "GCTI_CREATE", "Cannot create file or folder '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_NAME message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_NAME = CreateTemplate( 2011, LmsLogLevel.Standard, "GCTI_FILE_NAME", "File name '%s' is too long" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_HANDLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_HANDLE = CreateTemplate( 2012, LmsLogLevel.Standard, "GCTI_FILE_HANDLE", "No more system file handlers" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_INVALID_NAME message</summary> 
      public static readonly LmsMessageTemplate GCTI_INVALID_NAME = CreateTemplate( 2013, LmsLogLevel.Standard, "GCTI_INVALID_NAME", "File name, folder name syntax is incorrect" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DIR_NOT_EMPTY message</summary> 
      public static readonly LmsMessageTemplate GCTI_DIR_NOT_EMPTY = CreateTemplate( 2014, LmsLogLevel.Standard, "GCTI_DIR_NOT_EMPTY", "The directory '%s' is not empty" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PIPE_BROKEN message</summary> 
      public static readonly LmsMessageTemplate GCTI_PIPE_BROKEN = CreateTemplate( 2015, LmsLogLevel.Standard, "GCTI_PIPE_BROKEN", "Pipe has been broken" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_UNABLE_TO_OPEN message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_UNABLE_TO_OPEN = CreateTemplate( 2016, LmsLogLevel.Standard, "GCTI_FILE_UNABLE_TO_OPEN", "Unable to open %s file '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_UNABLE_TO_CLOSE message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_UNABLE_TO_CLOSE = CreateTemplate( 2017, LmsLogLevel.Standard, "GCTI_FILE_UNABLE_TO_CLOSE", "Unable to close %s file '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_UNABLE_TO_READ message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_UNABLE_TO_READ = CreateTemplate( 2018, LmsLogLevel.Standard, "GCTI_FILE_UNABLE_TO_READ", "Unable to read %s file '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_UNABLE_TO_WRITE message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_UNABLE_TO_WRITE = CreateTemplate( 2019, LmsLogLevel.Standard, "GCTI_FILE_UNABLE_TO_WRITE", "Unable to write %s file '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_UNABLE_TO_CREATE message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_UNABLE_TO_CREATE = CreateTemplate( 2020, LmsLogLevel.Standard, "GCTI_FILE_UNABLE_TO_CREATE", "Unable to create %s file/folder '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_FILE_UNABLE_TO_DELETE message</summary> 
      public static readonly LmsMessageTemplate GCTI_FILE_UNABLE_TO_DELETE = CreateTemplate( 2021, LmsLogLevel.Standard, "GCTI_FILE_UNABLE_TO_DELETE", "Unable to delete %s file/folder '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_WRONG_COMMAND message</summary> 
      public static readonly LmsMessageTemplate GCTI_WRONG_COMMAND = CreateTemplate( 2100, LmsLogLevel.Standard, "GCTI_WRONG_COMMAND", "Wrong command %s, state %s, client %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_READ message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_READ = CreateTemplate( 2101, LmsLogLevel.Standard, "GCTI_NET_READ", "Data read error, client %s, socket number %d, error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_SEND message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_SEND = CreateTemplate( 2102, LmsLogLevel.Standard, "GCTI_NET_SEND", "Data send error, client %s, socket number %d, error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROCESS_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROCESS_START = CreateTemplate( 2200, LmsLogLevel.Standard, "GCTI_PROCESS_START", "Cannot start new process" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROCESS_STOP message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROCESS_STOP = CreateTemplate( 2201, LmsLogLevel.Standard, "GCTI_PROCESS_STOP", "Cannot stop the process" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_THREAD_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_THREAD_START = CreateTemplate( 2202, LmsLogLevel.Standard, "GCTI_THREAD_START", "Cannot start new thread" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_THREAD_LIMIT message</summary> 
      public static readonly LmsMessageTemplate GCTI_THREAD_LIMIT = CreateTemplate( 2203, LmsLogLevel.Standard, "GCTI_THREAD_LIMIT", "Cannot start one more thread, too many started already" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_MEM_HANDLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_MEM_HANDLE = CreateTemplate( 2204, LmsLogLevel.Standard, "GCTI_MEM_HANDLE", "Invalid memory handle" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CREATE_MUTEX message</summary> 
      public static readonly LmsMessageTemplate GCTI_CREATE_MUTEX = CreateTemplate( 2205, LmsLogLevel.Standard, "GCTI_CREATE_MUTEX", "Cannot create mutex" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CREATE_SEMAPHORE message</summary> 
      public static readonly LmsMessageTemplate GCTI_CREATE_SEMAPHORE = CreateTemplate( 2206, LmsLogLevel.Standard, "GCTI_CREATE_SEMAPHORE", "Cannot create semaphore" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_ACCESS_VIOLATION message</summary> 
      public static readonly LmsMessageTemplate GCTI_ACCESS_VIOLATION = CreateTemplate( 2207, LmsLogLevel.Standard, "GCTI_ACCESS_VIOLATION", "Access violation, address %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_NOT_FOUND = CreateTemplate( 3000, LmsLogLevel.Standard, "GCTI_CFG_NOT_FOUND", "Configuration server not found at %s:%d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_WRONG_PROTOCOL message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_WRONG_PROTOCOL = CreateTemplate( 3001, LmsLogLevel.Standard, "GCTI_CFG_WRONG_PROTOCOL", "Wrong configuration protocol" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_WRONG_MSG message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_WRONG_MSG = CreateTemplate( 3002, LmsLogLevel.Standard, "GCTI_CFG_WRONG_MSG", "Wrong configuration message" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OBJECT_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_OBJECT_NOT_FOUND = CreateTemplate( 3003, LmsLogLevel.Standard, "GCTI_OBJECT_NOT_FOUND", "Configuration object '%s' not found" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_LIST message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_LIST = CreateTemplate( 3004, LmsLogLevel.Standard, "GCTI_CFG_LIST", "Configuration list item not found" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_UNIQ message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_UNIQ = CreateTemplate( 3005, LmsLogLevel.Standard, "GCTI_CFG_UNIQ", "Configuration uniqueness violation" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_INCOMPLETE_DATA message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_INCOMPLETE_DATA = CreateTemplate( 3006, LmsLogLevel.Standard, "GCTI_CFG_INCOMPLETE_DATA", "Incomplete configuration object data" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APPLICATION_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_APPLICATION_NOT_FOUND = CreateTemplate( 3007, LmsLogLevel.Standard, "GCTI_APPLICATION_NOT_FOUND", "Application '%s' not found in configuration database" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APPLICATION_LOCKED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APPLICATION_LOCKED = CreateTemplate( 3008, LmsLogLevel.Standard, "GCTI_APPLICATION_LOCKED", "Application '%s' is being used already" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_NOT_FOUND = CreateTemplate( 3009, LmsLogLevel.Standard, "GCTI_OPTION_NOT_FOUND", "Configuration option '%s' not found" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_VALUE message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_VALUE = CreateTemplate( 3010, LmsLogLevel.Standard, "GCTI_OPTION_VALUE", "Configuration option '%s' has wrong value '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_TO_MANY_CNTS message</summary> 
      public static readonly LmsMessageTemplate GCTI_TO_MANY_CNTS = CreateTemplate( 3100, LmsLogLevel.Standard, "GCTI_TO_MANY_CNTS", "Too many connections opened already" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SELECT message</summary> 
      public static readonly LmsMessageTemplate GCTI_SELECT = CreateTemplate( 3101, LmsLogLevel.Standard, "GCTI_SELECT", "Select error %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_HOST_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_HOST_NOT_FOUND = CreateTemplate( 3102, LmsLogLevel.Standard, "GCTI_HOST_NOT_FOUND", "Invalid host name '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_INIT message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_INIT = CreateTemplate( 3103, LmsLogLevel.Standard, "GCTI_NET_INIT", "Cannot initialize network sockets layer" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NO_LOGIN message</summary> 
      public static readonly LmsMessageTemplate GCTI_NO_LOGIN = CreateTemplate( 3200, LmsLogLevel.Standard, "GCTI_NO_LOGIN", "User login or password incorrect" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOGIN_EXP message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOGIN_EXP = CreateTemplate( 3201, LmsLogLevel.Standard, "GCTI_LOGIN_EXP", "User login expired" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PERMISSIONS message</summary> 
      public static readonly LmsMessageTemplate GCTI_PERMISSIONS = CreateTemplate( 3202, LmsLogLevel.Standard, "GCTI_PERMISSIONS", "User have not enough permissions to login" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOGIN_DISABLED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOGIN_DISABLED = CreateTemplate( 3203, LmsLogLevel.Standard, "GCTI_LOGIN_DISABLED", "Login currently disabled" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_TOO_MANY_USERS message</summary> 
      public static readonly LmsMessageTemplate GCTI_TOO_MANY_USERS = CreateTemplate( 3204, LmsLogLevel.Standard, "GCTI_TOO_MANY_USERS", "Login currently disabled; too many users" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVICE_SUSPEND message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVICE_SUSPEND = CreateTemplate( 4001, LmsLogLevel.Info, "GCTI_SERVICE_SUSPEND", "%s service suspended" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVICE_CONTINUE message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVICE_CONTINUE = CreateTemplate( 4002, LmsLogLevel.Info, "GCTI_SERVICE_CONTINUE", "%s service continued" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVICE_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVICE_START = CreateTemplate( 4003, LmsLogLevel.Info, "GCTI_SERVICE_START", "%s main process started" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVICE_STOP message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVICE_STOP = CreateTemplate( 4004, LmsLogLevel.Info, "GCTI_SERVICE_STOP", "%s main process stopped" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROC_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROC_START = CreateTemplate( 4005, LmsLogLevel.Info, "GCTI_PROC_START", "%s subprocess started" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROC_STOP message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROC_STOP = CreateTemplate( 4006, LmsLogLevel.Info, "GCTI_PROC_STOP", "%s subprocess stopped" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_START = CreateTemplate( 4100, LmsLogLevel.Info, "GCTI_LOG_START", "Logging service started" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_SEGMENT_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_SEGMENT_START = CreateTemplate( 4101, LmsLogLevel.Info, "GCTI_LOG_SEGMENT_START", "New log segment started %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPT_LEVEL message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPT_LEVEL = CreateTemplate( 4102, LmsLogLevel.Info, "GCTI_LOG_OPT_LEVEL", "Log level changed from '%s' to '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPT_SEGMENT message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPT_SEGMENT = CreateTemplate( 4103, LmsLogLevel.Info, "GCTI_LOG_OPT_SEGMENT", "Log segmentation turned %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPT_WRONG_VALUE message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPT_WRONG_VALUE = CreateTemplate( 4104, LmsLogLevel.Info, "GCTI_LOG_OPT_WRONG_VALUE", "Option '%s' set to the wrong value '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPT_NOT_SUPPORTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPT_NOT_SUPPORTED = CreateTemplate( 4105, LmsLogLevel.Info, "GCTI_LOG_OPT_NOT_SUPPORTED", "Option '%s' not supported" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_MSGFILELOADED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_MSGFILELOADED = CreateTemplate( 4106, LmsLogLevel.Standard, "GCTI_LOG_MSGFILELOADED", "Log Messages file '%s' successfully loaded" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_MSGFILELOADERROR message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_MSGFILELOADERROR = CreateTemplate( 4107, LmsLogLevel.Standard, "GCTI_LOG_MSGFILELOADERROR", "Unable to load Log Messages file '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPT_EXPIRATION message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPT_EXPIRATION = CreateTemplate( 4108, LmsLogLevel.Info, "GCTI_LOG_OPT_EXPIRATION", "Log expiration turned '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_STOP message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_STOP = CreateTemplate( 4109, LmsLogLevel.Info, "GCTI_LOG_STOP", "Logging service stopped" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPTSET message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPTSET = CreateTemplate( 4110, LmsLogLevel.Info, "GCTI_LOG_OPTSET", "Option '%s' has been set to the value '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPTDEL message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPTDEL = CreateTemplate( 4111, LmsLogLevel.Info, "GCTI_LOG_OPTDEL", "Option '%s' has been deleted, default value '%s' restored" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OUTCREATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OUTCREATED = CreateTemplate( 4112, LmsLogLevel.Info, "GCTI_LOG_OUTCREATED", "The Log Output of type '%s' has been created and opened" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OUTDELETED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OUTDELETED = CreateTemplate( 4113, LmsLogLevel.Info, "GCTI_LOG_OUTDELETED", "The Log Output of type '%s' has been closed and deleted" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_OPTDUMP message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_OPTDUMP = CreateTemplate( 4114, LmsLogLevel.Info, "GCTI_LOG_OPTDUMP", "Option '%s' has value '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_ALARM message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_ALARM = CreateTemplate( 4115, LmsLogLevel.Alarm, "GCTI_LOG_ALARM", "%s, alarm condition(%s)" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_SUSPENDED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_SUSPENDED = CreateTemplate( 4116, LmsLogLevel.Info, "GCTI_LOG_SUSPENDED", "Logging service suspended" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_RESUMED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_RESUMED = CreateTemplate( 4117, LmsLogLevel.Info, "GCTI_LOG_RESUMED", "Logging service resumed" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_NETFILE_WARNING message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_NETFILE_WARNING = CreateTemplate( 4118, LmsLogLevel.Standard, "GCTI_LOG_NETFILE_WARNING", "Warning, log output file '%s' has been opened on network drive." );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_MMAP_ON_NETWORK_WARNING message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_MMAP_ON_NETWORK_WARNING = CreateTemplate( 4119, LmsLogLevel.Standard, "GCTI_LOG_MMAP_ON_NETWORK_WARNING", "Warning, memory mapped buffering cannot be used on the network drive, snapshot file will be not created." );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LOG_CHECK_POINT message</summary> 
      public static readonly LmsMessageTemplate GCTI_LOG_CHECK_POINT = CreateTemplate( 4120, LmsLogLevel.Info, "GCTI_LOG_CHECK_POINT", "Check point %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_ALARM_CREATION message</summary> 
      public static readonly LmsMessageTemplate GCTI_ALARM_CREATION = CreateTemplate( 4200, LmsLogLevel.Alarm, "GCTI_ALARM_CREATION", "Active Alarm \"%s\" Created (ID=%s)" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_ALARM_CLEARANCE message</summary> 
      public static readonly LmsMessageTemplate GCTI_ALARM_CLEARANCE = CreateTemplate( 4210, LmsLogLevel.Alarm, "GCTI_ALARM_CLEARANCE", "Active Alarm \"%s\" Cleared (ID=%s)" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CLIENT_CONNECTING message</summary> 
      public static readonly LmsMessageTemplate GCTI_CLIENT_CONNECTING = CreateTemplate( 4500, LmsLogLevel.Info, "GCTI_CLIENT_CONNECTING", "Connecting to %s '%s' at host '%s', port %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CLIENT_CONTACTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_CLIENT_CONTACTED = CreateTemplate( 4501, LmsLogLevel.Info, "GCTI_CLIENT_CONTACTED", "Server %s contacted, socket %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CLIENT_UNABLE_CONNECT message</summary> 
      public static readonly LmsMessageTemplate GCTI_CLIENT_UNABLE_CONNECT = CreateTemplate( 4502, LmsLogLevel.Standard, "GCTI_CLIENT_UNABLE_CONNECT", "Cannot connect to %s '%s' at host '%s', port %d, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CLIENT_CONNECTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_CLIENT_CONNECTED = CreateTemplate( 4503, LmsLogLevel.Standard, "GCTI_CLIENT_CONNECTED", "Connected to %s '%s' at host '%s', port %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CLIENT_CONNECTION_LOST message</summary> 
      public static readonly LmsMessageTemplate GCTI_CLIENT_CONNECTION_LOST = CreateTemplate( 4504, LmsLogLevel.Standard, "GCTI_CLIENT_CONNECTION_LOST", "Connection to %s '%s' at host '%s', port %d lost" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CLIENT_DISCONNECTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_CLIENT_DISCONNECTED = CreateTemplate( 4505, LmsLogLevel.Standard, "GCTI_CLIENT_DISCONNECTED", "Disconnected from %s '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_NEW_CLIENT_CONNECTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_NEW_CLIENT_CONNECTED = CreateTemplate( 4520, LmsLogLevel.Info, "GCTI_SERVER_NEW_CLIENT_CONNECTED", "New client %d connected" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_NEW_CLIENT_CONNECTED_FROM message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_NEW_CLIENT_CONNECTED_FROM = CreateTemplate( 4521, LmsLogLevel.Info, "GCTI_SERVER_NEW_CLIENT_CONNECTED_FROM", "New client %d connected from '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_CLIENT_AUTHORIZED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_CLIENT_AUTHORIZED = CreateTemplate( 4522, LmsLogLevel.Info, "GCTI_SERVER_CLIENT_AUTHORIZED", "Client %d authorized, name '%s', type '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_CONNECTION_CLOSED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_CONNECTION_CLOSED = CreateTemplate( 4523, LmsLogLevel.Standard, "GCTI_SERVER_CONNECTION_CLOSED", "Connection to client '%s' closed, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_CLIENT_DISCONNECTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_CLIENT_DISCONNECTED = CreateTemplate( 4524, LmsLogLevel.Info, "GCTI_SERVER_CLIENT_DISCONNECTED", "Client '%s' disconnected" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_PORT_OPENED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_PORT_OPENED = CreateTemplate( 4525, LmsLogLevel.Standard, "GCTI_SERVER_PORT_OPENED", "Port %d opened for listening" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_PORT_UNABLE_TO_OPEN message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_PORT_UNABLE_TO_OPEN = CreateTemplate( 4526, LmsLogLevel.Standard, "GCTI_SERVER_PORT_UNABLE_TO_OPEN", "Cannot open port %d for listening, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SERVER_CLIENT_VERSION_INCOMPATIBLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_SERVER_CLIENT_VERSION_INCOMPATIBLE = CreateTemplate( 4527, LmsLogLevel.Standard, "GCTI_SERVER_CLIENT_VERSION_INCOMPATIBLE", "Client version '%s' is incompatible with server version '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_AUTHORIZATION_MESSAGE_RECEIVED message</summary> 
      public static readonly LmsMessageTemplate GCTI_AUTHORIZATION_MESSAGE_RECEIVED = CreateTemplate( 4528, LmsLogLevel.Info, "GCTI_AUTHORIZATION_MESSAGE_RECEIVED", "Authorization message received, socket %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_COMMUNICATION_UNKNOWN_MESSAGE message</summary> 
      public static readonly LmsMessageTemplate GCTI_COMMUNICATION_UNKNOWN_MESSAGE = CreateTemplate( 4540, LmsLogLevel.Info, "GCTI_COMMUNICATION_UNKNOWN_MESSAGE", "Unknown Message %s received from %d (%s '%s')" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_COMMUNICATION_MESSAGE_RECEIVED message</summary> 
      public static readonly LmsMessageTemplate GCTI_COMMUNICATION_MESSAGE_RECEIVED = CreateTemplate( 4541, LmsLogLevel.Info, "GCTI_COMMUNICATION_MESSAGE_RECEIVED", "Message %s received from %d (%s '%s')" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_COMMUNICATION_MESSAGE_SENT message</summary> 
      public static readonly LmsMessageTemplate GCTI_COMMUNICATION_MESSAGE_SENT = CreateTemplate( 4542, LmsLogLevel.Info, "GCTI_COMMUNICATION_MESSAGE_SENT", "Message %s sent to %d (%s '%s')" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_INTERACTION_MESSAGE_RECEIVED message</summary> 
      public static readonly LmsMessageTemplate GCTI_INTERACTION_MESSAGE_RECEIVED = CreateTemplate( 4543, LmsLogLevel.Interaction, "GCTI_INTERACTION_MESSAGE_RECEIVED", "Interaction message \"%s\" received from %d (\"%s\")" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_INTERACTION_MESSAGE_GENERATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_INTERACTION_MESSAGE_GENERATED = CreateTemplate( 4544, LmsLogLevel.Interaction, "GCTI_INTERACTION_MESSAGE_GENERATED", "Interaction message \"%s\" generated" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_INTERACTION_MESSAGE_SENT message</summary> 
      public static readonly LmsMessageTemplate GCTI_INTERACTION_MESSAGE_SENT = CreateTemplate( 4545, LmsLogLevel.Interaction, "GCTI_INTERACTION_MESSAGE_SENT", "Interaction message \"%s\" sent to %d (\"%s\")" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_INVALID_MESSAGE_RECEIVED message</summary> 
      public static readonly LmsMessageTemplate GCTI_INVALID_MESSAGE_RECEIVED = CreateTemplate( 4546, LmsLogLevel.Standard, "GCTI_INVALID_MESSAGE_RECEIVED", "Invalid %s message received from %s, %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_REDUNDANCY_WARM_STANDBY_BACKUP_ACTIVATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_REDUNDANCY_WARM_STANDBY_BACKUP_ACTIVATED = CreateTemplate( 4560, LmsLogLevel.Standard, "GCTI_REDUNDANCY_WARM_STANDBY_BACKUP_ACTIVATED", "Warm Standby (backup) mode activated" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_REDUNDANCY_HOT_STANDBY_BACKUP_ACTIVATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_REDUNDANCY_HOT_STANDBY_BACKUP_ACTIVATED = CreateTemplate( 4561, LmsLogLevel.Standard, "GCTI_REDUNDANCY_HOT_STANDBY_BACKUP_ACTIVATED", "Hot Standby (backup) mode activated" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_REDUNDANCY_WARM_STANDBY_PRIMARY_ACTIVATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_REDUNDANCY_WARM_STANDBY_PRIMARY_ACTIVATED = CreateTemplate( 4562, LmsLogLevel.Standard, "GCTI_REDUNDANCY_WARM_STANDBY_PRIMARY_ACTIVATED", "Warm Standby (Primary) mode activated" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_REDUNDANCY_HOT_STANDBY_PRIMARY_ACTIVATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_REDUNDANCY_HOT_STANDBY_PRIMARY_ACTIVATED = CreateTemplate( 4563, LmsLogLevel.Standard, "GCTI_REDUNDANCY_HOT_STANDBY_PRIMARY_ACTIVATED", "Hot Standby (Primary) mode activated" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_REDUNDANCY_CONNECTED_HOT_STANDBY message</summary> 
      public static readonly LmsMessageTemplate GCTI_REDUNDANCY_CONNECTED_HOT_STANDBY = CreateTemplate( 4580, LmsLogLevel.Standard, "GCTI_REDUNDANCY_CONNECTED_HOT_STANDBY", "Connected to server in Hot Standby mode: Primary server %s '%s', backup server %s '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_REDUNDANCY_PRIMARY_NOT_AVAILABLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_REDUNDANCY_PRIMARY_NOT_AVAILABLE = CreateTemplate( 4581, LmsLogLevel.Standard, "GCTI_REDUNDANCY_PRIMARY_NOT_AVAILABLE", "Primary server %s '%s' is not available, switching to backup %s '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_ACCESS_NT_REGISTRY message</summary> 
      public static readonly LmsMessageTemplate GCTI_ACCESS_NT_REGISTRY = CreateTemplate( 5000, LmsLogLevel.Standard, "GCTI_ACCESS_NT_REGISTRY", "Unable to obtain registry key: '%s', subkey: '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROCESS_CANNOT_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROCESS_CANNOT_START = CreateTemplate( 5020, LmsLogLevel.Standard, "GCTI_PROCESS_CANNOT_START", "Cannot start process '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROCESS_CANNOT_STOP message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROCESS_CANNOT_STOP = CreateTemplate( 5021, LmsLogLevel.Standard, "GCTI_PROCESS_CANNOT_STOP", "Cannot stop process '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROCESS_STARTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROCESS_STARTED = CreateTemplate( 5022, LmsLogLevel.Standard, "GCTI_PROCESS_STARTED", "Process '%s' started" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROCESS_STOPPED message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROCESS_STOPPED = CreateTemplate( 5023, LmsLogLevel.Standard, "GCTI_PROCESS_STOPPED", "Process '%s' stopped" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PROCESS_ABNORMALLY_TERMINATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_PROCESS_ABNORMALLY_TERMINATED = CreateTemplate( 5024, LmsLogLevel.Standard, "GCTI_PROCESS_ABNORMALLY_TERMINATED", "Process '%s' abnormally terminated, error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_THREAD_CANNOT_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_THREAD_CANNOT_START = CreateTemplate( 5040, LmsLogLevel.Standard, "GCTI_THREAD_CANNOT_START", "Cannot start new thread, error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_THREAD_CANNOT_CREATE_MUTEX message</summary> 
      public static readonly LmsMessageTemplate GCTI_THREAD_CANNOT_CREATE_MUTEX = CreateTemplate( 5041, LmsLogLevel.Standard, "GCTI_THREAD_CANNOT_CREATE_MUTEX", "Cannot create mutex, erro code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_THREAD_CANNOT_CREATE_SEMAPHORE message</summary> 
      public static readonly LmsMessageTemplate GCTI_THREAD_CANNOT_CREATE_SEMAPHORE = CreateTemplate( 5042, LmsLogLevel.Standard, "GCTI_THREAD_CANNOT_CREATE_SEMAPHORE", "Cannot create semaphore, error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_STARTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_STARTED = CreateTemplate( 5060, LmsLogLevel.Standard, "GCTI_APP_STARTED", "Application started" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_INIT_COMPLETED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_INIT_COMPLETED = CreateTemplate( 5061, LmsLogLevel.Standard, "GCTI_APP_INIT_COMPLETED", "Initialization completed" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_INIT_FAILED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_INIT_FAILED = CreateTemplate( 5062, LmsLogLevel.Standard, "GCTI_APP_INIT_FAILED", "Application initialization failed, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_STOPPED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_STOPPED = CreateTemplate( 5063, LmsLogLevel.Standard, "GCTI_APP_STOPPED", "Normal termination" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_TERMINATED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_TERMINATED = CreateTemplate( 5064, LmsLogLevel.Standard, "GCTI_APP_TERMINATED", "Application terminated due to internal condition" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_FAILED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_FAILED = CreateTemplate( 5065, LmsLogLevel.Standard, "GCTI_APP_FAILED", "Application stopped" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_INIT_COMPONENT_FAILED message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_INIT_COMPONENT_FAILED = CreateTemplate( 5066, LmsLogLevel.Standard, "GCTI_APP_INIT_COMPONENT_FAILED", "Initialization of %s failed, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NT_SERVICE_CANNOT_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_NT_SERVICE_CANNOT_START = CreateTemplate( 5080, LmsLogLevel.Standard, "GCTI_NT_SERVICE_CANNOT_START", "Application cannot start as NT service, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_START message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_START = CreateTemplate( 5090, LmsLogLevel.Standard, "GCTI_SCS_APP_START", "Application start detected by Management Layer" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_PLANNED_STOP message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_PLANNED_STOP = CreateTemplate( 5091, LmsLogLevel.Standard, "GCTI_SCS_APP_PLANNED_STOP", "Application stopped by Management Layer as planned" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_INITIALIZING message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_INITIALIZING = CreateTemplate( 5092, LmsLogLevel.Standard, "GCTI_SCS_APP_INITIALIZING", "Application entered initialization state" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_SERVICE_AVAILABLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_SERVICE_AVAILABLE = CreateTemplate( 5093, LmsLogLevel.Standard, "GCTI_SCS_APP_SERVICE_AVAILABLE", "Application is ready to provide service" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_SERVICE_UNAVAILABLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_SERVICE_UNAVAILABLE = CreateTemplate( 5094, LmsLogLevel.Standard, "GCTI_SCS_APP_SERVICE_UNAVAILABLE", "Application is not able to provide service" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_STATUS_UNKNOWN message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_STATUS_UNKNOWN = CreateTemplate( 5095, LmsLogLevel.Standard, "GCTI_SCS_APP_STATUS_UNKNOWN", "Application has unknown status" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_SUSPENDING message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_SUSPENDING = CreateTemplate( 5096, LmsLogLevel.Standard, "GCTI_SCS_APP_SUSPENDING", "Application is suspending" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_SUSPENDED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_SUSPENDED = CreateTemplate( 5097, LmsLogLevel.Standard, "GCTI_SCS_APP_SUSPENDED", "Application is suspended" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_RUNMODE_CHANGED_TO_PRIMARY message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_RUNMODE_CHANGED_TO_PRIMARY = CreateTemplate( 5150, LmsLogLevel.Standard, "GCTI_SCS_APP_RUNMODE_CHANGED_TO_PRIMARY", "Application's runmode changed to Primary" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SCS_APP_RUNMODE_CHANGED_TO_BACKUP message</summary> 
      public static readonly LmsMessageTemplate GCTI_SCS_APP_RUNMODE_CHANGED_TO_BACKUP = CreateTemplate( 5151, LmsLogLevel.Standard, "GCTI_SCS_APP_RUNMODE_CHANGED_TO_BACKUP", "Application's runmode changed to Backup" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_VERSION message</summary> 
      public static readonly LmsMessageTemplate GCTI_VERSION = CreateTemplate( 5200, LmsLogLevel.Standard, "GCTI_VERSION", "%s. Version %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_COPYRIGHT message</summary> 
      public static readonly LmsMessageTemplate GCTI_COPYRIGHT = CreateTemplate( 5201, LmsLogLevel.Standard, "GCTI_COPYRIGHT", "Copyright (c) %d-%d Genesys Telecommunications Laboratories, Inc." );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SYSLIB_INIT_FAILED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SYSLIB_INIT_FAILED = CreateTemplate( 6020, LmsLogLevel.Standard, "GCTI_SYSLIB_INIT_FAILED", "System library '%s' initialization failed, error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_DATA_NOT_AVAILABLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_DATA_NOT_AVAILABLE = CreateTemplate( 6040, LmsLogLevel.Standard, "GCTI_CFG_DATA_NOT_AVAILABLE", "Configuration data is not available, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_DATA_READ message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_DATA_READ = CreateTemplate( 6041, LmsLogLevel.Standard, "GCTI_CFG_DATA_READ", "Configuration data successfully read" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_DATA_READ_ERROR message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_DATA_READ_ERROR = CreateTemplate( 6042, LmsLogLevel.Standard, "GCTI_CFG_DATA_READ_ERROR", "Configuration data read error: object type:'%s', DBID [%ld], reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_DATA_WRITE_ERROR message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_DATA_WRITE_ERROR = CreateTemplate( 6043, LmsLogLevel.Standard, "GCTI_CFG_DATA_WRITE_ERROR", "Configuration data write error: object type:'%s', object name '%s', object DBID [%ld], reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_DATA_ITEM_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_DATA_ITEM_NOT_FOUND = CreateTemplate( 6044, LmsLogLevel.Standard, "GCTI_CFG_DATA_ITEM_NOT_FOUND", "Configuration item not found: object type:'%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_DATA_SPECIFIC_ITEM_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_DATA_SPECIFIC_ITEM_NOT_FOUND = CreateTemplate( 6045, LmsLogLevel.Standard, "GCTI_CFG_DATA_SPECIFIC_ITEM_NOT_FOUND", "Configuration item not found: object type:'%s', object name '%s', reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_MANDATORY_ENTITY_MISSING message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_MANDATORY_ENTITY_MISSING = CreateTemplate( 6046, LmsLogLevel.Standard, "GCTI_CFG_MANDATORY_ENTITY_MISSING", "Mandatory configuration entity missing: object type '%s', object name '%s', property name '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_OPTIONAL_ENTITY_MISSING message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_OPTIONAL_ENTITY_MISSING = CreateTemplate( 6047, LmsLogLevel.Standard, "GCTI_CFG_OPTIONAL_ENTITY_MISSING", "Optional configuration entity is missed: object type '%s', object name '%s', property name '%s', assuming default '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_ENTITY_INVALID_VALUE message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_ENTITY_INVALID_VALUE = CreateTemplate( 6048, LmsLogLevel.Standard, "GCTI_CFG_ENTITY_INVALID_VALUE", "Invalid value for configuration entity: object type:'%s', object name '%s', property name '%s' ='%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_ENTITY_SET message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_ENTITY_SET = CreateTemplate( 6049, LmsLogLevel.Info, "GCTI_CFG_ENTITY_SET", "Configuration entity set: object type '%s', object name '%s', property name '%s' = '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_OBJECT_ADDED message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_OBJECT_ADDED = CreateTemplate( 6050, LmsLogLevel.Info, "GCTI_CFG_OBJECT_ADDED", "Configuration object added: object type '%s' object name '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_OBJECT_DELETED message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_OBJECT_DELETED = CreateTemplate( 6051, LmsLogLevel.Info, "GCTI_CFG_OBJECT_DELETED", "Configuration object deleted: object type '%s' object name '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NO_CFG_APP message</summary> 
      public static readonly LmsMessageTemplate GCTI_NO_CFG_APP = CreateTemplate( 6052, LmsLogLevel.Standard, "GCTI_NO_CFG_APP", "Unable to obtain application '%s' from configuration server" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_APP message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_APP = CreateTemplate( 6053, LmsLogLevel.Standard, "GCTI_CFG_APP", "Configuration for application obtained" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_CFG_REGISTERFAILED message</summary> 
      public static readonly LmsMessageTemplate GCTI_CFG_REGISTERFAILED = CreateTemplate( 6054, LmsLogLevel.Standard, "GCTI_CFG_REGISTERFAILED", "Unable to register for configuration server notifications" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_MANDATORY_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_MANDATORY_NOT_FOUND = CreateTemplate( 6080, LmsLogLevel.Standard, "GCTI_OPTION_MANDATORY_NOT_FOUND", "Mandatory configuration option not found: '%s':'%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_APP_OPTION_NOT_FOUND message</summary> 
      public static readonly LmsMessageTemplate GCTI_APP_OPTION_NOT_FOUND = CreateTemplate( 6081, LmsLogLevel.Standard, "GCTI_APP_OPTION_NOT_FOUND", "Configuration option not found: '%s':'%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_MANDATORY_INVALID_VALUE message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_MANDATORY_INVALID_VALUE = CreateTemplate( 6082, LmsLogLevel.Standard, "GCTI_OPTION_MANDATORY_INVALID_VALUE", "Mandatory configuration option has invalid value: '%s':'%s' = '%s'." );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_INVALID_VALUE message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_INVALID_VALUE = CreateTemplate( 6083, LmsLogLevel.Standard, "GCTI_OPTION_INVALID_VALUE", "Configuration option has invalid value: '%s':'%s' = '%s'." );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_SET message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_SET = CreateTemplate( 6084, LmsLogLevel.Info, "GCTI_OPTION_SET", "Configuration option set: '%s':'%s' = '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_SET_DEFAULT message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_SET_DEFAULT = CreateTemplate( 6085, LmsLogLevel.Info, "GCTI_OPTION_SET_DEFAULT", "Configuration option set to default value: '%s':'%s' = '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_OPTION_CHANGED message</summary> 
      public static readonly LmsMessageTemplate GCTI_OPTION_CHANGED = CreateTemplate( 6086, LmsLogLevel.Info, "GCTI_OPTION_CHANGED", "Configuration option changed: '%s':'%s' = '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DB_UNABLE_TO_OPEN message</summary> 
      public static readonly LmsMessageTemplate GCTI_DB_UNABLE_TO_OPEN = CreateTemplate( 7000, LmsLogLevel.Standard, "GCTI_DB_UNABLE_TO_OPEN", "Could not open database '%s'; reason '%s'; error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DB_OPENED message</summary> 
      public static readonly LmsMessageTemplate GCTI_DB_OPENED = CreateTemplate( 7001, LmsLogLevel.Standard, "GCTI_DB_OPENED", "Database '%s' opened" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DB_EXECUTION_FAILURE message</summary> 
      public static readonly LmsMessageTemplate GCTI_DB_EXECUTION_FAILURE = CreateTemplate( 7002, LmsLogLevel.Standard, "GCTI_DB_EXECUTION_FAILURE", "Execution failure: SQL statement '%s', reason '%s', error code %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_PERMISSION_DENIED message</summary> 
      public static readonly LmsMessageTemplate GCTI_PERMISSION_DENIED = CreateTemplate( 7020, LmsLogLevel.Standard, "GCTI_PERMISSION_DENIED", "User '%s' permission denied, reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_ADDP_NO_RESPONSE message</summary> 
      public static readonly LmsMessageTemplate GCTI_ADDP_NO_RESPONSE = CreateTemplate( 7040, LmsLogLevel.Standard, "GCTI_ADDP_NO_RESPONSE", "No response from %s '%s' is received within %d seconds, request ID %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_ADDP_NO_RESPONSE_FROM_SOCKET message</summary> 
      public static readonly LmsMessageTemplate GCTI_ADDP_NO_RESPONSE_FROM_SOCKET = CreateTemplate( 7041, LmsLogLevel.Standard, "GCTI_ADDP_NO_RESPONSE_FROM_SOCKET", "Socket %d is not responding within %d milliseconds, remote socket %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_TLIBRARY_UNABLE_TO_REGISTER_DN message</summary> 
      public static readonly LmsMessageTemplate GCTI_TLIBRARY_UNABLE_TO_REGISTER_DN = CreateTemplate( 7060, LmsLogLevel.Standard, "GCTI_TLIBRARY_UNABLE_TO_REGISTER_DN", "Unable to register DN '%s', reason '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LICENSE_FAIL message</summary> 
      public static readonly LmsMessageTemplate GCTI_LICENSE_FAIL = CreateTemplate( 7100, LmsLogLevel.Standard, "GCTI_LICENSE_FAIL", "Licensing violation is identified, the violation type %s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LICENSE_CHECKED_OUT message</summary> 
      public static readonly LmsMessageTemplate GCTI_LICENSE_CHECKED_OUT = CreateTemplate( 7101, LmsLogLevel.Standard, "GCTI_LICENSE_CHECKED_OUT", "Feature '%s': %d licenses checked out" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LICENSE_CONNECTION_LOST message</summary> 
      public static readonly LmsMessageTemplate GCTI_LICENSE_CONNECTION_LOST = CreateTemplate( 7102, LmsLogLevel.Standard, "GCTI_LICENSE_CONNECTION_LOST", "Connection to the license server is lost" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LICENSE_CONNECTION_RESTORED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LICENSE_CONNECTION_RESTORED = CreateTemplate( 7103, LmsLogLevel.Standard, "GCTI_LICENSE_CONNECTION_RESTORED", "Connection to the license server is restored" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LICENSE_FILE_CHANGED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LICENSE_FILE_CHANGED = CreateTemplate( 7104, LmsLogLevel.Standard, "GCTI_LICENSE_FILE_CHANGED", "The license file is changed" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_LICENSE_RESTORED message</summary> 
      public static readonly LmsMessageTemplate GCTI_LICENSE_RESTORED = CreateTemplate( 7105, LmsLogLevel.Standard, "GCTI_LICENSE_RESTORED", "Licensing violation condition, violation type '%s', no longer exists" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_HOST_DOWN message</summary> 
      public static readonly LmsMessageTemplate GCTI_HOST_DOWN = CreateTemplate( 8000, LmsLogLevel.Standard, "GCTI_HOST_DOWN", "Host '%s' inaccessible - LCA is not listening on port %d" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_HOST_UP message</summary> 
      public static readonly LmsMessageTemplate GCTI_HOST_UP = CreateTemplate( 8001, LmsLogLevel.Standard, "GCTI_HOST_UP", "Host '%s' operates in normal condition" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_HOST_UNAVAILABLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_HOST_UNAVAILABLE = CreateTemplate( 8002, LmsLogLevel.Standard, "GCTI_HOST_UNAVAILABLE", "Host '%s' unavailable" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_HOST_UNREACHABLE message</summary> 
      public static readonly LmsMessageTemplate GCTI_HOST_UNREACHABLE = CreateTemplate( 8003, LmsLogLevel.Standard, "GCTI_HOST_UNREACHABLE", "Host '%s' unreachable" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SECURITY_CERTIFICATE_EXPIRED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SECURITY_CERTIFICATE_EXPIRED = CreateTemplate( 8100, LmsLogLevel.Standard, "GCTI_SECURITY_CERTIFICATE_EXPIRED", "Certificate is expired, type '%s', date '%s', issuer '%s', subject '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SECURITY_CERTIFCATE_ERROR message</summary> 
      public static readonly LmsMessageTemplate GCTI_SECURITY_CERTIFCATE_ERROR = CreateTemplate( 8101, LmsLogLevel.Standard, "GCTI_SECURITY_CERTIFCATE_ERROR", "Certificate is not valid - '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SECURITY_ERROR message</summary> 
      public static readonly LmsMessageTemplate GCTI_SECURITY_ERROR = CreateTemplate( 8102, LmsLogLevel.Standard, "GCTI_SECURITY_ERROR", "Secure connection error, '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_SECURITY_ESTABLISHED message</summary> 
      public static readonly LmsMessageTemplate GCTI_SECURITY_ESTABLISHED = CreateTemplate( 8103, LmsLogLevel.Info, "GCTI_SECURITY_ESTABLISHED", "Secure connection is established. type '%s', info '%s', issuer '%s', subject '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_NEW_CONNECTION message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_NEW_CONNECTION = CreateTemplate( 9000, LmsLogLevel.Debug, "GCTI_NET_NEW_CONNECTION", "New connection established with '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_COMMAND message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_COMMAND = CreateTemplate( 9001, LmsLogLevel.Debug, "GCTI_NET_COMMAND", "Command received '%s' from '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_DATA message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_DATA = CreateTemplate( 9002, LmsLogLevel.Debug, "GCTI_NET_DATA", "Data sent '%s' to '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_TRANS message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_TRANS = CreateTemplate( 9003, LmsLogLevel.Debug, "GCTI_NET_TRANS", "Transition '%s' done for '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_BUF message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_BUF = CreateTemplate( 9004, LmsLogLevel.Debug, "GCTI_NET_BUF", "Data buffer received '%s' from '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_NET_CONNECTION_CLOSE message</summary> 
      public static readonly LmsMessageTemplate GCTI_NET_CONNECTION_CLOSE = CreateTemplate( 9005, LmsLogLevel.Debug, "GCTI_NET_CONNECTION_CLOSE", "Connection closed with '%s'" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_STUCK_CALLS_DETECTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_STUCK_CALLS_DETECTED = CreateTemplate( 9500, LmsLogLevel.Standard, "GCTI_STUCK_CALLS_DETECTED", "Stuck calls detected" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_STUCK_CALLS_NOT_DETECTED message</summary> 
      public static readonly LmsMessageTemplate GCTI_STUCK_CALLS_NOT_DETECTED = CreateTemplate( 9501, LmsLogLevel.Standard, "GCTI_STUCK_CALLS_NOT_DETECTED", "Stuck calls not detected" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_DEBUG message</summary> 
      public static readonly LmsMessageTemplate GCTI_DEBUG = CreateTemplate( 9900, LmsLogLevel.Debug, "GCTI_DEBUG", "%s" );

      // ReSharper disable once InconsistentNaming
      ///<summary> the message template for GCTI_INTERNAL message</summary> 
      public static readonly LmsMessageTemplate GCTI_INTERNAL = CreateTemplate( 9999, LmsLogLevel.Standard, "GCTI_INTERNAL", "Internal error '%s' occurred" );

    }
}


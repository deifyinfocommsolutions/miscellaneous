//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Genesyslab.Platform.AppTemplate.Logger.LMS
{
  /// <summary>
  /// Describes policy to load lms file
  /// </summary>
  public interface ILmsFileLoadPolicy
  {
    /// <summary>
    /// This property is checked when a template from the lms file has the same <see cref="LmsMessageTemplate.Id"/>
    /// as one of the templates already loaded in the collection.<br/>
    /// If true, the new template replaces the existed one, otherwise it is skipped.
    /// </summary>
    bool ReplaceExistingTemplate { get; }
  }

  internal class DefaultLmsFileLoadPolicy : ILmsFileLoadPolicy
  {
    public bool ReplaceExistingTemplate { get { return false; } }
  }
  /// <summary>
  /// LMS file parser
  /// </summary>
  public sealed class LmsFileData
  {

    private const string DefaultLmsResourceFile = "Genesyslab.Platform.AppTemplate.Logger.LMS.common.lms";
    private const string DefaultLmsFile = "common.lms";

    private readonly string _name;
    private readonly LmsFileHeader _header;
    private readonly List<LmsMessageTemplate> _templates;
    /// <summary>
    /// Returns header of file
    /// </summary>
    public LmsFileHeader Header{get { return _header; }}
    /// <summary>
    /// Returns name of resource or null for default resource.
    /// </summary>
    public String Name { get { return _name; }}
    /// <summary>
    /// Returns loaded templates
    /// </summary>
    public ICollection<LmsMessageTemplate> Templates { get { return _templates.AsReadOnly(); } }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="name">name of resource</param>
    public LmsFileData(string name)
    {
      _templates = new List<LmsMessageTemplate>();
      _name = name;
      var data = LoadFromFile() ?? LoadFromResource();
      if (data == null)
      {
        _header = CommonLmsMessages.Header;
        _templates.AddRange(CommonLmsMessages.Templates.Values);
      }
      else
      {
        var index = 0;
        _header = LoadHeader(data, ref index);
        while (true)
        {
          var template = LoadTemplate(data, ref index);
          if (template==null) break;
          _templates.Add(template);
        }
      }
    }
    private LmsMessageTemplate LoadTemplate(IList<string> data, ref int index)
    {
      while (true)
      {
        if (index >= data.Count) break;
        var s = data[index++];
        var result = LmsMessageTemplate.Parse(s);
        if (result != null) return result;
      }
      return null;
    }

    private LmsFileHeader LoadHeader(IList<string> data, ref int index)
    {
      while (true)
      {
        if (index>=data.Count) break;
        var s = data[index++];
        var result = LmsFileHeader.Parse(s);
        if (result != null) return result;
      }
      throw new LmsLoadException("Can't find lms header");
    }
    private IList<string> ReadFromStream(StreamReader reader)
    {
      var result = new List<string>();
      while (!reader.EndOfStream)
      {
        var s = reader.ReadLine();
        if (String.IsNullOrEmpty(s)) continue;
        s = s.Trim();
        if (String.IsNullOrEmpty(s)) continue;
        result.Add(s);
      }
      return result;
    }
    private IList<string> LoadFromFile()
    {
      var name = _name;
      if (String.IsNullOrEmpty(name)) name = DefaultLmsFile;
      if (!File.Exists(name)) return null;
      using (var reader = new StreamReader(_name))
      {
        return ReadFromStream(reader);
      }
    }

    private IList<string> LoadFromResource()
    {
      var name = _name;
      if (String.IsNullOrEmpty(name)) name = DefaultLmsResourceFile;
      using (Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
      {
        if (resourceStream == null) return null;
        resourceStream.Seek(0, SeekOrigin.Begin);
        using (var reader = new StreamReader(resourceStream))
        {
          return ReadFromStream(reader);
        }
      }
    }

  }
}

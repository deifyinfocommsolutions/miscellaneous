//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

namespace Genesyslab.Platform.AppTemplate.Logger.LMS
{
    /// <summary>
    /// Instance that consists the same fields as the header of an lms-file does.
    /// </summary>
    [SuppressMessage("Microsoft.Naming","CA1704:IdentifiersShouldBeSpelledCorrectly")] //lms - is the extension of target files.
    public sealed class LmsFileHeader 
    {
      /// <summary>
      /// Parses header of LMS file.
      /// </summary>
      /// <param name="data">header string</param>
      /// <returns>header of file or null if error format</returns>
      public static LmsFileHeader Parse(string data)
      {
        if (string.IsNullOrEmpty(data)) return null;
        data = data.Trim();
        if (data.StartsWith(";")) return null;
        var options = data.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
        if (options.Length < 5) return null;
        for (int i = 0; i < 5; i++)
        {
          options[i] = options[i].Trim();
          if (String.IsNullOrEmpty(options[i])) return null;
        }
        return new LmsFileHeader(options[0],options[1],options[2],options[3],options[4]);
      }

        ///<summary>
        /// Default constructor. Initializes all properties with empty strings.
        ///</summary>
        public LmsFileHeader():this(string.Empty,string.Empty,string.Empty,string.Empty,string.Empty)
        {
        }


        ///<summary>
        /// Constructor which initializes all the properties with passed values.
        ///</summary>
        ///<param name="id">Initialized value for <see cref="Id"/>.</param>
        ///<param name="purpose">Initialized value for <see cref="Purpose"/>.</param>
        ///<param name="number">Initialized value for <see cref="Number"/>.</param>
        ///<param name="name">Initialized value for <see cref="Name"/>.</param>
        ///<param name="version">Initialized value for <see cref="Version"/>.</param>
        public LmsFileHeader(string id, string purpose, string number, string name, string version)
        {
            Id = id;
            Purpose = purpose;
            Number = number;
            Name = name;
            Version = version;
        }

        #region Properties

        /// <summary>
        /// Sets or Gets the ID of template message.
        /// </summary>
        public string Id
        {
            get;set;
        }

        /// <summary>
        /// Sets or Gets the Purpose value of header.
        /// </summary>
        public string Purpose
        {
            get;
            set;
        }

        /// <summary>
        /// Sets or Gets the Number of header.
        /// </summary>
        public string Number
        {
            get;
            set;
        }

        /// <summary>
        /// Sets or Gets the Name of header.
        /// </summary>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Sets or Gets the Version of header.
        /// </summary>
        public string Version
        {
            get;
            set;
        }

        #endregion

        ///<summary>
        /// Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        ///</summary>
        ///<returns>
        /// A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        ///</returns>
        ///<filterpriority>2</filterpriority>
        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0}|{1}|{2}|{3}|{4}|", Id, Purpose, Number, Name, Version);
        }
        
    }
}

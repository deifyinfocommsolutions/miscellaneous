//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using Genesyslab.Configuration;
using Genesyslab.Platform.AppTemplate.Utilites;

namespace Genesyslab.Platform.AppTemplate.Logger.LMS
{
  /// <summary>
  /// Builder class to load messages 
  /// </summary>
  public class LmsMessageConveyor:IDisposable
  {
    private static readonly ILmsFileLoadPolicy DefaultLmsFileLoadPolicy = new  DefaultLmsFileLoadPolicy();
    private ILmsFileLoadPolicy _policy  = DefaultLmsFileLoadPolicy;
    private IList<LmsFileData> _lmsFiles;
    private IDictionary<int, LmsMessageTemplate> _lmsMsgTemplates;
    private IDictionary<int, LmsMessageTemplate> _addedDirectlyTemplates;
    private IDictionary<int, LmsMessageTemplate> _lmsMsgTemplatesReadOnly;
    private readonly object _syncObj = new object();
    private volatile bool _isDisposed;
    private void CheckIfDisposed()
    {
      if (_isDisposed)
        throw new ObjectDisposedException("LmsMessageConveyor");
    }
    public void Dispose()
    {
      if (_isDisposed) return;
      lock (_syncObj)
      {
        if (_isDisposed) return;
        if (_lmsMsgTemplates != null)
        {
          _lmsMsgTemplates.Clear();
          _lmsMsgTemplates = null;
        }
        if (_addedDirectlyTemplates != null)
        {
          _addedDirectlyTemplates.Clear();
          _addedDirectlyTemplates = null;
        }
        if (_lmsFiles != null)
        {
          _lmsFiles.Clear();
          _lmsFiles = null;
        }
        _isDisposed = true;
      }
    }

    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    internal IDictionary<int, LmsMessageTemplate> MessagesTemplates
    {
      get
      {
        lock (_syncObj)
        {
          CheckIfDisposed();
          return _lmsMsgTemplatesReadOnly;
        }
      }
    }

    /// <summary>
    /// Default constructor
    /// </summary>
    public LmsMessageConveyor():this(null){}
    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="fileNames">list of names of files separated by ',' or ';'</param>
    public LmsMessageConveyor(string fileNames):this(fileNames, null){}
    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="fileNames">list of names of files separated by ',' or ';'</param>
    /// <param name="policy">policy of loading files</param>
    public LmsMessageConveyor(string fileNames, ILmsFileLoadPolicy policy)
    {
      _lmsMsgTemplates = new Dictionary<int, LmsMessageTemplate>();
      _lmsMsgTemplatesReadOnly = new ReadOnlyDictionary<int, LmsMessageTemplate>(_lmsMsgTemplates);
      _policy = policy ?? DefaultLmsFileLoadPolicy;
      if (PsdkCustomization.LogFactory.EnableStadardLmsMessages)
      {
        _lmsFiles = new List<LmsFileData> { new LmsFileData(null) };
      }
      LoadAndAddLmsFiles(fileNames);
      InitLmsTemplates();
    }
    private void LoadAndAddLmsFiles(string fileNames)
    {
      if (String.IsNullOrEmpty(fileNames)) return;
      var files = fileNames.Split(new[] {',', ';'}, StringSplitOptions.RemoveEmptyEntries);
      foreach (string file in files)
      {
        var fName = file.Trim();
        if (String.IsNullOrEmpty(fName)) continue;
        var dataFile = new LmsFileData(fName);
        lock (_syncObj)
        {
          if (_lmsFiles == null) _lmsFiles = new List<LmsFileData>();
          if (_lmsFiles.FirstOrDefault(data =>
          {
            if (!String.Equals(data.Name, dataFile.Name)) return false;
            if (!String.Equals(data.Header.Id, dataFile.Header.Id)) return false;
            if (!String.Equals(data.Header.Name, dataFile.Header.Name)) return false;
            if (!String.Equals(data.Header.Version, dataFile.Header.Version)) return false;
            if (!String.Equals(data.Header.Number, dataFile.Header.Number)) return false;
            if (!String.Equals(data.Header.Purpose, dataFile.Header.Purpose)) return false;
            return true;
          }) != null) continue;
          _lmsFiles.Add(dataFile);
        }
      }
    }

    private void InitLmsTemplates()
    {
      var newLmsMsgTemplates = new Dictionary<int, LmsMessageTemplate>();
      var files = new List<LmsFileData>();
      lock (_syncObj)
      {
        files.AddRange(_lmsFiles);
      }
      foreach (LmsFileData lmsFileData in files)
      {
        foreach (LmsMessageTemplate template in lmsFileData.Templates)
        {
          if (_policy.ReplaceExistingTemplate)
          {
            newLmsMsgTemplates[template.Id]= template;
          }
          else
          {
            if (!newLmsMsgTemplates.ContainsKey(template.Id))
              newLmsMsgTemplates.Add(template.Id, template);
          }
        }
      }
      lock (_syncObj)
      {
        if (_addedDirectlyTemplates != null)
        {
          foreach (KeyValuePair<int, LmsMessageTemplate> pair in _addedDirectlyTemplates)
          {
            var template = pair.Value;
            if (_policy.ReplaceExistingTemplate)
            {
              newLmsMsgTemplates[template.Id] = template;
            }
            else
            {
              if (!newLmsMsgTemplates.ContainsKey(template.Id))
                newLmsMsgTemplates.Add(template.Id, template);
            }
          }
        }
        _lmsMsgTemplates = newLmsMsgTemplates;
        _lmsMsgTemplatesReadOnly = new ReadOnlyDictionary<int, LmsMessageTemplate>(_lmsMsgTemplates);
      }
    }
    /// <summary>
    /// Adds new template
    /// </summary>
    /// <param name="template">template to be added</param>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public void AddTemplate(LmsMessageTemplate template)
    {
      if (template==null)
        throw new ArgumentNullException("template");
      lock (_syncObj)
      {
        CheckIfDisposed();
        if (_addedDirectlyTemplates==null)
          _addedDirectlyTemplates = new Dictionary<int, LmsMessageTemplate>();
        if (_policy.ReplaceExistingTemplate)
        {
          _addedDirectlyTemplates[template.Id] = template;
          _lmsMsgTemplates.Add(template.Id, template);
        }
        else
        {
          if (!_addedDirectlyTemplates.ContainsKey(template.Id))
            _addedDirectlyTemplates.Add(template.Id, template);
          if (!_lmsMsgTemplates.ContainsKey(template.Id))
            _lmsMsgTemplates.Add(template.Id, template);
        }
      }
    }
    /// <summary>
    /// Returns template by its identifier or null if the template is not loaded.
    /// </summary>
    /// <param name="id">identifier of template</param>
    /// <returns>template by its identifier or null if the template is not loaded</returns>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public LmsMessageTemplate GetMsgTemplate(int id)
    {
      lock (_syncObj)
      {
        CheckIfDisposed();
        return _lmsMsgTemplates.ContainsKey(id) ? _lmsMsgTemplates[id] : null;
      }
    }
    /// <summary>
    /// Loads new lms files
    /// </summary>
    /// <param name="filesNames">list of names of files separated by ',' or ';'</param>
    /// <returns></returns>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public LmsMessageConveyor LoadLmsFiles(string filesNames)
    {
      CheckIfDisposed();
      LoadAndAddLmsFiles(filesNames);
      InitLmsTemplates();
      return this;
    }
    /// <summary>
    /// Sets new policy
    /// </summary>
    /// <param name="policy">new policy instanse</param>
    /// <returns></returns>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public LmsMessageConveyor SetPolicy(ILmsFileLoadPolicy policy)
    {
      CheckIfDisposed();
      _policy = policy ?? DefaultLmsFileLoadPolicy;
      InitLmsTemplates();
      return this;
    }

  }
}

//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using Genesyslab.Platform.AppTemplate.Configuration.Log;
using Genesyslab.Platform.AppTemplate.Utilites;

namespace Genesyslab.Platform.AppTemplate.Logger.LMS
{
  /// <summary>
  /// Log categoty enumeration declarations specific for Genesys Message Server
  /// and Genesys LMS files specifications.
  /// </summary>
  public enum LmsLogCategory
  {
    ///<summary/>
    Default,
    ///<summary/>
    Application = 0,
    ///<summary/>
    Alarm,
    ///<summary/>
    Audit
  }
  /// <summary>
  /// Log levels enumeration declarations specific for Genesys Message Server
  /// and Genesys LMS files specifications.
  /// </summary>
  public enum LmsLogLevel
  {
    ///<summary>
    /// The log message level is not specified or is unknown.
    ///</summary>
    Unknown,

    ///<summary>
    /// Debug level LMS event.
    ///</summary>
    Debug,

    ///<summary>
    /// Trace (in terms of usual logging - 'info') level LMS event.
    ///</summary>
    Info,

    ///<summary>
    /// "Interaction" (in terms of usual logging - 'warning') level LMS event.
    ///</summary>
    Interaction,

    ///<summary>
    /// "Standard" (in terms of usual logging - 'error') level LMS event.
    ///</summary>
    Standard,

    ///<summary>
    /// "Alarm" (in terms of usual logging - 'fatal error') level LMS event.
    ///</summary>
    Alarm
  }
  /// <summary>
  /// The log message template.
  /// </summary>
  [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly")] //lms - is the extension of target files.
  public sealed class LmsMessageTemplate
  {
    private readonly FormatStringCompiler _formatString;

    /// <summary>
    /// Parses string into Lms Message Template
    /// </summary>
    /// <param name="data">source string</param>
    /// <returns>parsed template or null if string as wrong format</returns>
    public static LmsMessageTemplate Parse(string data)
    {
      if (string.IsNullOrEmpty(data)) return null;
      data = data.Trim();
      if (data.StartsWith(";")) return null;
      var options = data.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
      if (options.Length < 4) return null;
      for (int i = 0; i < 4; i++)
      {
        options[i] = options[i].Trim();
        if (String.IsNullOrEmpty(options[i])) return null;
      }
      int id;
      if (!Int32.TryParse(options[0], out id)) return null;
      LmsLogLevel? level = GAppLogExtOptions.GetLogLevel(options[1]);
      if (level==null) return null;
      return new LmsMessageTemplate(id, level.Value, options[2], options[3]);
    }
    ///<summary>
    /// Default constructor. Initializes the <see cref="Name"/> and <see cref="Format"/> properties with
    /// empty strings, <see cref="Id"/> with 0 and <see cref="Level"/> with <see cref="LmsLogLevel.Unknown"/>.
    ///</summary>
    public LmsMessageTemplate()
      : this(0, LmsLogLevel.Unknown, string.Empty, string.Empty)
    { }


    ///<summary>
    /// Constructor which initializes the properties with passed values:
    ///</summary>
    ///<param name="id">Initialized value for <see cref="Id"/>.</param>
    ///<param name="level">Initialized value for <see cref="Level"/>.</param>
    ///<param name="name">Initialized value for <see cref="Name"/>.</param>
    ///<param name="format">Initialized value for <see cref="Format"/>.</param>
    public LmsMessageTemplate(int id, LmsLogLevel level, string name, string format)
    {
      Id = id;
      Level = level;
      Name = name;
      Format = format;
      _formatString = new FormatStringCompiler(format, true);
    }

    /// <summary>
    /// Transforms template into string by given parameters.
    /// </summary>
    /// <param name="arguments">parameters</param>
    /// <returns>string representation</returns>
    public string GetFormatted(params object[] arguments)
    {
      return _formatString.Format(arguments);
    }
    #region Properties

    /// <summary>
    /// Sets or gets the Verbose of the message template.
    /// </summary>
    public LmsLogLevel Level
    { get; set; }


    /// <summary>
    /// Sets or gets the Name of message template.
    /// </summary>
    public string Name
    {
      get;
      set;
    }

    /// <summary>
    /// Sets or gets the Format line of the message template.
    /// </summary>
    public string Format
    {
      get;
      set;
    }

    ///<summary>
    /// The ID of the message template.
    ///</summary>
    public int Id { get; set; }
    #endregion

    ///<summary>
    /// Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
    ///</summary>
    ///<returns>
    /// A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
    ///</returns>
    ///<filterpriority>2</filterpriority>
    public override string ToString()
    {
      string result = string.Format(CultureInfo.InvariantCulture, "LmsMessageTemplate: [Id = {0}] [Name = {1}] [Level = {2}] [Format={3}]",
                                    Id, Name, Level, Format);
      return result;
    }
  }
}

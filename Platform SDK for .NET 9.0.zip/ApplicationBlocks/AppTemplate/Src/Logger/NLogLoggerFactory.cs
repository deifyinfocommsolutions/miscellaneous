//===============================================================================
// Genesys Platform SDK
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2009 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using Genesyslab.Configuration;
using Genesyslab.Platform.AppTemplate.Configuration.Log;
using Genesyslab.Platform.AppTemplate.Logger.LMS;
using Genesyslab.Platform.Commons;
using Genesyslab.Platform.Commons.Protocols.Custom;
using ILogger = Genesyslab.Platform.Commons.Logging.ILogger;

namespace Genesyslab.Platform.AppTemplate.Logger
{
  /// <summary>
  /// Bridge to LogManager class of NLog library. 
  /// Implements <see cref="ILoggerFactory"/> interface.
  /// Can be used by using app.config file:<br/>
  /// &lt;add key="Logger.AssemblyLocation" value="..."/&gt; <br/>
  /// &lt;add key="Logger.FactoryName" value="..."/&gt;<br/>
  /// or through <see cref="PsdkCustomization.LogFactory.AssemblyLocation"/> 
  /// and <see cref="PsdkCustomization.LogFactory.FactoryName"/> parameters.
  /// </summary>
  public class NLogLoggerFactory : ILoggerFactory, ILmsLogFactory, IDisposable
  {
    ~NLogLoggerFactory()
    {
      Dispose();
    }
    private volatile static NLogLoggerFactory _defaultFactory;
    /// <summary>
    /// Returns instance of the default factory
    /// </summary>
    public static NLogLoggerFactory Default
    {
      get
      {
        if (_defaultFactory == null)
        {
          lock (typeof (NLogLoggerFactory))
          {
            if (_defaultFactory == null)
            {
              _defaultFactory = new NLogLoggerFactory();
            }
          }
        }
        return _defaultFactory;
      }
    }
    private readonly INLogFactory _logFactory;

    private readonly LmsMessageConveyor _lmsMessageConveyor;

    internal static INLogFactory CreateNLogFactoryImpl()
    {
      var type =
        PsdkLibraryLoader.GetTypeByName("Genesyslab.Platform.AppTemplate.NLogAdapter.Logger.Impl.NLogFactoryImpl",
          "Genesyslab.Platform.AppTemplate.NLogAdapter.dll");
      if (type==null) return null;
      try
      {
        return Activator.CreateInstance(type) as INLogFactory;
      }
      catch (Exception)
      {
        return null;
      }
    }

    /// <summary>
    /// Substitute new NLog logger factory.
    /// </summary>
    /// <param name="factory">configured factory to be substituted</param>
    /// <param name="messageConveyor">Container to keep lms messages templates</param>
    public NLogLoggerFactory(INLogFactory factory, LmsMessageConveyor messageConveyor)
    {
      lock (this)
      {
        _logFactory = factory ?? CreateNLogFactoryImpl() ?? new NullLoggerFactory();
        _lmsMessageConveyor = messageConveyor ?? new LmsMessageConveyor();
      }
    }
    /// <summary>
    /// Substitute new NLog logger factory.
    /// </summary>
    /// <param name="factory">configured factory to be substituted</param>
    public NLogLoggerFactory(INLogFactory factory):this(factory, null){}
    /// <summary>
    /// Creates new logger factory.
    /// </summary>
    public NLogLoggerFactory():this(null){}

    /// <summary>
    /// Creates logger by its name.
    /// </summary>
    /// <param name="name">Name of logger</param>
    /// <returns><see cref="Commons.Logging.ILogger"/> instance</returns>
    public static ILogger GetLogger(string name)
    {
      return Default.CreateLogger(name);
    }
    /// <summary>
    /// Creates null logger instance.
    /// </summary>
    /// <returns><see cref="ILogger"/> instance</returns>
    public static ILogger CreateNullLogger()
    {
      return Default._logFactory.GetNullLogger();
    }

    private void CheckIfDisposed()
    {
      if (_isDisposed)
        throw new ObjectDisposedException("NLogLoggerFactory");
    }
    /// <summary>
    /// Creates ILogger instance for given object
    /// </summary>
    /// <param name="obj">object instance that requires ILogger</param>
    /// <returns>ILogger instance</returns>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public ILogger CreateLogger(object obj)
    {
      CheckIfDisposed();
      var name = obj as string;
      if (!String.IsNullOrEmpty(name)) return _logFactory.GetLogger(name);
      name = obj == null
          ? "null"
          : (PsdkCustomization.LogFactory.FullClassNameUsageForLogger ? obj.GetType().FullName : obj.GetType().Name);
      return _logFactory.GetLogger(name);
    }
    /// <summary>
    /// Creates Lms event logger
    /// </summary>
    /// <param name="name">name of logger or null</param>
    /// <returns>instance of <see cref="ILmsEventLogger"/> if the logger target exists and is configured.</returns>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public ILmsEventLogger CreateLmsLogger(string name)
    {
      CheckIfDisposed();
      return _logFactory.CreateLmsLogger(name, _lmsMessageConveyor);
    }
    /// <summary>
    /// Creates Lms event logger which skips all messages
    /// </summary>
    /// <returns>instance of <see cref="ILmsEventLogger"/>.</returns>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public ILmsEventLogger CreateNullLmsLogger()
    {
      CheckIfDisposed();
      return _logFactory.CreateNullLmsLogger(_lmsMessageConveyor);
    }

    /// <summary>
    /// Configures factory
    /// </summary>
    /// <param name="config">Configuration to be applied</param>
    /// <exception cref="InvalidOperationException">if the factory is set to null</exception>
    /// <exception cref="ArgumentNullException">if configuration is null</exception>
    /// <returns>this instance</returns>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public NLogLoggerFactory Configure(GAppLoggingOptions config)
    {
      CheckIfDisposed();
      _logFactory.Configure(config);
      return this;
    }
    /// <summary>
    /// Sets policy
    /// </summary>
    /// <param name="policy">Logger policy</param>
    /// <returns>this instance</returns>
    /// <exception cref="InvalidOperationException">if the factory is set to null</exception>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public NLogLoggerFactory WithPolicy(INLogLoggerPolicy policy)
    {
      CheckIfDisposed();
      if (_logFactory == null)
        throw new InvalidOperationException("NLog factory has been set to null");
      _logFactory.SetPolicy(policy);
      return this;
    }
    /// <summary>
    /// Reconfigures loggers created by this factory.
    /// </summary>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public void ReconfigureExistingLoggers()
    {
      CheckIfDisposed();
      _logFactory.ReconfigExistingLoggers();
    }
    /// <summary>
    /// Loads and adds new lms messages templates
    /// </summary>
    /// <param name="fileNames">list of files names separated by comas</param>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public void LoadLmsFiles(string fileNames)
    {
      CheckIfDisposed();
      _lmsMessageConveyor.LoadLmsFiles(fileNames);
    }

    /// <summary>
    /// Adds new template
    /// </summary>
    /// <param name="template">template to be added</param>
    /// <exception cref="ObjectDisposedException">If object is disposed</exception>
    public void AddTemplate(LmsMessageTemplate template)
    {
      CheckIfDisposed();
      _lmsMessageConveyor.AddTemplate(template);
    }

    private volatile bool _isDisposed;
    /// <exclude/>
    public void Dispose()
    {
      if (_isDisposed) return;
      lock (this)
      {
        if (_isDisposed) return;
        if (_logFactory!=null)
          _logFactory.Dispose();
        if (_lmsMessageConveyor!=null)
          _lmsMessageConveyor.Dispose();
        _isDisposed = true;
      }
      GC.SuppressFinalize(this);
    }
  }
}

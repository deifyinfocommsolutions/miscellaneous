//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Linq;
using System.Net;

namespace Genesyslab.Platform.AppTemplate.Utilites
{
  /// <summary>
  /// Helper class to work with configuration string
  /// </summary>
  public static class ConfigurationUtil
  {
    internal static TEnum? GetEnumValue<TEnum>(string name) where TEnum:struct 
    {
      try
      {
        return (TEnum) Enum.Parse(typeof (TEnum), name, true);
      }
      catch (Exception e)
      {
        return null;
      }
    } 

    private static readonly String[] ParamSeparator = {";"};

    /// <summary>
    /// Searches transportParameters for an occurrence of specified parameter name, returns parameter value.
    /// </summary>
    /// <param name="transportParameters">Semicolon-separated string of parameter pairs "name=value"</param>
    /// <param name="paramName">Name of the parameter</param>
    /// <returns>Parameter value (may be empty string) or null if parameter name is not found</returns>
    public static String FindTransportParameter(string transportParameters, string paramName)
    {
      if ((String.IsNullOrEmpty(transportParameters)) || (transportParameters.Trim().Length == 0))
      {
        return null;
      }
      if (null == paramName)
      {
        throw new ArgumentNullException("paramName", "paramName must not be null");
      }
      String[] parameters = transportParameters.Split(ParamSeparator, StringSplitOptions.RemoveEmptyEntries);
      var prefix = paramName + "=";
      return (from parameter in parameters
        where parameter.StartsWith(prefix)
        select parameter.Substring(prefix.Length)).FirstOrDefault();
    }

    /// <summary>
    /// Searches applicationParameters for an occurrence of specified parameter name, returns parameter value.
    /// </summary>
    /// <param name="applicationParameters">Semicolon-separated string of parameter pairs "name=value"</param>
    /// <param name="paramName">Name of the parameter</param>
    /// <returns>Parameter value (may be empty string) or null if parameter name is not found</returns>
    public static String FindAppParameter(string applicationParameters, string paramName)
    {
      if ((String.IsNullOrEmpty(applicationParameters)) || (applicationParameters.Trim().Length == 0))
      {
        return null;
      }
      if (null == paramName)
      {
        throw new ArgumentNullException("paramName", "paramName must not be null");
      }
      var parameters = applicationParameters.Split(ParamSeparator, StringSplitOptions.RemoveEmptyEntries).Select(s => s.Replace("\n", "").Replace("\r", "").Trim());
      var prefix = paramName + "=";
      return (from parameter in parameters
        where parameter.StartsWith(prefix)
        select parameter.Substring(prefix.Length).Trim()).FirstOrDefault();
    }
    /// <summary>
    /// Checks if the value may be recognized as 'true' value in configuration 
    /// </summary>
    /// <param name="value">source string value</param>
    /// <returns>true if string is recognized as 'true', otherwise false</returns>
    public static bool IsTrue(String value)
    {
      return "1".Equals(value)
             || "on".Equals(value, StringComparison.InvariantCultureIgnoreCase)
             || "yes".Equals(value, StringComparison.InvariantCultureIgnoreCase)
             || "true".Equals(value, StringComparison.InvariantCultureIgnoreCase);
    }
    /// <summary>
    /// Checks if the value may be recognized as 'false' value in configuration 
    /// </summary>
    /// <param name="value">source string value</param>
    /// <returns>true if string is recognized as 'false', otherwise false</returns>
    public static bool IsFalse(String value)
    {
      return "0".Equals(value)
             || "off".Equals(value, StringComparison.InvariantCultureIgnoreCase)
             || "no".Equals(value, StringComparison.InvariantCultureIgnoreCase)
             || "false".Equals(value, StringComparison.InvariantCultureIgnoreCase);
    }

    private static volatile String _localhostName ;
    /// <summary>
    /// Returns host name of the computer
    /// </summary>
    /// <returns>host name of the computer</returns>
    public static String GetLocalhostName() 
    {
        if (_localhostName == null){
          lock (typeof (ConfigurationUtil)){
            if (_localhostName == null){
              String lhname;
              try{
                lhname = Dns.GetHostName();
              }
              catch (Exception)
              {
                lhname = "localhost";
              }
              _localhostName = lhname;
            }
          }
        }
        return _localhostName;
    }

  }
}

//===============================================================================
// Genesys Platform SDK Application Template
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using System.Collections.Generic;
using System.Globalization;
using Genesyslab.Utils;

namespace Genesyslab.Platform.AppTemplate.Utilites
{
  /// <summary>
  /// Builds sequence of action to translate source format string with parameters into a result string. 
  /// </summary>
  public class FormatStringCompiler
  {
    private class FormatParser
    {
      /// <exclude/>
      public bool LeftJustify { get; private set; }
      /// <exclude/>
      public bool ForceSign { get; private set; }
      /// <exclude/>
      public bool Space { get; private set; }
      /// <exclude/>
      public bool Radix { get; private set; }
      /// <exclude/>
      public bool Zeros { get; private set; }
      /// <exclude/>
      public int Width { get; private set; }
      /// <exclude/>
      public int Precision { get; private set; }
      /// <exclude/>
      public bool Long { get; private set; }
      /// <exclude/>
      public bool LongLong { get; private set; }
      /// <exclude/>
      public bool Short { get; private set; }
      /// <exclude/>
      public bool ShortShort { get; private set; }
      /// <exclude/>
      public bool LongDouble { get; private set; }
      /// <exclude/>
      public char TypeCharacter { get; private set; }

      private bool ParseFlags(string format, int index)
      {
        switch (format[index])
        {
          case '-':
          {
            LeftJustify = true;
            return true;
          }
          case '+':
          {
            ForceSign = true;
            return true;
          }
          case ' ':
          {
            Space = true;
            return true;
          }
          case '#':
          {
            Radix = true;
            return true;
          }
          case '0':
          {
            Zeros = true;
            return true;
          }
        }
        return false;
      }

      /// <exclude/>
      public string RadixStr { get; private set; }
      /// <exclude/>
      public string SpaceStr { get; private set; }
      /// <exclude/>
      public string LeftFill { get; private set; }
      /// <exclude/>
      public string LeftFillA { get; private set; }
      /// <exclude/>
      public string RightFill { get; private set; }
      /// <exclude/>
      public string SignStr { get; private set; }
      /// <exclude/>
      public string FormatString { get; private set; }

      private static readonly char[] Digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
      private void ParseWigth(string format, ref int index, bool suppressExceptions)
      {
        var indexPoint = format.IndexOf('.', index);
        if (indexPoint >= 0)
        {
          var result = format.Substring(index, indexPoint - index);
          if (!String.IsNullOrEmpty(result))
          {
            int width;
            if (Int32.TryParse(result, out width))
            {
              Width = width;
              index = indexPoint;
              return;
            }
            if (!suppressExceptions)
              throw new ArgumentException("Wrong width format");
            return;
          }
        }
        var indexDig = format.LastIndexOfAny(Digits);
        if (indexDig<index) return;
        var result1 = format.Substring(index, indexDig - index+1);
        if (!String.IsNullOrEmpty(result1))
        {
          int width;
          if (Int32.TryParse(result1, out width))
          {
            Width = width;
            index = indexDig + 1;
            return;
          }
          if (!suppressExceptions)
            throw new ArgumentException("Wrong width format");
        }
      }
      private void ParsePrecision(string format, ref int index, bool suppressExceptions)
      {
        if (string.IsNullOrEmpty(format)) return;
        if (format.Length<index) return;
        if (format[index]!='.') return;
        index++;
        var indexDig = format.LastIndexOfAny(Digits);
        if (indexDig < index) return;
        var result1 = format.Substring(index, indexDig - index + 1);
        if (!String.IsNullOrEmpty(result1))
        {
          int width;
          if (Int32.TryParse(result1, out width))
          {
            Precision = width;
            index = indexDig + 1;
            return;
          }
          if (!suppressExceptions)
            throw new ArgumentException("Wrong width format");
        }
      }

      private void ParseType(string format, ref int index, bool suppressExceptions)
      {
        if (format.Length<=index)
          if (!suppressExceptions) throw new ArgumentException("Error parsing type character");
        TypeCharacter = format[index];
      }
      private void ParseLength(string format, ref int index, bool suppressExceptions)
      {
        if (format.Length <= index)
          if (!suppressExceptions) throw new ArgumentException("Error parsing type character");
        if (format[index] == 'l')
        {
          index++;
          if (format.Length <= index)
            if (!suppressExceptions) throw new ArgumentException("Error parsing type character");
          if (format[index] == 'l')
          {
            LongLong = true;
            index++;
          }
          else
          {
            Long = true;
          }
        }
        if (format[index] == 'h')
        {
          index++;
          if (format.Length <= index)
            if (!suppressExceptions) throw new ArgumentException("Error parsing type character");
          if (format[index] == 'h')
          {
            ShortShort = true;
            index++;
          }
          else
          {
            Short = true;
          }
        }
        if (format[index] == 'L')
        {
          index++;
          LongDouble = true;
        }
      }
      /// <exclude/>
      public static FormatParser Parse(string format, bool suppressExceptions)
      {
        var result = new FormatParser();
        int index = 0;
        while (result.ParseFlags(format, index)) index++;
        result.ParseWigth(format, ref index, suppressExceptions);
        result.ParsePrecision(format, ref index, suppressExceptions);
        result.ParseLength(format, ref index, suppressExceptions);
        result.ParseType(format, ref index, suppressExceptions);
        result.ProcessData();
        return result;
      }

      private const string SignedTypes = "dieEgGfF";
      private void ProcessData()
      {
        RadixStr = String.Empty;
        if (Radix)
        {
          if (TypeCharacter == 'x') RadixStr = "0x";
          if (TypeCharacter == 'X') RadixStr = "0X";
          if (TypeCharacter == 'o') RadixStr = "0";
        }
        SpaceStr = String.Empty;
        if (Space)
        {
          SpaceStr = " ";
        }
        LeftFill = String.Empty;
        RightFill = String.Empty;
        LeftFillA = String.Empty;
        if (LeftJustify)
        {
          RightFill = " ";
        }
        else
        {
          LeftFill = Zeros ? "0" : "";
          LeftFillA = Zeros ? "" : " ";
        }
        SignStr = String.Empty;
        if ((ForceSign) && (SignedTypes.IndexOf(TypeCharacter) >= 0)) SignStr = "+";
        if ((TypeCharacter == 'f') || (TypeCharacter == 'F'))
        {
          FormatString = new StringBuffer("{0,")
            .Append(LeftJustify ? "-" : "")
            .Append(Width.ToString(CultureInfo.InvariantCulture))
            .Append(":F")
            .Append(Precision.ToString(CultureInfo.InvariantCulture))
            .Append("}").ToString();
        }
        if ((TypeCharacter == 'g') || (TypeCharacter == 'G') || (TypeCharacter == 'e') || (TypeCharacter == 'E'))
        {
          FormatString = new StringBuffer("{0,")
            .Append(LeftJustify?"-":"")
            .Append(Width.ToString(CultureInfo.InvariantCulture))
            .Append(":").Append(TypeCharacter)
            .Append(Precision.ToString(CultureInfo.InvariantCulture))
            .Append("}").ToString();
        }
      }
    }

    /// <exclude/>
    protected readonly StringBuffer Buffer = new StringBuffer();
    /// <exclude/>
    protected readonly List<Action<object[]>> Actions = new List<Action<object[]>>();
    private readonly object _syncObj = new object();

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="formatSting">C++ format string.</param>
    public FormatStringCompiler(string formatSting)
    {
      Build(formatSting, true);
    }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="formatSting">C++ format string.</param>
    /// <param name="suppressExceptions">Supress all exceptions</param>
    public FormatStringCompiler(string formatSting, bool suppressExceptions)
    {
      Build(formatSting, suppressExceptions);
    }

    /// <summary>
    /// Translate given format string into result string.
    /// </summary>
    /// <param name="args">parameters of format string</param>
    /// <returns>Formatted string</returns>
    public string Format(params object[] args)
    {
      lock (_syncObj)
      {
        Buffer.Clear();
        foreach (var action in Actions)
        {
          if (action != null) action(args);
        }
        return Buffer.ToString();
      }
    }

    private static readonly char[] Specifiers = { 'd','i','u','o','x','X','f','F','e','E','g','G','s','S' };

    /// <summary>
    /// returns the first format specifier at the given starting index.
    /// </summary>
    /// <param name="formatString">source format string</param>
    /// <param name="startIndex">start index to look for the format specifier</param>
    /// <returns>format string or null if there no more format specifiers.</returns>
    protected virtual string GetFormat(string formatString, ref int startIndex)
    {
      var stIndex = formatString.IndexOf('%', startIndex);
      if (stIndex < 0) return null;
      var eIndex = formatString.IndexOfAny(Specifiers, stIndex + 1);
      if (eIndex<0) return null;
      startIndex = stIndex;
      return formatString.Substring(startIndex + 1, eIndex - startIndex);
    }

    /// <summary>
    /// Creates action for the
    /// </summary>
    /// <param name="format">format specifier</param>
    /// <param name="index">parameters index</param>
    /// <param name="suppressExceptions">flag to supress exceptions</param>
    /// <returns>function to translate parameter value into its string representation</returns>
    protected virtual Action<object[]> BuildFormatSpecifier(string format, int index, bool suppressExceptions)
    {
      var parser = FormatParser.Parse(format, suppressExceptions);
      switch (parser.TypeCharacter)
      {
        case 's':
        case 'S':
          return ProcessString(parser, index);
        case 'd':
        case 'i':
        case 'x':
        case 'X':
        case 'o':
          return ProcessInteger(parser, index);
        case 'f':
        case 'F':
        case 'e':
        case 'E':
        case 'g':
        case 'G':
          return ProcessFloat(parser, index);
      }
      return null;
    }

    private int GetRadix(FormatParser format)
    {
      switch (format.TypeCharacter)
      {
        case 'o':
          return 8;
        case 'x':
        case 'X':
          return 16;
        default:
          return 10;
      }
    }
    private string GetStringI(FormatParser format, int index, out bool positive, params object[] data)
    {
      positive = false;
      if ((data == null) || (data.Length <= index)) return null;
      var obj = data[index];

      if (obj is int)
      {
        var intVal = (int)obj;
        positive = intVal > 0;
        return Convert.ToString(intVal, GetRadix(format));
      }
      if (obj is uint)
      {
        var intVal = (uint)obj;
        positive = intVal > 0;
        return Convert.ToString(intVal, GetRadix(format));
      }
      if (obj is long)
      {
        var intVal = (long)obj;
        positive = intVal > 0;
        return Convert.ToString(intVal, GetRadix(format));
      }
      if (obj is ulong)
      {
        var intVal = Convert.ToInt64((ulong)obj);
        positive = intVal > 0;
        return Convert.ToString(intVal, GetRadix(format));
      }
      if (obj is short)
      {
        var intVal = (short)obj;
        positive = intVal > 0;
        return Convert.ToString(intVal, GetRadix(format));
      }
      if (obj is ushort)
      {
        var intVal = (ushort)obj;
        positive = intVal > 0;
        return Convert.ToString(intVal, GetRadix(format));
      }
      if (obj is byte)
      {
        var intVal = (byte)obj;
        positive = intVal > 0;
        return Convert.ToString(intVal, GetRadix(format));
      }
      return null;
    }
    private string GetStringF(FormatParser format, int index, out bool positive, params object[] data)
    {
      positive = false;
      if ((data == null) || (data.Length <= index)) return null;
      var obj = data[index];
      try
      {
        var fValue = Convert.ToDouble(obj);
        positive = fValue > 0;
        if (!String.IsNullOrEmpty(format.FormatString))
          return String.Format(format.FormatString, fValue);
        return fValue.ToString("F" + format.Precision);
      }
      catch (Exception)
      {
        return null;
      }
    }

    private void WriteStrData(FormatParser format, string data, bool positive)
    {
      if (data.Length >= format.Width)
      {
        Buffer.Append(format.RadixStr);
        Buffer.Append(data);
        return;
      }
      var addLen = format.Width - data.Length - (positive?format.SignStr.Length:0)-format.RadixStr.Length;
      if (addLen > 0)
      {
        Buffer.Append(format.LeftFillA, addLen).Append(format.RadixStr).Append(format.LeftFill, addLen);
        if (positive)
          Buffer.Append(format.SignStr);
        Buffer.Append(data).Append(format.RightFill, addLen);
      }
      else
      {
        Buffer.Append(format.RadixStr);
        if (positive)
          Buffer.Append(format.SignStr);
        Buffer.Append(data);
      }
    }

    private Action<object[]> ProcessInteger(FormatParser format, int index)
    {
      return objects =>
      {
        bool positive;
        var result = GetStringI(format, index, out positive, objects);
        if (result == null) return;
        WriteStrData(format, result, positive);
      };
    }
    private Action<object[]> ProcessFloat(FormatParser format, int index)
    {
      return objects =>
      {
        bool positive;
        var result = GetStringF(format, index, out positive, objects);
        if (result == null) return;
        WriteStrData(format, result.Trim(), positive);
      };
    }

    private Action<object[]> ProcessString(FormatParser format, int index)
    {
      return objects =>
      {
        if ((objects == null) || (objects.Length <= index)) return;
        var result = objects[index] as string;
        if (result==null) return;
        if (result.Length >= format.Width)
        {
          Buffer.Append(result);
          return;
        }
        if (format.LeftJustify)
        {
          Buffer.Append(result);
          Buffer.Append(' ', format.Width - result.Length);
        }
        else
        {
          Buffer.Append(' ', format.Width - result.Length);
          Buffer.Append(result);
        }
      };
    }

    private void Build(string formatString, bool suppressExceptions)
    {
      if (String.IsNullOrEmpty(formatString)) return;
      int index = 0;
      int paramIndex = 0;
      while (index < formatString.Length)
      {
        var startIndex = index;
        var formatSpecifier = GetFormat(formatString, ref startIndex);
        if (String.IsNullOrEmpty(formatSpecifier))
        {
          var subString = formatString.Substring(index, formatString.Length - index);
          Actions.Add(objects => Buffer.Append(subString));
          break;
        }
        var func = BuildFormatSpecifier(formatSpecifier, paramIndex++, suppressExceptions);
        if (func == null)
        {
          var subString = formatString.Substring(index, formatString.Length - index);
          Actions.Add(objects => Buffer.Append(subString));
          break;
        }
        if (startIndex != index)
        {
          var subString = formatString.Substring(index, startIndex - index);
          Actions.Add(objects => Buffer.Append(subString));
        }
        Actions.Add(func);
        index = startIndex + formatSpecifier.Length+1;
      }
    }
  }
}

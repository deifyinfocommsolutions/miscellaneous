//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using System;
using System.Threading;
using Genesyslab.Configuration;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.ClusterProtocol
{
  /// <exclude/>
  public abstract class AbstractClusterChannelBase : AbstractLogEnabled
  {
    /// <summary>
    /// Name of configuration property that is used to define what method of using invoker is. 
    /// Boolean value. Possible values: 'true'|'false'.
    /// Config file section: &lt;add key="ClusterChannel.UseInvokerFactory" value="..."/&gt;
    /// Default value is false, that means that each cluster protocol has own invoker.
    /// </summary>
    public const string UseInvokerFactory = "ClusterChannel.UseInvokerFactory";
    /// <summary>
    /// Name of invoker used through factory.
    /// </summary>
    public const string InvokerName = "ClusterChannelInvoker";
  }
  /// <summary>
  /// Abstract class to provide a common functionality for all Cluster Protocols.
  /// </summary>
  public abstract class AbstractClusterChannel:AbstractClusterChannelBase,
    IInputChannel, IOutputChannel, IRequestChannel, IMessageReceiverManagement, IRequestChannelEx
  {
    /// <exclude/>
    protected Endpoint MyEndpoint;
    private readonly object _syncObject = new object();
    /// <exclude/>
    protected object SyncLock{ get { return _syncObject; }}
    private volatile ChannelState _state = ChannelState.Closed;
    private bool _useInvokerFactory;
    private IAsyncInvoker _internalInvoker;
    private int _stateModificationsCounter = 0;
    private readonly ManualResetEvent _openedEvent = new ManualResetEvent(false);
    private readonly ManualResetEvent _closedEvent = new ManualResetEvent(false);
    /// <exclude/>
    protected AbstractClusterChannel()
    {
      Timeout = DuplexChannel.DefaultTimeout;
    } 

    #region API

    internal void SetState(ChannelState newState, Exception cause)
    {
      lock (SyncLock)
      {
        ChannelState prevState = _state;
        if (newState == _state) return;
        if ((_state == ChannelState.Closed) && (newState == ChannelState.Closing))
          return; // ignore incorect change state;
        _stateModificationsCounter++;
        _state = newState;
        this.DebugLog("{0} Cluster state transition [{1}]->[{2}]",LogObject, prevState, newState);
        switch (newState)
        {
          case ChannelState.Closed:
          {
              ProcessIncomingMessages(true);
              FireClosed(new ClosedEventArgs(prevState, cause));
              ReleaseInvoker();
              //GetInvoker().Invoke(state => ReleaseInvoker(),this);
              break;
            }
          case ChannelState.Opening:
            {
              if (prevState == ChannelState.Opened)
              {
                FireClosed(new ClosedEventArgs(prevState, cause));
                //GetInvoker().Invoke(state => ReleaseInvoker(), this);
              }
              _openedEvent.Reset();
              _closedEvent.Reset();
              break;
            }
          case ChannelState.Opened:
            {
              ProcessIncomingMessages(false);
              FireOpened(new OpenedEventArgs(cause));
              break;
            }
          case ChannelState.Closing:
            {
              _openedEvent.Reset();
              _closedEvent.Reset();
              break;
            }
        }
      }
      
    }
    /// <exclude/>
    protected virtual void ProcessIncomingMessages(bool failed){}
    /// <summary>
    /// Returns state of cluster channel
    /// </summary>
    public ChannelState State
    {
      get
      {
        lock (SyncLock)
        {
          return _state;
        }
      }
    }
    /// <exclude/>
    public abstract void BeginOpen();
    /// <exclude/>
    public abstract void BeginClose();
    /// <summary>
    /// Synchronous method to open cluster channel
    /// </summary>
    public void Open()
    {
      Open(Timeout);
    }
    /// <summary>
    /// Synchronous method to close cluster channel
    /// </summary>
    public void Close()
    {
      Close(Timeout);
    }
    /// <exclude/>
    public abstract void Open(TimeSpan timeout);
    /// <exclude/>
    public abstract void Close(TimeSpan timeout);
    /// <summary>
    /// Gets/sets default timeout for I/O operations
    /// </summary>
    public TimeSpan Timeout { get; set; }
    /// <exclude/>
    public abstract void Send(IMessage message);
    /// <exclude/>
    [Obsolete("Obsolete method. Does nothing.")]
    public void ClearInput(){}
    /// <exclude/>
    [Obsolete("Obsolete method. Setter does nothing. Getter function returns zero.")]
    public int InputSize { get { return 0; } set { } }
    /// <exclude/>
    [Obsolete("Obsolete method. Does nothing.")]
    public void ReleaseReceivers() { }
    /// <summary>
    /// Do not use this method directly. It always returns null.
    /// </summary>
    /// <returns>always returns null</returns>
    [Obsolete("Obsolete method. Returns null.")]
    public IMessage Receive(){ return null; }
    /// <summary>
    /// Do not use this method directly. It always returns null.
    /// </summary>
    /// <returns>always returns null</returns>
    [Obsolete("Obsolete method. Returns null.")]
    public IMessage Receive(TimeSpan timeout) { return null; }
    /// <summary>
    /// Performs synchronous request to the first available node of cluster.
    /// </summary>
    /// <param name="message">request message</param>
    /// <returns>response message or null in case of timeout</returns>
    public IMessage Request(IMessage message)
    {
      return Request(message, Timeout);
    }
    /// <exclude/>
    public abstract IMessage Request(IMessage message, TimeSpan timeout);
    /// <summary>
    /// Starts asynchronous request.
    /// </summary>
    /// <param name="message">request message</param>
    /// <param name="asyncCallback">callback function</param>
    /// <param name="state">user parameter for callback. Available through <see cref="IAsyncResult.AsyncState"/> property.</param>
    /// <returns><see cref="IAsyncResult"/> instance</returns>
    public IAsyncResult BeginRequest(IMessage message, AsyncCallback asyncCallback, object state)
    {
      return BeginRequest(message, asyncCallback, state, Timeout);
    }
    /// <exclude/>
    public abstract IAsyncResult BeginRequest(IMessage message, AsyncCallback asyncCallback, object state, TimeSpan timeOut);
    /// <exclude/>
    public abstract IMessage EndRequest(IAsyncResult asyncResult);
    /// <exclude/>
    public void ResetReceiver(){}
    /// <summary>
    /// Not supported.
    /// </summary>
    /// <exception cref="NotSupportedException"></exception>
    /// <param name="receiver"></param>
    [Obsolete("Obsolete method. Throws 'NotSupportedException'.")]
    public void SetReceiver(IMessageReceiverSupport receiver)
    {
      ThrowUnsupportedException();
    }

    #endregion API
    #region Events
    /// <summary>
    /// Event to notify that at least one cluster node has became available.
    /// </summary>
    public event EventHandler Opened;

    private void FireEvent(EventHandler handler, EventArgs args)
    {
      FireEvent(handler, this, args);
    }
    private void FireEvent(EventHandler handler, Object sender, EventArgs args)
    {
      if (handler == null) return;
      GetInvoker().Invoke(handler, sender, args);
    }
    internal virtual void FireOpened(EventArgs args)
    {
      _closedEvent.Reset();
      _openedEvent.Set();
      FireEvent(Opened, args);
    }
    /// <summary>
    /// Event to notify that all cluster nodes are no longer available.
    /// </summary>
    public event EventHandler Closed;
    internal virtual void FireClosed(EventArgs args)
    {
      _openedEvent.Reset();
      _closedEvent.Set();
      FireEvent(Closed, args);
    }
    /// <summary>
    /// Event to notify of channel error.
    /// </summary>
    public event EventHandler Error;
    internal virtual void FireError(EventArgs args)
    {
      FireEvent(Error, args);
    }
    /// <summary>
    /// Event to notify that the new message is received.
    /// </summary>
    public event EventHandler Received;
    internal virtual void FireReceived(EventArgs args)
    {
      FireEvent(Received, args);
    }
    /// <summary>
    /// Notifies about cluster node connection open.
    /// </summary>
    /// <seealso cref="OpenedEventArgs"/>
    /// <seealso cref="WSOpenedEvent"/>
    public event EventHandler InternalChannelOpened;
    internal virtual void FireInternalChannelOpened(Object sender, EventArgs args)
    {
      FireEvent(InternalChannelOpened, sender, args);
    }
    /// <summary>
    /// Notifies about cluster node connection close.
    /// </summary>
    /// <seealso cref="ClosedEventArgs"/>
    /// <seealso cref="WSClosedEvent"/>
    public event EventHandler InternalChannelClosed;
    internal virtual void FireInternalChannelClosed(Object sender, EventArgs args)
    {
      FireEvent(InternalChannelClosed, sender, args);
    }
    #endregion Events
    #region utility methods
    /// <exclude/>
    protected void ThrowUnsupportedException()
    {
      throw new NotSupportedException("This operation is not supported by this protocol type.");
    }
    /// <exclude/>
    protected virtual void OnClusterOpen()
    {
      _useInvokerFactory = PsdkCustomization.CustomOption(UseInvokerFactory, false);
    }
    /// <exclude/>
    protected IAsyncInvoker GetInvoker()
    {
      lock (SyncLock)
      {
        if (_internalInvoker != null) return _internalInvoker;
        this.DebugLog("{0} Assign new invoker (Pooled:{1})", LogObject, _useInvokerFactory);
          _internalInvoker = (_useInvokerFactory)
            ? InvokerFactory.NamedInvoker(InvokerName)
            : new SingleThreadInvoker(InvokerName);
        return _internalInvoker;
      }
    }
    /// <exclude/>
    protected void ReleaseInvoker()
    {
      IAsyncInvoker invoker;
      lock (SyncLock)
      {
        if (_internalInvoker == null) return;
        invoker = _internalInvoker;
        _internalInvoker = null;
      }
      if (invoker == null) return;
      invoker.Invoke(state =>
      {
        if (_useInvokerFactory)
        {
          InvokerFactory.ReleaseInvoker(InvokerName);
        }
        else
        {
          var disposable = invoker as IDisposable;
          if (disposable != null)
            disposable.Dispose();
        }
        this.DebugLog("{0} Release invoker (Pooled:{1})", LogObject, _useInvokerFactory);
      }, this);
    }
    /// <exclude/>
    protected abstract String LogObject { get; }
    /// <exclude/>
    protected bool WaitOpened(int ms)
    {
      return _openedEvent.WaitOne(ms);
    }
    /// <exclude/>
    protected bool WaitClosed(int ms)
    {
      return _closedEvent.WaitOne(ms);
    }
    #endregion utility methods
  }
}

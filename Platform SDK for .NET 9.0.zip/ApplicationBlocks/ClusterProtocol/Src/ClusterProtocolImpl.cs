//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Genesyslab.Platform.ClusterProtocol.Runtime;
using Genesyslab.Platform.Commons;
using Genesyslab.Platform.Commons.Collections.Internal;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;
using Genesyslab.Platform.ClusterProtocol.LoadBalancer;
using Genesyslab.Platform.Standby;
using IMessage = Genesyslab.Platform.Commons.Protocols.IMessage;
using Genesyslab.Platform.Commons.Collections.Internal;

namespace Genesyslab.Platform.ClusterProtocol
{
  /// <summary>
  /// Abstract implementation base of Cluster Protocol interface. <br/>
  /// It's a common functionality for all specific Cluster Protocols.
  /// </summary>
  /// <typeparam name="TProtocol">Type of protocol</typeparam>
  /// <typeparam name="TBuilder">Type of protocol builder</typeparam>
  public abstract class ClusterProtocolImpl<TProtocol, TBuilder>:AbstractClusterChannel, IClusterProtocol
    where TProtocol:ClientChannel
    where TBuilder: ProtocolBuilder<TProtocol,TBuilder>
  {
    private readonly IDictionary<String, ClusterProtocolNodeImpl> _clusterNodes = new OrderedDictionary<String, ClusterProtocolNodeImpl>();
    private readonly HashSet<ClusterProtocolNodeImpl> _openedClusterNodes = new HashSet<ClusterProtocolNodeImpl>();
    private readonly HashSet<ClusterProtocolNodeImpl> _openingClusterNodes = new HashSet<ClusterProtocolNodeImpl>();
    private readonly HashSet<ClusterProtocolNodeImpl> _closingClusterNodes = new HashSet<ClusterProtocolNodeImpl>();
    private readonly HashSet<ClusterProtocolNodeImpl> _removingClusterNodes = new HashSet<ClusterProtocolNodeImpl>();
    /// <exclude/>
    protected readonly IClusterProtocolLoadBalancer LoadBalancer;
    private readonly IClusterProtocolPolicy _clusterProtocolPolicy;
    /// <summary>
    /// Returns <see cref="IClusterProtocolPolicy"/> instance.
    /// </summary>
    public IClusterProtocolPolicy ClusterProtocolPolicy { get { return _clusterProtocolPolicy; } }
    private readonly ProtocolBuilder<TProtocol, TBuilder> _protocolBuilder;
    private readonly MessageEngine _messageEngine;
    private readonly IReferenceBuilder _referenceBuilder = new IntReferenceBuilder();
    /// <exclude/>
    protected ClusterProtocolImpl(
      ProtocolBuilder<TProtocol, TBuilder> protocolBuilder,
      IClusterProtocolPolicy protocolPolicy,
      IClusterProtocolLoadBalancer loadBalancer)
    {
      ThrowArgumentNull(protocolBuilder, "ProtocolBuilder");
      _clusterProtocolPolicy = protocolPolicy == null
        ? new DefaultClusterProtocolPolicy()
        : new DefaultClusterProtocolPolicy(protocolPolicy.WaitOnChannelOpening, protocolPolicy.UseRequestProtocolId);
      LoadBalancer = loadBalancer ?? ClusterProtocolLoadBalancerFactory.GetLoadBalancer();
      MyEndpoint = new Endpoint("ClusterConnProtocol-" + protocolBuilder.Description,
        new PropertyConfiguration());

      _protocolBuilder = protocolBuilder.WithReferenceBuilder(ReferenceBuilder);
      _messageEngine = new MessageEngine().UseCluster(this);
    }
    /// <exclude/>
    protected override void OnEnableLogging(ILogger logger)
    {
      base.OnEnableLogging(logger);
      if (logger==null) return;
      var ale = LoadBalancer as AbstractLogEnabled;
      if (ale!=null)
        ale.EnableLogging(logger.CreateChildLogger("LoadBalancer"));
      _messageEngine.EnableLogging(logger.CreateChildLogger("MessageEngine`"));
      foreach (KeyValuePair<string, ClusterProtocolNodeImpl> clusterNode in _clusterNodes)
      {
        clusterNode.Value.WarmStandby.EnableLogging(logger.CreateChildLogger("ClusterNode.Service"));
        ale = clusterNode.Value.Protocol as AbstractLogEnabled;
        if (ale!=null)
          ale.EnableLogging(logger.CreateChildLogger("ClusterNode.Channel"));
      }
    }


    private static IInterceptor _noInterceptor = new NoInterceptor();
    /// <exclude/>
    public IInterceptor Interceptor { get { return _noInterceptor; } }
    /// <exclude/>
    public IConnectionConfiguration Configuration
    {
      get { return (_endpoint != null) ? _endpoint.GetConfiguration() : null; }
    }
    /// <exclude/>
    public void Configure(IConnectionConfiguration connectionConfiguration)
    {
#pragma warning disable 618
      if (_endpoint!=null)
        _endpoint.SetConfiguration(connectionConfiguration);
#pragma warning restore 618
      if (LoadBalancer != null)
        LoadBalancer.Configure(connectionConfiguration);
    }

    private Endpoint _endpoint;
    /// <exclude/>
    public Endpoint Endpoint {
      get { return _endpoint; }
      set
      {
        ThrowNull(value,"endpoint");
        ThrowNotClosed();
        _endpoint = value.Clone() as Endpoint;
        if (_endpoint!=null)
          Configure(_endpoint.GetConfiguration());
      } 
    }
    /// <exclude/>
    public ProtocolDescription ProtocolDescription { get; private set; }
    /// <exclude/>
    [Obsolete("Obsolete method. Does nothing.")]
    public IAsyncInvoker Invoker { set; private get; }
    /// <summary>
    /// Do not use this method. It throws <see cref="NotSupportedException"/>.
    /// </summary>
    /// <param name="connectionInvoker"></param>
    /// <exception cref="NotSupportedException">always</exception>
    [Obsolete("Obsolete method. Throws 'NotSupportedException'.")]
    public void SetConnectionInvoker(IAsyncInvoker connectionInvoker)
    {
      ThrowUnsupportedException();
    }
    /// <exclude/>
    public bool CopyResponse { get; set; }
    /// <summary>
    /// returns reference builder
    /// </summary>
    public virtual IReferenceBuilder ReferenceBuilder { get { return _referenceBuilder; } }
    /// <exclude/>
    public int ProtocolId { get { return UniqueObjectId; } }


    #region API implementation
    /// <summary>
    /// Starts asynchronous opening of cluster.
    /// </summary>
    public override void BeginOpen()
    {
      OpenAsync(null);
    }
    /// <summary>
    /// Starts asynchronous closing of cluster.
    /// </summary>
    public override void BeginClose()
    {
      CloseAsync(null);
    }
    /// <summary>
    /// Performs synchronous opening of cluster.
    /// </summary>
    /// <param name="timeout">timeout value</param>
    public override void Open(TimeSpan timeout)
    {
      Exception cause = null;
      var completedEvent = new ManualResetEvent(false);
      OpenAsync((sender, args) =>
      {
        cause = args.Cause;
        completedEvent.Set();
      });
      if (completedEvent.WaitOne(timeout))
      {
        if (cause != null)
          throw cause;
        return;
      }
      throw new ProtocolTimeoutException("Cluster hasn't managed to open for given timeout ("+(int)timeout.TotalMilliseconds+" ms).");
    }
    /// <summary>
    /// Performs synchronous closing of cluster.
    /// </summary>
    /// <param name="timeout">timeout value</param>
    public override void Close(TimeSpan timeout)
    {
      Exception cause = null;
      var completedEvent = new ManualResetEvent(false);
      CloseAsync((sender, args) =>
      {
        cause = args.Cause;
        completedEvent.Set();
      });
      if (completedEvent.WaitOne(timeout))
      {
        if (cause is ProtocolTimeoutException)
        {
          cause.PreserveStackTrace();
          throw cause;
        }
        return;
      }
      throw new ProtocolTimeoutException("Cluster hasn't managed to close for given timeout (" + (int)timeout.TotalMilliseconds + " ms).");
    }
    /// <summary>
    /// Sends message to the first available node of cluster. 
    /// Node is selected by load balancer.
    /// </summary>
    /// <param name="message">message to be sent</param>
    public override void Send(IMessage message)
    {
      if (_clusterProtocolPolicy.WaitOnChannelOpening)
        WaitOpened((int) Timeout.TotalMilliseconds);
      _messageEngine.Send(message);
    }
    /// <summary>
    /// Performs a synchronoous request to the first available node of cluster. 
    /// Node is selected by load balancer.
    /// </summary>
    /// <param name="message">request message</param>
    /// <param name="timeout">timeout for response</param>
    /// <returns>cluster's response or null by timeout</returns>
    public override IMessage Request(IMessage message, TimeSpan timeout)
    {
      if (_clusterProtocolPolicy.WaitOnChannelOpening)
        WaitOpened((int)timeout.TotalMilliseconds);
      return _messageEngine.Request(message, timeout);
    }
    /// <summary>
    /// Starts an asynchronoous request to the first available node of cluster. 
    /// Node is selected by load balancer.
    /// </summary>
    /// <param name="message">request message</param>
    /// <param name="asyncCallback">callback function</param>
    /// <param name="state">user parameter for callback. Available through <see cref="IAsyncResult.AsyncState"/> property.</param>
    /// <param name="timeOut">timeout for response</param>
    /// <returns><see cref="IAsyncResult"/> instance</returns>
    public override IAsyncResult BeginRequest(IMessage message, AsyncCallback asyncCallback, object state, TimeSpan timeOut)
    {
      if (_clusterProtocolPolicy.WaitOnChannelOpening)
        WaitOpened((int)timeOut.TotalMilliseconds);
      return _messageEngine.BeginRequest(message, asyncCallback, state, timeOut);
    }
    /// <summary>
    /// Performs a synchronous operation to complete asynchronous request.
    /// </summary>
    /// <param name="asyncResult"><see cref="IAsyncResult"/> instance</param>
    /// <returns>Cluster's response or null by timeout.</returns>
    public override IMessage EndRequest(IAsyncResult asyncResult)
    {
      return _messageEngine.EndRequest(asyncResult);
    }
    #endregion API implementation
    #region Process Messages

    private class MessageEngine: AbstractLogEnabled
    {
      private ClusterProtocolImpl<TProtocol,TBuilder> _clusterProtocol;
      public MessageEngine UseCluster(ClusterProtocolImpl<TProtocol, TBuilder> protocol)
      {
        _clusterProtocol = protocol;
        return this;
      }

      private IProtocol Protocol(IMessage message)
      {
        IProtocol protocol;
        if ((_clusterProtocol.ClusterProtocolPolicy != null) && (_clusterProtocol.ClusterProtocolPolicy.UseRequestProtocolId))
        {
          protocol = _clusterProtocol.GetNodeProtocol(message.ProtocolId);
          if ((protocol != null) && (protocol.State == ChannelState.Opened)) 
            return protocol;

        }
        return _clusterProtocol.GetNextAvailableProtocol();
      }

      public void Send(IMessage message)
      {
        MakeRequest(message, _clusterProtocol.Timeout, protocol =>
        {
          protocol.Send(message);
          return null;
        });
      }

      public IMessage Request(IMessage message, TimeSpan timeout)
      {
        return EndRequest(BeginRequest(message, null, null, timeout));
      }

      private object MakeRequest(IMessage message, TimeSpan timeout, Func<IProtocol,Object> funtion)
      {
        var elapsedTime = Stopwatch.StartNew();
        var waitOpening = _clusterProtocol.ClusterProtocolPolicy.WaitOnChannelOpening;
        while (true)
        {
          var state = _clusterProtocol.State;
          if ((state == ChannelState.Closed) || (state == ChannelState.Closing))
            throw new ChannelClosedOnSendException("Channel has been closed before message delivery");
          if ((state == ChannelState.Opening) && (!waitOpening))
            throw new ChannelClosedOnSendException("Protocol is not opened");
          IProtocol protocol = Protocol(message);
          if ((protocol != null) && (protocol.State == ChannelState.Opened))
          {
            try
            {
              return funtion(protocol);
            }
            catch (ChannelClosedOnSendException e1)
            {
              this.DebugLog("Protocol connection has been lost right before sending", e1);
              _clusterProtocol.FireError(new ErrorArgs(e1));
            }
            catch (ChannelNotOpenedException e2)
            {
              this.DebugLog("Protocol connection has been lost before sending", e2);
              _clusterProtocol.FireError(new ErrorArgs(e2));
            }
          }
          lock (_clusterProtocol.SyncLock)
          {
            try
            {
              if (protocol != null)
              {
                try
                {
                  _clusterProtocol.LoadBalancer.RemoveNode(protocol);
                }
                catch (Exception e)
                {
                  this.WarnLog("Exception removing node from Load Balancer: {0}", e);
                }
              }
              if ((_clusterProtocol.State == ChannelState.Opening) && (waitOpening))
              {
                var remainedTime = timeout - elapsedTime.Elapsed;
                if (remainedTime < TimeSpan.Zero)
                  throw new ChannelClosedOnSendException("Got no connected protocol in the timeout period");
                _clusterProtocol.WaitOpened((int) remainedTime.TotalMilliseconds);
              }
            }
            catch (ThreadInterruptedException e)
            {
              throw new ChannelClosedOnSendException("Failed to wait for protocol connection", e);
            }
          }
        }
      }

      public IAsyncResult BeginRequest(IMessage message, AsyncCallback asyncCallback, object state, TimeSpan timeOut)
      {
        return MakeRequest(message, timeOut, protocol =>
        {
          var exRq = protocol as IRequestChannelEx;
          return exRq == null
            ? protocol.BeginRequest(message, asyncCallback, state)
            : exRq.BeginRequest(message, asyncCallback, state, timeOut);
        }) as IAsyncResult;
      }

      public IMessage EndRequest(IAsyncResult asyncResult)
      {
        if (asyncResult==null)
          throw new ArgumentNullException("asyncResult");
        var asyncRes = asyncResult as AsyncRequestResult;
        if (asyncRes != null)
        {
          try
          {
            return asyncRes.Protocol.EndRequest(asyncResult);
          }
          catch (ChannelClosedOnSendException)
          {
            throw;
          }
          catch (ChannelClosedOnRequestException)
          {
            throw;
          }
          catch (ProtocolException)
          {
            throw;
          }
          catch (ThreadInterruptedException e)
          {
            var cause = e.InnerException;
            if (cause is ChannelClosedOnSendException)
            {
              throw;
            }
            if (cause is ProtocolException)
            {
              throw new ChannelClosedOnRequestException(cause.ToString());
            }
            throw new OperationCanceledException(e.ToString());
          }
          catch (Exception ex)
          {
            throw new ProtocolException("Unknown exception: ", ex);
          }
        }
        throw new ArgumentException("Async result doesn't belong to this engine");
      }
    }
    #endregion Process Messages
    #region CompletionHandler

    private abstract class CompletionHandler<T>:AbstractLogEnabled
      where T: ChannelArgs
    {
      protected readonly ClusterProtocolImpl<TProtocol, TBuilder> Cluster;
      private readonly List<EventHandler<T>> _handlers = new List<EventHandler<T>>();
      internal CompletionHandler(ClusterProtocolImpl<TProtocol, TBuilder> cluster,
        EventHandler<T> handler)
      {
        Cluster = cluster;
        _handlers.Add(handler);
      }

      internal void AddHandler(EventHandler<T> handler)
      {
        if (handler==null) return;
        _handlers.Add(handler);
      }

      internal void Complete(EventArgs args)
      {
          this.DebugLog("[{0}, ID={1}] invoke completeon handler", GetType().Name, UniqueObjectId);
        foreach (EventHandler<T> handler in _handlers)
        {
          if (handler != null)
            Cluster.GetInvoker().Invoke(handler, Cluster, args);
        }
      }
      protected override void OnEnableLogging(ILogger logger)
      {
        base.OnEnableLogging(logger);
        this.DebugLog("[{0}, ID={1}] created ", GetType().Name, UniqueObjectId);
      }
    }
    private class OpenCompletionHandler : CompletionHandler<OpenedEventArgs>
    {
      public OpenCompletionHandler(ClusterProtocolImpl<TProtocol, TBuilder> cluster, 
        EventHandler<OpenedEventArgs> handler) : base(cluster, handler){}
    }
    private class CloseCompletionHandler : CompletionHandler<ClosedEventArgs>
    {
      public CloseCompletionHandler(ClusterProtocolImpl<TProtocol, TBuilder> cluster,
        EventHandler<ClosedEventArgs> handler)
        : base(cluster, handler) { }
    }
    #endregion CompletionHandler
    #region Cluster API implementation

    private OpenCompletionHandler _openCompletionHandler;
    /// <summary>
    /// Starts asynchronous opening of cluster. 
    /// </summary>
    /// <param name="handler">Completion handler to notify that cluster is opened.</param>
    public void OpenAsync(EventHandler<OpenedEventArgs> handler)
    {
      lock (SyncLock)
      {
        ThrowNotClosed();
        ThrowEmptyNodes();
        SetState(ChannelState.Opening, null);
        OnClusterOpen();
        _closeCompletionHandler = null;
        _openCompletionHandler = new OpenCompletionHandler(this, handler);
        if (Logger!=null)
          _openCompletionHandler.EnableLogging(Logger.CreateChildLogger("OpenAsync.CompletionHandler"));
        foreach (ClusterProtocolNodeImpl node in _clusterNodes.Values)
        {
          var currNode = node;
          _closingClusterNodes.Remove(currNode);
          _openingClusterNodes.Add(currNode);
          SetProtocolInvoker(currNode.WarmStandby.Channel);
          currNode.WarmStandby.BeginOpen(ar => this.DebugLog("{0}: OpenAsync handler for node [ID={1}, {2}]", LogObject, currNode.WarmStandby.ID, currNode.WarmStandby.Channel.Endpoint), null);
          currNode.WarmStandby.AutoRestore(false);
        }
      }
    }
    internal override void FireOpened(EventArgs args)
    {
      base.FireOpened(args);
      if (_openCompletionHandler != null)
      {
        _openCompletionHandler.Complete(args as OpenedEventArgs);
        _openCompletionHandler = null;
      }
    }

    private CloseCompletionHandler _closeCompletionHandler;
    /// <summary>
    /// Starts asynchronous closing of cluster. 
    /// </summary>
    /// <param name="handler">Completion handler to notify that cluster is closed.</param>
    public void CloseAsync(EventHandler<ClosedEventArgs> handler)
    {
      lock (SyncLock)
      {
        if (State == ChannelState.Closing)
        {
          if (_closeCompletionHandler!=null)
            _closeCompletionHandler.AddHandler(handler);
          return;
          //throw new ChannelNotOpenedException("Operation is not supported when cluster is already closing.");
        }
        if (State == ChannelState.Closed)
        {
          if (handler!=null)
            GetInvoker().Invoke(handler, this, new ClosedEventArgs(ChannelState.Closed, null));
          ReleaseInvoker();
          return;
        }
        SetState(ChannelState.Closing, null);
        _openCompletionHandler = null;
        _closeCompletionHandler = new CloseCompletionHandler(this, handler);
        if (Logger != null)
          _closeCompletionHandler.EnableLogging(Logger.CreateChildLogger("OpenAsync.CompletionHandler"));
        int count = 0;
        foreach (ClusterProtocolNodeImpl node in _clusterNodes.Values)
        {
          var currNode = node;
          if (_closingClusterNodes.Contains(currNode)) continue;
          _openingClusterNodes.Remove(currNode);
          _openedClusterNodes.Remove(currNode);
          _closingClusterNodes.Add(currNode);
          _removingClusterNodes.Remove(currNode);
          LoadBalancer.RemoveNode(currNode.Protocol);
          count++;
          currNode.CancelCloseSchedule();
          currNode.WarmStandby.BeginClose(AsyncClosedHandler, currNode);
        }
        this.DebugLog("Initialized closing of {0} nodes", count);
      }
    }
    private void AsyncClosedHandler(IAsyncResult ar)
    {
      var wsArg = ar as WSAsyncResult;
      if (wsArg != null)
      {
        var currNode = ar.AsyncState as ClusterProtocolNodeImpl;
        if (currNode != null)
        {
          int countNonClosing;
          int activeNodes;
          lock (SyncLock)
          {
            _closingClusterNodes.Remove(currNode);
            activeNodes = _openedClusterNodes.Count + _openingClusterNodes.Count + _closingClusterNodes.Count+_removingClusterNodes.Count;
            countNonClosing = _closingClusterNodes.Count;
          }
          this.DebugLog("{0}: CloseAsync handler for node [ID={1}, {2}] closing queue: [{3}] of [{4}] total active",
            LogObject, currNode.WarmStandby.ID, currNode.WarmStandby.Channel.Endpoint, countNonClosing, activeNodes);
          currNode.OnClosed(() => NotifyChannelClosedEvent(currNode.WarmStandby.Channel, wsArg.Arguments));
          if (activeNodes == 0)
          {
            LoadBalancer.ClearNodes();
            SetState(ChannelState.Closed, wsArg.Cause);
          }
        }
      }
    }

    internal override void FireClosed(EventArgs args)
    {
      base.FireClosed(args);
      if (_closeCompletionHandler != null)
      {
        _closeCompletionHandler.Complete(args as ClosedEventArgs);
        _closeCompletionHandler = null;
      }
    }
    /// <summary>
    /// Returns list of configured cluster nodes.
    /// </summary>
    public IList<WSConfig> NodesConfig
    {
      get
      {
        lock (SyncLock)
        {
          return _clusterNodes.Values.Select(node => node.WarmStandby.Configuration).ToList();
        }
      }
    }
    /// <summary>
    /// Configures new set of nodes by its endpoints. 
    /// All existed nodes that are absent in this set will be stopped in <see cref="AbstractClusterChannel.Timeout"/> interval.
    /// </summary>
    /// <param name="endpoints">Array of endpoints</param>
    public void SetNodesEndpoints(params Endpoint[] endpoints)
    {
      ThrowArgumentNull(endpoints, "endpoints");
      SetNodesEndpoints(endpoints.ToList());
    }
    /// <summary>
    /// Configures new set of nodes by its endpoints. 
    /// All existed nodes that are absent in this set will be stopped in <see cref="AbstractClusterChannel.Timeout"/> interval.
    /// </summary>
    /// <param name="endpoints">Sequence of endpoints</param>
    public void SetNodesEndpoints(IEnumerable<Endpoint> endpoints)
    {
      ThrowArgumentNull(endpoints, "endpoints");
      var list = endpoints as IList<Endpoint> ?? endpoints.ToList();
      ValidateEndpoints(list);
      SetNodes(list.Select(endpoint => new WSConfig(endpoint.Name).SetEndpoints(endpoint)).ToList());
    }
    /// <summary>
    /// Configures new set of nodes by its <see cref="WSConfig"/> configurations. 
    /// All existed nodes that are absent in this set will be stopped in <see cref="AbstractClusterChannel.Timeout"/> interval.
    /// </summary>
    /// <param name="nodesConfig">Array of <see cref="WSConfig"/> configurations.</param>
    public void SetNodes(params WSConfig[] nodesConfig)
    {
      ThrowArgumentNull(nodesConfig, "nodesConfig");
      SetNodes(nodesConfig.ToList());
    }
    /// <summary>
    /// Configures new set of nodes by its <see cref="WSConfig"/> configurations. 
    /// All existed nodes that are absent in this set will be stopped in <see cref="AbstractClusterChannel.Timeout"/> interval.
    /// </summary>
    /// <param name="nodesConfig">Sequence of <see cref="WSConfig"/> configurations.</param>
    public void SetNodes(IEnumerable<WSConfig> nodesConfig)
    {
      ThrowArgumentNull(nodesConfig, "nodesConfig");
      var list = nodesConfig as IList<WSConfig> ?? nodesConfig.ToList();
      ValidateWSConfigs(list);
      SetNodesImpl(list);
    }

    private void SetNodesImpl(IList<WSConfig> nodes)
    {
      lock (SyncLock)
      {
        List<WSConfig> nodesToAdd = null;
        Dictionary<string, WSConfig> nodes2Update = null;
        List<string> nodes2Remove = null;
        foreach (WSConfig nodeConfig in nodes)
        {
          var name = nodeConfig.Name;
          var existingItem = _clusterNodes.ContainsKey(name) ? _clusterNodes[name] : null;
          if (existingItem != null) // already exist node with such key
          {
            if (nodes2Update==null) nodes2Update = new Dictionary<string, WSConfig>();
            nodes2Update[name] = nodeConfig;
          }
          else
          {
            if (nodesToAdd == null) nodesToAdd = new List<WSConfig>();
            nodesToAdd.Add(nodeConfig);
          }
        }
        foreach (string nodeName in _clusterNodes.Keys)
        {
          if ((nodes2Update == null) || (!nodes2Update.ContainsKey(nodeName)))
          {
            if (nodes2Remove == null) nodes2Remove = new List<string>();
            nodes2Remove.Add(nodeName);
          }
        }
        if (nodesToAdd != null) AddNodes(nodesToAdd);
        if (nodes2Update != null)
        {
          foreach (KeyValuePair<string, WSConfig> pair in nodes2Update)
          {
            var node = _clusterNodes.ContainsKey(pair.Key) ? _clusterNodes[pair.Key] : null;
            if (node != null)
            {
              node.WarmStandby.Configuration = pair.Value;
            }
          }
        }
        if (nodes2Remove != null) RemoveNodes(nodes2Remove);
      }
    }

    /// <summary>
    /// Adds new nodes by its endpoints. 
    /// Nodes with the same names will be skipped.
    /// </summary>
    /// <param name="endpoints">Array of endpoints.</param>
    public void AddNodesEndpoints(params Endpoint[] endpoints)
    {
      ThrowArgumentNull(endpoints, "endpoints");
      AddNodesEndpoints(endpoints.ToList());
    }
    /// <summary>
    /// Adds new nodes by its endpoints. 
    /// Nodes with the same names will be skipped.
    /// </summary>
    /// <param name="endpoints">Sequence of endpoints.</param>
    public void AddNodesEndpoints(IEnumerable<Endpoint> endpoints)
    {
      ThrowArgumentNull(endpoints, "endpoints");
      var list = endpoints as IList<Endpoint> ?? endpoints.ToList();
      ValidateEndpoints(list);
      AddNodes(list.Select(endpoint => new WSConfig(endpoint.Name).SetEndpoints(endpoint)).ToList());
    }
    /// <summary>
    /// Adds new nodes by its <see cref="WSConfig"/> configurations. 
    /// Nodes with the same names will be skipped.
    /// </summary>
    /// <param name="nodesConfig">Array of <see cref="WSConfig"/> configurations.</param>
    public void AddNodes(params WSConfig[] nodesConfig)
    {
      ThrowArgumentNull(nodesConfig, "nodesConfig");
      AddNodes(nodesConfig.ToList());
    }
    /// <summary>
    /// Adds new nodes by its <see cref="WSConfig"/> configurations. 
    /// Nodes with the same names will be skipped.
    /// </summary>
    /// <param name="nodesConfig">Sequence of <see cref="WSConfig"/> configurations.</param>
    public void AddNodes(IEnumerable<WSConfig> nodesConfig)
    {
      ThrowArgumentNull(nodesConfig, "nodesConfig");
      var list = nodesConfig as IList<WSConfig> ?? nodesConfig.ToList();
      ValidateWSConfigs(list);
      lock (SyncLock)
      {
        foreach (WSConfig wsConfig in list)
        {
          if (wsConfig != null)
            AddSingleNode(wsConfig);
        }
      }
    }

    private void AddSingleNode(ClusterProtocolNodeImpl newItem, bool doOpen, string name, string logData)
    {
      _clusterNodes.Add(name, newItem);
      if (doOpen)
      {
        _openingClusterNodes.Add(newItem);
        this.DebugLog("{0} Opening new cluster node: {1}", LogObject, name);
        newItem.WarmStandby.BeginOpen(
          ar =>
            this.DebugLog("{0}: OpenAsync handler for node [ID={1}, {2}]", LogObject, newItem.WarmStandby.ID,
              newItem.WarmStandby.Channel.Endpoint), null);
        newItem.WarmStandby.AutoRestore(false);
      }
    }

    private void AddSingleNode(WSConfig wsConfig)
    {
      bool doOpen = (State == ChannelState.Opened) || (State == ChannelState.Opening);
      if (_clusterNodes.ContainsKey(wsConfig.Name))
      {
        this.WarnLog("{0} Failed to add new node to cluster: '{1}'. Cause: node already exists.", LogObject, wsConfig.Name);
        return;
      }
      var newItem = CreateProtocolNode(wsConfig);
      this.DebugLog("{0} Add new node to cluster: {1}", LogObject, wsConfig.Name);
      AddSingleNode(newItem, doOpen, wsConfig.Name, wsConfig.ToString());
    }
    /// <summary>
    /// Removes nodes by its name. 
    /// </summary>
    /// <param name="names">Array of names</param>
    public void RemoveNodes(params string[] names)
    {
      if (names == null) return;
      RemoveNodes(names.ToList());
    }
    /// <summary>
    /// Removes nodes by its name. 
    /// </summary>
    /// <param name="names">Sequence of names</param>
    public void RemoveNodes(IEnumerable<string> names)
    {
      if (names == null) return;
      foreach (string name in names)
      {
        if (name!=null)
          RemoveSingleNode(name);
      }
    }

    private void RemoveSingleNode(ClusterProtocolNodeImpl node)
    {
      lock (SyncLock)
      {
        _removingClusterNodes.Remove(node);
        _closingClusterNodes.Add(node);
      }
      node.WarmStandby.BeginClose(AsyncClosedHandler, node);
    }

    private void RemoveSingleNode(string endpoint)
    {
      ClusterProtocolNodeImpl node = null;
      bool doClose=false;
      lock(SyncLock)
      {
        if (_clusterNodes.ContainsKey(endpoint))
        {
          node = _clusterNodes[endpoint];
          _clusterNodes.Remove(endpoint);
          doClose = ((State == ChannelState.Opened) || (State == ChannelState.Opening));
          _openingClusterNodes.Remove(node);
          _openedClusterNodes.Remove(node);
          LoadBalancer.RemoveNode(node.Protocol);
          this.DebugLog("{0}: Remove node [ID={1}, {2}]", 
                LogObject, node.WarmStandby.ID, node.WarmStandby.Configuration.Name);
          //if (!doClose)
          //{
          //  _closingClusterNodes.Remove(node);
          //  if (_openedClusterNodes.Count + _openingClusterNodes.Count == 0)
          //    SetState(ChannelState.Closed, null);
          //}
        }
        if (doClose)
        {
          if (node.Protocol.State == ChannelState.Opened)
          {
            _removingClusterNodes.Add(node);
            if (node.SetCloseTimer(RemoveSingleNode, SyncLock)) return;
          }
          _removingClusterNodes.Remove(node);
          _closingClusterNodes.Add(node);
          node.WarmStandby.BeginClose(AsyncClosedHandler, node);
        }
      }
    }
    /// <summary>
    /// Returns the first available protocol. 
    /// Decision of availability of the protocol makes a load balancer.
    /// </summary>
    /// <returns><see cref="IProtocol"/> instance or null when there is no available protocols.</returns>
    public IProtocol GetNextAvailableProtocol()
    {
      return GetNextAvailableProtocol(null);
    }
    /// <summary>
    /// Returns the first available protocol for the given message. 
    /// Decision of availability of the protocol makes a load balancer.
    /// </summary>
    /// <param name="message">message associated with channel.</param>
    /// <returns><see cref="IProtocol"/> instance or null when there is no available protocols.</returns>
    public IProtocol GetNextAvailableProtocol(IMessage message)
    {
      if (LoadBalancer == null) return null;
      return LoadBalancer.ChooseNode(message);
    }
    /// <summary>
    /// Returns the protocol by its <see cref="IProtocol.ProtocolId"/>. 
    /// </summary>
    /// <param name="protocolId"><see cref="IProtocol.ProtocolId"/></param>
    /// <returns><see cref="IProtocol"/> instance or null when there is no available protocols.</returns>
    public IProtocol GetNodeProtocol(int protocolId)
    {
      var node = _clusterNodes.Values.FirstOrDefault(impl => impl.Protocol.ProtocolId == protocolId);
      if (node == null) return null;
      return node.Protocol;
    }
    /// <summary>
    /// Returns the protocol by its name. 
    /// </summary>
    /// <param name="name">Name of node.</param>
    /// <returns><see cref="IProtocol"/> instance or null when there is no available protocols.</returns>
    public IProtocol GetNodeProtocol(string name)
    {
      if (name==null) return null;
      if (!_clusterNodes.ContainsKey(name)) return null;
      var node = _clusterNodes[name];
      if (node == null) return null;
      return node.Protocol;
    }
    /// <summary>
    /// Returns the list of opened protocols.
    /// </summary>
    public IList<IProtocol> OpenedNodesProtocols
    {
      get
      {
        lock (SyncLock)
        {
          return _openedClusterNodes.Select(node => node.Protocol).ToList();
        }
      }
    }
    /// <summary>
    /// Returns the list of all configured protocols.
    /// </summary>
    public IList<IProtocol> AllNodesProtocols
    {
      get
      {
        lock (SyncLock)
        {
          var result = new List<IProtocol>();
          if ((_clusterNodes != null) && (_clusterNodes.Count > 0))
          {
            foreach (ClusterProtocolNodeImpl node in _clusterNodes.Values)
            {
              if (node.Protocol == null) continue;
              result.Add(node.Protocol);
            }
          }
          return result;
          //return _clusterNodes.Select(node => node.Value.Protocol).ToList();
        }
        
      }
    }

    #endregion Cluster API implementation
    #region utility

    /// <summary>
    /// Creates instance of protocol class.
    /// </summary>
    /// <returns>instance of protocol class</returns>
    protected virtual TProtocol CreateProtocol()
    {
      return _protocolBuilder.Build();
    }

    private ClusterProtocolNodeImpl CreateProtocolNode(WSConfig wsConfig)
    {
      var protocol = CreateProtocol();
      if ((protocol.Endpoint==null) || (protocol.Endpoint.IsUndefined))
      {
        var endpoints = wsConfig.Endpoints;
        var endpoint = (endpoints != null) ? endpoints.FirstOrDefault() : null;
        if (endpoint != null) 
          protocol.Endpoint = endpoint;
      }
      var ws = new WarmStandby(wsConfig.Name, protocol) { Configuration = wsConfig };
      if (Logger != null)
      {
        ws.EnableLogging(Logger.CreateChildLogger("ClusterNode.Service"));
        protocol.EnableLogging(Logger.CreateChildLogger("ClusterNode.Channel"));
      }
      var protocolNode = new ClusterProtocolNodeImpl(ws);
      SetupProtocolNode(protocolNode);
      return protocolNode;
    }

    private void ValidateEndpoints(IEnumerable<Endpoint> endpoints)
    {
      ThrowArgumentNull(endpoints, "endpoints");
      var names = new HashSet<string>();
      foreach (Endpoint endpoint in endpoints)
      {
        ThrowNull(endpoint, "endpoint");
        var name = endpoint.Name;
        if (String.IsNullOrEmpty(name))
          throw new ArgumentException("Endpoint does not contain name");
        if (names.Contains(name))
          throw new ArgumentException("Given Endpoint's set contains duplicated names (" + name + ")");
        names.Add(name);
      }
    }
    private void ValidateWSConfigs(IEnumerable<WSConfig> nodes)
    {
      ThrowArgumentNull(nodes, "nodes");
      var names = new HashSet<string>();
      foreach (WSConfig node in nodes)
      {
        ThrowNull(node, "node");
        var name = node.Name;
        var endpoints = node.Endpoints;
        if ((endpoints == null) || (endpoints.Count == 0))
          throw new ArgumentException("WSConfig does not contain Endpoints");
        if (String.IsNullOrEmpty(name))
          throw new ArgumentException("WSConfig does not contain name");
        if (names.Contains(name))
          throw new ArgumentException("Given WSConfig's set contains duplicated names (" + name + ")");
        names.Add(name);
      }
    }
    private void ThrowNotClosed()
    {
      lock (SyncLock)
      {
        if (State != ChannelState.Closed)
          throw new ChannelNotClosedException("Operation is not supported when cluster is not closed.");
      }
    }

    private void ThrowEmptyNodes()
    {
      if (_clusterNodes.Count==0)
        throw new InvalidOperationException("No cluster nodes initialized");
    }
    private void ThrowArgumentNull(Object reference, string paramName)
    {
      if (reference==null)
        throw new ArgumentNullException(paramName);
    }
    private void ThrowNull(Object reference, string paramName)
    {
      if (reference == null)
        throw new ArgumentException(paramName);
    }
    /// <summary>
    /// Returns string representation of object. 
    /// </summary>
    protected override String LogObject
    {
      get { return String.Format("[ClusterProtocol({0})<{1}>]", UniqueObjectId,_clusterNodes.Count); }
    }
    internal virtual void SetupProtocolNode(IClusterProtocolNode protocolItem)
    {
      var node = protocolItem as ClusterProtocolNodeImpl;
      if (node != null)
      {
        node.WarmStandby.ChannelOpened += WarmStandbyOnChannelOpened;
        node.WarmStandby.ChannelDisconnected += WarmStandbyOnChannelDisconnected;
        var protocol = node.WarmStandby.Channel;
        protocol.Timeout = Timeout;
        SetProtocolInvoker(protocol);
        //protocol.Invoker = GetInvoker();
        protocol.Received += OnChannelMessage;
        protocol.Error += OnChannelError;
        protocol.CopyResponse = CopyResponse;
      }
    }

    private void SetProtocolInvoker(ClientChannel protocol)
    {
      protocol.Invoker = GetInvoker();
    }

    private void NotifyChannelClosedEvent(object sender, EventArgs eventArgs)
    {
      var ceArgs = eventArgs as ClosedEventArgs;
      if (ceArgs != null)
        this.DebugLog("{0}: Internal channel closed: {1}", LogObject, ceArgs.Endpoint);
      FireInternalChannelClosed(sender, eventArgs);
    }

    private void WarmStandbyOnChannelDisconnected(object sender, EventArgs eventArgs)
    {
      var ws = sender as WarmStandby;
      if (ws == null) return;
      var wsArgs = eventArgs as WSClosedEvent;
      if (wsArgs == null) return;
      lock (SyncLock)
      {
        this.DebugLog("{0}: Node disconnected [ID={1}]", LogObject, ws.ID);
        var node = _clusterNodes.Values.FirstOrDefault(impl => impl.WarmStandby.ID == ws.ID);
        if (node != null)
        {
          _openedClusterNodes.Remove(node);
          _closingClusterNodes.Remove(node);
          LoadBalancer.RemoveNode(node.Protocol);
          node.OnClosed(() => NotifyChannelClosedEvent(node.WarmStandby.Channel, eventArgs));
          if ((State == ChannelState.Opened) || (State == ChannelState.Opening))
          {
            _openingClusterNodes.Add(node);
            if (_openedClusterNodes.Count == 0)
              SetState(ChannelState.Opening, wsArgs.Cause);
          }
          else
          {
            _openingClusterNodes.Remove(node);
            if (_openedClusterNodes.Count + _openingClusterNodes.Count + _closingClusterNodes.Count == 0)
            {
              SetState(ChannelState.Closed, wsArgs.Cause);
              LoadBalancer.ClearNodes();
            }
          }
        }
      }
    }

    private void WarmStandbyOnChannelOpened(object sender, EventArgs eventArgs)
    {
      lock (SyncLock)
      {
        var ws = sender as WarmStandby;
        var wsArgs = eventArgs as WSOpenedEvent;
        if (wsArgs != null)
        {
          this.DebugLog("[WarmStandbyOnChannelOpened] with cause: {0}",
            wsArgs.OpenedEvent.Cause == null ? "<OK>" : wsArgs.OpenedEvent.Cause.ToString());
        }
        if (ws != null)
        {
          var node = _clusterNodes.Values.FirstOrDefault(impl => impl.WarmStandby.ID == ws.ID);
          if (node != null)
          {
            if ((State == ChannelState.Closing) || (State == ChannelState.Closed))
            {
              this.DebugLog("{0}: Node disconnecting... [ID={1}, {2}]", LogObject, ws.ID, ws.Channel.Endpoint);
              _openingClusterNodes.Remove(node);
              _openingClusterNodes.Remove(node);
              _closingClusterNodes.Add(node);
              ThreadPool.QueueUserWorkItem(state => node.WarmStandby.BeginClose(AsyncClosedHandler, node));
              return;
            }
            this.DebugLog("{0}: Node connected [ID={1}, {2}]", LogObject, ws.ID, ws.Channel.Endpoint);
            _openingClusterNodes.Remove(node);
            _openedClusterNodes.Add(node);
            LoadBalancer.AddNode(node.Protocol);
            SetState(ChannelState.Opened, wsArgs==null?null:wsArgs.OpenedEvent.Cause);
            this.DebugLog("{0}: Internal channel opened: {1}", LogObject, ws.Channel.Endpoint);
            node.OnOpened(
              () =>
                FireInternalChannelOpened(ws.Channel,
                  new OpenedEventArgs(wsArgs == null ? null : wsArgs.OpenedEvent.Cause, node.Protocol.Endpoint)));
          }
        }
      }
    }

    private void OnChannelMessage(object sender, EventArgs arg)
    {
      FireReceived(arg);
    }
    private void OnChannelError(object sender, EventArgs arg)
    {
      FireError(arg);
    }
    #endregion utility
  }
}

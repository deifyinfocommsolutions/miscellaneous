//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using System;
using System.Collections.Generic;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.ClusterProtocol
{
  /// <summary>
  /// Interface representing a client protocol connection on top of encapsulated 
  /// multiple protocol connections to a cluster of similarly configured servers.
  ///  </summary>
  public interface IClusterProtocol : IProtocol, IRequestChannelEx
  {
    /// <summary>
    /// Returns policy of cluster protocol.
    /// </summary>
    IClusterProtocolPolicy ClusterProtocolPolicy { get; }

    /// <summary>
    /// Starts connections in accordance to the HA strategy options.<br/>
    /// The completion handler will be notified by the first connection open event.
    /// </summary>
    /// <param name="handler">the completion handler to be notified with the operation result.</param>
    void OpenAsync(EventHandler<OpenedEventArgs> handler);
    /// <summary>
    /// Starts closing all cluster's connections.<br/>
    /// The completion handler will be notified by the last connection close event.
    /// </summary>
    /// <param name="handler">the completion handler to be notified with the operation result.</param>
    void CloseAsync(EventHandler<ClosedEventArgs> handler);

    /// <summary>
    /// Sets the protocols endpoints array.
    /// </summary>
    /// <param name="endpoints">the endpoints array</param>
    void SetNodesEndpoints(params Endpoint[] endpoints);
    /// <summary>
    /// Sets the protocols endpoints list.
    /// </summary>
    /// <param name="endpoints">the endpoints list</param>
    void SetNodesEndpoints(IEnumerable<Endpoint> endpoints);
    /// <summary>
    /// Sets the protocols nodes configuration array.
    /// </summary>
    /// <param name="nodesConfig">the nodes configuration array</param>
    void SetNodes(params WSConfig[] nodesConfig);
    /// <summary>
    /// Sets the protocols nodes configuration list.
    /// </summary>
    /// <param name="nodesConfig">the nodes configuration list</param>
    void SetNodes(IEnumerable<WSConfig> nodesConfig);

    /// <summary>
    /// Returns list of the configured servers cluster endpoints.
    /// </summary>
    /// <returns>list of the configured servers cluster endpoints.</returns>
    IList<WSConfig> NodesConfig { get; }

    /// <summary>
    /// Append new endpoint to the list of the configured servers cluster endpoints.
    /// </summary>
    /// <param name="endpoints">Endpoints to be added into the list of the configured servers cluster endpoints</param>
    void AddNodesEndpoints(params Endpoint[] endpoints);
    /// <summary>
    /// Append new endpoint to the list of the configured servers cluster endpoints.
    /// </summary>
    /// <param name="endpoints">Endpoints to be added into the list of the configured servers cluster endpoints</param>
    void AddNodesEndpoints(IEnumerable<Endpoint> endpoints);
    /// <summary>
    /// Append new nodes configuration to the list of the configured servers cluster endpoints.
    /// </summary>
    /// <param name="endpoints">Nodes configuration to be added into the list of the configured servers cluster endpoints</param>
    void AddNodes(params WSConfig[] endpoints);
    /// <summary>
    /// Append new nodes configuration  to the list of the configured servers cluster endpoints.
    /// </summary>
    /// <param name="endpoints">Nodes configuration to be added into the list of the configured servers cluster endpoints</param>
    void AddNodes(IEnumerable<WSConfig> endpoints);

    /// <summary>
    /// Remove node from the list of the configured servers cluster nodes.
    /// </summary>
    /// <param name="names">Names of endpoints to be removed from the list of the configured servers cluster endpoints</param>
    void RemoveNodes(params string[] names);
    /// <summary>
    /// Remove endpoint to the list of the configured servers cluster endpoints.
    /// </summary>
    /// <param name="names">Names of endpoints to be removed from the list of the configured servers cluster endpoints</param>
    void RemoveNodes(IEnumerable<string> names);


    /// <summary>
    /// Returns reference to some opened instance of protocol in the encapsulated pool
    /// in accordance to the LB strategy.
    /// </summary>
    /// <returns>reference to a wrapped protocol instance.</returns>
    IProtocol GetNextAvailableProtocol();
    /// <summary>
    /// Returns reference to some opened instance of protocol in the encapsulated pool
    /// in accordance to the LB strategy.
    /// </summary>
    /// <param name="message">The user message to be sent</param>
    /// <returns>reference to a wrapped protocol instance.</returns>
    IProtocol GetNextAvailableProtocol(IMessage message);

    /// <summary>
    /// Returns reference to some opened instance of protocol in the encapsulated pool by its protocol Id.
    /// </summary>
    /// <param name="protocolId">Id of protocol</param>
    /// <returns>reference to a protocol instance</returns>
    IProtocol GetNodeProtocol(int protocolId);

    /// <summary>
    /// Returns reference to some opened instance of protocol in the encapsulated pool by its Endpoint.
    /// </summary>
    /// <param name="name">requested Endpoint's name</param>
    /// <returns>reference to a protocol instance</returns>
    IProtocol GetNodeProtocol(string name);
    /// <summary>
    /// Returns collection of all opened instances of protocol
    /// </summary>
    IList<IProtocol> OpenedNodesProtocols { get; }
    /// <summary>
    /// Returns collection of all configured instances of protocol
    /// </summary>
    IList<IProtocol> AllNodesProtocols { get; }
  }

  /// <summary>
  /// Describes policies flags.
  /// </summary>
  public interface IClusterProtocolPolicy
  {
    /// <summary>
    /// Flas indicates that method Send will wait for first connected protocol.
    /// </summary>
    bool WaitOnChannelOpening { get; }
    /// <summary>
    /// Tries to use protocol with requested Protocol Id
    /// </summary>
    bool UseRequestProtocolId { get; }
  }
}

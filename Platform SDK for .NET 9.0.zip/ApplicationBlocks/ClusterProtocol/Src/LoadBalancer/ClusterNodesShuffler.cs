//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Standby;
using Genesyslab.Security;

namespace Genesyslab.Platform.ClusterProtocol.LoadBalancer
{
  /// <summary>
  /// Helper component for doing cluster load balancing from client type applications.
  /// It allows applications to work with servers cluster without creation of live connections to all of its nodes.<br/>
  /// This option may be critical in case of tens of thousands clients.
  /// <para>
  /// This component uses existing functionality of ClusterProtocol to update its nodes configuration.
  /// ClusterProtocol allows dynamic change of nodes configuration:
  /// <list type="bullet">
  /// <item>
  /// Newly added nodes will get new instance of usual PSDK protocol class.
  /// And its asynchronous open will be started. Node will be added to the load balancer right after its connection.
  /// </item>
  /// <item>
  /// Removed nodes will be immediately excluded from the load balancer, and scheduled for closing
  /// after its protocol timeout delay. It will help with delivery of responses on already started requests.
  /// </item>
  /// </list>
  /// </para>
  /// The randomizer component will have optional ability to attach truncated nodes' endpoints
  /// as backup endpoints for selected ones. It will allow internal WarmStandby service to "switch over"
  /// unresponsive node faster.
  /// </summary>
  public class ClusterNodesShuffler:ITimerAction
  {
    private readonly IClusterProtocol _cluster;
    private readonly int _activeNodes;
    private readonly List<WSConfig> _clusterNodes = new List<WSConfig>();
    private static readonly SecureRandom Randomizer = new SecureRandom();

    /// <summary>
    /// Creates nodes shuffler for the given Cluster Protocol instance.
    /// </summary>
    /// <param name="cluster">the cluster protocol reference.</param>
    /// <param name="nodes">number of active cluster nodes to pass to the protocol.</param>
    public ClusterNodesShuffler(IClusterProtocol cluster, int nodes)
    {
      UseBackups = true;
      _cluster = cluster;
      _activeNodes = nodes;
    }

    /// <summary>
    /// Enables or disables adding to the selected nodes other ones endpoints as backups.
    /// If its enabled, it allows internal WarmStandby service to work around unresponsive nodes
    /// without waiting for a next rotation(s).<br/>
    /// Its enabled by default.
    /// </summary>
    public bool UseBackups { get; set; }
    /// <summary>
    /// Sets the collection of <see cref="WSConfig"/> nodes.
    /// </summary>
    /// <param name="nodes">Collection of <see cref="WSConfig"/> nodes.</param>
    public void SetNodes(ICollection<WSConfig> nodes)
    {
      lock (_clusterNodes)
      {
        _clusterNodes.Clear();
        if (nodes != null)
        {
          _clusterNodes.AddRange(nodes);
          Shuffle(_clusterNodes);
        }
        SetActiveNodes();
      }
    }

    /// <summary>
    /// Combines "active nodes" list and passes it to the cluster protocol for appliance.
    /// </summary>
    protected void SetActiveNodes()
    {
      List<WSConfig> list = _clusterNodes.GetRange(0, Math.Min(_activeNodes, _clusterNodes.Count));
      int listSize = list.Count;
      if (UseBackups && listSize > 0)
      {
        for (int i = listSize; i < _clusterNodes.Count; i++)
        {
          int pos = i%listSize;
          WSConfig item = list[pos];
          if (i < 2*listSize)
          {
            item = (WSConfig) item.Clone();
          }
          foreach (var endpoint in _clusterNodes[i].Endpoints)
          {
            item.Endpoints.Add(endpoint);
          }
          list[pos] = item;
        }
      }
      _cluster.SetNodes(list);
    }
    /// <summary>
    /// Performs single rotation of the selected cluster nodes.<br/>
    /// This operation is designed to be executed as periodical task <see cref="ITimerAction"/> though, 
    /// may be used directly in case of application specific needs.
    /// </summary>
    public void RotateNodes()
    {
      lock (_clusterNodes)
      {
        // Rotate the shuffled list by one node:
        if (_clusterNodes.Count > 1)
        {
          _clusterNodes.Add(_clusterNodes[0]);
          _clusterNodes.RemoveAt(0);
        }
        SetActiveNodes();
      }
    }

    #region utils

    private static void Shuffle(IList<WSConfig> list)
    {
      if ((list != null) && (list.Count != 0))
      {
        int count = list.Count;
        for (int i = count; i > 0; i--)
        {
          int index = Randomizer.Next(i);
          var item = list[index];
          list.RemoveAt(index);
          list.Add(item);
        }
      }
    }

    #endregion utils
    #region interface members
    /// <summary>
    /// Performs single rotation of the selected cluster nodes.
    /// <seealso cref="RotateNodes"/>
    /// </summary>
    void ITimerAction.OnTimer()
    {
      RotateNodes();
    }

    private readonly IScheduler _scheduler = TimerFactory.Scheduler;
    private ITimerActionTicket _ticket;
    /// <summary>
    /// Starts periodical shuffling of cluster nodes
    /// </summary>
    /// <param name="delay">value of delay (milliseconds) before the first start</param>
    /// <param name="interval">interval between shufflings</param>
    public void StartTimer(int delay, int interval)
    {
      lock (_clusterNodes)
      {
        if (_ticket!=null) _ticket.Cancel();
        _ticket = _scheduler.Schedule(delay, interval, this);
      }
    }
    /// <summary>
    /// Stops periodical shuffling of cluster nodes
    /// </summary>
    public void StopTimer()
    {
      lock (_clusterNodes)
      {
        if (_ticket != null) _ticket.Cancel();
        _ticket = null;
      }
    }
    #endregion interface members

  }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ClusterProtocol.LoadBalancer
{
  /// <summary>
  /// Common interface for Cluster Protocol Load Balancer component.<br/>
  /// It allows user applications to implement custom load balancing strategies.
  /// </summary>
  public interface IClusterProtocolLoadBalancer
  {
    /// <summary>
    /// This method is to choose and apply load balancer specific options
    /// from the cluster connection configuration.
    /// </summary>
    /// <param name="configuration">connection configuration from the Cluster Protocol base Endpoint.</param>
    void Configure(IConnectionConfiguration configuration);
    /// <summary>
    /// This method is to apply load balancing strategy on available cluster nodes.
    /// </summary>
    /// <param name="message">user specified protocol message for sending or null.</param>
    /// <returns>selected cluster protocol node.</returns>
    IProtocol ChooseNode(IMessage message);
    /// <summary>
    /// This method is to add just connected Cluster Protocol Node to load balancing strategy.
    /// </summary>
    /// <param name="node">cluster protocol node.</param>
    void AddNode(IProtocol node);
    /// <summary>
    /// This method is to remove Cluster Protocol Node from load balancing strategy.<br/>
    /// Its called when node is removed from the cluster, or its protocol connection is lost.
    /// </summary>
    /// <param name="node">cluster protocol node.</param>
    /// <returns>true if node is removed, otherwise false.</returns>
    bool RemoveNode(IProtocol node);
    /// <summary>
    /// This method is called when Cluster Protocol is being closed.
    /// </summary>
    void ClearNodes();
  }

}

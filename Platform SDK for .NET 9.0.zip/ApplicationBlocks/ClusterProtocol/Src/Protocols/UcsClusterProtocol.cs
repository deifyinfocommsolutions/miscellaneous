//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using Genesyslab.Platform.ClusterProtocol.LoadBalancer;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Protocols.Custom;
using Genesyslab.Platform.Contacts.Protocols;

namespace Genesyslab.Platform.ClusterProtocol.Protocols
{
  /// <summary>
  /// Protocol builder for <see cref="UniversalContactServerProtocol"/>.
  /// </summary>
  public class UcsProtocolBuilder : ProtocolBuilder<UniversalContactServerProtocol, UcsProtocolBuilder>
  {
    /// <summary>
    /// Returns <see cref="ProtocolDescription"/>.
    /// </summary>
    public override ProtocolDescription Description
    {
      get { return UniversalContactServerProtocol.Description; }
    }
    /// <summary>
    /// Creates <see cref="UniversalContactServerProtocol"/> instance.
    /// </summary>
    /// <returns>The <see cref="UniversalContactServerProtocol"/> instance</returns>
    protected override UniversalContactServerProtocol CreateProtocol()
    {
      return new UniversalContactServerProtocol(null, ReferenceBuilder);
    }
  }
  /// <summary>
  /// Cluster protocol builder for <see cref="UcsClusterProtocol"/>.
  /// </summary>
  public class UcsClusterProtocolBuilder : ClusterProtocolBuilder<UcsClusterProtocol, UniversalContactServerProtocol, UcsProtocolBuilder, UcsClusterProtocolBuilder>
  {
    /// <summary>
    /// Creates <see cref="UcsClusterProtocol"/> instance.
    /// </summary>
    /// <returns>The <see cref="UcsClusterProtocol"/> instance.</returns>
    public override UcsClusterProtocol Build()
    {
      return new UcsClusterProtocol(ProtocolBuilder, ProtocolPolicy, LoadBalancer);
    }
  }

  /// <summary>
  /// Implementation of <see cref="IClusterProtocol"/> for <see cref="UniversalContactServerProtocol"/>.
  /// </summary>
  public class UcsClusterProtocol : ClusterProtocolImpl<UniversalContactServerProtocol, UcsProtocolBuilder>,
    IUniversalContactServerProtocolHandshakeOptions, IRequestorInfoSupport
  {

    internal UcsClusterProtocol(
            ProtocolBuilder<UniversalContactServerProtocol, UcsProtocolBuilder> protoBuilder,
            IClusterProtocolPolicy protocolPolicy,
            IClusterProtocolLoadBalancer loadBalancer) 
        :base( protoBuilder ?? new UcsProtocolBuilder(), protocolPolicy, loadBalancer)
    {
    }

    /// <summary>
    /// Gets/Sets client name for the handshake procedure.
    /// </summary>
    public string ClientName { get; set; }
    /// <summary>
    /// Gets/Sets client application type for the handshake procedure.
    /// </summary>
    public string ClientApplicationType { get; set; }
    /// <summary>
    /// Creates instance of <see cref="UniversalContactServerProtocol"/> class.
    /// </summary>
    /// <returns>Instance of <see cref="UniversalContactServerProtocol"/> class.</returns>
    protected override UniversalContactServerProtocol CreateProtocol()
    {
      var protocol = base.CreateProtocol();
      protocol.ClientName = ClientName;
      protocol.ClientApplicationType = ClientApplicationType;
      if (RequestorInfo != null)
        protocol.RequestorInfo = RequestorInfo;
      return protocol;
    }
    private RequestorInfo _requestorInfo;
    /// <summary>
    /// Gets/Sets additional requestor information.  See <see cref="RequestorInfo"/>.
    /// </summary>
    public RequestorInfo RequestorInfo
    {
      get { return _requestorInfo; }
      set
      {
        _requestorInfo = value;
        foreach (IProtocol protocol in AllNodesProtocols)
        {
          var riSupport = protocol as IRequestorInfoSupport;
          if (riSupport == null) continue;
          riSupport.RequestorInfo = _requestorInfo;
        }
      }
    }
  }
}

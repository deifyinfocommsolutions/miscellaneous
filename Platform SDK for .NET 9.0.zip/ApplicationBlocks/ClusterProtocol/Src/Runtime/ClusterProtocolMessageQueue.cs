//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using Genesyslab.Platform.ClusterProtocol.LoadBalancer;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ClusterProtocol.Runtime
{
  #region MessageQueue

  internal abstract class AbstractMessageQueueItem : AbstractLogEnabled, ITimerAction
  {
    private static IScheduler Scheduler = TimerFactory.Scheduler;
    public IMessage Message { get; private set; }

    public int? Timeout
    {
      get
      {
        if ((_timeout == null) || (_stopwatch == null)) return null;
        return (int)(_timeout.Value - _stopwatch.ElapsedMilliseconds);
      }
    }

    private readonly ITimerActionTicket _timerActionTicket;
    public Exception Cause { get; private set; }
    private readonly int? _timeout;
    private readonly Stopwatch _stopwatch;

    public AbstractMessageQueueItem(IMessage message, int? timeout)
    {
      Message = message;
      _timeout = timeout;
      if ((timeout != null) && (timeout.Value >= 0))
      {
        _stopwatch = Stopwatch.StartNew();
        _timerActionTicket = Scheduler.Schedule(timeout.Value <= 1 ? 1 : timeout.Value, this);
      }
    }
    public void OnTimer()
    {
      lock (this)
      {
        _timerActionTicket.Cancel();
        Failed(new OperationCanceledException());
      }
    }

    public void Completed(IProtocol protocol)
    {
        OnCompleted(protocol);
    }
    public virtual void Failed(Exception exception)
    {
      Cause = exception;
      lock (this)
      {
        OnFailed();
      }
    }

    public abstract void OnFailed();
    public abstract void OnCompleted(IProtocol protocol);

    protected IProtocol GetProtocol(IClusterProtocolLoadBalancer loadBalancer)
    {
      var clusterNode = loadBalancer.ChooseNode(null);
      if (clusterNode == null) return null;
      return clusterNode.Protocol;
    }
  }

  internal class SendMessageQueueItem : AbstractMessageQueueItem
  {
    public SendMessageQueueItem(IMessage message, int? timeout)
      : base(message, timeout)
    {
    }
    public override void OnFailed() { }
    public override void OnCompleted(IProtocol protocol)
    {
      try
      {
        protocol.Send(Message);
      }
      catch (Exception e)
      {
        Failed(e);
      }
    }
  }

  internal class RequestMessageQueueItem : AbstractMessageQueueItem, IAsyncResult
  {
    public IMessage Response { get; private set; }
    public AsyncCallback Callback { get; private set; }
    public RequestMessageQueueItem(IMessage message, int? timeout,
      AsyncCallback callback, object state)
      : base(message, timeout)
    {
      Callback = callback;
      AsyncState = state;
      AsyncWaitHandle = new ManualResetEvent(false);
    }

    public override void OnFailed()
    {
    }

    public override void OnCompleted(IProtocol protocol)
    {
      try
      {
        int? timeout = Timeout;
        if (timeout == null)
        {
          Response = protocol.Request(Message);
        }
        else
        {
          Response = protocol.Request(Message, TimeSpan.FromMilliseconds(timeout.Value));
        }
      }
      catch (Exception e)
      {
        Failed(e);
      }
    }

    public bool IsCompleted { get; private set; }
    public WaitHandle AsyncWaitHandle { get; private set; }
    public object AsyncState { get; private set; }
    public bool CompletedSynchronously { get; private set; }
  }
  #endregion MessageQueue
  internal class ClusterProtocolMessageQueue
  {
    private readonly Queue<AbstractMessageQueueItem> _items = new Queue<AbstractMessageQueueItem>();
    private AbstractMessageQueueItem _pushedBackMessageItem;
    public void Push(AbstractMessageQueueItem item)
    {
      if (item != null)
      {
        lock (_items)
        {
          _items.Enqueue(item);
        }
      }
    }
    public void PushBack(AbstractMessageQueueItem item)
    {
      if (item != null)
      {
        lock (_items)
        {
          if (_pushedBackMessageItem != null)
            throw new InvalidOperationException("Can't push the message back");
          _pushedBackMessageItem = item;
        }
      }
    }

    public AbstractMessageQueueItem Get()
    {
      lock (_items)
      {
        var item = _pushedBackMessageItem;
        _pushedBackMessageItem = null;
        if (item != null) return item;
        if (_items.Count==0) return null;
        return _items.Dequeue();
      }
    }
  }
}

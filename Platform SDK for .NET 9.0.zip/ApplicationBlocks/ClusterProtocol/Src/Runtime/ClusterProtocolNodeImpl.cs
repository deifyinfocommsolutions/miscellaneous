//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using System;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ClusterProtocol.Runtime
{
  internal interface IClusterProtocolNode
  {
    IProtocol Protocol { get; }
  }

  internal class ClusterProtocolNodeImpl : IClusterProtocolNode, ITimerAction
  {
    internal delegate void RemoveNodeDelegate(ClusterProtocolNodeImpl node);
    private static readonly IScheduler Scheduler = TimerFactory.Scheduler;
    private readonly Standby.WarmStandby _warmStandby;
    private readonly ProtocolInstanceWrapper _protocolWrapper;
    private volatile bool _shouldNotifyClosedEvent;

    internal void OnOpened(Action action)
    {
      _shouldNotifyClosedEvent = true;
      if (action != null)
        action();
    }

    internal void OnClosed(Action action)
    {
      if (!_shouldNotifyClosedEvent) return;
      _shouldNotifyClosedEvent = false;
      if (action != null)
        action();
    }

    public ClusterProtocolNodeImpl(Standby.WarmStandby warmStandby)
    {
      if (warmStandby==null)
        throw new ArgumentNullException("warmStandby");
      _warmStandby = warmStandby;
      _protocolWrapper = new ProtocolInstanceWrapper(_warmStandby.Channel);
    }
    public Standby.WarmStandby WarmStandby { get { return _warmStandby; } }
    public IProtocol Protocol { get { return _protocolWrapper; } }

    public override int GetHashCode()
    {
      return GetType().GetHashCode() ^ (17*_warmStandby.ID) ^ (31*_protocolWrapper.ProtocolId);
    }

    public void OnTimer()
    {
      ITimerActionTicket ticket;
      lock (_syncObj)
      {
        ticket = _closeTimerTicket;
        _closeTimerTicket = null;
      }
      if (ticket==null) return;
      ticket.Cancel();
      if (_removeNodeDelegate != null) _removeNodeDelegate(this);
    }

    public override bool Equals(object obj)
    {
      if (ReferenceEquals(this, obj)) return true;
      var item = obj as ClusterProtocolNodeImpl;
      if (item == null) return false;
      if (item._warmStandby.ID!=_warmStandby.ID) return false;
      if (item._protocolWrapper.ProtocolId != _protocolWrapper.ProtocolId) return false;
      return true;
    }

    private ITimerActionTicket _closeTimerTicket;
    private RemoveNodeDelegate _removeNodeDelegate;
    private object _syncObj;
    public bool SetCloseTimer(RemoveNodeDelegate callback, object sync)
    {
      if (_closeTimerTicket == null)
      {
        TimeSpan? closeDelay=null;
        if (_protocolWrapper.LastRequestTimeStamp != null) 
        {
          var diff = DateTime.Now - _protocolWrapper.LastRequestTimeStamp.Value;
          if ((long)diff.TotalMilliseconds > 1) closeDelay = diff;
        }
        if ((closeDelay == null) || ((long)closeDelay.Value.TotalMilliseconds <= 0)) return false;
        _removeNodeDelegate = callback;
        _syncObj = sync;
        _closeTimerTicket = Scheduler.Schedule((long) closeDelay.Value.TotalMilliseconds, this);
      }
      return true;
    }

    internal void CancelCloseSchedule()
    {
      if (_closeTimerTicket != null)
      {
        _closeTimerTicket.Cancel();
        _closeTimerTicket = null;
      }
    }

  }
}

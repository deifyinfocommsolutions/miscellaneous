//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using System;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Protocols.Custom;
using Genesyslab.Platform.Commons.Threading;

namespace Genesyslab.Platform.ClusterProtocol.Runtime
{
  internal class ProtocolInstanceWrapper: AbstractLogEnabled, IProtocol,IRequestChannelEx, IRequestorInfoSupport
  {
    private void ThrowNull(Object reference, string parameter)
    {
      if (reference == null)
        throw new ArgumentNullException(parameter);
    }
    private readonly IProtocol _innerInstance;
    internal ProtocolInstanceWrapper(IProtocol innerInstance)
    {
      ThrowNull(innerInstance, "innerInstance");
      _innerInstance = innerInstance;
    }
    private void ThrowUnsupportedException()
    {
      throw new NotSupportedException("This operation is unsupported for the protocol wrapper instance.");
    }

    protected override void OnEnableLogging(ILogger logger)
    {
      base.OnEnableLogging(logger);
      if (logger != null)
      {
        var ale = _innerInstance as AbstractLogEnabled;
        if (ale!=null) ale.EnableLogging(logger);
      }
    }

    internal DateTime? LastRequestTimeStamp;
    public ChannelState State { get { return _innerInstance.State; } }
    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public void BeginOpen()
    {
      ThrowUnsupportedException();
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public void BeginClose()
    {
      ThrowUnsupportedException();
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    /// <exception cref="ArgumentNullException">If value is null.</exception>
    public event EventHandler Opened
    {
      add{ ThrowNull(value,"value"); ThrowUnsupportedException(); }
      remove { ThrowNull(value, "value"); ThrowUnsupportedException(); }
    }
    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    /// <exception cref="ArgumentNullException">If value is null.</exception>
    public event EventHandler Closed
    {
      add { ThrowNull(value, "value"); ThrowUnsupportedException(); }
      remove { ThrowNull(value, "value"); ThrowUnsupportedException(); }
    }
    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    /// <exception cref="ArgumentNullException">If value is null.</exception>
    public event EventHandler Error
    {
      add { ThrowNull(value,"value"); ThrowUnsupportedException(); }
      remove { ThrowNull(value, "value"); ThrowUnsupportedException(); }
    }
    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public void Open()
    {
      ThrowUnsupportedException();
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public void Close()
    {
      ThrowUnsupportedException();
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public void Open(TimeSpan timeout)
    {
      ThrowUnsupportedException();
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public void Close(TimeSpan timeout)
    {
      ThrowUnsupportedException();
    }

    public TimeSpan Timeout { get { return _innerInstance.Timeout; } set { _innerInstance.Timeout = value; } }
    public void Send(IMessage message)
    {
      LastRequestTimeStamp = DateTime.Now+(Timeout>TimeSpan.Zero?Timeout:DuplexChannel.DefaultTimeout);
      _innerInstance.Send(message);
    }

    public void ClearInput()
    {
      _innerInstance.ClearInput();
    }

    public int InputSize { get { return _innerInstance.InputSize; } set { _innerInstance.InputSize = value; } }
    public void ReleaseReceivers()
    {
      _innerInstance.ReleaseReceivers();
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public IMessage Receive()
    {
      throw new NotSupportedException("This operation is unsupported for the protocol wrapper instance.");
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    public IMessage Receive(TimeSpan timeout)
    {
      throw new NotSupportedException("This operation is unsupported for the protocol wrapper instance.");
    }
    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    /// <exception cref="ArgumentNullException">If value is null.</exception>
    public event EventHandler Received
    {
      add { ThrowNull(value, "value"); ThrowUnsupportedException(); }
      remove { ThrowNull(value, "value"); ThrowUnsupportedException(); }
    }
    public IMessage Request(IMessage message)
    {
      LastRequestTimeStamp = DateTime.Now + (Timeout > TimeSpan.Zero ? Timeout : DuplexChannel.DefaultTimeout);
      return _innerInstance.Request(message);
    }

    public IMessage Request(IMessage message, TimeSpan timeout)
    {
      LastRequestTimeStamp = DateTime.Now + (timeout > TimeSpan.Zero ? timeout : DuplexChannel.DefaultTimeout);
      return _innerInstance.Request(message, timeout);
    }

    public IAsyncResult BeginRequest(IMessage message, AsyncCallback asyncCallback, object state)
    {
      LastRequestTimeStamp = DateTime.Now + (Timeout > TimeSpan.Zero ? Timeout : DuplexChannel.DefaultTimeout);
      return _innerInstance.BeginRequest(message, asyncCallback, state);
    }

    public IMessage EndRequest(IAsyncResult asyncResult)
    {
      return _innerInstance.EndRequest(asyncResult);
    }

    public IInterceptor Interceptor { get { return _innerInstance.Interceptor; } }
    public void ResetReceiver()
    {
      _innerInstance.ResetReceiver();
    }

    public IConnectionConfiguration Configuration { get { return _innerInstance.Configuration; } }
    public void Configure(IConnectionConfiguration connectionConfiguration)
    {
      _innerInstance.Configure(connectionConfiguration);
    }

    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    /// <exception cref="ArgumentNullException">If value is null.</exception>
    public Endpoint Endpoint
    {
      get{ return _innerInstance.Endpoint; }
      set { ThrowNull(value, "value"); ThrowUnsupportedException(); }
    }

    public ProtocolDescription ProtocolDescription { get { return _innerInstance.ProtocolDescription; } }
    /// <summary>
    /// Not supported. Throws <see cref="NotSupportedException"/>.
    /// </summary>
    /// <exception cref="ArgumentNullException">If value is null.</exception>
    public IAsyncInvoker Invoker { set { ThrowNull(value, "value"); ThrowUnsupportedException(); } }
    public void SetConnectionInvoker(IAsyncInvoker connectionInvoker)
    {
      _innerInstance.SetConnectionInvoker(connectionInvoker);
    }

    public bool CopyResponse { get { return _innerInstance.CopyResponse; } set { _innerInstance.CopyResponse = value; } }
    public IReferenceBuilder ReferenceBuilder { get { return _innerInstance.ReferenceBuilder; } }
    public int ProtocolId { get { return _innerInstance.ProtocolId; } }
    public IAsyncResult BeginRequest(IMessage message, AsyncCallback asyncCallback, object state, TimeSpan timeout)
    {
      var reEx = _innerInstance as IRequestChannelEx;
      LastRequestTimeStamp = DateTime.Now + (timeout > TimeSpan.Zero ? timeout : DuplexChannel.DefaultTimeout); 
      return reEx == null
        ? _innerInstance.BeginRequest(message, asyncCallback, state)
        : reEx.BeginRequest(message, asyncCallback, state, timeout);
    }

    RequestorInfo IRequestorInfoSupport.RequestorInfo
    {
      get
      {
        var ris = _innerInstance as IRequestorInfoSupport;
        return ris == null ? null : ris.RequestorInfo;
      }
      set
      {
        var ris = _innerInstance as IRequestorInfoSupport;
        if (ris != null) ris.RequestorInfo = value;
      }
    }
  }
}

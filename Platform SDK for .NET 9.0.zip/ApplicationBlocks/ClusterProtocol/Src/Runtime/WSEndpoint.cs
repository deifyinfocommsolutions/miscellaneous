//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using System;
using System.Linq;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.ClusterProtocol.Runtime
{
  internal sealed class WSEndpoint:Endpoint
  {
    #region HelperMethods
    private static Endpoint GetEndpoint(WSConfig configuration)
    {
      if (configuration == null) throw new ArgumentNullException("configuration");
      var endpoints = configuration.Endpoints;
      if ((endpoints==null) || (endpoints.Count==0)) 
        throw new ArgumentException("Configuration does not contain any Enpoints", "configuration");
      var endpoint =
        endpoints.FirstOrDefault(endpoint1 => ((endpoint1 != null)));
      if (endpoint==null)
        throw new ArgumentException("Configuration does not contain valid endpoints", "configuration");
      return endpoint;
    }
    #endregion HelperMethods

    private readonly WSConfig _configuration;
    internal WSConfig Configuration{get { return _configuration; }}

    internal WSEndpoint(WSConfig configuration) : this(GetEndpoint(configuration))
    {
      _configuration = configuration;
    }
    private WSEndpoint(Endpoint primaryEndpoint)
      : base(primaryEndpoint.Name, primaryEndpoint.Host, 
             primaryEndpoint.Port, primaryEndpoint.GetConfiguration()){}
    protected override void CheckPortNumber(int port){}
    public override object Clone()
    {
      return new WSEndpoint(_configuration);
    }
    public override bool Equals(object obj)
    {
      if (obj == null) return false;
      if (this == obj) return true;
      var ep = obj as WSEndpoint;
      if (ep==null) return false;
      return _configuration.Equals(ep._configuration);
    }
    public override int GetHashCode()
    {
      return GetType().GetHashCode() ^ _configuration.GetHashCode();
    }
  }

}

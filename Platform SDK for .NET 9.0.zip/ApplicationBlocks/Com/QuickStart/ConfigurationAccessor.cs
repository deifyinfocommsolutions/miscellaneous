//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Commons.Protocols;
using System.Configuration;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace QuickStart
{
    /// <summary>
    /// This class is used to access configuration server data. 
    /// </summary>
    class ConfigurationAccessor
    {
        private Uri uri;
        private string userName;
        private string password;
        private string clientName;
        private CfgAppType clientType;
        IConfService confService;
        Subscription currentSubscription;
        Action<ConfEvent> currentHandler;
        int subscribedAppDBID = -1;

        #region Internal

        /// <summary>
        /// Creates a new instance of the Configuration Server protocol
        /// and sets all of the attributes required for its use.
        /// </summary>
        /// <returns></returns>
        private ConfServerProtocol GetProtocol()
        {
            //The ConfServFactory.Retrieve method uses the protocol's endpoint
            //as the identifier by which to retrieve the confservice.  The 
            //Guid in this case is used to differentiate two connections with
            //the same URI.
            Endpoint desc = new Endpoint(Guid.NewGuid().ToString(), uri);

            ConfServerProtocol confProtocol = new ConfServerProtocol(desc);

            confProtocol.ClientApplicationType = (int)clientType;
            confProtocol.ClientName = clientName;
            confProtocol.UserName = userName;
            confProtocol.UserPassword = password;

            return confProtocol;
        }

        #endregion

        public ConfigurationAccessor()
        {
        }

        /// <summary>
        /// Returns the current state of the configuration server channel.  Should be
        /// used to determine whether a connection is opened.
        /// </summary>
        public ChannelState ChannelState
        {
            get
            {
                ConfServerProtocol protocol =
                    (ConfServerProtocol)confService.Protocol;

                return protocol == null ?
                    ChannelState.Closed :
                    protocol.State;
            }
        }


        /// <summary>
        /// The URI of the current configuration server
        /// </summary>
        public Uri Uri
        {
            get
            {
                ConfServerProtocol protocol =
                   (ConfServerProtocol)confService.Protocol;

                return protocol != null && protocol.Endpoint != null ?
                    protocol.Endpoint.Uri : null;
            }

        }

        /// <summary>
        /// Used to determine whether we're subscribed for events relating to the
        /// application specified by the passed dbid
        /// </summary>
        /// <param name="dbid"></param>
        /// <returns></returns>
        public bool IsSubscribedForAppEvents(int dbid)
        {
            return (subscribedAppDBID == dbid);
        }

        /// <summary>
        /// Used to open the connection to the Configuration Server specified
        /// in the App.config file for this application
        /// </summary>
        public void Connect()
        {
            ConfServerProtocol protocol = GetProtocol();

            try
            {
                protocol.Open();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Cannot connect to the configuration server (" + ex.Message + ").");
            }

            confService = ConfServiceFactory.CreateConfService(protocol);
        }

        /// <summary>
        /// Should be called before working with Configuration Server.  This method
        /// reads the necessary configuration information from the App.config and 
        /// sets the appropriate properties.
        /// </summary>
        public void Initialize()
        {
            try
            {
                uri = new Uri(ConfigurationManager.AppSettings["Uri"]);
            }
            catch
            {
                throw new Exception("Invalid configuration server URI");
            }

            userName = ConfigurationManager.AppSettings["UserName"];
            password = ConfigurationManager.AppSettings["Password"];
            clientName = ConfigurationManager.AppSettings["ClientName"];

            try
            {
                clientType = (CfgAppType)Enum.Parse(
                    typeof(CfgAppType),
                    ConfigurationManager.AppSettings["ClientType"]);
            }
            catch
            {
                throw new Exception("Invalid client type.  See CfgAppType enum for valid values.");
            }
        }

        /// <summary>
        /// Closes connection with configuration server
        /// </summary>
        internal void Disconnect()
        {
            if (confService != null)
            {
                ConfServiceFactory.ReleaseConfService(confService);

                IProtocol protocol =
                    confService.Protocol;

                protocol.Close();
            }
        }

        /// <summary>
        /// Retrieves an application by name.
        /// </summary>
        /// <param name="appName">application name as seen in configuration server</param>
        /// <returns>CfgApplication object describing the retrieved application, or null if not found</returns>
        internal CfgApplication RetrieveApplication(string appName)
        {
            CfgApplicationQuery query = new CfgApplicationQuery();

            query.Name = appName;

            return confService.RetrieveObject<CfgApplication>(query);
        }


        /// <summary>
        /// Unsubscribes from Configuration server notifications about the current "subscribed"
        /// application.
        /// </summary>
        public void Unsubscribe()
        {
            if (currentHandler != null && currentSubscription != null)
            {
                confService.Unregister(currentHandler);
                confService.Unsubscribe(currentSubscription);
            }

            currentHandler = null;
            currentSubscription = null;

            subscribedAppDBID = -1;
        }

        /// <summary>
        /// Subscribes to events about an object of the specified type, 
        /// and with the specified dbid
        /// </summary>
        /// <param name="myAction">a delegate which will be called when events are received</param>
        /// <param name="objectType">the type of subscribed object</param>
        /// <param name="dbid">the dbid of subscribed object</param>
        public void Subscribe(Action<ConfEvent> myAction, CfgObjectType objectType, int dbid)
        {
            if (currentHandler != null && currentSubscription != null)
            {
                Unsubscribe();
            }

            NotificationQuery notificationQuery = new NotificationQuery();
            notificationQuery.ObjectType = objectType;
            notificationQuery.ObjectDbid = dbid;
            notificationQuery.TenantDbid = WellKnownDbids.EnvironmentDbid;

            NotificationFilter filter = new NotificationFilter(notificationQuery);

            confService.Register(myAction, filter);

            currentSubscription = confService.Subscribe(notificationQuery);
            currentHandler = myAction;

            subscribedAppDBID = dbid;
        }
    }
}

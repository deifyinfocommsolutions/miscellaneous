//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace QuickStart
{
    public partial class frmQuickStart : Form
    {
        ConfigurationAccessor configAccessor = null;
        CfgApplication app;
        private static readonly string SectionsNodeName = "nodeSections";

        delegate void UpdateStatusBarDelegate(string text);

        public frmQuickStart()
        {
            InitializeComponent();
        }

        /// <summary>
        /// We initialize the configuration accessor and connect to
        /// Configuration Server on form load. The configuration information
        /// for Configuration server is specified in the App.config file.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmQuickStart_Load(object sender, EventArgs e)
        {
            configAccessor = new ConfigurationAccessor();

            try
            {
                configAccessor.Initialize();
                configAccessor.Connect();
                UpdateStatusBar(
                    configAccessor.ChannelState.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }


        }

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            app = null;

            configAccessor.Unsubscribe();

            UpdateUI();

            try
            {
                app = configAccessor.RetrieveApplication(txtQueryAppName.Text);

                if (app == null)
                {
                    MessageBox.Show("Specified application not found!");
                }
                else
                {
                    UpdateUI();
                    UpdateStatusBar("Retrieved application " + app.Name);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can't retrieve application! Reason: " + ex.Message);
            }
        }

        private void UpdateStatusBar(string status)
        {
            statusStrip.Items["currentStatus"].Text = string.Format("[{0}]: {1}",
                configAccessor.Uri, status);
        }

        private void UpdateUI()
        {
            bool isAppAvailable = !(app == null);

            txtAppName.Enabled = isAppAvailable;
            txtAppVersion.Enabled = false;
            txtAppVersion.Enabled = false;
            btnSubscribe.Enabled = isAppAvailable && configAccessor.IsSubscribedForAppEvents(app.DBID) == false;
            btnUnsubscribe.Enabled = isAppAvailable && !btnSubscribe.Enabled;
            btnApply.Enabled = isAppAvailable;
            lstAppConnections.Enabled = isAppAvailable;
            treeAppOptions.Enabled = isAppAvailable;

            if (isAppAvailable == true)
            {
                grpApplication.Text = string.Format("{0}(dbid:{1}) Properties", app.Name, app.DBID);
                txtAppName.Text = app.Name;
                txtAppType.Text = app.Type.ToString();
                txtAppVersion.Text = app.Version;

                FillConnectionsList(app);
                FillOptionsTree(app);
            }
            else
            {
                txtAppName.Text = "";
                txtAppType.Text = "";
                txtAppVersion.Text = "";
                lstAppConnections.Items.Clear();
                treeAppOptions.Nodes[SectionsNodeName].Nodes.Clear();
            }
        }

        private void FillOptionsTree(CfgApplication app)
        {
            TreeNode section = null;
            TreeNode root = treeAppOptions.Nodes[SectionsNodeName];

            if (root == null || app == null || app.Options == null) return;

            root.Nodes.Clear();

            foreach (string sectionName in app.Options.Keys)
            {
                section = root.Nodes.Add(sectionName);

                KeyValueCollection optionList = app.Options[sectionName] as KeyValueCollection;

                if (optionList == null) continue;

                foreach (string optionName in optionList.Keys)
                {
                    section.Nodes.Add(
                        optionName + ":" + optionList[optionName] as string);
                }
            }
        }

        private void FillConnectionsList(CfgApplication app)
        {
            if (app == null || app.AppServers == null) return;

            lstAppConnections.Items.Clear();

            foreach (CfgConnInfo connInfo in app.AppServers)
            {
                lstAppConnections.Items.Add(connInfo.AppServer.Name);
            }
        }

        private void frmQuickStart_Close(object sender, FormClosedEventArgs e)
        {
            configAccessor.Unsubscribe();
            configAccessor.Disconnect();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (treeAppOptions.SelectedNode == null)
            {
                optionsMenu.Items["btnAdd"].Enabled = false;
                optionsMenu.Items["btnRemove"].Enabled = false;
                optionsMenu.Items["btnClear"].Enabled = false;
                optionsMenu.Items["btnEdit"].Enabled = false;

                return;
            }

            //If it's the root node...
            if (treeAppOptions.SelectedNode.Level == 0)
            {
                optionsMenu.Items["btnAdd"].Enabled = true;
                optionsMenu.Items["btnRemove"].Enabled = false;
                optionsMenu.Items["btnClear"].Enabled = true;
                optionsMenu.Items["btnEdit"].Enabled = false;
            }
            //If it's a section...
            else if (treeAppOptions.SelectedNode.Level == 1)
            {
                optionsMenu.Items["btnAdd"].Enabled = true;
                optionsMenu.Items["btnRemove"].Enabled = true;
                optionsMenu.Items["btnClear"].Enabled = true;
                optionsMenu.Items["btnEdit"].Enabled = true;
            }
            //If it's an option...
            else
            {
                optionsMenu.Items["btnAdd"].Enabled = false;
                optionsMenu.Items["btnRemove"].Enabled = true;
                optionsMenu.Items["btnClear"].Enabled = false;
                optionsMenu.Items["btnEdit"].Enabled = true;

            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            treeAppOptions.SelectedNode.BeginEdit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Add section if root selected
            if (treeAppOptions.SelectedNode.Level == 0)
            {
                treeAppOptions.SelectedNode = treeAppOptions.SelectedNode.Nodes.Add("New Section");
            }
            //Add kv pair if section selected
            else
            {
                treeAppOptions.SelectedNode = treeAppOptions.SelectedNode.Nodes.Add("New option name : New option value");
            }

            treeAppOptions.SelectedNode.BeginEdit();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            treeAppOptions.SelectedNode.Remove();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            treeAppOptions.SelectedNode.Nodes.Clear();
        }

        private void BeforeOptionLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            //Can't allow editing of root
            if (treeAppOptions.SelectedNode.Level == 0)
            {
                e.CancelEdit = true;
            }
        }

        private void AfterOptionLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            //If editing option, make sure there's a key value separator
            if (e.Node.Level == 2)
            {
                if (e.Label != null && e.Label.Contains(":") == false || (e.Label == null && e.Node.Text.Contains(":") == false))
                {
                    if (e.Label != null)
                    {
                        e.Node.Text = e.Label;
                    }

                    MessageBox.Show("Option name and value must be separated by ':' character.");
                    e.Node.BeginEdit();
                }
            }

        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            app.Name = txtAppName.Text;

            UpdateApplicationOptions();

            try
            {
                app.Save();
                UpdateStatusBar("Applied changes to " + app.Name);
            }
            catch (ConfigServerException ex)
            {
                MessageBox.Show(
                    string.Format("Error type: [{0}]\r\nObject type: [{1}]\r\nObject property: [{2}]\r\n\r\nMessage: {3}", ex.ErrorType, ex.ObjectType, ex.ObjectProperty, ex.Message), "Error applying changes!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Apply failed!", ex.ToString());
            }
        }

        private void UpdateApplicationOptions()
        {
            app.Options.Clear();
            KeyValueCollection section;
            string[] kv;

            foreach (TreeNode sectionNode in treeAppOptions.Nodes[SectionsNodeName].Nodes)
            {
                section = new KeyValueCollection();
                app.Options.Add(sectionNode.Text, section);

                foreach (TreeNode optionNode in sectionNode.Nodes)
                {
                    kv = optionNode.Text.Split(':');

                    section.Add(kv[0], kv[1]);
                }
            }
        }

        private void btnSubscribe_Click(object sender, EventArgs e)
        {
            try
            {
                configAccessor.Subscribe(
                    new Action<ConfEvent>(this.EventHandler),
                    app.ObjectType,
                    app.DBID);

                UpdateStatusBar("Subscribed for " + app.Name + " events.");

                UpdateUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Subscribe failed!", ex.ToString());
            }
        }

        private void EventHandler(ConfEvent myEvent)
        {
            if (myEvent.ObjectType != CfgObjectType.CFGApplication || myEvent.ObjectId != app.DBID)
            {
                return;
            }

            app.Update(myEvent.Delta);

            this.Invoke(new MethodInvoker(UpdateUI));
            this.Invoke(new UpdateStatusBarDelegate(UpdateStatusBar), new object[] { "Application " + app.Name + " updated." });
            MessageBox.Show("Received configuration update!");
        }

        private void btnUnsubscribe_Click(object sender, EventArgs e)
        {
            configAccessor.Unsubscribe();
            UpdateStatusBar("Unsubscribed from " + app.Name + " events.");

            UpdateUI();
        }
    }
}

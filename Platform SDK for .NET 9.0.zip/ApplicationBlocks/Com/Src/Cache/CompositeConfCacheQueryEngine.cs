//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using System.Collections.ObjectModel;
using System.Collections;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache
{
    /// <summary>
    /// An implementation of the query engine interface which allows for 
    /// new query interpretation modules to be added at run time.
    /// </summary>
    public sealed class CompositeConfCacheQueryEngine : IConfCacheQueryEngine
    {
        ICollection<IConfCacheQueryEngine> queryEngines = new Collection<IConfCacheQueryEngine>();

        #region IConfCacheQueryEngine Members

        /// <summary>
        /// Looks for a query engine in its list which is capable of executing
        /// the specified query. 
        /// </summary>
        /// <param name="query">the query to execute</param>
        /// <returns>true if a capable query engine is found, false otherwise</returns>
        public bool CanExecute(ICfgQuery query)
        {
            foreach (IConfCacheQueryEngine queryEngine in queryEngines)
            {
                if (queryEngine.CanExecute(query))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Looks for a query engine which is capable of executing the 
        /// specified query, and if found, uses it to retrieve an
        /// object based on that query.
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="query">The query to execute</param>
        /// <returns>An object matching the passed query</returns>
        /// <exception cref="InvalidOperationException">Thrown if no query engine available to execute the query.</exception>
        public T RetrieveObject<T>(ICfgQuery query) where T : ICfgObject
        {
            foreach (IConfCacheQueryEngine queryEngine in queryEngines)
            {
                if (queryEngine.CanExecute(query))
                {
                    return queryEngine.RetrieveObject<T>(query);
                }
            }

            return default(T);
        }

        /// <summary>
        /// Looks for a query engine which is capable of executing the 
        /// specified query, and if found, uses it to retrieve a
        /// list of objects based on that query.
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="query">The query to execute</param>
        /// <returns>A list of objects matching the passed query</returns>
        /// <exception cref="InvalidOperationException">Thrown if no query engine available to execute the query.</exception>
        public ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query) where T : ICfgObject
        {
            foreach (IConfCacheQueryEngine queryEngine in queryEngines)
            {
                if (queryEngine.CanExecute(query))
                {
                    return queryEngine.RetrieveMultipleObjects<T>(query);
                }
            }

            return new Collection<T>();
        }

        /// <summary>
        /// Looks for a query engine which returns a result using the parameters
        /// passed. Returns the first obtained result.
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="type">The type of object (CfgObjectType)</param>
        /// <param name="dbid">The dbid of the object</param>
        /// <returns>A configuration object with the requested dbid and type</returns>
        public T RetrieveObject<T>(CfgObjectType type, int dbid) where T : ICfgObject
        {
            T obj = default(T);

            foreach (IConfCacheQueryEngine queryEngine in queryEngines)
            {
                try
                {
                    obj = queryEngine.RetrieveObject<T>(type, dbid);
                }
                catch
                {
                    continue;
                }

                if ((obj as object) != null)
                {
                    break;
                }
            }

            return obj;
        }

        #endregion

        /// <summary>
        /// Registers a query engine module.
        /// </summary>
        /// <param name="queryEngine"></param>
        public void Register(IConfCacheQueryEngine queryEngine)
        {
            lock (queryEngines)
            {
                queryEngines.Add(queryEngine);
            }
        }

        /// <summary>
        /// Unregisters a query engine module.
        /// </summary>
        /// <param name="queryEngine"></param>
        public void Unregister(IConfCacheQueryEngine queryEngine)
        {
            lock (queryEngines)
            {
                queryEngines.Remove(queryEngine);
            }
        }

    }
}

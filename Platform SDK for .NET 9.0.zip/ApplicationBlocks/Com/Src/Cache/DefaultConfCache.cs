//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Configuration;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using System.Collections;
using System.Collections.ObjectModel;
using System.IO;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;
using System.ComponentModel;
using System.Xml;
using Genesyslab.Platform.ApplicationBlocks.Commons;
using System.Threading;
using Genesyslab.Platform.Commons.Protocols;
using System.Xml.Linq;
using System.Linq;
using System.Xml.XPath;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Commons.Threading;
using Genesyslab.Platform.Commons.Logging;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache
{
    /// <summary>
    /// The default implementation of the configuration cache interface.
    /// </summary>
    public sealed class DefaultConfCache : AbstractLogEnabled, IConfCache, ISubscriptionService<ConfCacheEvent>, IDisposable
    {
        private IConfCachePolicy policy;
        private IConfCacheQueryEngine queryEngine;
        private IConfCacheStorage storage;

        private ICollection<Endpoint> endpoints = new Collection<Endpoint>();

        private COMBrokerService<ConfCacheEvent> brokerService;

        private readonly object invokerGuard = new object();
        private IAsyncInvoker asyncInvoker = new DefaultInvoker();
        private readonly bool _eventUpdatedOnSave = PsdkCustomization.CustomOption("DefaultConfCache.EventUpdateOnFirstSaveObject", false);

        
        private class SerializationConstants
        {
            internal static string ConfigurationNode = "CacheConfiguration";
            internal static string ConfigurationServerNode = "ConfigurationServer";
            internal static string CacheNode = "Cache";
            internal static string ConfDataNode = "ConfData";
            internal static string NameAttribute = "name";
            internal static string UriAttribute = "uri";
        }

        #region Constructors

        /// <summary>
        /// Creates a cache which will use the default policy, storage and query
        /// engine.
        /// </summary>
        public DefaultConfCache() :
            this(null, null, null)
        {
        }

        /// <summary>
        /// Creates a new instance of the configuration cache.
        /// </summary>
        /// <param name="policy">The cache policy</param>
        /// <param name="storage">The storage to be used in this cache</param>
        /// <param name="queryEngine">The query engine to be used to retrieve 
        /// data from the storage</param>
        public DefaultConfCache(
            IConfCachePolicy policy,
            IConfCacheStorage storage,
            IConfCacheQueryEngine queryEngine)
        {
            this.policy = policy == null ? new DefaultConfCachePolicy() : policy;
            this.storage = storage == null ? new DefaultConfCacheStorage() : storage;
            this.queryEngine = queryEngine == null ? new DefaultConfCacheQueryEngine(this.storage) : queryEngine;

            brokerService = new COMBrokerService<ConfCacheEvent>();

        }
        #endregion

        #region Internal

        private void PerformRefresh()
        {
            IEnumerable<ICfgObject> objList = storage.Retrieve<ICfgObject>();

            foreach (ICfgObject obj in objList)
            {
                obj.Refresh();
            }
        }

        private void RefreshThread(object obj)
        {
            PerformRefresh();

            ConfAsyncResult res = (ConfAsyncResult)obj;

            if (res != null)
                res.SetCompleted();
        }

        private void OnObjectUpdated(ConfEvent configEvent)
        {
            if (queryEngine == null)
            {
                this.Logger.Debug("queryEngine is null");
                return;
            }

            ICfgObject obj = queryEngine.RetrieveObject<ICfgObject>(configEvent.ObjectType, configEvent.ObjectId);

            if (obj != null && policy.TrackUpdates(obj))
            {
                try
                {
                    obj.Update(configEvent.Delta);

                    if (policy.ReturnCopies && obj is ICloneable)
                    {
                        obj = (obj as ICloneable).Clone() as ICfgObject;
                    }

                    brokerService.Publish(
                        new ConfCacheEvent(obj, ConfCacheUpdateType.ObjectUpdated));
                }
                catch (Exception ex)
                {
                    Logger.Warn("OnObjectUpdated got an exception", ex);
                }

            }
        }

        private void OnObjectDeleted(ConfEvent configEvent)
        {
            if (configEvent.IsUnsolicited == false)
            {
                return;
            }

            ICfgObject obj = Retrieve<ICfgObject>(configEvent.ObjectType, configEvent.ObjectId);

            if (obj != null && policy.RemoveOnDelete(obj))
            {
                Remove(obj);
            }
        }


        private void OnObjectCreated(ConfEvent configEvent)
        {
            ConfEventObjectCreated evt = configEvent as ConfEventObjectCreated;

            if (evt == null) throw new InvalidOperationException("Expected type 'ConfEventObjectCreated' on created event");

            if (configEvent.IsUnsolicited &&
                policy.CacheOnCreate(evt.Object))
            {
                Add(evt.Object);
            }
        }

        private void Validate(ICfgObject obj)
        {
            if (obj == null)
            {
                throw new ArgumentNullException("obj");
            }

            if (endpoints.Contains(obj.Endpoint) == false)
            {
                throw new InvalidOperationException(
                    "The specified object does not belong to a configuration server supported by this cache.");
            }
        }

        internal int EndpointCount
        {
            get { return endpoints.Count; }
        }
        #endregion

        #region DefaultConfCache members

        /// <summary>
        /// Adds a supported endpoint to the list. By default, the endpoint of the configuration
        /// service with which this cache is initially associated is added. This method should be used
        /// to add any other endpoints at which the objects in this cache are valid -- for instance the
        /// endpoint of a backup configuration server or a proxy. Note that ALL objects in the cache are assumed
        /// to be valid at ALL endpoints. This means that adding unrelated configuration servers to the list
        /// is unsupported and will result in undefined behavior.
        /// </summary>
        /// <param name="endpoint">The endpoint of a configuration server</param>
        public void AddEndpoint(Endpoint endpoint)
        {
          if (endpoints.Contains(endpoint)) return;
          endpoints.Add(endpoint);
        }

        /// <summary>
        /// Sets IAsyncInvoker (for thread management in asynchronous operations like BeginRefresh(...))
        /// </summary>
        public IAsyncInvoker Invoker
        {
            set
            {
                lock (invokerGuard)
                {
                    IDisposable disposable = asyncInvoker as IDisposable;
                    if (disposable != null)
                        disposable.Dispose();
                    asyncInvoker = value;
                }
            }
            get
            {
                lock (invokerGuard)
                {
                    return asyncInvoker;
                }
            }
        }

        #endregion

        #region IConfCache Members

        /// <summary>
        /// Adds a new configuration object to the cache. 
        /// </summary>
        /// <remarks>
        /// An "ObjectAdded" cache event is fired upon the successful completion of
        /// this operation.
        /// </remarks>
        /// <param name="obj">A configuration object</param>
        public void Add(ICfgObject obj)
        {
            Validate(obj);

            storage.Add(obj);

            brokerService.Publish(new ConfCacheEvent(obj, ConfCacheUpdateType.ObjectAdded));
        }


        /// <summary>
        /// Overwrites a configuration object which already exists in the cache
        /// with a new copy.
        /// </summary>
        /// <remarks>
        /// An "ObjectUpdated" cache event is fired upon the successful completion of
        /// this operation.
        /// </remarks>
        /// <param name="obj">A configuration object</param>
        public void Update(ICfgObject obj)
        {
          Validate(obj);
          if (Contains(obj))
          {
            storage.Update(obj);
            brokerService.Publish(new ConfCacheEvent(obj, ConfCacheUpdateType.ObjectUpdated));
          }
          else
          {
            storage.Add(obj);
            brokerService.Publish(_eventUpdatedOnSave
              ? new ConfCacheEvent(obj, ConfCacheUpdateType.ObjectUpdated)
              : new ConfCacheEvent(obj, ConfCacheUpdateType.ObjectAdded));
          }

        }

        /// <summary>
        /// Removes the specified configuration object from the cache.
        /// </summary>
        /// <remarks>
        /// An "ObjectRemoved" cache event is fired upon the successful completion of
        /// this operation.
        /// </remarks>
        /// <param name="obj">A configuration object</param>
        public void Remove(ICfgObject obj)
        {
            if (obj == null) throw new ArgumentNullException("obj");

            if (storage.Remove(obj))
            {
                brokerService.Publish(
                    new ConfCacheEvent(obj, ConfCacheUpdateType.ObjectRemoved));
            }
        }

        /// <summary>
        /// Removes the configuration object with the specified type and dbid
        /// from the cahe.
        /// </summary>
        /// <remarks>
        /// An "ObjectRemoved" cache event is fired upon the successful completion of
        /// this operation.
        /// </remarks>
        /// <param name="type">The type of configuration object</param>
        /// <param name="dbid">The dbid of the configuration object</param>

        public void Remove(CfgObjectType type, int dbid)
        {
            IEnumerable<ICfgObject> objList = storage.Retrieve<ICfgObject>(new CacheKey(type, dbid));

            foreach (ICfgObject obj in objList)
            {
                if (obj.ObjectDbid == dbid && obj.ObjectType == type)
                {
                    Remove(obj);
                    break;
                }
            }
        }

        /// <summary>
        /// Retrieves a configuration object from the cache using the cache's
        /// query engine.
        /// </summary>
        /// <typeparam name="T">The type of configuration object that should be returned</typeparam>
        /// <param name="type">The type of configuration object</param>
        /// <param name="dbid">The dbid of the configuration object</param>
        /// <returns>A configuration object of the requested type</returns>

        public T Retrieve<T>(CfgObjectType type, int dbid) where T : ICfgObject
        {
            if (queryEngine == null) throw new InvalidOperationException("A query engine has not been specified for the cache.");

            T obj = queryEngine.RetrieveObject<T>(type, dbid);

            if ((obj as object) != null && policy.ReturnCopies)
            {
                ICloneable cloneable = obj as ICloneable;

                if (cloneable != null)
                {
                    return (T)cloneable.Clone();
                }
            }

            return obj;
        }

        /// <summary>
        /// Retrieves a configuration object from the cache using the cache's 
        /// query engine.
        /// </summary>
        /// <typeparam name="T">The type of configuration object that should be returned</typeparam>
        /// <param name="query"> 
        /// A query based on which the result is obtained. 
        /// </param>
        /// <returns>A configuration object matching the specified query</returns>

        public T Retrieve<T>(ICfgQuery query) where T : ICfgObject
        {
            if (queryEngine == null) throw new InvalidOperationException("A query engine has not been specified for the cache.");

            T obj;

            try
            {
                obj = queryEngine.RetrieveObject<T>(query);
            }
            catch (Exception ex)
            {
                Logger.Warn("Retrieve<" + typeof(T) + "> got an exception", ex);
                return default(T);
            }

            if ((obj as object) != null && policy.ReturnCopies)
            {
                ICloneable cloneable = obj as ICloneable;

                if (cloneable != null)
                {
                    return (T)cloneable.Clone();
                }
            }

            return obj;

        }

        /// <summary>
        /// Retrieves an enumerable list of objects from the cache using the 
        /// cache's query engine.
        /// </summary>
        /// <typeparam name="T">The types of configuration objects to be included in the list.</typeparam>
        /// <param name="query"> 
        /// A query based on which the result is obtained. 
        /// </param>
        /// <returns>An enumerable list of configuration objects matching the specified query</returns>
        public IEnumerable<T> RetrieveMultiple<T>(ICfgQuery query) where T : ICfgObject
        {
            if (queryEngine == null) throw new InvalidOperationException("A query engine has not been specified for the cache.");

            return queryEngine.RetrieveMultipleObjects<T>(query);
        }

        /// <summary>
        /// Retrieves an enumerable list of all configuration objects in the storage.
        /// </summary>
        /// <remarks>
        /// Unlike the other Get methods this method does not use the query engine.
        /// Instead, all cached objects are returned, filtered by the T parameter.
        /// </remarks>
        /// <typeparam name="T">The type of configuration object to include 
        /// (use ICfgObject to retrieve an enumeration of all stored objects)</typeparam>
        /// <returns>An enumerable list of configuration objects</returns>
        public IEnumerable<T> RetrieveMultiple<T>() where T : ICfgObject
        {
            return storage.Retrieve<T>();
        }

        /// <summary>
        /// Serializes the cache into the specified stream.
        /// </summary>
        /// <param name="stream">The stream into which the cache is to be written</param>
        public void Serialize(Stream stream)
        {
            XmlWriterSettings settings = new XmlWriterSettings();

            settings.ConformanceLevel = ConformanceLevel.Fragment;
            settings.CheckCharacters = false;

            XmlWriter writer = XmlWriter.Create(stream, settings);

            XDocument doc = new XDocument();

            XElement cache = new XElement(SerializationConstants.CacheNode);

            XElement cacheConfig = new XElement(SerializationConstants.ConfigurationNode);

            XElement configServer;

            XElement confData = new XElement(SerializationConstants.ConfDataNode);
            XAttribute attr;

            doc.Add(cache);
            cache.Add(cacheConfig);
            cache.Add(confData);

            foreach (Endpoint ep in endpoints)
            {
                if (ep.Name == null || ep.Uri == null) continue;

                configServer = new XElement(SerializationConstants.ConfigurationServerNode);

                attr = new XAttribute(SerializationConstants.NameAttribute, ep.Name);

                configServer.Add(attr);

                attr = new XAttribute(SerializationConstants.UriAttribute, ep.Uri.ToString());

                configServer.Add(attr);

                cacheConfig.Add(configServer);
            }

            IEnumerable<ICfgObject> objList = storage.Retrieve<ICfgObject>();

            if (objList == null) return;

            foreach (ICfgObject obj in objList)
            {
                confData.Add(obj.ToXml());
            }

            cache.WriteTo(writer);

            writer.Close();

        }

        /// <summary>
        /// Deserializes the cache from the specified stream.
        /// </summary>
        /// <param name="stream">The stream from which the cache is to be read</param>
        public void Deserialize(Stream stream)
        {
          XmlReaderSettings settings = new XmlReaderSettings()
                                         {
                                           CheckCharacters = false
                                         };
            XmlReader reader = XmlReader.Create(stream, settings);

            XDocument doc = XDocument.Load(reader);

            IConfService confService = null;
            ICfgObject obj;

            IEnumerable<XElement> configServerNodes = doc.XPathSelectElements(
                SerializationConstants.CacheNode + "/" +
                SerializationConstants.ConfigurationNode + "/" +
                SerializationConstants.ConfigurationServerNode);

            XAttribute nameAttr, uriAttr;

            foreach (XElement node in configServerNodes)
            {
                nameAttr = node.Attribute(SerializationConstants.NameAttribute);
                uriAttr = node.Attribute(SerializationConstants.UriAttribute);

                if (nameAttr == null) throw new InvalidDataException("The serialized data is not in a valid format.");
                if (uriAttr == null) throw new InvalidDataException("The serialized data is not in a valid format.");

                confService = ConfServiceFactory.RetrieveConfService(
                    new Endpoint(nameAttr.Value, new Uri(uriAttr.Value)));

                if (confService != null)
                {
                    break;
                }
            }

            if (confService == null) throw new InvalidDataException("The serialized data requires a confService which has not been created.");

            IEnumerable<XElement> confData = doc.XPathSelectElements(
                SerializationConstants.CacheNode + "/" +
                SerializationConstants.ConfDataNode);

            if (confData == null) throw new InvalidDataException("The serialized data is not in a valid format.");

            foreach (XElement node in confData.Elements())
            {
                obj = confService.CreateObjectFromXml(node, true);

                try
                {
                    Add(obj);
                }
                catch (Exception ex)
                {
                    Logger.Warn("Deserialize got an exception", ex);
                }
            }
        }

        /// <summary>
        /// Removes all cache contents.
        /// </summary>
        public void Clear()
        {
            storage.Clear();
        }

        /// <summary>
        /// Synchronously updates all configuration objects which are currently in the cache.
        /// </summary>
        public void Refresh()
        {
            PerformRefresh();
        }

        /// <summary>
        /// Asynchronously updates all configuration objects in the cache.
        /// </summary>
        /// <param name="callback">The callback method to be invoked when the operation completes.</param>
        /// <returns>The async result associated with this operation.</returns>
        public IAsyncResult BeginRefresh(AsyncCallback callback)
        {
            ConfAsyncResult asyncResult = new ConfAsyncResult();
            asyncResult.EnableLogging(Logger.CreateChildLogger("ConfAsyncResult"));
            asyncResult.Callback = callback;

            Invoker.Invoke(new WaitCallback(RefreshThread), asyncResult);

            return asyncResult;
        }


        /// <summary>
        /// To be called when the asynchronous refresh operation is complete. If called before 
        /// the refresh operation completes, this method will block until completion.
        /// </summary>
        /// <param name="asyncResult">The async result associated with the current operation</param>
        public void EndRefresh(IAsyncResult asyncResult)
        {
            if (asyncResult == null) throw new ArgumentNullException("asyncResult");

            if (asyncResult.AsyncWaitHandle == null ||
                asyncResult.AsyncWaitHandle.SafeWaitHandle == null ||
                asyncResult.AsyncWaitHandle.SafeWaitHandle.IsInvalid)
            {
                throw new ArgumentException("Invalid AsyncWaitHandle");
            }

            try
            {
                asyncResult.AsyncWaitHandle.WaitOne();
            }
            catch (ObjectDisposedException ode)
            {
                throw new ConfigException("Error while retrieving multiple objects", ode);
            }
            catch (AbandonedMutexException ame)
            {
                throw new ConfigException("Error while retrieving multiple objects", ame);
            }
        }

        /// <summary>
        /// Returns the current policy associated with this cache.
        /// </summary>
        public IConfCachePolicy Policy
        {
            get { return this.policy; }
            set { this.policy = value; }
        }

        /// <summary>
        /// Determines whether the cache contains the specified object.
        /// </summary>
        /// <remarks>
        /// For the purposes of this method, two objects are considered
        /// equal if they have the same dbid and type.
        /// </remarks>
        /// <param name="obj">The configuration object to look for</param>
        /// <returns>true if the object is in the cache, false otherwise</returns>
        public bool Contains(ICfgObject obj)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (queryEngine == null) throw new InvalidOperationException("A query engine has not been specified for the cache.");
            return queryEngine.RetrieveObject<ICfgObject>(obj.ObjectType, obj.ObjectDbid)!=null;

            //return Retrieve<ICfgObject>(obj.ObjectType, obj.ObjectDbid) != null;
        }


        #endregion

        #region ISubscriptionService<ConfCacheEvent> Members

        /// <summary>
        /// Registers a subscriber object for receiving notifications from 
        /// the cache.
        /// </summary>
        /// <param name="subscriber">the "subscriber" object which will handle the notifications</param>

        public void Register(ISubscriber<ConfCacheEvent> subscriber)
        {
            brokerService.Register(subscriber);
        }

        /// <summary>
        /// Registers a delegate for receiving notifications from the cache. 
        /// </summary>
        /// <param name="handler">the notification delegate</param>
        public void Register(Action<ConfCacheEvent> handler)
        {
            brokerService.Register(handler);
        }

        /// <summary>
        /// Registers a delegate for receiving notifications from the cache
        /// based on the specified filter.
        /// </summary>
        /// <param name="handler">The delegate which will handle the event</param>
        /// <param name="filter">A filter to apply to the event</param>
        public void Register(Action<ConfCacheEvent> handler, IPredicate<ConfCacheEvent> filter)
        {
            brokerService.Register(handler, filter);
        }

        /// <summary>
        /// Unregisters the subscriber from event notifications
        /// </summary>
        /// <param name="subscriber">the subscriber to unregister</param>
        public void Unregister(ISubscriber<ConfCacheEvent> subscriber)
        {
            brokerService.Unregister(subscriber);
        }

        /// <summary>
        /// Unregisters the specified delegate from notifications
        /// </summary>
        /// <param name="handler">the function to unregister</param>
        public void Unregister(Action<ConfCacheEvent> handler)
        {
            brokerService.Unregister(handler);
        }

        #endregion

        #region ISubscriber<ConfigurationEvent> Members

        IPredicate<ConfEvent> ISubscriber<ConfEvent>.Filter
        {
            get { return null; }
        }

        void ISubscriber<ConfEvent>.Handle(ConfEvent configEvent)
        {
            switch (configEvent.EventType)
            {
                case ConfEventType.ObjectCreated:
                    OnObjectCreated(configEvent);
                    break;

                case ConfEventType.ObjectDeleted:
                    OnObjectDeleted(configEvent);
                    break;

                case ConfEventType.ObjectUpdated:
                    OnObjectUpdated(configEvent);
                    break;
            }
        }

        #endregion


        #region IDisposable Members

        /// <summary>
        /// Releases cache resources.
        /// </summary>
        public void Dispose()
        {
            DefaultConfCacheStorage defaultStorage = this.storage as DefaultConfCacheStorage;

            if (defaultStorage != null)
            {
                defaultStorage.Dispose();
            }
        }

        #endregion
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using System.Collections.ObjectModel;
using System.Collections;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache
{
    /// <summary>
    /// The default query engine implementation.
    /// </summary>
    public sealed class DefaultConfCacheQueryEngine : IConfCacheQueryEngine
    {
        private IConfCacheStorage storage;

        /// <summary>
        /// Creates a new query engine which works with the specified
        /// storage.
        /// </summary>
        /// <param name="storage">The storage which will be queried</param>
        public DefaultConfCacheQueryEngine(IConfCacheStorage storage)
        {
            if (storage == null) throw new ArgumentNullException("storage");

            this.storage = storage;
        }

        #region IConfCacheQueryEngine Members

        /// <summary>
        /// Determines whether the query engine can execute the specified query. Currently,
        /// only queries which contain an object type and dbid parameters are supported.
        /// </summary>
        /// <param name="query">The query to execute</param>
        /// <returns>true if the query engine can execute this query, false otherwise</returns>
        public bool CanExecute(ICfgQuery query)
        {
            ICfgFilterBasedQuery fbQuery = query as ICfgFilterBasedQuery;

            return (fbQuery != null && fbQuery[MiscConstants.FilterDbidName] != null);
        }

        /// <summary>
        /// Retrieves an object based on the specified query. Note that this implementation
        /// only supports the "dbid" and "type" query filters. All other filters
        /// are ignored.
        /// </summary>
        /// <param name="query">The query by which to retrieve the object</param>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <returns>The object specified by the query or 
        /// null if the object is not found</returns>
        public T RetrieveObject<T>(ICfgQuery query) where T : ICfgObject
        {
            if (CanExecute(query) == false) throw new InvalidOperationException("Query not supported");

            var fbQuery = query as ICfgFilterBasedQuery;
            if (fbQuery == null) return default(T);

            return RetrieveObject<T>(fbQuery.QueryObjectType, (int)fbQuery[MiscConstants.FilterDbidName]);
        }

        /// <summary>
        /// This method is from IConfCacheQueryEngine interface. It is not supported
        /// by this implementation.
        /// </summary>
        /// <param name="query">query object</param>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <returns>an empty collection</returns>
        public ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query) where T : ICfgObject
        {
            return new Collection<T>();
        }

        /// <summary>
        /// Retrieves an object using the specified parameters.
        /// </summary>
        /// <param name="type">The type of object (CfgObjectType)</param>
        /// <param name="dbid">The dbid of the object</param>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <returns>A configuration object with the requested dbid and type or 
        /// null if the object is not found</returns>
        public T RetrieveObject<T>(CfgObjectType type, int dbid) where T : ICfgObject
        {
            IEnumerable<T> objList = storage.Retrieve<T>(new CacheKey(type, dbid));

            foreach (T obj in objList)
            {
                if (obj.ObjectType == type && obj.ObjectDbid == dbid)
                {
                    return obj;
                }
            }

            return default(T);
        }

        #endregion
    }
}

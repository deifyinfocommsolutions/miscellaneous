//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.Types;
using System.Threading;
using System.Collections;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache
{
    /// <summary>
    /// The default implementation of the configuration cache storage.
    /// </summary>
    /// <remarks>
    /// This storage implementation is thread safe.
    /// </remarks>
    public sealed class DefaultConfCacheStorage : IConfCacheStorage, IDisposable
    {
        private IDictionary<CfgObjectType, IDictionary<int, ICfgObject>> objects =
            new Dictionary<CfgObjectType, IDictionary<int, ICfgObject>>();

        ReaderWriterLockSlim rwLock = new ReaderWriterLockSlim();

        private class StorageObjectEnumeration<T> : IEnumerable<T>
        {
            private IDictionary<CfgObjectType, IDictionary<int, ICfgObject>> objects =
                new Dictionary<CfgObjectType, IDictionary<int, ICfgObject>>();

            object helper;
            DefaultConfCacheStorage storage;

            internal StorageObjectEnumeration(IDictionary<CfgObjectType, IDictionary<int, ICfgObject>> objects, object helper, DefaultConfCacheStorage storage)
            {
                if (objects == null)
                {
                    throw new ArgumentNullException("objects");
                }

                if (storage == null)
                {
                    throw new ArgumentNullException("storage");
                }

                this.objects = objects;
                this.helper = helper;
                this.storage = storage;
            }

            #region IEnumerable<T> Members

            public IEnumerator<T> GetEnumerator()
            {
                return GetEnumeratorInternal();
            }

            #endregion

            #region IEnumerable Members

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumeratorInternal();
            }

            private IEnumerator<T> GetEnumeratorInternal()
            {
                ICollection<T> objectsCol = null;

                if (helper == null)
                {
                    objectsCol = CopyAll();
                }
                else if (helper is CfgObjectType)
                {
                    objectsCol = CopyByType();
                }
                else if (helper is CacheKey)
                {
                    objectsCol = CopyByKey();
                }

                return objectsCol != null ? objectsCol.GetEnumerator() : null;
            }

            private ICollection<T> CopyByKey()
            {
                CacheKey cacheKey = helper as CacheKey;
                if (cacheKey==null) return new List<T>();

                ICfgObject obj = null;

                storage.EnterReadLock();

                if (objects.ContainsKey(cacheKey.ObjectType))
                {
                    objects[cacheKey.ObjectType].TryGetValue(cacheKey.ObjectDbid, out obj);
                }

                storage.ExitReadLock();

                List<T> objectsCol = new List<T>();

                if (obj is T)
                {
                    objectsCol.Add((T)obj);
                }

                return objectsCol;
            }

            private ICollection<T> CopyByType()
            {
                List<T> objectsCol = new List<T>();
                CfgObjectType objType = (CfgObjectType)helper;
                IDictionary<int, ICfgObject> table;

                storage.EnterReadLock();

                bool containsTypeList = objects.TryGetValue(objType, out table);

                if (containsTypeList)
                {
                    foreach (ICfgObject obj in table.Values)
                    {
                        objectsCol.Add((T)obj);
                    }
                }

                storage.ExitReadLock();

                return objectsCol;
            }

            private ICollection<T> CopyAll()
            {
                IDictionary<int, ICfgObject> table;
                List<T> objectsCol = new List<T>();

                storage.EnterReadLock();

                for (IEnumerator<IDictionary<int, ICfgObject>> en = objects.Values.GetEnumerator();
                    en.MoveNext(); )
                {
                    table = en.Current;

                    if (table != null)
                    {
                        for (IEnumerator<ICfgObject> en2 = table.Values.GetEnumerator(); en2.MoveNext(); )
                        {
                            if (en2.Current is T)
                            {
                                objectsCol.Add((T)en2.Current);
                            }
                        }
                    }
                }

                storage.ExitReadLock();

                return objectsCol;
            }

            #endregion
        }
        #region IConfCacheStorage Members

        internal void EnterReadLock()
        {
            rwLock.EnterReadLock();
        }

        internal void EnterWriteLock()
        {
            rwLock.EnterWriteLock();
        }

        internal void ExitReadLock()
        {
            rwLock.ExitReadLock();
        }

        internal void ExitWriteLock()
        {
            rwLock.ExitWriteLock();
        }

        /// <summary>
        /// Adds the specified object into the cache. 
        /// </summary>
        /// <exception cref="ArgumentException">The object being added has not been saved in the configuration server.</exception>
        /// <exception cref="InvalidOperationException">The object being added is already in the cache (dbid and type are used for the purposes of determining equality)</exception>
        /// <param name="obj"></param>
        public void Add(ICfgObject obj)
        {
            Add(obj, false);
        }

        /// <summary>
        /// Updates an existing configuration object in the storage
        /// with the passed copy.
        /// </summary>
        /// <remarks>
        /// If the passed object does not already exist in the cache, it is added
        /// to the cache. The object's dbid and type are used to determine equality.
        /// </remarks>
        /// <param name="obj">The new version of a cached configuration object</param>
        public void Update(ICfgObject obj)
        {
            Add(obj, true);
        }

        private void Add(ICfgObject obj, bool replaceOldCopy)
        {
            if (obj == null) throw new ArgumentNullException("obj");

            int dbid = obj.ObjectDbid;

            if (dbid == 0)
            {
                throw new ArgumentException("The passed object has not been saved in Configuration Server.");
            }

            IDictionary<int, ICfgObject> objList;

            EnterWriteLock();

            bool containsTypeList =
                objects.TryGetValue(obj.ObjectType, out objList);

            bool alreadyInList = false;

            if (containsTypeList == false)
            {
                objects[obj.ObjectType] = objList = new Dictionary<int, ICfgObject>();
            }
            else
            {
                alreadyInList = objList.ContainsKey(dbid);
            }

            if (alreadyInList)
            {
                if (replaceOldCopy == false)
                {
                    ExitWriteLock();
                    throw new InvalidOperationException("Object already in cache.");
                }

                objList[dbid] = obj;
            }
            else
            {
                objList.Add(dbid, obj);
            }

            ExitWriteLock();
        }

        /// <summary>
        /// Removes the specified configuration object from the storage.
        /// </summary>
        /// <remarks>The object is located using its dbid and type.</remarks>
        /// <param name="obj">The configuration object to remove</param>
        /// <returns>true if object successfuly deleted, false otherwise.</returns>
        public bool Remove(ICfgObject obj)
        {
            CfgObjectType type = obj.ObjectType;
            int dbid = (int)obj[MiscConstants.DbidPropertyName];

            IDictionary<int, ICfgObject> objList;
            bool res = false;

            EnterWriteLock();

            bool containsType = objects.TryGetValue(type, out objList);

            if (containsType)
            {
                res = objList.Remove(dbid);

                if (objList.Count == 0)
                {
                    objects.Remove(type);
                }
            }

            ExitWriteLock();

            return res;
        }


        /// <summary>
        /// Removes all items in storage.
        /// </summary>
        public void Clear()
        {
            EnterWriteLock();
            objects.Clear();
            ExitWriteLock();

        }

        /// <summary>
        /// Retrieves a list of all objects in the storage.
        /// </summary>
        /// <typeparam name="T">The type of object in the resulting list</typeparam>
        /// <returns>An enumerable list of the requested objects</returns>
        public IEnumerable<T> Retrieve<T>() where T : ICfgObject
        {
            return new StorageObjectEnumeration<T>(objects, null, this);
        }

        /// <summary>
        /// Retrieves a list of objects in storage utilizing a "helper"
        /// parameter.
        /// </summary>
        /// <typeparam name="T">The type of object in the resulting list</typeparam>
        /// <param name="helper">can be either "null" to retrieve all objects,
        /// or CfgObjectType to retrieve by type.</param>
        /// <returns>An enumerable list of the requested objects</returns>
        public IEnumerable<T> Retrieve<T>(object helper) where T : ICfgObject
        {
            return new StorageObjectEnumeration<T>(objects, helper, this);
        }

        #endregion


        #region IDisposable Members

        /// <summary>
        /// Releases the resources associated with the storage.
        /// </summary>
        public void Dispose()
        {
            rwLock.Dispose();
        }

        #endregion
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.Types;
using System.IO;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using System.Collections.ObjectModel;
using System.Collections;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache
{
    /// <summary>
    /// Interface for the configuration object cache.
    /// </summary>
    public interface IConfCache : ISubscriber<ConfEvent>
    {
        /// <summary>
        /// Adds a new configuration object to the cache. 
        /// </summary>
        /// <param name="obj">A configuration object</param>
        void Add(ICfgObject obj);

        /// <summary>
        /// Overwrites a configuration object which already exists in the cache
        /// with a new copy.
        /// </summary>
        /// <param name="obj">A configuration object</param>
        void Update(ICfgObject obj);

        /// <summary>
        /// Removes the specified configuration object from the cache.
        /// </summary>
        /// <param name="obj">A configuration object</param>
        void Remove(ICfgObject obj);

        /// <summary>
        /// Removes the configuration object with the specified type and dbid
        /// from the cahe.
        /// </summary>
        /// <param name="type">The type of configuration object</param>
        /// <param name="dbid">The dbid of the configuration object</param>
        void Remove(CfgObjectType type, int dbid);

        /// <summary>
        /// Removes all cache contents.
        /// </summary>
        void Clear();

        /// <summary>
        /// Retrieves a configuration object from the cache.
        /// </summary>
        /// <typeparam name="T">The type of configuration object that should be returned</typeparam>
        /// <param name="type">The type of configuration object</param>
        /// <param name="dbid">The dbid of the configuration object</param>
        /// <returns>A configuration object of the requested type</returns>
        T Retrieve<T>(CfgObjectType type, int dbid) where T : ICfgObject;

        /// <summary>
        /// Retrieves a configuration object from the cache.
        /// </summary>
        /// <typeparam name="T">The type of configuration object that should be returned</typeparam>
        /// <param name="query"> 
        /// A query based on which the result is obtained. 
        /// </param>
        /// <returns>A configuration object matching the specified query</returns>
        T Retrieve<T>(ICfgQuery query) where T : ICfgObject;

        /// <summary>
        /// Retrieves an enumerable list of objects from the cache.
        /// </summary>
        /// <typeparam name="T">The types of configuration objects to be included in the list.</typeparam>
        /// <param name="query"> 
        /// A query based on which the result is obtained. 
        /// </param>
        /// <returns>An enumerable list of configuration objects matching the specified query</returns>
        IEnumerable<T> RetrieveMultiple<T>(ICfgQuery query) where T : ICfgObject;

        /// <summary>
        /// Retrieves an enumerable list of objects from the cache.
        /// </summary>
        /// <typeparam name="T">The types of configuration objects to be included in the list.</typeparam>
        /// <returns>An enumerable list of configuration objects matching the specified query</returns>
        IEnumerable<T> RetrieveMultiple<T>() where T : ICfgObject;

        /// <summary>
        /// Determines whether the cache contains the specified object.
        /// </summary>
        /// <param name="obj">The configuration object to look for</param>
        /// <returns>true if the object is in the cache, false otherwise</returns>
        bool Contains(ICfgObject obj);

        /// <summary>
        /// Serializes the cache into the specified stream.
        /// </summary>
        /// <param name="stream">The stream into which the cache is to be written</param>
        void Serialize(Stream stream);

        /// <summary>
        /// Deserializes the cache from the specified stream.
        /// </summary>
        /// <param name="stream">The stream from which the cache is to be read</param>
        void Deserialize(Stream stream);

        /// <summary>
        /// Synchronously updates all configuration objects which are currently in the cache.
        /// </summary>
        void Refresh();

        /// <summary>
        /// Asynchronously updates all configuration objects in the cache.
        /// </summary>
        /// <param name="callback">The callback method to be invoked when the operation completes.</param>
        /// <returns>The async result associated with this operation.</returns>
        IAsyncResult BeginRefresh(AsyncCallback callback);

        /// <summary>
        /// To be called when the asynchronous refresh operation is complete. If called before 
        /// the refresh operation completes, this method will block until completion.
        /// </summary>
        /// <param name="asyncResult">The async result associated with the current operation</param>
        void EndRefresh(IAsyncResult asyncResult);

        /// <summary>
        /// Returns the current policy associated with this cache.
        /// </summary>
        IConfCachePolicy Policy
        {
            get;
        }
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// The default policy for a configuration service which has caching
    /// enabled.
    /// </summary>
    public sealed class CachingConfServicePolicy : IConfServicePolicy
    {
        bool validateBeforeSave = true;

        #region IConfServicePolicy Members

        /// <summary>
        /// Determines whether the cache should be queried before a retrieve operation
        /// is performed.
        /// </summary>
        /// <param name="query">This parameter is ignored</param>
        /// <returns>false for all queries</returns>
        public bool QueryCacheOnRetrieve(ICfgQuery query)
        {
            return false;
        }

        /// <summary>
        /// Determines whether the cache should be queried before a retrieve multiple
        /// operation is performed.
        /// </summary>
        /// <param name="query">This parameter is ignored</param>
        /// <returns>false for all queries</returns>
        public bool QueryCacheOnRetrieveMultiple(ICfgQuery query)
        {
            return false;
        }

        /// <summary>
        /// Determines whether the properties of an object should be validated
        /// for correctness before a save operation is attempted. True by default.
        /// </summary>
        public bool ValidateBeforeSave
        {
            get { return validateBeforeSave; }
            set { validateBeforeSave = value; }
        }

        /// <summary>
        /// Determines whether the specified object should be cached upon being
        /// retrieved from the configuration server.
        /// </summary>
        /// <param name="obj">This paramter is ignored</param>
        /// <returns>true for all objects</returns>
        public bool CacheOnRetrieve(ICfgObject obj)
        {
            return true;
        }

        /// <summary>
        /// Determines whether the specified object should be cached upon being
        /// saved in the configuration server.
        /// </summary>
        /// <param name="obj">This paramter is ignored</param>
        /// <returns>true for all objects</returns>
        public bool CacheOnSave(ICfgObject obj)
        {
            return true;
        }

        /// <summary>
        /// Determines whether link resolution should be attempted through the cache
        /// before querying the configuration server (link resolution refers to
        /// the automatic retrieval of configuration objects when certain 
        /// properties are accessed).
        /// </summary>
        /// <param name="objectType">This parameter is ignored</param>
        /// <returns>true for all object types</returns>
        public bool AttemptLinkResolutionThroughCache(CfgObjectType objectType)
        {
            return true;
        }

        /// <summary>
        /// Determines whether an existing cached object should be overwritten 
        /// if a newer copy is retrieved from configuration server. 
        /// </summary>
        /// <param name="newObj">This parameter is ignored</param>
        /// <returns>false for all objects</returns>
        public bool OverwriteCachedVersionOnRetrieve(ICfgObject newObj)
        {
            return false;
        }

        #endregion
    }
}

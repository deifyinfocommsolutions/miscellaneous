//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================


using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using System.Xml.Linq;
using Genesyslab.Platform.Commons;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CapacityRules
{

  /// <summary>
  /// This is an exception that CapacityRule's classes throw in case of abnormal flow.
  /// See exception's message for more detailed information.
  /// </summary>

  [Serializable]
  public class CapacityRuleException : PlatformException
  {
    /// <summary>
    /// Creates the exception class.
    /// </summary>
    public CapacityRuleException()
      : base()
    {
    }

    /// <summary>
    /// Creates the exception class.
    /// <param name="innerException">the inner exception</param>
    /// <param name="message">exception message</param>
    /// </summary>
    public CapacityRuleException(string message, Exception innerException)
      : base(message, innerException)
    {
    }

    /// <summary>
    /// Creates the exception class.
    /// </summary>
    /// <param name="message">Exception Message.</param>
    public CapacityRuleException(string message)
      : base(message)
    {
    }

    /// <summary>
    /// Creates the exception class.
    /// <param name="context">see context parameter for Exception class</param>
    /// <param name="info">see info parameter for Exception class</param>
    /// </summary>

    protected CapacityRuleException(SerializationInfo info, StreamingContext context)
      : base(info, context)
    {
    }

  }

  /// <summary>
  /// Helper class to create binary presentation of CapacityRule from XML. 
  /// </summary>
  internal class CapacityRule
  {

    private ICapacityRuleReader _reader;
    private ICapacityRuleWriter _writer;
    public XDocument Document { get; private set; }
    internal OnMediaRuleChanged OnRuleChanged;


    private CRHeader _header;
    public byte[] BinaryData { get; private set; }
    public Dictionary<string, int> SimpleMediaMap { get; private set; }

    private CapacityRule(XDocument document)
    {
      Document = document;
    }

    /// <summary>
    /// Creates an instance of class
    /// </summary>
    /// <param name="document">XDocument which contains capacity rules</param>
    /// <returns>Instance of capacity rules class. Rules will be transformed into DNF during execution</returns>
    /// <exception cref="PlatformException">See exception message to identify of problem</exception>
    public static CapacityRule CreateFromXML(XDocument document)
    {
      return CreateFromXML(document, null);
    }
    /// <summary>
    /// Creates an instance of class
    /// </summary>
    /// <param name="document">XDocument which contains capacity rules</param>
    /// <param name="onChanged">Event, which will be invoked each transformation of rule</param>
    /// <returns>Instance of capacity rules class. Rules will be transformed into DNF during execution</returns>
    /// <exception cref="PlatformException">See exception message to identify of problem</exception>
    public static CapacityRule CreateFromXML(XDocument document, OnMediaRuleChanged onChanged)
    {
      return CreateFromXML(document, null, onChanged);
    }

    internal static CapacityRule CreateFromXML(XDocument document, ICapacityRuleFactory factory,
                                               OnMediaRuleChanged onChanged)
    {
      if (factory == null) factory = new CapacityRuleInternalFactory();
      var rule = new CapacityRule(document)
                   {
                     _reader = factory.Reader,
                     _writer = factory.Writer,
                     OnRuleChanged = onChanged
                   };
      rule.Create();
      return rule;
    }

    private void Create()
    {
      _reader.SetSource(Document);
      _reader.OnProcessElement += OnProcessElement;
      _reader.Process();
      if ((_header != null) && (_writer != null))
      {
        _header.Write(_writer);
        BinaryData = _writer.GetBuffer();
      }
      CreateSimpleMediaMap();
    }
    private void CreateSimpleMediaMap()
    {
      SimpleMediaMap = null;
      if (_header == null) return ;
      if (_header.MediaMap == null) return;
      if (_header.MediaDir == null) return;
      var map = new Dictionary<string, int>();
      foreach (var media in _header.MediaDir.AMediaDirEntry)
      {
        foreach (var entry in _header.MediaMap.AMediaMapEntry)
        {
          if (entry.MediaType!=media.MediaType) continue;
          if (entry.MediaName.Equals(media.MediaName,StringComparison.CurrentCultureIgnoreCase))
          {
            int maxCapacity = 0;
            foreach (var blockEntry in media.RuleBlock.ARuleBlockEntry)
            {
              blockEntry.MediaRule.Rule.CalcMaxMediaValue(entry.MediaType, ref maxCapacity);
            }
            if (maxCapacity>0)
              map.Add(entry.MediaName, maxCapacity);
          }
        }
      }
      SimpleMediaMap = map;
    }

    private void OnProcessElement(object sender, EventArgs args)
    {
      var eArgs = args as EnterElementArgs;
      var reader = sender as ICapacityRuleReader;
      if ((eArgs != null) && (reader!=null)) // OnEnterElement
      {
        if (eArgs.Element != null)
        {
          if (eArgs.Element.Name.LocalName.Equals(CRHeader.TagName, StringComparison.InvariantCultureIgnoreCase))
          {
            _reader.OnProcessElement -= OnProcessElement;
            _header = new CRHeader(reader, this);
          }
        }
      }
    }
    /// <summary>
    /// Validates rule. 
    /// </summary>
    /// <returns>True if validation successful otherwise - false</returns>
    public bool Validate()
    {
      return Validate(false);
    }

    /// <summary>
    /// Validates rule. 
    /// </summary>
    /// <param name="outValidationTable">Flag. Writing full table of validation in report</param>
    /// <returns>True if validation successful otherwise - false</returns>
    public virtual bool Validate(bool outValidationTable)
    {
      if (_header == null) return SetValidationError("Error in header");
      if (_header.MediaDir == null) return SetValidationError("Error in media dir");
      if (_header.MediaMap == null) return SetValidationError("Error in media map");
      if (_header.MediaDir.AMediaDirEntry == null) return SetValidationError("Error in media dir entry");
      var sb = new StringBuilder();
      var result = true;
      foreach (var entry in _header.MediaDir.AMediaDirEntry)
      {
        if (entry.RuleBlock == null) return SetValidationError("Error in rule block");
        if (entry.RuleBlock.ARuleBlockEntry == null) return SetValidationError("Error in rule block entry");
        foreach (var blockEntry in entry.RuleBlock.ARuleBlockEntry)
        {
          if (blockEntry.MediaRule == null) return SetValidationError("Error in media rule");
          sb.AppendLine("***********************************  Checking rule...  ***********************************");
          sb.AppendLine("Original rule: "+ blockEntry.MediaRule.OriginalRule);
          sb.AppendLine("Result rule  : "+ blockEntry.MediaRule.Rule);
          sb.AppendLine("\n");
          var newSb = blockEntry.MediaRule.ValidateRule(_header.MediaMap);
          sb.AppendLine(newSb != null ? newSb.ToString() : "Success");
          result &= (newSb == null);
          if (outValidationTable)
          {
            newSb = blockEntry.MediaRule.ValidateRuleTable(_header.MediaMap);
            if (newSb != null)
            {
              sb.AppendLine("\nValidation table:");
              sb.AppendLine(newSb.ToString());
            }
          }
        }
      }
      ValidationResult = sb;
      return result;
    }
    /// <summary>
    /// Returns detailed validation result
    /// </summary>
    public StringBuilder ValidationResult { get; private set; }

    private bool SetValidationError(String value)
    {
      ValidationResult = new StringBuilder(value);
      return false;
    }

    #region ToString()

    public override string ToString()
    {
      return (_header != null) ? _header.ToString() : "";
    }

    #endregion ToString()
  }
}

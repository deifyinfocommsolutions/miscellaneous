//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Genesyslab.Platform.Commons;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CapacityRules
{
  internal interface ICapacityRuleExternalValidator
  {
    bool Validate();
  }
  /// <summary>
  /// Class for validation XML and binary presentation (or two binary presentations) of capacity rule. 
  /// Builds truth tables for both presentations and compares results
  /// </summary>
  internal class CapacityRuleExternalValidator
  {
    #region Inner classes
    private class CapacityRuleContainer
    {
      internal readonly List<string> MediaList = new List<string>();
      internal readonly List<int> MaxMediaCapacity = new List<int>();
      internal readonly List<AbstractRule> Rules = new List<AbstractRule>();
      internal CapacityRuleContainer Clone()
      {
        var container = new CapacityRuleContainer();
        foreach (string s in MediaList) { container.MediaList.Add(s); }
        foreach (int i in MaxMediaCapacity) { container.MaxMediaCapacity.Add(i); }
        foreach (AbstractRule rule in Rules) { container.Rules.Add(rule.Clone(container, null)); }
        return container;
      }
      internal bool IsEqualsTo(CapacityRuleContainer container)
      {
        if (MediaList.Count != container.MediaList.Count) return false;
        while (MediaList.Count>0)
        {
          int index = -1;
          for (int i = 0; i < container.MediaList.Count; i++)
          {
            if (MediaList[0].Equals(container.MediaList[i],StringComparison.InvariantCultureIgnoreCase))
            {
              index = i;
              break;
            }
          }
          if (index < 0) return false;
          container.MediaList.RemoveAt(index);
          MediaList.RemoveAt(0);
        }
        if (Rules.Count != container.Rules.Count) return false;
        while (Rules.Count > 0)
        {
          int index = -1;
          for (int i = 0; i < container.Rules.Count; i++)
          {
            if (Rules[0].IsEqualsTo(container.Rules[i]))
            {
              index = i;
              break;
            }
          }
          if (index < 0) return false;
          container.Rules.RemoveAt(index);
          Rules.RemoveAt(0);
        }
        return true;
      }
    }
    #region Rule Structure
    private enum ComplexRuleType
    {
      Or = 1,
      And = 2
    }
    private abstract class AbstractRule
    {
      protected CapacityRuleContainer Root;
      protected AbstractRule Parent;

      internal abstract bool Calculate(int[] values);

      protected AbstractRule(CapacityRuleContainer root, AbstractRule parent)
      {
        Root = root;
        Parent = parent;
      }
      internal virtual void LoadFromXml(XElement element)
      {}

      protected internal abstract void UpdateMediaType();
      protected internal abstract void ExpandAny();
      protected internal abstract AbstractRule Clone(CapacityRuleContainer root, AbstractRule parent);
      protected internal abstract bool IsEqualsTo(AbstractRule rule);
    }
    private class ElementaryRule:AbstractRule
    {
      private string _mediaName;
      private int _mediaType;
      private int _capacity;
      protected internal override bool IsEqualsTo(AbstractRule rule)
      {
        var eRule = rule as ElementaryRule;
        if (eRule==null) return false;
        if (eRule._mediaType != _mediaType) return false;
        if (eRule._capacity != _capacity) return false;
        return true;
      }
      protected internal override AbstractRule Clone(CapacityRuleContainer root, AbstractRule parent)
      {
        var rule = new ElementaryRule(root, parent, _mediaType, _capacity);
        rule._mediaName = _mediaName;
        return rule;
      }
      public ElementaryRule(CapacityRuleContainer root, AbstractRule parent, string mediaName, string capacity)
        : base(root, parent)
      {
        _mediaType = -1;
        _mediaName = mediaName;
        _capacity = Int32.Parse(capacity);
      }
      public ElementaryRule(CapacityRuleContainer root, AbstractRule parent, int mediaType, int capacity)
        : base(root, parent)
      {
        _capacity = capacity;
        _mediaName = "";
        _mediaType = mediaType;
      }
      protected internal override void UpdateMediaType()
      {
        if (_mediaType>=0) return;
        if (_mediaName=="") return;
        for (int i = 0; i < Root.MediaList.Count; i++)
        {
          if (_mediaName.Equals(Root.MediaList[i], StringComparison.InvariantCultureIgnoreCase))
          {
            _mediaType = i;
            return;
          }
        }
        throw new CapacityRuleException("Capacity rule validation error: error media name  '" + _mediaName + "'");
      }
      protected internal override void ExpandAny()
      {
        if (Parent is ComplexRule)
        if ((this._mediaName=="") && (_mediaType<0))
        {
          if ((Parent as ComplexRule).Type == ComplexRuleType.Or)
          {
            var list = new List<int>();
            foreach (var rule in Root.Rules)
            {
              var rrule = rule as CapacityRuleRoot;
              if (rrule == null) continue;
              if (list.Contains(rrule.MediaType)) continue;
              var eRule = new ElementaryRule(Root, Parent, rrule.MediaType, _capacity);
              list.Add(rrule.MediaType);
              (Parent as ComplexRule).AddRule(eRule);
              if (Root.MaxMediaCapacity[rrule.MediaType] < _capacity)
                Root.MaxMediaCapacity[rrule.MediaType] = _capacity;
            }
            (Parent as ComplexRule).RemoveRule(this);
          }
          if ((Parent as ComplexRule).Type == ComplexRuleType.And)
          {
            var newRule = new ComplexRule(Root, Parent, ComplexRuleType.Or.ToString());
            var list = new List<int>();
            foreach (var rule in Root.Rules)
            {
              var rrule = rule as CapacityRuleRoot;
              if (rrule == null) continue;
              if (list.Contains(rrule.MediaType)) continue;
              var eRule = new ElementaryRule(Root, Parent, rrule.MediaType, _capacity);
              list.Add(rrule.MediaType);
              newRule.AddRule(eRule);
              if (Root.MaxMediaCapacity[rrule.MediaType] < _capacity)
                Root.MaxMediaCapacity[rrule.MediaType] = _capacity;
            }
            (Parent as ComplexRule).RemoveRule(this);
            (Parent as ComplexRule).AddRule(newRule);
          }
        }
        else
        {
          if (Root.MaxMediaCapacity[_mediaType] < _capacity) Root.MaxMediaCapacity[_mediaType] = _capacity;
        }
      }
      internal override bool Calculate(int[] values)
      {
        if (_mediaType < 0) return true;
        if (_mediaType >= values.Length) return true;
        return (values[_mediaType] >= _capacity);
      }
    }
    private class ComplexRule:AbstractRule
    {
      internal ComplexRuleType Type;
      private List<AbstractRule> _childRules = new List<AbstractRule>();
      public ComplexRule(CapacityRuleContainer root, AbstractRule parent, string condition):base(root,parent)
      {
        Type = (ComplexRuleType)Enum.Parse(typeof(ComplexRuleType), condition, true);
      }
      protected internal override AbstractRule Clone(CapacityRuleContainer root, AbstractRule parent)
      {
        var rule = new ComplexRule(root, parent, Type.ToString());
        foreach (AbstractRule childRule in _childRules)
        {
          rule.AddRule(childRule.Clone(root,rule));
        }
        return rule;
      }
      protected internal override bool IsEqualsTo(AbstractRule rule)
      {
        var cRule = rule as ComplexRule;
        if (cRule == null) return false;
        if (cRule.Type != Type) return false;
        if (cRule._childRules.Count != _childRules.Count) return false;
        while (_childRules.Count>0)
        {
          int index = -1;
          for (int i = 0; i < cRule._childRules.Count; i++)
          {
            if (_childRules[0].IsEqualsTo(cRule._childRules[i]))
            {
              index = i;
              break;
            }
          }
          if (index < 0) return false;
          _childRules.RemoveAt(0);
          cRule._childRules.RemoveAt(index);
        }
        return true;
      }
      internal override bool Calculate(int[] values)
      {
        var value = (Type == ComplexRuleType.And);
        foreach (var rule in _childRules)
        {
          if (Type == ComplexRuleType.And)
            value &= rule.Calculate(values);
          if (Type == ComplexRuleType.Or)
            value |= rule.Calculate(values);
        }
        return value;
      }
      internal void AddRule(AbstractRule rule)
      {
        _childRules.Add(rule);
      }
      internal void RemoveRule(AbstractRule rule)
      {
        if (_childRules.Contains(rule)) _childRules.Remove(rule);
      }
      internal override void LoadFromXml(XElement element)
      {
        IEnumerable<XElement> elements = element.GetElementsByPathIgnoreCase("ComplexCondition");
        foreach (var xElement in elements)
        {
          var type = xElement.GetAttributeByLocalNameIgnoreCase("type");
          if (type == null) continue;
          var compCond = new ComplexRule(Root, this, type.Value);
          compCond.LoadFromXml(xElement);
          AddRule(compCond);
        }
        elements = element.GetElementsByPathIgnoreCase("ElementaryRule");
        foreach (var xElement in elements)
        {
          var media = xElement.GetAttributeByLocalNameIgnoreCase("media");
          if (media == null) continue;
          var capacity = xElement.GetAttributeByLocalNameIgnoreCase("capacity");
          if (capacity == null) continue;
          var rule = new ElementaryRule(Root, this, media.Value, capacity.Value);
          AddRule(rule);
        }
      }
      protected internal override void UpdateMediaType()
      {
        foreach (var rule in _childRules)
        {
          rule.UpdateMediaType();
        }
      }
      protected internal override void ExpandAny()
      {
        var lRules = _childRules.ToList();
        foreach (var rule in lRules)
        {
          rule.ExpandAny();
        }
      }
    }
    private class CapacityRuleRoot:AbstractRule
    {
      internal AbstractRule RootRule;
      internal int MediaType;
      internal string MediaName;
      internal int Priority;
      public CapacityRuleRoot(CapacityRuleContainer root, AbstractRule parent, string name) : base(root, parent)
      {
        RootRule = null;
        MediaName = name;
        MediaType = -1;
        Priority = -1;
      }
      public CapacityRuleRoot(CapacityRuleContainer root, AbstractRule parent, int type)
        : base(root, parent)
      {
        RootRule = null;
        MediaName = "";
        MediaType = type;
        Priority = -1;
      }
      protected internal override AbstractRule Clone(CapacityRuleContainer root, AbstractRule parent)
      {
        var rule =  new CapacityRuleRoot(root, parent, MediaType);
        rule.RootRule = RootRule.Clone(root, this);
        rule.MediaName = MediaName;
        rule.Priority = Priority;
        return rule;
      }

      protected internal override bool IsEqualsTo(AbstractRule rule)
      {
        var rRule = rule as CapacityRuleRoot;
        if (rRule == null) return false;
        if ((RootRule == null) && (rRule.RootRule==null)) return true;
        if ((RootRule == null) || (rRule.RootRule == null)) return false;
        if (Priority != rRule.Priority) return false;
        return RootRule.IsEqualsTo(rRule.RootRule);
      }

      internal override bool Calculate(int[] values)
      {
        if (RootRule == null) return true;
        return RootRule.Calculate(values);
      }
      internal override void LoadFromXml(XElement element)
      {
        IEnumerable<XElement> elements = element.GetElementsByPathIgnoreCase("ComplexCondition");
        if (elements.Count()>1) RootRule = new ComplexRule(Root, this, "Or");
        foreach (var xElement in elements)
        {
          var type = xElement.GetAttributeByLocalNameIgnoreCase("type");
          if (type==null) continue;
          var compCond = new ComplexRule(Root, RootRule, type.Value);
          compCond.LoadFromXml(xElement);
          if (RootRule == null) RootRule = compCond;
          else
          {
            if (RootRule is ComplexRule) 
              (RootRule as ComplexRule).AddRule(compCond);
          }
        }
        if (RootRule == null) RootRule = new ComplexRule(Root, this, "Or");
        elements = element.GetElementsByPathIgnoreCase("ElementaryRule");
        foreach (var xElement in elements)
        {
          var media = xElement.GetAttributeByLocalNameIgnoreCase("media");
          if (media==null) continue;
          var capacity = xElement.GetAttributeByLocalNameIgnoreCase("capacity");
          if (capacity==null) continue;
          var rule = new ElementaryRule(Root, RootRule, media.Value, capacity.Value);
          if (RootRule is ComplexRule)
            (RootRule as ComplexRule).AddRule(rule);
        }
      }

      protected internal override void UpdateMediaType()
      {
        if (RootRule!=null) RootRule.UpdateMediaType();
        if (MediaType >= 0) return;
        for (int i = 0; i < Root.MediaList.Count; i++)
        {
          if (MediaName.Equals(Root.MediaList[i], StringComparison.InvariantCultureIgnoreCase))
          {
            MediaType = i;
            return;
          }
        }
        throw new CapacityRuleException("Capacity rule validation error: error media name  '" + MediaName + "'");
      }
      protected internal override void ExpandAny()
      {
        if (RootRule != null) RootRule.ExpandAny();
      }

    }
    #endregion Rule Structure
    #endregion Inner classes

    private readonly CapacityRule _sourceRule;
    private CapacityRuleContainer _firstRule;
    private CapacityRuleContainer _secondRule;


    internal CapacityRuleExternalValidator(CapacityRule rule)
    {
      _sourceRule = rule;
      _firstRule = CreateFromXML(_sourceRule.Document);
      _secondRule = CreateFromBinary(_sourceRule.BinaryData);
    }
    /// <summary>
    /// Creates instance of validator of the capacity rules 
    /// </summary>
    /// <param name="document">XML-presentation of capacity rule</param>
    /// <param name="data">Binary-presentation of capacity rule</param>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If data or document are null</exception>
    public CapacityRuleExternalValidator(XDocument document, byte[] data)
    {
      if (document==null)
        throw new ArgumentNullException("document");
      if (data == null)
        throw new ArgumentNullException("data");
      _sourceRule = null;
      _firstRule = CreateFromXML(document);
      _secondRule = CreateFromBinary(data);
    }
    /// <summary>
    /// Creates instance of validator of the capacity rules 
    /// </summary>
    /// <param name="data1">Binary-presentation of the first capacity rule</param>
    /// <param name="data2">Binary-presentation of the second capacity rule</param>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If data or document are null</exception>
    public CapacityRuleExternalValidator(byte[] data1, byte[] data2)
    {
      if (data1 == null)
        throw new ArgumentNullException("data1");
      if (data2 == null)
        throw new ArgumentNullException("data2");
      _sourceRule = null;
      _firstRule = CreateFromBinary(data1);
      _secondRule = CreateFromBinary(data2);
    }
    private CapacityRuleContainer CreateFromXML(XDocument doc)
    {
      if (doc == null)
        throw new CapacityRuleException("CapacityRuleExternalValidator: document can not be null");
      if (doc.Root==null)
        throw new CapacityRuleException("CapacityRuleExternalValidator: do not use empty document.");
      var newRule = new CapacityRuleContainer();
      var mediaNames = doc.Root.GetElementByPathIgnoreCase("MediaTypes");
      if (mediaNames==null)
        throw new CapacityRuleException("CapacityRuleExternalValidator: invalid document format. Section 'MediaTypes' is empty.");
      foreach (var element in mediaNames.Elements())
      {
        if (element.Name.LocalName.Equals("Media",StringComparison.InvariantCultureIgnoreCase))
        {
          var attr = element.GetAttributeByLocalNameIgnoreCase("name");
          if (attr != null) 
          {
            newRule.MediaList.Add(attr.Value);
            newRule.MaxMediaCapacity.Add(0);
          }
        }
      }
      var mediaRules = doc.Root.GetElementsByPathIgnoreCase("MediaRule");
      if (mediaRules == null)
        throw new CapacityRuleException("CapacityRuleExternalValidator: invalid document format. Section 'MediaRule' is empty.");
      foreach (var xElement in mediaRules)
      {
        var name = xElement.GetAttributeByLocalNameIgnoreCase("media");
        if (name==null) continue;
        if (String.IsNullOrEmpty(name.Value)) continue;
        var rule = new CapacityRuleRoot(newRule, null, name.Value);
        var priorityAttr = xElement.GetAttributeByLocalNameIgnoreCase("priority");
        if ((priorityAttr!=null) && !(String.IsNullOrEmpty(priorityAttr.Value)))
        {
          int priority;
          if (Int32.TryParse(priorityAttr.Value, out priority)) rule.Priority = priority;
        }
        rule.LoadFromXml(xElement);
        newRule.Rules.Add(rule);
      }
      foreach (var rule in newRule.Rules)
      {
        rule.UpdateMediaType();
      }
      foreach (var rule in newRule.Rules)
      {
        rule.ExpandAny();
      }
      return newRule;
    }

    private CapacityRuleContainer CreateFromBinary(byte[] data)
    {
      if (data == null)
        throw new CapacityRuleException("CapacityRuleExternalValidator: binary data can not be null");
      const int mediaRulesOffset = 0x08;
      const int mediaNamesOffset = 0x0C;
      int mainRulesOffset = data.GetInt(mediaRulesOffset);
      int mediaOffset = data.GetInt(mediaNamesOffset);
      var newRule = new CapacityRuleContainer();
      var tmpDict = new Dictionary<int, string>();
      for (int i=0;i<data[mediaOffset];i++)
      {
        int strOfs = data.GetInt(mediaOffset + 2 + 5*i);
        int mediaIndex = data[mediaOffset + 1 + 5*i];
        tmpDict.Add(mediaIndex, data.GetString(strOfs));
      }
      for (int i = 0; i < data[mediaOffset]; i++)
      {
        if (!tmpDict.ContainsKey(i)) throw new CapacityRuleException("Error read binary media");
        newRule.MediaList.Add(tmpDict[i]);
        newRule.MaxMediaCapacity.Add(0);
      }
      for (int i = 0; i < data[mainRulesOffset]; i++) // rulesOffset = 0x14
      {
        int ruleBlockOffset = mainRulesOffset + 1 + 5 * i; // 0x15
        int rulesOffset = data.GetInt(ruleBlockOffset+1); // 0x29
        for (int j = 0; j < data[rulesOffset]; j++) //0x02
        {
          var rule = new CapacityRuleRoot(newRule, null, data[ruleBlockOffset]);
          rule.Priority = data[rulesOffset+1];
          newRule.Rules.Add(rule);
          int ruleOffset = data.GetInt(rulesOffset + 2 + 5 * j); // 34
          var rootRule = new ComplexRule(newRule, rule, "Or");
          for (int k = 0; k < data[ruleOffset]; k++)
          {
            int andRuleOffset = data.GetInt(ruleOffset + 1 + 4*k); //39
            var ruleAnd = new ComplexRule(newRule, rootRule, "And");
            rootRule.AddRule(ruleAnd);
            for (int l=0;l<data[andRuleOffset];l++)
            {
              int mType = data[andRuleOffset + 1 + 2*l];
              int cap = data[andRuleOffset + 2 + 2*l];
              var eRule = new ElementaryRule(newRule, ruleAnd, mType, cap);
              ruleAnd.AddRule(eRule);
              if (newRule.MaxMediaCapacity[mType] < cap) newRule.MaxMediaCapacity[mType] = cap;
            }
          }
          rule.RootRule = rootRule;
        }
      }
      return newRule;
    }
    private Dictionary<int,int> MatchMedia(CapacityRuleContainer firstRule, CapacityRuleContainer secondRule)
    {
      var matchTable = new Dictionary<int, int>();
      for (int xmlIndex=0;xmlIndex<firstRule.MediaList.Count;xmlIndex++)
      {
        matchTable.Add(xmlIndex,-1);
        for (int binaryIndex=0; binaryIndex< secondRule.MediaList.Count;binaryIndex++)
        {
          if (firstRule.MediaList[xmlIndex].Equals(secondRule.MediaList[binaryIndex],StringComparison.InvariantCultureIgnoreCase))
          {
            matchTable[xmlIndex] = binaryIndex;
          }
        }
        if (matchTable[xmlIndex] < 0)
          throw new CapacityRuleException("Media lists in xml-rule and binary rule are not matched");
      }
      return matchTable;
    }
    private bool Validate(Dictionary<int,int> matchTable, int[] values, int[] binValues, 
                          int index, int xmlRuleIndex, int binRuleIndex, StringBuilder error)
    {
      if (index!=values.Length)
      {
        int maxValue = Math.Max(_firstRule.MaxMediaCapacity[index], _secondRule.MaxMediaCapacity[matchTable[index]]);
        bool result = true;
        for (int val = 0; val <= maxValue; val++)
        {
          values[index] = val;
          result &= Validate(matchTable, values, binValues, index+1, xmlRuleIndex, binRuleIndex, error);
        }
        return result;
      }
      for (int i = 0; i < values.Length; i++)
        binValues[i] = values[matchTable[i]];
      var xmlResult = _firstRule.Rules[xmlRuleIndex].Calculate(values);
      var binResult = _secondRule.Rules[binRuleIndex].Calculate(binValues);
      if (xmlResult != binResult)
      {
        for (int i=0;i<values.Length;i++)
        {
          if (i > 0) error.Append(" ");
          error.Append(values[i].ToString("000"));
        }
        error.Append("  [1]=").Append(xmlResult).Append("  => ");
        for (int i = 0; i < binValues.Length; i++)
        {
          if (i > 0) error.Append(" ");
          error.Append(binValues[i].ToString("000"));
        }
        error.Append("  [2]=").Append(binResult).AppendLine();
      }
      return xmlResult == binResult;
    }
    public bool Validate()
    {
      var matchTable = MatchMedia(_firstRule, _secondRule);
      var report = new StringBuilder();
      if (_firstRule.Rules.Count != _secondRule.Rules.Count)
      {
        report.AppendLine("ERROR: Compared rules lists have different number of rules.");
        ValidationReport = report;
        return false;
      }
      bool result = true;
      for (int mediaIndex=0;mediaIndex<_firstRule.MediaList.Count;mediaIndex++)
      {
        int xmlMediaRuleIndex = 0;
        for (int i=0;i<_firstRule.Rules.Count;i++)
        {
          var xmlCurrentRule = _firstRule.Rules[i] as CapacityRuleRoot;
          if (xmlCurrentRule==null) continue;
          if (xmlCurrentRule.MediaType!=mediaIndex) continue;
          xmlMediaRuleIndex++;
          int binMediaRuleIndex = 0;
          for (int j = 0; j < _secondRule.Rules.Count; j++)
          {
            var binCurrentRule = _secondRule.Rules[j] as CapacityRuleRoot;
            if (binCurrentRule == null) continue;
            if (binCurrentRule.MediaType!=mediaIndex) continue;
            binMediaRuleIndex++;
            if (binMediaRuleIndex!=xmlMediaRuleIndex) continue;
            var values = new int[matchTable.Count];
            var binValues = new int[values.Length];
            result &= Validate(matchTable, values, binValues, 0, i, j, report);
            break;
          }
        }
      }
      ValidationReport = report;
      return result;
    }

    public StringBuilder ValidationReport { get; private set; }

    public bool IsBinaryEquals()
    {
      if (_firstRule.Rules.Count != _secondRule.Rules.Count) return false;
      var firstRule = _firstRule.Clone();
      var secondRule = _secondRule.Clone();
      return firstRule.IsEqualsTo(secondRule);
    }
  }
  internal static class ByteArrayExtentions
  {
    public static int GetInt(this byte[] data, int index)
    {
      int value = 0;
      index += 3;
      value += data[index--];
      value <<= 8;
      value += data[index--];
      value <<= 8;
      value += data[index--];
      value <<= 8;
      value += data[index];
      return value;
    }
    public static string GetString(this byte[] data, int index)
    {
      var sb = new StringBuilder();
      while (data[index]>0)
      {
        sb.Append((char) data[index++]);
      }
      return sb.ToString();
    }
  }
}

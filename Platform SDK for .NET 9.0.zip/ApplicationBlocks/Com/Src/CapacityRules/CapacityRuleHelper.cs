//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Xml.Linq;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.Commons;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CapacityRules
{
  /// <summary>
  /// Enum represents validation result
  /// </summary>
  public enum CapacityRuleValidationResult
  {
    /// <exclude/>
    Unknown,
    /// <exclude/>
    Failed,
    /// <exclude/>
    Success
  }
  /// <summary>
  /// Helper class to retrieving CapacityRule data from CfgScript object.
  /// </summary>
  /// <example>
  /// Example of using helper-class
  /// <code>
  /// public static void Test(string host, int port, string client, int app, string user, string password, string ruleName)
  /// {
  ///   var prot = new ConfServerProtocol(new Endpoint(host, port))
  ///   {
  ///     ClientApplicationType = app,
  ///     ClientName = client,
  ///     UserName = user,
  ///     UserPassword = password
  ///   };
  ///   var service = (ConfService)ConfServiceFactory.CreateConfService(prot);
  ///   service.Protocol.Open();
  ///   var obj =(CfgScript)service.RetrieveObject
  ///               (new CfgScriptQuery(service) {ScriptType = CfgScriptType.CFGCapacityRule, Name = ruleName});
  ///   var helper = CapacityRuleHelper.Create(obj);
  ///   var xml = helper.XMLPresentation;
  ///   // edit xml here
  ///   helper.EnableValidation = true;
  ///   helper.XMLPresentation = xml;
  ///   if (helper.ValidationResult == CapacityRuleValidationResult.Success )
  ///   {
  ///     helper.Script.Save();  // save valid script
  ///   }
  ///   service.Protocol.Close(); 
  ///   ConfServiceFactory.ReleaseConfService(service);
  /// }
  /// 
  /// </code>
  /// </example>
  public class CapacityRuleHelper
  {
    private const string WizardKey = "_WIZARD_";
    private const string MediaRulesKey = "_CRWizardMediaCapacityList_";
    private const string GuiPresentationKey = "_CRWizardGUIPresentation_";
    private const string BinaryPresentationKey = "_CRWizardBinaryPresentation_";

    private XDocument _document;
    private byte[] _bytesData;
    private CfgScript _cfgScript;
    private readonly object _lockObject = new object();
    /// <summary>
    /// Flag indicates that script does not have any data of capacity rule
    /// </summary>
    public bool IsEmpty { get; private set; }
    /// <summary>
    /// Flag to enable/disable (to increase performance) internal validation of capacity rule.
    /// Set to true before assign new XML-presentation to validate results
    /// </summary>
    public bool EnableValidation { get; set; }
    /// <summary>
    /// Result of validation of capacity rule. 
    /// </summary>
    public CapacityRuleValidationResult ValidationResult { get; private set; }
    private CapacityRuleHelper()
    {
      ValidationResult = CapacityRuleValidationResult.Unknown;
      EnableValidation = false;
    }

    /// <summary>
    /// Creates instance of CapacityRuleHelper class. Verifies script object and retrieves data.
    /// Script can be empty. In this case empty structures will be created.
    /// Script type must be equal <see cref="CfgScriptType.CFGCapacityRule"/>. It's mandatory condition.
    /// If this script should be saved, the property 'Tenant' must be assigned.
    /// </summary>
    /// <param name="cfgScript">instance of CfgScript object</param>
    /// <returns>instance of this helper class</returns>
    /// <exception cref="CapacityRuleException">if script has unknown format</exception>
    /// <exception cref="ArgumentNullException">if script is null</exception>
    public static CapacityRuleHelper Create(CfgScript cfgScript)
    {
      if (cfgScript==null)
        throw new ArgumentNullException("cfgScript");
      if (cfgScript.Type != CfgScriptType.CFGCapacityRule)
      {
        throw new CapacityRuleException("Script has incorrect type. Expected: 'CFGCapacityRule', actual: '" +
                                     (cfgScript.Type==null?"null":cfgScript.Type.ToString()) + "'");
      }
      KeyValueCollection wizardData = null;
      if (cfgScript.UserProperties == null)
      {
        return new CapacityRuleHelper
        {
          _cfgScript = cfgScript,
          _document = null,
          _bytesData = null,
          IsEmpty = true,
        };
      }
      wizardData = cfgScript.UserProperties[WizardKey] as KeyValueCollection;
      if (wizardData == null)
      {
        return new CapacityRuleHelper
        {
          _cfgScript = cfgScript,
          _document = null,
          _bytesData = null,
          IsEmpty = true,
        };
      }
      var guiPresentation = wizardData[GuiPresentationKey] as byte[];
      var binaryPresentation = wizardData[BinaryPresentationKey] as byte[];
      if ((guiPresentation == null) || (binaryPresentation == null)) 
      {
        guiPresentation = null;
        binaryPresentation = null;
        wizardData.Remove(GuiPresentationKey);
        wizardData.Remove(BinaryPresentationKey);
      }
      XDocument document = null;
      if (guiPresentation != null)
      {
        var xmlData = Encoding.UTF8.GetString(guiPresentation);
        while (xmlData[xmlData.Length - 1] == 0) xmlData = xmlData.Remove(xmlData.Length - 1); // remove tail zeros
        document = XDocument.Parse(xmlData);
      }

      return new CapacityRuleHelper
               {
                 _cfgScript = cfgScript,
                 _document = document,
                 _bytesData = binaryPresentation,
                 IsEmpty = (document == null),
               };
    }
    /// <summary>
    /// Gets clone or sets new XML presentation of CapacityRule in CfgScript object. 
    /// During setting new XML the new binary data will be created. If there are some problems in source
    /// XML the <see cref="CapacityRuleException"/> can be raised.
    /// Set null value to delete the rule data.
    /// </summary>
    /// <exception cref="CapacityRuleException">If script has unknown format or can not be transformed into DNF</exception>
    public XDocument XMLPresentation
    {
      get
      {
        if (_document == null) return null;
        string strDocument = "";
        lock (_lockObject)
        {
          strDocument = _document.ToString();
        }
        return XDocument.Parse(strDocument);
      }
      set 
      {
        lock (_lockObject)
        {
          if (_cfgScript.UserProperties == null)
            _cfgScript.UserProperties = new KeyValueCollection();
          var wizardData = _cfgScript.UserProperties[WizardKey] as KeyValueCollection;
          if (wizardData == null)
          {
            _cfgScript.UserProperties[WizardKey] = wizardData = new KeyValueCollection();
          }
          if (value == null)
          {
            // deleting the capacity rule data
            wizardData.Remove(GuiPresentationKey);
            wizardData.Remove(BinaryPresentationKey);
            _cfgScript.UserProperties.Remove(MediaRulesKey);
            if (wizardData.Count == 0)
              _cfgScript.UserProperties.Remove(WizardKey);
            _document = null;
            _bytesData = null;
            IsEmpty = true;
            ValidationResult = CapacityRuleValidationResult.Unknown;
            return;
          }
          var rule = CapacityRule.CreateFromXML(value);
          ValidationResult = EnableValidation
                                       ? (
                                           rule.Validate(false)
                                             ? CapacityRuleValidationResult.Success
                                             : CapacityRuleValidationResult.Failed)
                                       : CapacityRuleValidationResult.Unknown;
          _bytesData = rule.BinaryData;
          _document = value;
          if ((_bytesData == null) || (_document==null))
          {
            // deleting the capacity rule data
            wizardData.Remove(GuiPresentationKey);
            wizardData.Remove(BinaryPresentationKey);
            _cfgScript.UserProperties.Remove(MediaRulesKey);
            if (wizardData.Count == 0)
              _cfgScript.UserProperties.Remove(WizardKey);
            _document = null;
            _bytesData = null;
            IsEmpty = true;
            ValidationResult = CapacityRuleValidationResult.Unknown;
            return;
          }
          wizardData[GuiPresentationKey] = Encoding.UTF8.GetBytes(XMLStringData + "\0"); 
          wizardData[BinaryPresentationKey] = _bytesData;
          var map = rule.SimpleMediaMap;
          if (map != null)
          {
            var mapValues = new KeyValueCollection();
            foreach (KeyValuePair<string, int> entry in map)
            {
              mapValues.Add(entry.Key , entry.Value);
            }
            if (_cfgScript.UserProperties[MediaRulesKey]==null)
            {
              _cfgScript.UserProperties.Add(MediaRulesKey,mapValues);
            }else 
            {
              _cfgScript.UserProperties[MediaRulesKey] = mapValues;
            }
          }
          IsEmpty = (_document == null) || (_bytesData == null) || (_bytesData.Length == 0);
        }
      }
    }
    /// <summary>
    /// Returns XML data as string
    /// </summary>
    public string XMLStringData
    {
      get
      {
        if (_document == null) return null;
        lock (_lockObject)
        {
          return _document.Declaration + "\r\n" + _document;
        }
      }
    }
    /// <summary>
    /// Gets binary presentation of CapacityRule in CfgScript object 
    /// </summary>
    public byte[] BinaryPresentation
    {
      get
      {
        lock (_lockObject)
        {
          return _bytesData;
        }
      }
    }
    /// <summary>
    /// return COM AB CfgScript object instance
    /// </summary>
    public CfgScript Script
    {
      get
      {
        lock (_lockObject)
        {
          return _cfgScript;
        }
      }
    }

    #region Static members
    /// <summary>
    /// Builds capacity rule binary data 
    /// </summary>
    /// <param name="document">XML-presentation of capacity rule</param>
    /// <returns>Binary presentation of capacity rule</returns>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If document is null</exception>
    public static byte[] BinaryFromXML(XDocument document)
    {
      if (document == null)
        throw new ArgumentNullException("document");
      return CapacityRule.CreateFromXML(document).BinaryData;
    }
    /// <summary>
    /// Builds capacity rule binary data 
    /// </summary>
    /// <param name="data">XML-presentation of capacity rule as string</param>
    /// <returns>Binary presentation of capacity rule</returns>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If data is null</exception>
    /// <exception cref="ArgumentException">If data is empty</exception>
    public static byte[] BinaryFromXML(string data)
    {
      if (data == null)
        throw new ArgumentNullException("data");
      if (String.IsNullOrEmpty(data))
        throw new ArgumentException("Argument can not be empty", "data");
      return BinaryFromXML(XDocument.Parse(data));
    }
    #endregion 
    #region UseExternalValidator
    /// <summary>
    /// Compares current binary representation of capacity rule with other binary presentation of capacity rule.
    /// Builds truth tables for both representations and compares results
    /// </summary>
    /// <param name="data">Binary representation of capacity rule for comparison</param>
    /// <param name="compareTo">Binary representation of capacity rule for comparison</param>
    /// <param name="report">Output report</param>
    /// <returns>True if both of data are equal</returns>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If document is null</exception>
    public static bool MatchBinaries(byte[] data, byte[] compareTo, out StringBuilder report)
    {
      if (data==null)
      {
        throw new ArgumentNullException("data","Source data can not be null");
      }
      if (compareTo==null)
      {
        throw new ArgumentNullException("compareTo", "Destination data can not be null");
      }
      var validator = new CapacityRuleExternalValidator(data, compareTo);
      var result = validator.Validate();
      report = validator.ValidationReport;
      return result;
    }
    /// <summary>
    /// Compares current binary representation of capacity rule with other binary representation of capacity rule.
    /// Builds truth tables for both representations and compares results
    /// </summary>
    /// <param name="data">Binary representation of capacity rule for comparison with current rule</param>
    /// <param name="report">Output report</param>
    /// <returns>True if both of data are equal</returns>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If data is null</exception>
    public bool MatchBinaries(byte[] data, out StringBuilder report)
    {
      if (BinaryPresentation == null)
      {
        throw new CapacityRuleException("Source data is absent");
      }
      if (data == null)
      {
        throw new ArgumentNullException("data");
      }
      var validator = new CapacityRuleExternalValidator(data, BinaryPresentation);
      var result = validator.Validate();
      report = validator.ValidationReport;
      return result;
    }
    /// <summary>
    /// Compares content of current binary representation of capacity rule with other content of binary presentation of capacity rule.
    /// Order of rules is does not matter.
    /// </summary>
    /// <param name="data">Binary representation of capacity rule for comparison</param>
    /// <param name="compareTo">Binary representation of capacity rule for comparison</param>
    /// <returns>True if both of data are equal</returns>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If document is null</exception>
    public static bool EqualsBinaries(byte[] data, byte[] compareTo)
    {
      if (data == null)
      {
        throw new ArgumentNullException("data", "Source data can not be null");
      }
      if (compareTo == null)
      {
        throw new ArgumentNullException("compareTo", "Destination data can not be null");
      }
      var validator = new CapacityRuleExternalValidator(data, compareTo);
      return validator.IsBinaryEquals();
    }
    /// <summary>
    /// Compares content of current binary representation of capacity rule with other content of binary presentation of capacity rule.
    /// Order of rules is does not matter.
    /// </summary>
    /// <param name="data">Binary representation of capacity rule for comparison with current rule</param>
    /// <returns>True if both of data are equal</returns>
    /// <exception cref="CapacityRuleException">See exception message to identify of problem</exception>
    /// <exception cref="ArgumentNullException">If data is null</exception>
    public bool EqualsBinaries(byte[] data)
    {
      if (BinaryPresentation == null)
      {
        throw new CapacityRuleException("Source data is absent");
      }
      if (data == null)
      {
        throw new ArgumentNullException("data");
      }
      var validator = new CapacityRuleExternalValidator(BinaryPresentation, data);
      return validator.IsBinaryEquals();
    }
    #endregion UseExternalValidator
  }

}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================


using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Genesyslab.Platform.Commons;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CapacityRules
{
  /**************************************************************************
  *       CRHeader              CRMediaDir         CRMediaDirEntry
  *   +-------------+  +->>+-------------------+ / +------------+
  *   | MagicNumber |  |   | cMediaDirEntry    |/  | MediaType  |   
  *   | Size        |  |   | aMediaDirEntry[0] |   | oRuleBlock |--+
  *   | oMediaDir   |--+   | aMediaDirEntry[1] |\  +------------+  |
  *   | oMediaMap   |----+ |    . . .          | \                 |
  *   | oExtension  |--+ | | aMediaDirEntry[N] |                   |  
  *   +-------------+  | | +-------------------+                   |  
  *    +---------------+ |                                         |
  *    | +---------------+                                         |
  *    | | +--------------------------------------------------------+
  *    | | |         CRRuleBlock      CRRuleBlockEntry     
  *    | | +->>+--------------------+ /+-----------+  
  *    | |     | cRuleBlockEntry    |/ | Priority  |      
  *    | |     | aRuleBlockEntry[0] |  | oRuleBody |--+    
  *    | |     | aRuleBlockEntry[1] |\ +-----------+  |    
  *    | |     |    . . .           | \               |    
  *    | |     | aRuleBlockEntry[N] |                 |    
  *    | |     +--------------------+                 |    
  *    | | +------------------------------------------+
  *    | | |     CRRuleBody                CRAndExprBlock    CRElemExpr
  *    | | +->>+-------------------+  +->>+--------------+ /+-----------+
  *    | |     | coAndExprBlock    |  |   | cElemExpr    |/ | MediaType |
  *    | |     | aoAndExprBlock[0] |--+   | aElemExpr[0] |  | Capacity  |
  *    | |     | aoAndExprBlock[1] |      | aElemExpr[1] |\ +-----------+
  *    | |     |    . . .          |      |   . . .      | \
  *    | |     | aoAndExprBlock[N] |      | aElemExpr[N] |
  *    | |     +-------------------+      +--------------+
  *    | |     
  *    | |       CRMediaMap             CRMediaMapEntry
  *    | +--->>+-------------------+ /+------------+
  *    |       | cMediaMapEntry    |/ | MediaType  |
  *    |       | aMediaMapEntry[0] |  | oMediaName |---->ASCIZ string with media system 
  *    |       | aMediaMapEntry[1] |\ +------------+
  *    |       |    . . .          | \
  *    |       | aMediaMapEntry[N] |
  *    |       +-------------------+
  *    |
  *    |   CRExtension
  *    +->>+----------+
  *        | Reserved |
  *        +----------+
  * Legend: c - counter, a - array, o - offset from header, ao - array offsets
  **************************************************************************/

  #region Internal Logic
  /// <exclude/>
  internal static class XElementExtention
  {
    public static XAttribute GetAttributeByLocalNameIgnoreCase(this XElement element, string attrName)
    {
      return element.Attributes().
        FirstOrDefault(
          attribute => attribute.Name.LocalName.Equals(attrName, StringComparison.InvariantCultureIgnoreCase));
    }
    public static XElement GetElementByPathIgnoreCase(this XElement element, string path)
    {
      var pathArray = path.Split(new char[] {'/','\\'});
      return GetElementByPathIgnoreCase(element, pathArray,0);
    }
    public static IEnumerable<XElement> GetElementsByPathIgnoreCase(this XElement element, string path)
    {
      var pathArray = path.Split(new char[] { '/', '\\' });
      return GetElementsByPathIgnoreCase(element, pathArray, 0);
    }
    private static XElement GetElementByPathIgnoreCase(this XElement element, string[] path, int index)
    {
      if (index >= path.Length) return element;
      if (element == null) return null;
      var newElm = element.Elements().FirstOrDefault(
          elm => elm.Name.LocalName.Equals(path[index], StringComparison.InvariantCultureIgnoreCase));
      if (newElm == null) return null;
      return GetElementByPathIgnoreCase(newElm, path, index + 1);
    }
    private static IEnumerable<XElement> GetElementsByPathIgnoreCase(this XElement element, string[] path, int index)
    {
      if (element == null) return null;
      if (index < path.Length - 1)
      {
        var newElm = element.Elements().FirstOrDefault(
          elm => elm.Name.LocalName.Equals(path[index], StringComparison.InvariantCultureIgnoreCase));
        if (newElm == null) return null;
        return GetElementsByPathIgnoreCase(newElm, path, index + 1);
      }
      return element.Elements().Where(
         elm => elm.Name.LocalName.Equals(path[index], StringComparison.InvariantCultureIgnoreCase));
    }
  }
  internal class AbstractWritableCapacityRuleElement
  {
    internal UInt32 Offset { get; set; }
    internal UInt32 Size { get; set; }

    internal virtual object Parent
    {
      get { return null; }
    }

    internal virtual void OnBeginWrite(ICapacityRuleWriter writer)
    {
      Offset = writer.Size;
    }

    internal virtual void OnWrite(ICapacityRuleWriter writer)
    {
    }

    internal virtual void OnEndWrite(ICapacityRuleWriter writer)
    {
      Size = writer.Size - Offset;
    }

    public virtual void Write(ICapacityRuleWriter writer)
    {
      OnBeginWrite(writer);
      OnWrite(writer);
      OnEndWrite(writer);
    }

    protected void OnBeginWrite(ICapacityRuleWriter writer, IEnumerable list)
    {
      if (list == null) return;
      foreach (var item in list)
      {
        if (item is AbstractWritableCapacityRuleElement)
          (item as AbstractWritableCapacityRuleElement).OnBeginWrite(writer);
      }
    }

    protected void OnWrite(ICapacityRuleWriter writer, IEnumerable list)
    {
      if (list == null) return;
      foreach (var item in list)
      {
        if (item is AbstractWritableCapacityRuleElement)
          (item as AbstractWritableCapacityRuleElement).OnWrite(writer);
      }
    }

    protected void OnEndWrite(ICapacityRuleWriter writer, IEnumerable list)
    {
      if (list == null) return;
      foreach (var item in list)
      {
        if (item is AbstractWritableCapacityRuleElement)
          (item as AbstractWritableCapacityRuleElement).OnEndWrite(writer);
      }
    }
  }

  internal class CRElemExpr : AbstractWritableCapacityRuleElement
  {
    internal Byte MediaType;
    internal Byte Capacity;

    private readonly CRAndExprBlock _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRElemExpr(CRAndExprBlock parent)
    {
      _parent = parent;
    }

    #region WriteBinary

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      writer.AddByte(MediaType);
      writer.AddByte(Capacity);
    }

    #endregion WriteBinary
  }

  internal class CRAndExprBlock : AbstractWritableCapacityRuleElement
  {
    internal Byte CElemExpr;
    internal List<CRElemExpr> AElemExpr;

    private readonly CRRuleBody _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRAndExprBlock(CRRuleBody parent)
    {
      _parent = parent;
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      if (AElemExpr == null) return;
      writer.AddUInt32(Offset);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      if (AElemExpr == null) return;
      writer.SetUInt32(Offset, writer.Size);
      writer.AddByte(CElemExpr);
      OnWrite(writer, AElemExpr);
    }

    #endregion WriteBinary
  }

  internal class CRRuleBody : AbstractWritableCapacityRuleElement // Or Expression
  {
    internal Byte COAndExprBlock;
    internal List<CRAndExprBlock> AAndExprBlock;

    private readonly CRRuleBlockEntry _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRRuleBody(CRRuleBlockEntry parent)
    {
      _parent = parent;
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      if (AAndExprBlock == null) return;
      writer.AddByte(COAndExprBlock);
      OnBeginWrite(writer, AAndExprBlock);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      OnWrite(writer, AAndExprBlock);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      OnEndWrite(writer, AAndExprBlock);
    }

    #endregion WriteBinary
  }

  internal class CRRuleBlockEntry : AbstractWritableCapacityRuleElement
  {
    private const Byte DefaultPriority = 0xFF;
    internal Byte Priority;
    internal UInt32 ORuleBody;
    private CRRuleBody _ruleBody;
    internal readonly MediaRule MediaRule;

    private readonly CRRuleBlock _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    private readonly string _priority;

    internal CRRuleBlockEntry(CRRuleBlock parent, ICapacityRuleReader reader, string priority)
    {
      _parent = parent;
      _priority = priority;
      if (!byte.TryParse(_priority, out Priority)) Priority = DefaultPriority;
      MediaRule = new MediaRule(reader, this);
    }

    internal void Process(CRMediaMap map)
    {
      if (MediaRule != null)
      {
        OnMediaRuleChanged onChanged = null;
        object parent = Parent;
        while (parent != null)
        {
          if (parent is CapacityRule)
          {
            onChanged = (parent as CapacityRule).OnRuleChanged;
            break;
          }
          if (parent is AbstractWritableCapacityRuleElement)
          {
            parent = (parent as AbstractWritableCapacityRuleElement).Parent;
          }
          else
          {
            break;
          }
        }
        MediaRule.OnRuleChanged = onChanged;
        _ruleBody = MediaRule.Process(map);
      }
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      if (_ruleBody == null) return;
      writer.AddByte(Priority);
      writer.AddUInt32(ORuleBody);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      if (_ruleBody == null) return;
      _ruleBody.Write(writer);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      base.OnEndWrite(writer);
      if (_ruleBody == null) return;
      ORuleBody = _ruleBody.Offset;
      writer.SetUInt32(Offset + 1, ORuleBody);
    }

    #endregion WriteBinary

    #region ToString()

    public override string ToString()
    {
      var sb =
        new StringBuilder().Append(CRMediaDirEntry.TagAttributePriority).Append("=\"").Append(_priority).Append("\">");
      sb.AppendLine();
      if (MediaRule != null) sb.AppendLine(MediaRule.ToString());
      return sb.ToString();
    }

    #endregion ToString()
  }

  internal class CRRuleBlock : AbstractWritableCapacityRuleElement
  {
    internal Byte CRuleBlockEntry;
    internal List<CRRuleBlockEntry> ARuleBlockEntry;

    private readonly CRMediaDirEntry _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRRuleBlock(CRMediaDirEntry parent, ICapacityRuleReader reader, XElement element)
    {
      _parent = parent;
      ARuleBlockEntry = new List<CRRuleBlockEntry>();
      AddNewRuleBlock(reader, element);
    }

    internal void AddNewRuleBlock(ICapacityRuleReader reader, XElement element)
    {
      var attrP = element.GetAttributeByLocalNameIgnoreCase(CRMediaDirEntry.TagAttributePriority);
      var ruleBlock = new CRRuleBlockEntry(this, reader, attrP == null ? "" : attrP.Value);
      ARuleBlockEntry.Add(ruleBlock);
      CRuleBlockEntry = (Byte)ARuleBlockEntry.Count;
    }

    internal void Process(CRMediaMap map)
    {
      if (ARuleBlockEntry != null)
        foreach (var crRuleBlockEntry in ARuleBlockEntry)
        {
          crRuleBlockEntry.Process(map);
        }
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      if (ARuleBlockEntry == null) return;
      writer.AddByte(CRuleBlockEntry);
      OnBeginWrite(writer, ARuleBlockEntry);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      OnWrite(writer, ARuleBlockEntry);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      base.OnEndWrite(writer);
      OnEndWrite(writer, ARuleBlockEntry);
    }

    #endregion WriteBinary

    #region ToString()

    public override string ToString()
    {
      const string leftMargin = "  ";
      var sb = new StringBuilder();
      foreach (var crRuleBlockEntry in ARuleBlockEntry)
      {
        sb.Append(leftMargin).Append("<").Append(CRMediaDir.TagName).Append(" ")
          .Append(CRMediaDirEntry.TagAttributeName).Append("=\"").Append(_parent.MediaName).Append("\" ");
        sb.Append(crRuleBlockEntry);
        sb.Append(leftMargin).Append("</").Append(CRMediaDir.TagName).AppendLine(">");
      }
      return sb.ToString();

    }

    #endregion ToString();
  };

  internal class CRMediaDirEntry : AbstractWritableCapacityRuleElement
  {
    internal const string TagAttributeName = "media";
    internal const string TagAttributePriority = "priority";
    internal Byte MediaType;
    internal UInt32 ORuleBlock;
    internal readonly CRRuleBlock RuleBlock;

    private readonly CRMediaDir _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal string MediaName { get; private set; }

    private CRMediaDirEntry(CRMediaDir parent, ICapacityRuleReader reader, XElement element)
    {
      var attrN = element.GetAttributeByLocalNameIgnoreCase(TagAttributeName);
      _parent = parent;
      MediaName = (attrN != null) ? attrN.Value : "";
      RuleBlock = new CRRuleBlock(this, reader, element);
    }

    internal void AddNewRuleBlock(ICapacityRuleReader reader, XElement element)
    {
      if (RuleBlock != null) RuleBlock.AddNewRuleBlock(reader, element);
    }

    internal static CRMediaDirEntry Create(CRMediaDir parent, ICapacityRuleReader reader, XElement element)
    {
      var attrN = element.GetAttributeByLocalNameIgnoreCase(TagAttributeName);
      if (attrN == null) return null;
      return new CRMediaDirEntry(parent, reader, element);
    }

    internal void Process(CRMediaMap map)
    {
      if (map == null) return;
      MediaType = map.GetMediaType(MediaName);
      if (RuleBlock != null)
        RuleBlock.Process(map);
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      if (RuleBlock == null) return;
      writer.AddByte(MediaType);
      writer.AddUInt32(ORuleBlock);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      base.OnWrite(writer);
      if (RuleBlock == null) return;
      RuleBlock.Write(writer);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      base.OnEndWrite(writer);
      if (RuleBlock == null) return;
      ORuleBlock = RuleBlock.Offset;
      writer.SetUInt32(Offset + 1, ORuleBlock);
    }

    #endregion

    #region ToString()

    public override string ToString()
    {
      if (RuleBlock != null) return RuleBlock.ToString();
      return base.ToString();
    }

    #endregion ToString()
  }

  internal class CRMediaDir : AbstractWritableCapacityRuleElement
  {
    internal const string TagName = "MediaRule";
    internal Byte CMediaDirEntry;
    internal List<CRMediaDirEntry> AMediaDirEntry;
    private readonly CRHeader _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRMediaDir(CRHeader parent)
    {
      _parent = parent;
    }

    internal void Add(XElement element, ICapacityRuleReader reader)
    {
      if (AMediaDirEntry == null) AMediaDirEntry = new List<CRMediaDirEntry>();
      var attrN = element.GetAttributeByLocalNameIgnoreCase(CRMediaDirEntry.TagAttributeName);
      if (attrN == null) return;
      var dirEntry =
        AMediaDirEntry.Find(entry => entry.MediaName.Equals(attrN.Value, StringComparison.InvariantCultureIgnoreCase));
      if (dirEntry == null)
      {
        var item = CRMediaDirEntry.Create(this, reader, element);
        if (item != null)
        {
          AMediaDirEntry.Add(item);
          CMediaDirEntry = (Byte)AMediaDirEntry.Count;
        }
        return;
      }
      dirEntry.AddNewRuleBlock(reader, element);
    }

    internal void Process(CRMediaMap map)
    {
      if (AMediaDirEntry != null)
      {
        foreach (var crMediaDirEntry in AMediaDirEntry)
        {
          crMediaDirEntry.MediaType = map.GetMediaType(crMediaDirEntry.MediaName);
        }
        foreach (var crMediaDirEntry in AMediaDirEntry)
        {
          crMediaDirEntry.Process(map);
        }
      }
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      writer.AddByte(CMediaDirEntry);
      OnBeginWrite(writer, AMediaDirEntry);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      OnWrite(writer, AMediaDirEntry);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      base.OnEndWrite(writer);
      OnEndWrite(writer, AMediaDirEntry);
    }

    #endregion

    #region ToString()

    public override string ToString()
    {
      var sb = new StringBuilder();
      foreach (var crMediaDirEntry in AMediaDirEntry)
      {
        sb.Append(crMediaDirEntry);
      }
      return sb.ToString();
    }

    #endregion ToString()
  }

  internal class CRMediaMapEntry : AbstractWritableCapacityRuleElement
  {
    internal const string TagName = "Media";
    private const string TagAttribute = "name";
    internal Byte MediaType;
    private UInt32 _offsetMediaName;
    internal Byte MaxCapacity;

    internal string MediaName { get; private set; }

    private readonly CRMediaMap _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    private CRMediaMapEntry(CRMediaMap parent, string name)
    {
      _parent = parent;
      MediaType = parent.CMediaMapEntry;
      MediaName = name;
      MaxCapacity = 0;
    }

    internal static CRMediaMapEntry Create(CRMediaMap parent, XElement element)
    {
      var attr = element.GetAttributeByLocalNameIgnoreCase(TagAttribute);
      if (attr != null)
      {
        return new CRMediaMapEntry(parent, attr.Value);
      }
      return null;
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      writer.AddByte(MediaType);
      writer.AddUInt32(Offset);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      base.OnWrite(writer);
      _offsetMediaName = writer.Size;
      foreach (char t in MediaName)
      {
        writer.AddByte((byte)t);
      }
      writer.AddByte(0);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      base.OnEndWrite(writer);
      writer.SetUInt32(Offset + 1, _offsetMediaName);
    }

    #endregion WriteBinary

    #region ToString()

    public override string ToString()
    {
      return "<Media name=\"" + MediaName + "\"/>";
    }

    #endregion ToString()
  }

  internal class CRMediaMap : AbstractWritableCapacityRuleElement
  {
    internal const string TagName = "MediaTypes";
    internal Byte CMediaMapEntry;
    internal List<CRMediaMapEntry> AMediaMapEntry;

    private readonly CRHeader _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRMediaMap(CRHeader parent, ICapacityRuleReader reader)
    {
      _parent = parent;
      reader.OnProcessElement += OnProcessElement;
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      base.OnBeginWrite(writer);
      if (AMediaMapEntry == null) return;
      writer.AddByte(CMediaMapEntry);
      OnBeginWrite(writer, AMediaMapEntry);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      base.OnWrite(writer);
      OnWrite(writer, AMediaMapEntry);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      base.OnEndWrite(writer);
      OnEndWrite(writer, AMediaMapEntry);
    }

    #endregion WriteBinary

    internal Byte GetMediaType(string name)
    {
      if (AMediaMapEntry == null) throw new CapacityRuleException("No media types in capacity rules");
      foreach (var crMediaMapEntry in AMediaMapEntry)
      {
        if (crMediaMapEntry.MediaName.Equals(name, StringComparison.InvariantCultureIgnoreCase))
          return crMediaMapEntry.MediaType;
      }
      throw new CapacityRuleException("Unknown media name: '" + name + "'");
    }

    private void OnProcessElement(object sender, EventArgs args)
    {
      var eArgs = args as EnterElementArgs;
      if (eArgs != null) // enter element
      {
        if (eArgs.Element != null)
        {
          if (eArgs.Element.Name.LocalName.Equals(CRMediaMapEntry.TagName, StringComparison.InvariantCultureIgnoreCase))
          {
            if (AMediaMapEntry == null) AMediaMapEntry = new List<CRMediaMapEntry>();
            var item = CRMediaMapEntry.Create(this, eArgs.Element);
            if (item != null)
            {
              AMediaMapEntry.Add(item);
              CMediaMapEntry = (Byte)AMediaMapEntry.Count;
            }
          }
        }
      }
      var lArgs = args as LeaveElementArgs;
      if (lArgs != null) // leave element
      {
        if (lArgs.Element != null)
        {
          if ((lArgs.Element.Name.LocalName.Equals(TagName, StringComparison.InvariantCultureIgnoreCase)) &&
              (sender is ICapacityRuleReader))
            (sender as ICapacityRuleReader).OnProcessElement -= OnProcessElement;
        }
      }
    }

    #region ToString()

    public override string ToString()
    {
      const string leftMargin = "  ";
      var sb = new StringBuilder();
      sb.Append(leftMargin).Append("<").Append(TagName).AppendLine(">");
      foreach (var crMediaMapEntry in AMediaMapEntry)
      {
        sb.Append(leftMargin).Append(leftMargin).AppendLine(crMediaMapEntry.ToString());
      }
      sb.Append(leftMargin).Append("</").Append(TagName).AppendLine(">");
      return sb.ToString();
    }

    #endregion ToString()
  }

  internal class CRExtension : AbstractWritableCapacityRuleElement
  {
    internal UInt32 Reserved;

    private readonly CRHeader _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRExtension(CRHeader parent)
    {
      _parent = parent;
      Reserved = 0;
    }
  }

  internal class CRHeader : AbstractWritableCapacityRuleElement
  {
    internal const string TagName = "CapacityRule";
    internal UInt32 MagicNumber = 5450453u;
    internal UInt32 OMediaDir;
    internal UInt32 OMediaMap;
    internal UInt32 OExtension;

    internal CRMediaMap MediaMap;
    internal CRMediaDir MediaDir;
    internal CRExtension Extension;
    private readonly CapacityRule _parent;

    internal override object Parent
    {
      get { return _parent; }
    }

    internal CRHeader(ICapacityRuleReader reader, CapacityRule parent)
    {
      _parent = parent;
      Extension = null;
      reader.OnProcessElement += OnProcessElement;
    }

    private void OnProcessElement(object sender, EventArgs args)
    {
      var reader = sender as ICapacityRuleReader;
      var eArgs = args as EnterElementArgs;
      if ((eArgs != null) && (reader!=null)) // OnEnterElement
      {
        if (eArgs.Element != null)
        {
          if (eArgs.Element.Name.LocalName.Equals(CRMediaMap.TagName, StringComparison.InvariantCultureIgnoreCase))
          {
            if (MediaMap == null) MediaMap = new CRMediaMap(this, reader);
          }
          if (eArgs.Element.Name.LocalName.Equals(CRMediaDir.TagName, StringComparison.InvariantCultureIgnoreCase))
          {
            if (MediaDir == null) MediaDir = new CRMediaDir(this);
            MediaDir.Add(eArgs.Element, reader);
          }
        }
      }
      var lArgs = args as LeaveElementArgs;
      if (lArgs != null) // OnLeaveElement
      {
        if (lArgs.Element != null)
        {
          if (lArgs.Element.Name.LocalName.Equals(TagName, StringComparison.InvariantCultureIgnoreCase))
          {
            if (reader != null) reader.OnProcessElement -= OnProcessElement;
            Process();
          }
        }
      }
    }

    internal void Process()
    {
      if (MediaDir != null)
        MediaDir.Process(MediaMap);
    }

    #region WriteBinary

    internal override void OnBeginWrite(ICapacityRuleWriter writer)
    {
      writer.Reset();
      base.OnBeginWrite(writer);
      writer.AddUInt32(MagicNumber);
      writer.AddUInt32(Size);
      writer.AddUInt32(OMediaDir);
      writer.AddUInt32(OMediaMap);
      writer.AddUInt32(OExtension);
    }

    internal override void OnWrite(ICapacityRuleWriter writer)
    {
      if (MediaDir != null) MediaDir.Write(writer);
      if (MediaMap != null) MediaMap.Write(writer);
      if (Extension != null) Extension.Write(writer);
    }

    internal override void OnEndWrite(ICapacityRuleWriter writer)
    {
      base.OnEndWrite(writer);
      writer.SetUInt32(0x04, Size);
      OMediaDir = (MediaDir == null) ? 0 : MediaDir.Offset;
      writer.SetUInt32(0x08, OMediaDir);
      OMediaMap = (MediaDir == null) ? 0 : MediaMap.Offset;
      writer.SetUInt32(0x0C, OMediaMap);
      OExtension = (Extension == null) ? 0 : Extension.Offset;
      writer.SetUInt32(0x10, OExtension);
    }

    #endregion WriteBinary

    #region ToString()

    public override string ToString()
    {
      var sb = new StringBuilder();
      sb.AppendLine(TagName + ":");
      sb.AppendLine("  <MagicNumber value=" + MagicNumber + "/>");
      sb.AppendLine("  <Size value=" + Size + "/>");
      if (MediaMap != null)
      {
        sb.Append(MediaMap.ToString());
      }
      if (MediaDir != null)
      {
        sb.AppendLine(MediaDir.ToString());
      }
      if (Extension != null)
      {
        sb.Append(Extension.ToString());
      }
      return sb.ToString();
    }

    #endregion
  }


  #endregion Internal Logic

}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================


using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CapacityRules
{
  #region Interfaces

  internal interface ICapacityRuleWriter
  {
    void AddByte(byte value);
    void SetByte(UInt32 offset, byte value);
    void AddUInt32(UInt32 value);
    void SetUInt32(UInt32 offset, UInt32 value);
    byte[] GetBuffer();
    UInt32 Size { get; }
    void Reset();
  }

  internal interface ICapacityRuleReader
  {
    event EventHandler OnProcessElement;
    void Process();
    ICapacityRuleReader SetSource(object source);
  }

  internal interface ICapacityRuleFactory
  {
    ICapacityRuleWriter Writer { get; }
    ICapacityRuleReader Reader { get; }
  }

  #endregion Interfaces

  #region EventHandlerStack
  /// <exclude/>
  internal class EventHandlerStack
  {
    private readonly List<EventHandler> _handlers = new List<EventHandler>();

    public void Add(EventHandler handler)
    {
      lock (_handlers)
      {
        if (!_handlers.Contains(handler)) _handlers.Add(handler);
      }
    }

    public void Remove(EventHandler handler)
    {
      lock (_handlers)
      {
        if (_handlers.Contains(handler)) _handlers.Remove(handler);
      }
    }

    public void Invoke(object sender, EventArgs args)
    {
      lock (_handlers)
      {
        if (_handlers.Count > 0)
          _handlers[_handlers.Count - 1].Invoke(sender, args);
      }
    }
  }
  
  /// <exclude/>
  internal class EnterElementArgs : EventArgs
  {
    public XElement Element;
  }

  /// <exclude/>
  internal class LeaveElementArgs : EventArgs
  {
    public XElement Element;
  }

  #endregion EventHandlerStack

  #region Internal Writer

  internal class InternalCapacityRuleWriter : ICapacityRuleWriter
  {
    public static int DefaultBufferSize = 1024;
    private byte[] _buffer;
    private int _capacity;

    internal InternalCapacityRuleWriter()
    {
      Reset();
    }

    public void AddByte(byte value)
    {
      if (Size >= _capacity)
      {
        _capacity *= 2;
        var newBuffer = new byte[_capacity];
        Array.Copy(_buffer, 0, newBuffer, 0, Size);
        _buffer = newBuffer;
      }
      _buffer[Size++] = value;
    }

    public void SetByte(UInt32 offset, byte value)
    {
      if (offset >= _capacity) return;
      _buffer[offset] = value;
    }

    public void AddUInt32(uint value)
    {
      if (Size + 4 > _capacity)
      {
        _capacity *= 2;
        var newBuffer = new byte[_capacity];
        Array.Copy(_buffer, 0, newBuffer, 0, Size);
        _buffer = newBuffer;
      }
      _buffer[Size++] = (byte) value;
      value >>= 8;
      _buffer[Size++] = (byte) value;
      value >>= 8;
      _buffer[Size++] = (byte) value;
      value >>= 8;
      _buffer[Size++] = (byte) value;
    }

    public void SetUInt32(UInt32 offset, uint value)
    {
      if (offset + 3 >= _capacity) return;
      _buffer[offset++] = (byte) value;
      value >>= 8;
      _buffer[offset++] = (byte) value;
      value >>= 8;
      _buffer[offset++] = (byte) value;
      value >>= 8;
      _buffer[offset] = (byte) value;
    }

    public byte[] GetBuffer()
    {
      var result = new byte[Size];
      Array.Copy(_buffer, 0, result, 0, Size);
      return result;
    }

    public UInt32 Size { get; private set; }

    public void Reset()
    {
      _buffer = new byte[DefaultBufferSize];
      _capacity = DefaultBufferSize;
      Size = 0;
    }
  }

  #endregion

  #region Internal Reader

  internal class InternalCapacityRuleReader : ICapacityRuleReader
  {
    private readonly EventHandlerStack _handlerStack = new EventHandlerStack();
    private XDocument _document;

    public event EventHandler OnProcessElement
    {
      add { _handlerStack.Add(value); }
      remove { _handlerStack.Remove(value); }
    }

    private void ProcessNode(XNode node)
    {
      if (node == null) return;
      var elm = node as XElement;
      if (elm == null) return;
      var eArgs = new EnterElementArgs {Element = node as XElement};
      _handlerStack.Invoke(this, eArgs);
      foreach (var xNode in elm.Nodes())
      {
          ProcessNode(xNode);
      }
      var lArgs = new LeaveElementArgs {Element = node as XElement};
      _handlerStack.Invoke(this, lArgs);
    }

    public void Process()
    {
      if (_document == null) return;
      ProcessNode(_document.Root);
    }

    ICapacityRuleReader ICapacityRuleReader.SetSource(object source)
    {
      _document = (source as XDocument);
      return this;
    }
  }

  #endregion Internal Reader

  #region CapacityRuleInternalFactory

  internal class CapacityRuleInternalFactory : ICapacityRuleFactory
  {
    public ICapacityRuleWriter Writer
    {
      get { return new InternalCapacityRuleWriter(); }
    }

    public ICapacityRuleReader Reader
    {
      get { return new InternalCapacityRuleReader(); }
    }
  }

  #endregion CapacityRuleInternalFactory

}

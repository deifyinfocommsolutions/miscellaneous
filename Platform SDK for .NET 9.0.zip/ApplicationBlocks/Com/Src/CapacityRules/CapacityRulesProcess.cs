//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================


using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using Genesyslab.Platform.Commons;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CapacityRules
{

  #region MediaRules

  /// <summary>
  /// Arguments of event handler for handling any changes of capacity rule 
  /// </summary>
  internal class OnMediaRuleChangedArgs : EventArgs
  {
    /// <summary>
    /// Name of transformation
    /// </summary>
    public String Method;
    /// <summary>
    /// Simple string presentation of capacity rule
    /// </summary>
    public string Result;
    /// <summary>
    /// Flag of root rule
    /// </summary>
    public bool Root;
  }
  /// <summary>
  /// Event handler for handling any changes of capacity rule 
  /// </summary>
  /// <param name="sender">Instance of class which invokes event</param>
  /// <param name="args">Arguments. Instance of <see cref="OnMediaRuleChangedArgs"/> class</param>
  internal delegate void OnMediaRuleChanged(object sender, EventArgs args);

  internal class MediaRule
  {
    private const string ElementaryRuleName = "ElementaryRule";
    private const string ComplexConditionName = "ComplexCondition";


    internal OnMediaRuleChanged OnRuleChanged;
    private readonly ICapacityRuleReader _reader;
    internal AbstractRule Rule { get; private set; }
    internal AbstractRule OriginalRule { get; private set; }
    private AbstractRule _currentRule;
    private readonly CRRuleBlockEntry _parent;

    internal MediaRule(ICapacityRuleReader reader, CRRuleBlockEntry parent)
    {
      _reader = reader;
      _parent = parent;
      _reader.OnProcessElement += OnProcessElement;
    }

    private void OnProcessElement(object sender, EventArgs args)
    {
      var eArgs = args as EnterElementArgs;
      if (eArgs != null)
      {
        if (eArgs.Element.Name.LocalName.Equals(ElementaryRuleName, StringComparison.InvariantCultureIgnoreCase))
        {
          if (Rule == null)
            Rule = _currentRule = new ComplexCondition(null, ComplexCondition.ConditionType.Or);
          var rule = new ElementaryRule(_currentRule, eArgs.Element);
          if (_currentRule is ComplexCondition)
          {
            rule.OnExpandAny += delegate(AbstractRule source, CRMediaMap map, byte capacity)
            {
              var newRule = source.Parent as ComplexCondition;
              if (newRule == null) return;
              var header = map.Parent as CRHeader;
              if (header == null) return;
              if (header.MediaDir == null) return;
              if (header.MediaDir.AMediaDirEntry == null) return;
              if (newRule.Condition == ComplexCondition.ConditionType.Or)
              {
                foreach (var entry in header.MediaDir.AMediaDirEntry)
                {
                  newRule.AddRule(new ElementaryRule(newRule, entry.MediaName, entry.MediaType, capacity));
                }
                newRule.RemoveRule(source);
              }
              if (newRule.Condition == ComplexCondition.ConditionType.And)
              {
                var addRule = new ComplexCondition(newRule, ComplexCondition.ConditionType.Or);
                foreach (var entry in header.MediaDir.AMediaDirEntry)
                {
                  addRule.AddRule(new ElementaryRule(newRule, entry.MediaName, entry.MediaType, capacity));
                }
                newRule.RemoveRule(source);
                newRule.AddRule(addRule);
              }
            };
            (_currentRule as ComplexCondition).AddRule(rule);
          }
        }
        if (eArgs.Element.Name.LocalName.Equals(ComplexConditionName, StringComparison.InvariantCultureIgnoreCase))
        {
          var rule = new ComplexCondition(_currentRule, eArgs.Element);
          if (Rule == null)
          {
            Rule = _currentRule = rule;
          }
          else
          {
            if (_currentRule is ComplexCondition)
            {
              (_currentRule as ComplexCondition).AddRule(rule);
              _currentRule = rule;
            }
          }
        }
        return;
      }
      var lArgs = args as LeaveElementArgs;
      if (lArgs != null) // leave element
      {
        if (lArgs.Element.Name.LocalName.Equals(ComplexConditionName, StringComparison.InvariantCultureIgnoreCase))
        {
          if (_currentRule == null) throw new CapacityRuleException("Capacity rule contains wrong MediaRule");
          if ((_currentRule is ComplexCondition) && ((_currentRule as ComplexCondition).ChildRules.Count==0))
            throw new CapacityRuleException("Capacity rule contains wrong MediaRule");
          _currentRule = _currentRule.Parent;
        }
        if (lArgs.Element.Name.LocalName.Equals(CRMediaDir.TagName, StringComparison.InvariantCultureIgnoreCase) &&
            (sender is ICapacityRuleReader))
        {
          (sender as ICapacityRuleReader).OnProcessElement -= OnProcessElement;
        }
      }
    }

    public string ToXMLString()
    {
      if (Rule != null) return Rule.ToString("      ");
      return "";
    }
    public override string ToString()
    {
      if (Rule != null) return Rule.ToString();
      return "";
    }

    #region Inner Classes

    internal class RuleFactory
    {
      public static AbstractRule Create(XElement element, ICapacityRuleReader reader, AbstractRule parent)
      {
        return null;
      }
    }

    internal abstract class AbstractRule
    {
      internal delegate void OnExpandAnyHandler(AbstractRule sender, CRMediaMap map, Byte capacity);

      internal AbstractRule Parent { get; set; }

      internal AbstractRule(AbstractRule parent)
      {
        Parent = parent;
      }

      protected XAttribute GetAttribute(XElement element, string name)
      {
        return
          element.Attributes().FirstOrDefault(
            attribute => attribute.Name.LocalName.Equals(name, StringComparison.InvariantCultureIgnoreCase));
      }

      protected string GetAttributeValue(XElement element, string name)
      {
        var attr = GetAttribute(element, name);
        if (attr == null)
          throw new CapacityRuleException("Capacity rule XML does not contain mandatory attribute '" + name + "'");
        return attr.Value;
      }

      internal abstract void ExpandAny(CRMediaMap map);
      internal abstract void AssginMediaTypes(CRMediaMap map);
      internal abstract string ToString(string leftMargin);
      internal abstract CRRuleBody CreateBinaryStructure(CRRuleBlockEntry parent);
      internal abstract AbstractRule Clone(AbstractRule parent);
      internal abstract bool Calculate(Byte[] values);
      internal abstract void CalcMaxMediaValue(Byte mediaType, ref int maxValue);
      internal abstract int TotalCountChildrens { get; set; }
    }

    internal class ElementaryRule : AbstractRule
    {
      private const int MinCapacity = 1;
      private const int MaxCapacity = 255;
      private const string MediaAttributeName = "media";
      private const string CapacityAttributeName = "capacity";

      internal string MediaName { get; private set; }
      internal Byte MediaType { get; set; }
      internal Byte Capacity { get; private set; }


      internal event OnExpandAnyHandler OnExpandAny = null;
      internal override void CalcMaxMediaValue(byte mediaType, ref int maxValue)
      {
        if (MediaType!=mediaType) return;
        if (Capacity > maxValue) maxValue = Capacity;
      }
      internal override void ExpandAny(CRMediaMap map)
      {
        if (!MediaName.Equals("")) return;
        if (OnExpandAny == null) return;
        OnExpandAny(this, map, Capacity);
      }

      internal override void AssginMediaTypes(CRMediaMap map)
      {
        foreach (var entry in map.AMediaMapEntry)
        {
          if (entry.MediaName.Equals(MediaName, StringComparison.InvariantCultureIgnoreCase))
          {
            MediaType = entry.MediaType;
            if (Capacity > entry.MaxCapacity) entry.MaxCapacity = Capacity;
            return;
          }
        }
        if (MediaName.Equals("")) return; // Expand any
        throw new CapacityRuleException("CapacityRule process error: Unknown media name: '" + MediaName + "'");
      }

      internal override bool Calculate(Byte[] values)
      {
        return values[MediaType] >= Capacity;
      }

      private void ThrowInvalidCapacity(string val)
      {
        throw new CapacityRuleException("Capacity rule XML contains invalid attribute value. Attribute 'capacity', media name ='" + MediaName + "' value = '" + val + "'");
      }

      internal ElementaryRule(AbstractRule parent, XElement element)
        : base(parent)
      {
        MediaName = GetAttributeValue(element, MediaAttributeName);
        string capacity = GetAttributeValue(element, CapacityAttributeName);
        int lCapacity;
        if (String.IsNullOrEmpty(capacity)) ThrowInvalidCapacity(capacity);
        if (!Int32.TryParse(capacity, out lCapacity)) ThrowInvalidCapacity(capacity);
        if ((lCapacity < MinCapacity) || (lCapacity > MaxCapacity)) ThrowInvalidCapacity(capacity);
        Capacity = (Byte)lCapacity;
      }

      internal ElementaryRule(AbstractRule parent, string name, Byte mediaType, Byte capacity)
        : base(parent)
      {
        MediaName = name;
        MediaType = mediaType;
        Capacity = capacity;
      }

      internal override string ToString(string leftMargin)
      {
        return leftMargin +
               String.Format("<{0} {1}=\"{2}\" {3}=\"{4}\"/>", ElementaryRuleName,
                             MediaAttributeName, MediaName, CapacityAttributeName,
                             Capacity);
      }
      public override string ToString()
      {
        return String.Format("{0}:{1}", MediaName, Capacity);
      }

      internal override CRRuleBody CreateBinaryStructure(CRRuleBlockEntry parent)
      {
        var complexCond = new ComplexCondition(null, ComplexCondition.ConditionType.Or);
        complexCond.AddRule(this);
        return complexCond.CreateBinaryStructure(parent);
      }

      internal override AbstractRule Clone(AbstractRule parent)
      {
        return new ElementaryRule(parent, MediaName, MediaType, Capacity);
      }
      internal override int TotalCountChildrens { get { return 1; } set { }}
    }

    internal class ComplexCondition : AbstractRule
    {
      private const string ConditionTypeAttributeName = "type";

      internal enum ConditionType
      {
        Or = 0,
        And = 1,
        Not = 2
      }

      internal readonly List<AbstractRule> ChildRules = new List<AbstractRule>();
      internal ConditionType Condition { get; set; }
      private int _totalCountChildrens = 0;
      internal override int TotalCountChildrens 
      { get { return _totalCountChildrens; }
        set
        {
          _totalCountChildrens = value;
          if (Parent is ComplexCondition)
          {
            (Parent as ComplexCondition).GetCountChildrens();
          }
        }
      }
      private void GetCountChildrens()
      {
        int count = 0;
        foreach (var childRule in ChildRules)
        {
          count += childRule.TotalCountChildrens;
        }
        TotalCountChildrens = count;
      }
      internal ConditionType ContrCondition
      {
        get { return (Condition == ConditionType.Or) ? ConditionType.And : ConditionType.Or; }
      }

      internal AbstractRule AddRule(AbstractRule rule)
      {
        rule.Parent = this;
        ChildRules.Add(rule);
        TotalCountChildrens += rule.TotalCountChildrens;
        return this;
      }

      internal AbstractRule AddRuleAt(int index, AbstractRule rule)
      {
        ChildRules.Insert(index, rule);
        TotalCountChildrens += rule.TotalCountChildrens;
        return this;
      }

      internal AbstractRule RemoveRule(AbstractRule rule)
      {
        if (ChildRules.Contains(rule)) ChildRules.Remove(rule);
        TotalCountChildrens -= rule.TotalCountChildrens;
        return this;
      }

      internal ComplexCondition(AbstractRule parent, ConditionType type)
        : base(parent)
      {
        Condition = type;
      }

      internal ComplexCondition(AbstractRule parent, XElement element)
        : base(parent)
      {
        var condition = GetAttributeValue(element, ConditionTypeAttributeName);
        try
        {
          Condition = (ConditionType)Enum.Parse(typeof(ConditionType), condition, true);
        }
        catch (Exception)
        {
          throw new CapacityRuleException("Capacity rule XML contains invalid attribute value. Attribute '" +
                                      ConditionTypeAttributeName + " value ='" + condition + "'");
        }
      }
      internal override void CalcMaxMediaValue(byte mediaType, ref int maxValue)
      {
        if (ChildRules!=null)
        foreach (var rule in ChildRules)
        {
          rule.CalcMaxMediaValue(mediaType, ref maxValue);
        }
      }
      internal override AbstractRule Clone(AbstractRule parent)
      {
        var complex = new ComplexCondition(parent, Condition);
        foreach (var rule in ChildRules)
        {
          complex.AddRule(rule.Clone(complex));
        }
        return complex;
      }

      internal override void ExpandAny(CRMediaMap map)
      {
        if (ChildRules == null) return;
        var rules = ChildRules.ToList();
        foreach (var abstractRule in rules)
        {
          abstractRule.ExpandAny(map);
        }
      }

      internal override void AssginMediaTypes(CRMediaMap map)
      {
        if (ChildRules == null) return;
        var rules = ChildRules.ToList();
        foreach (var abstractRule in rules)
        {
          abstractRule.AssginMediaTypes(map);
        }
      }

      internal override bool Calculate(Byte[] values)
      {
        bool result = Condition == ConditionType.And;
        if (ChildRules == null) return result;
        foreach (var rule in ChildRules)
        {
          if (Condition == ConditionType.And) result &= rule.Calculate(values);
          else result |= rule.Calculate(values);
        }
        return result;
      }

      internal override string ToString(string leftMargin)
      {
        var sb =
          new StringBuilder().Append(leftMargin).Append("<").Append(ComplexConditionName).Append(" ")
                             .Append(ConditionTypeAttributeName)
                             .Append("=\"")
                             .Append(Condition)
                             .AppendLine("\">");
        foreach (var abstractRule in ChildRules)
        {
          sb.AppendLine(abstractRule.ToString(leftMargin + "  "));
        }
        sb.Append(leftMargin).Append("</").Append(ComplexConditionName).Append(">");
        return sb.ToString();
      }
      public override string ToString()
      {
        var sb = new StringBuilder().AppendFormat("{0}(",Condition.ToString().ToUpper());
        foreach (var abstractRule in ChildRules)
        {
          sb.Append(abstractRule.ToString()).Append(",");
        }
        sb.Remove(sb.Length - 1, 1);
        sb.Append(")");
        return sb.ToString();
      }

      internal override CRRuleBody CreateBinaryStructure(CRRuleBlockEntry parent)
      {
        var body = new CRRuleBody(parent) { AAndExprBlock = new List<CRAndExprBlock>() };
        foreach (var abstractRule in ChildRules)
        {
          var ab = new CRAndExprBlock(body) { AElemExpr = new List<CRElemExpr>() };
          var cRule = (abstractRule as ComplexCondition);
          if (cRule != null)
          {
            foreach (var rule in cRule.ChildRules)
            {
              var eRule = rule as ElementaryRule;
              if (eRule == null) continue;
              ab.AElemExpr.Add(new CRElemExpr(ab) { Capacity = eRule.Capacity, MediaType = eRule.MediaType });
              ab.CElemExpr++;
            }
          }
          var elRule = (abstractRule as ElementaryRule);
          if (elRule != null)
          {
            ab.AElemExpr.Add(new CRElemExpr(ab) { Capacity = elRule.Capacity, MediaType = elRule.MediaType });
            ab.CElemExpr++;
          }
          body.AAndExprBlock.Add(ab);
          body.COAndExprBlock++;
        }
        return body;
      }
    }

    #endregion Inner Classes

    #region Mathematic

    internal CRRuleBody Process(CRMediaMap map)
    {
      if (Rule == null) return null;
      Rule.AssginMediaTypes(map);
      OriginalRule = Rule;
      Rule.ExpandAny(map);
      if (Rule is ComplexCondition) Rule = TransformRule();
      return CreateRuleBody();
    }

    private CRRuleBody CreateRuleBody()
    {
      if (Rule == null) return null;
      ConvertStructure();
      return Rule.CreateBinaryStructure(_parent);
    }

    private void InvokeEvent(string header, AbstractRule rule)
    {
      if (OnRuleChanged == null) return;
      var args = new OnMediaRuleChangedArgs
                   {
                     Method = header,
                     Result = (rule != null) ? rule.ToString() : null,
                     Root = (rule != null) && rule.Parent == null
                   };
      OnRuleChanged(this, args);
    }

    private bool ReduceRule(AbstractRule rule)
    {
      var needTransform = true;
      var ruleChanged = false;
      while (needTransform)
      {
        var result = false;
        result |= SimplifyRule(ref rule);
        result |= TransformAssociativeRule(rule);
        result |= TransformIdempotencyRule(rule);
        result |= SimplifyRule(ref rule);
        result |= TransformAbsorbtionRule(rule);
        result |= SimplifyRule(ref rule);
        needTransform = result;
        ruleChanged |= result;
      }
      return ruleChanged;
    }

    private bool DistributeRule(AbstractRule rule)
    {
      var result = TransformDistributeRule(rule);
      if (result) SimplifyRule(ref rule);
      return result;
    }

    private void ConvertStructure()
    {
      if (!IsRuleMappedToDNF(Rule, 0)) return;
      var cRule = Rule as ComplexCondition;
      if ((cRule == null) || (cRule.Condition != ComplexCondition.ConditionType.Or))
      {
        Rule = new ComplexCondition(null, ComplexCondition.ConditionType.Or).AddRule(Rule);
      }
    }
    private bool IsRuleMappedToDNF(AbstractRule rule)
    {
      return IsRuleMappedToDNF(rule, 0);
    }
    private bool IsRuleMappedToDNF(AbstractRule rule, int level)
    {
      switch (level)
      {
        case 0:
          {
            var cRule = rule as ComplexCondition;
            if (cRule == null) return true;
            foreach (var childRule in cRule.ChildRules)
            {
              if (!IsRuleMappedToDNF(childRule, level + 1)) return false;
            }
            return true;
          }
        case 1:
          {
            var cRule = rule as ComplexCondition;
            if (cRule == null) return true;
            if (!(cRule.Parent is ComplexCondition)) return false;
            if ((cRule.Parent as ComplexCondition).Condition != ComplexCondition.ConditionType.Or) return false;
            if (cRule.Condition != ComplexCondition.ConditionType.And) return false;
            foreach (var childRule in cRule.ChildRules)
            {
              if (!IsRuleMappedToDNF(childRule, level + 1)) return false;
            }
            return true;
          }
        case 2:
          {
            var cRule = rule as ComplexCondition;
            if (cRule != null) return false;
            return true;
          }
        default:
          return false;
      }
    }

    private void PrepareStructure()
    {
      if (Rule is ElementaryRule)
      {
        var newRule = new ComplexCondition(null, ComplexCondition.ConditionType.Or);
        newRule.AddRule(Rule);
        Rule = newRule;
      }
    }
    private AbstractRule TransformRule()
    {
      InvokeEvent("Source rule", Rule);
      var needTransform = true;
      var ruleChanged = false;
      PrepareStructure();
      var newRule = Rule.Clone(null);
      InvokeEvent("Clone rule", newRule);
      ruleChanged |= ReduceRule(newRule);
      if (!IsRuleMappedToDNF(newRule))
      {
        while (needTransform)
        {
          var result = false;
          result |= DistributeRule(newRule);
          result |= ReduceRule(newRule);
          needTransform = result && (!IsRuleMappedToDNF(newRule));
          ruleChanged |= result;
        }
      }
      if (ruleChanged) Rule = newRule;
      InvokeEvent("Out rule", Rule);
      InvokeEvent(null, null);
      return Rule;
    }

    /// <summary>
    /// Replace all inner rules with equal condition 
    /// a &amp;&amp;(b &amp;&amp; c) = a&amp;&amp; b &amp;&amp; c
    /// a || (b || c) = a || b || c
    /// </summary>
    /// <param name="rule">Root rule</param>
    /// <returns>true, if root rule is changed, otherwise - false</returns>
    private bool TransformAssociativeRule(AbstractRule rule)
    {
      var baseRule = rule as ComplexCondition;
      if (baseRule == null) return false;
      bool result = false;
      var children = baseRule.ChildRules.ToList();
      foreach (var child in children)
      {
        var complexChild = child as ComplexCondition;
        if (complexChild == null) continue;
        result |= TransformAssociativeRule(complexChild);
        if (complexChild.Condition == baseRule.Condition)
        {
          baseRule.RemoveRule(complexChild);
          foreach (var childRule in complexChild.ChildRules)
          {
            baseRule.AddRuleAt(0, childRule);
          }
          result = true;
        }
      }
      if (result) InvokeEvent("Associavive rule", rule);
      return result;
    }

    /// <summary>
    /// Distribution rule 
    /// a &amp;&amp; (b || c) = (a &amp;&amp; b) || (a &amp;&amp; c)
    /// a || (b &amp;&amp; c) = (a || b) &amp;&amp; (a || c)
    /// </summary>
    /// <param name="rule">Root rule</param>
    /// <returns>true, if root rule is changed, otherwise - false</returns>
    private bool TransformDistributeRule(AbstractRule rule)
    {
      var baseRule = rule as ComplexCondition;
      if (baseRule == null) return false;

      var elemRulesList = new List<AbstractRule>();
      foreach (var childRule in baseRule.ChildRules)
      {
        if (childRule is ElementaryRule) elemRulesList.Add(childRule);
        if (childRule is ComplexCondition)
        {
          if ((childRule as ComplexCondition).Condition == baseRule.Condition) elemRulesList.Add(childRule);
        }
      }
      var compRulesList = new List<AbstractRule>();
      foreach (var childRule in baseRule.ChildRules)
      {
        if (childRule is ComplexCondition)
          if ((childRule as ComplexCondition).ContrCondition == baseRule.Condition) compRulesList.Add(childRule);
      }
      if (compRulesList.Count == 0) return false;
      if (compRulesList.Count == 1)
      {
        var child = compRulesList[0] as ComplexCondition;
        if ((child == null) || (child.ChildRules == null) || (child.ChildRules.Count == 0)) return false;
        baseRule.Condition = baseRule.ContrCondition;
        baseRule.ChildRules.Clear();
        foreach (var childRule in child.ChildRules)
        {
          var tRule = new ComplexCondition(baseRule, baseRule.ContrCondition);
          tRule.AddRule(childRule);
          foreach (var abstractRule in elemRulesList)
          {
            tRule.AddRule(abstractRule);
          }
          baseRule.AddRule(tRule);
        }
        InvokeEvent("Distribution rule", rule);
        return true;
      }
      baseRule.Condition = baseRule.ContrCondition;
      baseRule.ChildRules.Clear();
      for (int i = 0; i < compRulesList.Count - 1; i++)
        for (int j = i + 1; j < compRulesList.Count; j++)
        {
          var child1 = compRulesList[i] as ComplexCondition;
          var child2 = compRulesList[j] as ComplexCondition;
          if ((child1 == null) || (child2 == null)) continue;
          if ((child1.ChildRules == null) || (child2.ChildRules == null)) continue;
          foreach (var rule1 in child1.ChildRules)
            foreach (var rule2 in child2.ChildRules)
            {
              var tcRule = new ComplexCondition(baseRule, baseRule.ContrCondition);
              tcRule.AddRule(rule1);
              tcRule.AddRule(rule2);
              foreach (var abstractRule in elemRulesList)
              {
                tcRule.AddRule(abstractRule);
              }
              foreach (var rule3 in compRulesList)
              {
                if (rule3==child1) continue;
                if (rule3 == child2) continue;
                tcRule.AddRule(rule3);
              }
              ReduceRule(tcRule);
              TransformDistributeRule(tcRule);
              ReduceRule(tcRule);
              baseRule.AddRule(tcRule);

            }
        }
      InvokeEvent("Distribution rule", rule);
      return true;
    }


    /// <summary>
    /// Idempotency rule
    /// a &amp;&amp; a  = a 
    /// a || a  = a 
    /// </summary>
    /// <param name="rule">Root rule</param>
    /// <returns>true, if root rule is changed, otherwise - false</returns>
    private bool TransformIdempotencyRule(AbstractRule rule)
    {
      var complexRule = rule as ComplexCondition;
      if (complexRule == null) return false; // Elementary rule
      bool result = false;
      for (int i = 0; i < complexRule.ChildRules.Count; i++)
      {
        result |= TransformIdempotencyRule(complexRule.ChildRules[i]);
        if (result) SimplifyRule(ref rule);
      }
      while (true)
      {
        int index = FindImpodency(complexRule.ChildRules, complexRule.Condition);
        if (index < 0) break;
        result = true;
        complexRule.RemoveRule(complexRule.ChildRules[index]);
      }
      if (result) InvokeEvent("Impodency rule", rule);
      return result;
    }

    private int FindImpodency(List<AbstractRule> childs, ComplexCondition.ConditionType condition)
    {
      for (int i = 0; i < childs.Count - 1; i++)
      {
        var rule1 = childs[i] as ElementaryRule;
        if (rule1 == null) continue;
        for (int j = i + 1; j < childs.Count; j++)
        {
          var rule2 = childs[j] as ElementaryRule;
          if (rule2 == null) continue;
          if (rule1.MediaType != rule2.MediaType) continue; // different media types
          if (condition == ComplexCondition.ConditionType.Or)
          {
            return (rule2.Capacity > rule1.Capacity) ? j : i;
          }
          if (condition == ComplexCondition.ConditionType.And)
          {
            return (rule2.Capacity < rule1.Capacity) ? j : i;
          }
        }
      }
      return -1;
    }

    private bool SimplifyRule(ref AbstractRule rule)
    {
      var complexRule = rule as ComplexCondition;
      if (complexRule == null) return false; // Elementary rule
      if (complexRule.ChildRules == null) return false;
      if (complexRule.ChildRules.Count == 1)
      {
        rule = complexRule.ChildRules[0];
        InvokeEvent("Simplify rule", rule);
        return true;
      }
      var newList = complexRule.ChildRules.ToList();
      complexRule.ChildRules.Clear();
      bool result = false;
      while (newList.Count > 0)
      {
        var tRule = newList[0];
        newList.RemoveAt(0);
        result |= SimplifyRule(ref tRule);
        complexRule.ChildRules.Add(tRule);
      }
      if (result) InvokeEvent("Simplify rule", rule);
      return result;
    }

    /// <summary>
    /// Absorbtion of equals rules
    /// a &amp;&amp; (a || b) = a 
    /// a || (a &amp;&amp; b) = a 
    /// </summary>
    /// <param name="rule">Root rule</param>
    /// <returns>true, if root rule is changed, otherwise - false</returns>
    private bool TransformAbsorbtionRule(AbstractRule rule)
    {
      var complexRule = rule as ComplexCondition;
      if (complexRule == null) return false; // Elementary rule
      bool result = false;
      for (int i = 0; i < complexRule.ChildRules.Count; i++)
      {
        result |= TransformAbsorbtionRule(complexRule.ChildRules[i]);
        if (result) SimplifyRule(ref rule);
      }
      while (true)
      {
        bool lResult = false;
        int index = FindAbsorbtion(complexRule.ChildRules, complexRule.Condition);
        if (index >= 0)
        {
          lResult = true;
          complexRule.RemoveRule(complexRule.ChildRules[index]);
        }
        index = FindAbsorbtion2(complexRule.ChildRules, complexRule.Condition);
        if (index >= 0)
        {
          lResult = true;
          complexRule.RemoveRule(complexRule.ChildRules[index]);
        }
        if (lResult) result = true; else break;
      }
      if (result) InvokeEvent("Absorbtion rule", rule);
      return result;
    }

    private int FindAbsorbtion(List<AbstractRule> childs, ComplexCondition.ConditionType condition)
    {
      for (int i = 0; i < childs.Count; i++)
      {
        var rule1 = childs[i] as ElementaryRule;
        if (rule1 == null) continue;
        for (int j = 0; j < childs.Count; j++)
        {
          if (i == j) continue;
          var complexRule = childs[j] as ComplexCondition;
          if (complexRule == null) continue;
          foreach (var childRule in complexRule.ChildRules)
          {
            var rule2 = childRule as ElementaryRule;
            if (rule2 == null) continue; // complexRule
            if (rule1.MediaType != rule2.MediaType) continue; // different media types
            if (condition == ComplexCondition.ConditionType.Or)
            {
              if (rule1.Capacity <= rule2.Capacity) return j;
            }
            if (condition == ComplexCondition.ConditionType.And)
            {
              if (rule1.Capacity >= rule2.Capacity) return j;
            }
          }
        }
      }
      return -1;
    }
    private int FindAbsorbtion2(List<AbstractRule> childs, ComplexCondition.ConditionType condition)
    {
      if (condition == ComplexCondition.ConditionType.Or) return FindAbsorbtion2Or(childs);
      //if (condition == ComplexCondition.ConditionType.And) return FindAbsorbtion2And(childs);
      return -1;
    }
    // (a || b) && (a || b || c) = a || b || c
    // TODO May be implemented later if needed

    // (a && b) || (a && b && c) = (a && b)
    private int FindAbsorbtion2Or(List<AbstractRule> childs)
    {
      for (int i = 0; i < childs.Count; i++)
      {
        var cRule1 = childs[i] as ComplexCondition;
        if (cRule1 == null) continue;
        for (int j = 0; j < childs.Count; j++)
        {
          if (i == j) continue; // do not compare self
          var complexRule = childs[j] as ComplexCondition;
          if (complexRule == null) continue;
          var originalRules = cRule1.ChildRules.ToList();
          if (originalRules.Count == 0) continue;
          foreach (var childRule1 in cRule1.ChildRules)
          {
            var rule1 = childRule1 as ElementaryRule;
            if (rule1 == null) continue; // 
            foreach (var childRule2 in complexRule.ChildRules)
            {
              var rule2 = childRule2 as ElementaryRule;
              if (rule2 == null) continue; // complexRule

              if (rule1.MediaType != rule2.MediaType) continue; // different media types
              if (rule1.Capacity <= rule2.Capacity)
              {
                if (originalRules.Contains(rule1))
                  originalRules.Remove(rule1);
              }
            }
          }
          if (originalRules.Count == 0) return j;
        }
      }
      return -1;
    }

    private void CalculateRule(Byte[] values, CRMediaMap map, int index, StringBuilder error)
    {
      for (byte i = 0; i <= map.AMediaMapEntry[index].MaxCapacity; i++)
      {
        values[index] = i;
        if (index + 1 == map.CMediaMapEntry)
        {
          bool oValue = OriginalRule.Calculate(values);
          bool cValue = Rule.Calculate(values);
          if (oValue != cValue)
          {
            for (int j = 0; j < map.CMediaMapEntry; j++)
              error.Append(String.Format("'{0}'={1} ", map.AMediaMapEntry[j].MediaName, values[j]));
            error.AppendLine(String.Format(" |  Original value = {0}, New value = {1}", oValue, cValue));
          }
        }
        else
          CalculateRule(values, map, index + 1, error);
      }
    }
    private void LogCalculatedRule(Byte[] values, CRMediaMap map, int index, StringBuilder error)
    {

      for (byte i = 0; i <= map.AMediaMapEntry[index].MaxCapacity; i++)
      {
        values[index] = i;
        if (index + 1 == map.CMediaMapEntry)
        {
          bool oValue = OriginalRule.Calculate(values);
          bool cValue = Rule.Calculate(values);
          for (int j = 0; j < map.CMediaMapEntry; j++)
            error.Append(String.Format("'{0}'={1} ", map.AMediaMapEntry[j].MediaName, values[j]));
          error.AppendLine(String.Format(" |  Original value = {0}, New value = {1}", oValue, cValue));
        }
        else
          LogCalculatedRule(values, map, index + 1, error);
      }
    }

    internal StringBuilder ValidateRule(CRMediaMap map)
    {
      var values = new Byte[map.CMediaMapEntry];
      var error = new StringBuilder();
      CalculateRule(values, map, 0, error);
      if (error.Length == 0) return null;
      return error;
    }
    internal StringBuilder ValidateRuleTable(CRMediaMap map)
    {
      var values = new Byte[map.CMediaMapEntry];
      var error = new StringBuilder();
      LogCalculatedRule(values, map, 0, error);
      if (error.Length == 0) return null;

      return error;
    }

    #endregion Mathematic
  }

  #endregion MediaRules
}

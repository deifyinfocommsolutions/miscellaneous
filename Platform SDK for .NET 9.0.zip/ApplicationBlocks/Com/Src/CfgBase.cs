//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections;
using System.Linq;
using System.Xml;
using System.Threading;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Genesyslab.Configuration;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Commons.Protocols;
using System.Xml.Linq;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Configuration.Protocols.Metadata;
using Genesyslab.Threading;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// The parent class for all configuration object categories (structures
    /// and classes)
    /// </summary>
    public abstract class CfgBase : AbstractLogEnabled, ICfgBase
    {
      private static readonly bool IgnoreIsSavedFlag = 
        PsdkCustomization.CustomOption("COM.CfgObject.Equals.IgnoreIsSavedFlag", true);

        private CfgDescriptionClass dataClass;
        private bool isSaved;

        /// <summary>
        /// The XML representation of the current object
        /// </summary>
        private XElement xmlData;
        /// <summary>
        /// Reference to the configuration service to use for updating this object
        /// </summary>
        private IConfService configurationService;
        private bool isStructure;
#if (NETCORE || NETSTD20)
        private readonly ReentralReadWriteLock rwLock;
#else
        private readonly ReaderWriterLock rwLock;
#endif
        /// <exclude/>
        protected void AcquireReaderLock()
        {
            if (rwLock == null) return;
            //Console.Write("lock r: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
#if (NETCORE || NETSTD20)
            rwLock.AcquireReadLock();
#else
            rwLock.AcquireReaderLock(-1);
#endif
            //Console.WriteLine(" completed");
        }
        /// <exclude/>
        protected void AcquireWriterLock()
        {
            if (rwLock == null) return;
            //Console.Write("lock w: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
#if (NETCORE || NETSTD20)
            rwLock.AcquireWriteLock();
#else
            rwLock.AcquireWriterLock(-1);
#endif
            //Console.WriteLine(" completed");
        }
        /// <exclude/>
        protected void ReleaseReaderLock()
        {
            if (rwLock == null) return;
            //Console.Write("unlock r: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
#if (NETCORE || NETSTD20)
            rwLock.ReleaseReadLock();
#else
            rwLock.ReleaseReaderLock();
#endif
            //Console.WriteLine(" completed");
        }
        /// <exclude/>
        protected void ReleaseWriterLock()
        {
            if (rwLock == null) return;
            //Console.Write("unlock w: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
#if (NETCORE || NETSTD20)
            rwLock.ReleaseWriteLock();
#else
            rwLock.ReleaseWriterLock();
#endif
            //Console.WriteLine(" completed");
        }
#if (NETCORE || NETSTD20)
        protected void UpgradeToWriteLock()
        {
            rwLock.UpgradeToWriteLock(); 
        }
#else
        protected bool UpgradeToWriteLock(ref LockCookie cookie)
        {
            if (rwLock.IsReaderLockHeld)
            {
                //Console.Write("upgrade w: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
                cookie = rwLock.UpgradeToWriterLock(-1);
                //Console.WriteLine(" completed");
                return true;
            }
            //Console.Write("lock w: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
            rwLock.AcquireWriterLock(-1);
            //Console.WriteLine(" completed");
            return false;
        }
#endif
#if (NETCORE || NETSTD20)
        protected void DowngradeFromWriteLock()
        {
           rwLock.DowngradeWriteLock();
        }
#else
    protected void DowngradeFromWriteLock(bool updraded,ref LockCookie cookie)
        {
            if (updraded)
            {
                //Console.Write("downgrade w: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
                rwLock.DowngradeFromWriterLock(ref cookie);
                //Console.WriteLine(" completed");
            }
            else
            {
                //Console.Write("unlock w: {0} -> {1}", Thread.CurrentThread.ManagedThreadId, rwLock.GetHashCode());
                rwLock.ReleaseWriterLock();
                //Console.WriteLine(" completed");
            }
        }
#endif
    private Hashtable objectsHash;

        /// <summary>
        /// The parent of the current object.
        /// </summary>
        private CfgBase parent;

        private object lockObject = new object();
        //private readonly Hashtable _propertyLocks = new Hashtable();

        internal CfgBase(IConfService confService, XElement xmlData, bool isStructure, CfgBase parent, string dataClassName)
        {
            IsSaved = true;
#if (NETCORE || NETSTD20)
            rwLock = new ReentralReadWriteLock();
#else
            rwLock = new ReaderWriterLock();
#endif
            Initialize(confService, xmlData, isStructure, parent, dataClassName);
        }

#if (NETCORE || NETSTD20)
        /// <exclude/>
        protected ReentralReadWriteLock LockObject
        {
            get
            {
                return rwLock;
            }
        }
#else
        /// <exclude/>
        protected ReaderWriterLock LockObject
        {
            get
            {
                return rwLock;
            }
        }
#endif

        /// <summary>
        /// Used to access the configuration service that this object was 
        /// created with.
        /// </summary>
        protected IConfService ConfigurationService
        {
            get
            {
                return configurationService;
            }
        }

        /// <summary>
        /// Used to retrieve the parent of the current object
        /// </summary>
        protected CfgBase Parent
        {
            get
            {
                return parent;
            }
        }

        /// <summary>
        /// This is a constructor of an object with no external data
        /// </summary>
        /// <param name="confService">A reference to Configuration Service</param>
        /// <param name="className">The name of a class</param>
        /// <param name="isStructure">If true, this is a structure that belongs to some class, false - a class</param>
        /// <param name="parent">For a structure, a reference to its parent</param>
        /// <param name="dataClassName">The name of the data class associated with this object</param>
        internal CfgBase(IConfService confService, string className, bool isStructure, CfgBase parent, string dataClassName)
        {
            XDocument newDoc = new XDocument();

            newDoc.Add(new XElement(
                XName.Get(className, Utils.GetNamespace(confService.Protocol))));
#if (NETCORE || NETSTD20)
            rwLock = new ReentralReadWriteLock();
#else
            rwLock = new ReaderWriterLock();
#endif

            Initialize(confService, newDoc.Root, isStructure, parent, dataClassName);
        }

        internal bool IsSaved
        {
            get
            {
                return isSaved;
            }
            set
            {
                isSaved = value;
            }
        }

        private void Initialize(IConfService initConfService, XElement initXmlData, bool initIsStructure, CfgBase initParent, string dataClassName)
        {

            this.isStructure = initIsStructure;
            this.configurationService = initConfService;
            this.parent = initParent;

            // initialize a data class
            dataClass = configurationService.MetaData.GetClass<CfgDescriptionClass>(dataClassName);

            AcquireWriterLock();

            try
            {
                InitData(initXmlData);
            }
            catch (Exception ex)
            {
                Logger.Warn("Error initializing object", ex);
            }
            finally
            {
                ReleaseWriterLock();
            }
        }

        private void InitData(XElement xmlNewData)
        {
            //this.xmlData = new XElement(xmlNewData);  // first

            //this.xmlData = xmlNewData;  // second
            //objectsHash = null;
            //InitData(xmlNewData, this.dataClass);

            this.xmlData = new XElement(xmlNewData);  // third
            objectsHash = null;
            InitData(xmlData, this.dataClass);
        }

        internal void PostProcessingClonedObject(CfgBase obj)
        {
          if (IgnoreIsSavedFlag) return;
          if (obj == null) return;
          obj.isSaved = isSaved;
          foreach (CfgDescriptionAttribute info in dataClass.Attributes)
          {
            var propName = info.SchemaName;
            if ((info.IsCfgType(CfgTypeMask.List) && info.IsCfgType(CfgTypeMask.Structure)) ||
                IsListOfLinkStructures(info))
            {
              var prop1 = GetPropertyImpl(propName);
              var prop2 = obj.GetPropertyImpl(propName);
              var list1 = prop1 as IList;
              var list2 = prop2 as IList;
              if ((list1 == null) || (list2 == null))
              {
                var cfgBase1 = prop1 as CfgBase;
                var cfgBase2 = prop2 as CfgBase;
                if ((cfgBase1 == null) || (cfgBase2 == null)) continue;
                cfgBase2.isSaved = cfgBase1.isSaved;
                continue;
              }
              if (list1.Count == list2.Count)
              {
                for (int i = 0; i < list1.Count; i++)
                {
                  var obj1 = list1[i] as CfgBase;
                  var obj2 = list2[i] as CfgBase;
                  if ((obj1==null) || (obj2==null)) continue;
                  obj2.isSaved = obj1.isSaved;
                }
                continue;
              }
              foreach (CfgBase cfgBase in list1.OfType<CfgBase>())
              {
                foreach (CfgBase cfgBase2 in list2.OfType<CfgBase>())
                {
                  var objSaved = cfgBase2.isSaved;
                  cfgBase2.isSaved = cfgBase.isSaved;
                  var equals = cfgBase2.Equals(cfgBase);
                  if (!equals) 
                    cfgBase2.isSaved = objSaved;
                }
              }
            }
          }
        }

        private void InitData(XElement xmlNewData, CfgDescriptionClass objDesc)
        {
            // initialize and fill the structures
            if (objectsHash==null)
              objectsHash = new Hashtable();

            CfgBase myParent;
            if (isStructure)
                myParent = this.parent;
            else
                myParent = this;

            string propName;

            foreach (CfgDescriptionAttribute info in objDesc.Attributes)
            {
                propName = info.SchemaName;

                if (info.IsCfgType(CfgTypeMask.Reference) &&
                    objDesc.IsCfgType(CfgTypeMask.Delta) &&
                    info.IsCfgType(CfgTypeMask.List) == false)
                {
                    CfgDescriptionAttributeReference rf = info as CfgDescriptionAttributeReference;
                    ICfgClassOperationalInfo deltaDataClass = objDesc as ICfgClassOperationalInfo;

                    if ((rf!=null) && (deltaDataClass!=null) && 
                       (rf.Class.Name == deltaDataClass.SubjectClassDescription.Name))
                    {
                        InitData(xmlNewData, rf.Class);
                    }
                }

                if (IsDeltaStructureList(info))
                {
                    CfgDescriptionAttributeReference attrClass =
                        info as CfgDescriptionAttributeReference;

                    IList collectionTemp = CreateDeltaStructureList(propName, myParent);
                    if ((collectionTemp != null) && (attrClass!=null))
                    {
                      Type structureClassType = CfgObjectActivator.GetType(
                        attrClass.Class.Name);

                      Type cfgBrokerType = typeof (StructuresBroker<>).MakeGenericType(structureClassType);

                      object broker = Activator.CreateInstance(cfgBrokerType, new object[] {collectionTemp});
                      objectsHash.Add(propName, broker);
                    }
                }
                else if (info is CfgDescriptionAttributeReferenceKeyListDelta)
                {
                    CfgDescriptionAttributeReferenceKeyListDelta attrClass =
                        info as CfgDescriptionAttributeReferenceKeyListDelta;

                    IList collectionTemp = CreateDeltaStructureList(propName, myParent);
                    if (collectionTemp != null)
                    {
                      Type structureClassType = CfgObjectActivator.GetType(
                        attrClass.Class.Name);

                      Type cfgBrokerType = typeof (StructuresBroker<>).MakeGenericType(structureClassType);

                      object broker = Activator.CreateInstance(cfgBrokerType, new object[] {collectionTemp});
                      objectsHash.Add(propName, broker);
                    }
                }
                else if ((info.IsCfgType(CfgTypeMask.List) && info.IsCfgType(CfgTypeMask.Structure)) ||
                     IsListOfLinkStructures(info))
                {
                    //TODO: Should CfgDescriptionAttributeReferenceClassListDelta inherit from CfgDescriptionAttributeReferenceClassList?

                    ICfgListItemInfo classListAttr =
                        info as ICfgListItemInfo;

                    IList collectionTemp = CreateStructureList(propName, myParent, objDesc);
                    if ((collectionTemp != null) && (classListAttr!=null))
                    {
                      Type structureClassType = CfgObjectActivator.GetType(classListAttr.ItemName);

                      Type cfgBrokerType = typeof (StructuresBroker<>).MakeGenericType(structureClassType);

                      object broker = Activator.CreateInstance(cfgBrokerType, new object[] {collectionTemp});
                      objectsHash.Add(propName, broker);
                    }
                }
                else if (info.IsCfgType(CfgTypeMask.Link) && info.IsCfgType(CfgTypeMask.List))
                {
                     object broker = PropertyAccessHelper.CreateLinksListBroker(
                        configurationService, this, this.parent, objDesc, info);
                    if (broker != null) {
                      objectsHash.Add(propName, broker);
                    }

                    //CfgDescriptionAttributeReferenceLink attrLinkList =
                    //                       info as CfgDescriptionAttributeReferenceLink;

                    //Type linkClassType =
                    //    CfgObjectActivator.GetType(attrLinkList.Class.Name);

                    //Type cfgBrokerType = typeof(CfgLinksBroker<>).MakeGenericType(linkClassType);

                    //object broker = Activator.CreateInstance(cfgBrokerType, new object[] { (CfgBase)this, propName });
                    //objectsHash.Add(propName, broker);
                }
                else if (info.IsCfgType(CfgTypeMask.KvList))
                {
                  // Must be lazy for non delta
                  if (this is ICfgDelta)
                  {
                    var obj = CreateKVList(propName, myParent, objDesc);
                    if (obj != null)
                      objectsHash.Add(propName, obj);
                  }
                }
                else if (info.IsCfgType(CfgTypeMask.Structure))
                {
                  var obj = CreateStructureClass(propName, myParent, objDesc);
                  if (obj!=null)
                    objectsHash.Add(propName, obj);
                }
            }
        }

        private bool IsDeltaStructureList(CfgDescriptionAttribute info)
        {
            //This method is called when a property in the delta which is related to a property in the
            //"regular" object is of a different type. Specifically, if the source property is NOT of type
            //"dbidlist" and this property is.

            ICfgAttributeOperationalInfo attrInfo = info as ICfgAttributeOperationalInfo;

            if (attrInfo == null || attrInfo.SubjectAttributeDescription == null) return false;

            return (attrInfo.SubjectAttributeDescription.TypeMask & info.TypeMask) != attrInfo.SubjectAttributeDescription.TypeMask;
        }

        private bool IsListOfLinkStructures(CfgDescriptionAttribute info)
        {
            bool br = false;

            if (info.IsCfgType(CfgTypeMask.List) && info.IsCfgType(CfgTypeMask.Link))
            {
                CfgDescriptionAttributeReference refAttr = info as CfgDescriptionAttributeReference;

                br = refAttr != null ?
                    refAttr.Class.IsCfgType(CfgTypeMask.Structure) : false;
            }

            return br;
        }

        internal void ReloadObjectWithNewXml(XElement xmlNewData)
        {
            AcquireWriterLock();

            InitData(xmlNewData);

            ReleaseWriterLock();
        }

        internal XElement XmlData
        {
            get
            {
                return xmlData;
            }
        }

        internal CfgDescriptionClass MetaData
        {
            get
            {
                return dataClass;
            }
        }

        internal bool IsStructure
        {
            get
            {
                return isStructure;
            }
        }
        /// <exclude/>
        protected virtual int? GetLinkValue(string propertyName)
        {
            AcquireReaderLock();
            int? tempValue = null;

            try
            {
                tempValue = PropertyAccessHelper.GetLinkValue(propertyName, dataClass, xmlData);
            }
            catch (Exception)
            {
                ReleaseReaderLock();

                throw;
            }

            ReleaseReaderLock();

            return tempValue;
        }

        internal int[] GetLinkListValue(string propertyName)
        {
            AcquireReaderLock();
            try
            {
                return PropertyAccessHelper.GetLinkListValue(propertyName, dataClass, xmlData);
            }
            finally
            {
                ReleaseReaderLock();
            }
        }

        internal ICollection<int> GetLinkListCollection(string propertyName)
        {
            AcquireReaderLock();
            try
            {
                return PropertyAccessHelper.GetLinkListCollection(propertyName, dataClass, xmlData);
            }
            finally
            {
                ReleaseReaderLock();
            }
        }

        private object CreateStructureClass(string propertyName, object classRef, CfgDescriptionClass dc)
        {
            return PropertyAccessHelper.CreateStructureClass(propertyName, classRef, dc, configurationService, xmlData);
        }

        internal IList CreateStructureList(string propertyName, object classRef, CfgDescriptionClass dc)
        {
            return PropertyAccessHelper.CreateStructureList(propertyName, classRef, dc, configurationService, xmlData);
        }

        internal IList CreateDeltaStructureList(string propertyName, object classRef, CfgDescriptionClass dc)
        {
            return PropertyAccessHelper.CreateDeltaStructureList(propertyName, classRef, dc, configurationService, xmlData);
        }

        internal IList CreateLinksList(string propertyName, CfgDescriptionClass dc)
        {
            return PropertyAccessHelper.CreateLinksList(propertyName, dc, configurationService, xmlData);
        }

        internal KeyValueCollection CreateKVList(string propertyName, CfgDescriptionClass dc)
        {
            return PropertyAccessHelper.CreateKVList(propertyName, dc, xmlData);
        }
        internal KeyValueCollection CreateKVList(string propertyName, object classRef, CfgDescriptionClass dc)
        {
          return PropertyAccessHelper.CreateKVList(propertyName, classRef, dc, xmlData);
        }

        private object CreateStructureClass(string propertyName, object classRef)
        {
            return PropertyAccessHelper.CreateStructureClass(propertyName, classRef, dataClass, configurationService, xmlData);
        }

        internal IList CreateStructureList(string propertyName, object classRef)
        {
            return PropertyAccessHelper.CreateStructureList(propertyName, classRef, dataClass, configurationService, xmlData);
        }

        internal IList CreateDeltaStructureList(string propertyName, object classRef)
        {
            return PropertyAccessHelper.CreateDeltaStructureList(propertyName, classRef, dataClass, configurationService, xmlData);
        }

        internal IList CreateLinksList(string propertyName)
        {
            return PropertyAccessHelper.CreateLinksList(propertyName, dataClass, configurationService, xmlData);
        }

        internal KeyValueCollection CreateKVList(string propertyName)
        {
            return PropertyAccessHelper.CreateKVList(propertyName, this, dataClass, xmlData);
        }

        internal CfgDescriptionAttribute GetAttributeInfo(string propertyName)
        {
            CfgDescriptionAttribute info = this.dataClass.GetAttribute(propertyName);

            if (info == null)
            {
                ICfgClassOperationalInfo delta = this.dataClass as ICfgClassOperationalInfo;

                if (delta != null)
                {
                    info = delta.SubjectClassDescription.GetAttribute(propertyName);
                }
            }

            return info;
        }
        private object GetPropertyImpl(string propertyName)
        {
            //TODO: Review whether we can optimize the search for properties if this is a delta.
            CfgDescriptionAttribute info = GetAttributeInfo(propertyName);

            // this is the case of Cfg groups. They don't have DBID, it is located in their
            // child, CFG group. For now, we have a straightforward workaround - we get the
            // group info child. Later this need to be re-done
            if (!this.isStructure && (propertyName.Equals(MiscConstants.DbidPropertyName)) && info == null)
            {
              if (this is ICfgBriefInfo)
              {
                CfgBase id = (CfgBase) GetPropertyImpl("ID");
                if (id!=null)
                {
                  return id.GetPropertyImpl(MiscConstants.DbidPropertyName);
                }
                return null;
              }
              CfgBase groupInfo = null;
              if (this is ICfgDelta)
              {
                groupInfo = GetPropertyImpl("deltaGroupInfo") as CfgBase;
              }
              else
              {
                groupInfo = GetPropertyImpl("groupInfo") as CfgBase;
              }
              if (groupInfo == null) return null;
              return groupInfo.GetPropertyImpl(MiscConstants.DbidPropertyName);
            }
          //TODO: Do we want to throw this exception property hasn't been found in the metadata?
            if (info == null)
                throw new InvalidOperationException("Property '" + propertyName + "' is not supported by this version of the configuration server.");

            if (info.IsCfgType(CfgTypeMask.Primitive))
            {
                return PropertyAccessHelper.GetSimpleProperty(info, xmlData);
            }
            else if (info.IsCfgType(CfgTypeMask.Structure) ||
                     (info.IsCfgType(CfgTypeMask.List) && info.IsCfgType(CfgTypeMask.Structure)) ||
                     (info.IsCfgType(CfgTypeMask.Link) && info.IsCfgType(CfgTypeMask.List)) ||
                     info is CfgDescriptionAttributeReferenceKeyListDelta)
            //TODO: ER for this property being key = true? Otherwise we can't tell it's a key list unless we use reflection
            {
              if (objectsHash.ContainsKey(propertyName))
                    return objectsHash[propertyName];
              return null;
            }else
            if (info.IsCfgType(CfgTypeMask.KvList))
            {
              if (objectsHash.ContainsKey(propertyName))
                return objectsHash[propertyName];
              if (this is ICfgDelta) return null;
#if (NETCORE || NETSTD20)
              UpgradeToWriteLock();
#else
              var cookie = new LockCookie();
              var isReadLock = UpgradeToWriteLock(ref cookie);
#endif
              //bool isReadLock = rwLock.IsReaderLockHeld;
              //if (isReadLock)
              //  cookie = rwLock.UpgradeToWriterLock(-1);
              //else
              //  rwLock.AcquireWriterLock(-1);
              try
              {
                if (objectsHash.ContainsKey(propertyName))
                  return objectsHash[propertyName];
                var newKvList = CreateKVList(propertyName);
                if (newKvList != null)
                {
                  objectsHash.Add(propertyName, newKvList);
                }
                return newKvList;
              }
              finally
              {
#if (NETCORE || NETSTD20)
                DowngradeFromWriteLock();
#else
                DowngradeFromWriteLock(isReadLock, ref cookie);
#endif
                //if (isReadLock)
                //  rwLock.DowngradeFromWriterLock(ref cookie);
                //else
                //  rwLock.ReleaseWriterLock();
              }
              //if (objectsHash.ContainsKey(propertyName))
              //  return objectsHash[propertyName];
              //if (this is ICfgDelta) return null;
              //bool isReadLock = rwLock.IsReaderLockHeld;
              //if (isReadLock) rwLock.ReleaseReaderLock();
              //try
              //{
              //  object propLockObject;
              //  lock (_propertyLocks)
              //  {
              //    if (!_propertyLocks.ContainsKey(propertyName))
              //    {
              //      propLockObject = new object();
              //      _propertyLocks[propertyName] = propLockObject;
              //    }
              //    else propLockObject = _propertyLocks[propertyName];
              //  }
              //  KeyValueCollection newKvList;
              //  lock (propLockObject)
              //  {
              //    if (objectsHash.ContainsKey(propertyName))
              //      return objectsHash[propertyName];
              //    newKvList = CreateKVList(propertyName);
              //    if (newKvList != null)
              //    {
              //      rwLock.AcquireWriterLock(-1);
              //      objectsHash.Add(propertyName, newKvList);
              //      rwLock.ReleaseWriterLock();
              //    }
              //  }
              //  return newKvList;
              //}finally
              //{
              //  if (isReadLock) rwLock.AcquireReaderLock(-1);
              //}
            }
            else if (info.IsCfgType(CfgTypeMask.Link))
            {
                if (objectsHash.ContainsKey(propertyName))
                {
                    return objectsHash[propertyName];
                }

                return PropertyAccessHelper.CreateLinkObject(info, configurationService, xmlData);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// This indexer is used to access any configuration object's property using its
        /// string name. Any changes will not be synchronized with Configuration Server 
        /// until the Save() method is called.
        /// </summary>
        /// <param name="propertyName">The name of the property</param>
        /// 
        public object this[string propertyName]
        {
            set
            {
                AcquireWriterLock();

                try
                {
                    EnsureDataBackup();
                    SetPropertyImpl(propertyName, value);
                }
                catch (Exception)
                {
                    ReleaseWriterLock();

                    throw;
                }

                ReleaseWriterLock();
            }

            get
            {
                AcquireReaderLock();
                object tempObject = null;

                try
                {
                    tempObject = GetPropertyImpl(propertyName);
                }
                catch (Exception)
                {
                    ReleaseReaderLock();

                    throw;
                }

                ReleaseReaderLock();

                return tempObject;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal int GetInt(string name)
        {
            object o = this[name];
            if (o == null)
                return 0;
            return Int32.Parse(o.ToString());
        }

        /// <exclude/>
        protected virtual void EnsureDataBackup()
        {
          if (parent!=null)
            parent.EnsureDataBackup();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        private void SetPropertyImpl(string propertyName, object propertyValue)
        {
            CfgDescriptionAttribute info = this.dataClass.GetAttribute(propertyName);

            // this is the case of Cfg groups. They don't have DBID, it is located in their
            // child, CFG group. For now, we have a straightforward workaround - we get the
            // group info child. Later this need to be re-done
            if (!this.isStructure && (propertyName.CompareTo(MiscConstants.DbidPropertyName) == 0) && info == null)
            {
                if (this is CfgDelta)
                {
                    CfgBase groupInfo = GetPropertyImpl("deltaGroupInfo") as CfgBase;
                    if (groupInfo == null) throw new InvalidOperationException("deltaGroupInfo is absent");
                    groupInfo.SetPropertyImpl(MiscConstants.DbidPropertyName, propertyValue);
                }
                else 
                if (this is CfgBriefInfo)
                {
                  CfgBase Id = GetPropertyImpl("ID") as CfgBase;
                  if (Id != null)
                  {
                    Id.SetPropertyImpl(MiscConstants.DbidPropertyName, propertyValue);
                  }
                  return;
                }
                else
                {
                    CfgBase groupInfo = GetPropertyImpl("groupInfo") as CfgBase;
                    if (groupInfo!=null)
                      groupInfo.SetPropertyImpl(MiscConstants.DbidPropertyName, propertyValue);
                }

                return;
            }

            if (info == null)
                throw new ArgumentException("Invalid property name");

            // object objOldProperty = GetProperty(propertyName, null);
            if (xmlData == null)
                throw new InvalidOperationException("The object doesn't have a root node");

            if (propertyValue == null)
                throw new ArgumentException("New value is null");

            if (info.IsCfgType(CfgTypeMask.Primitive))
            {
                PropertyAccessHelper.SetSimpleProperty(info, xmlData, propertyValue);
            }
            else if (info.IsCfgType(CfgTypeMask.KvList))
            {
                if (!(propertyValue is KeyValueCollection))
                    throw new ArgumentException("The new value is not the right type. It should be KeyValueCollection");

                //object propLockObject;
                //lock (_propertyLocks)
                //{
                //  if (!_propertyLocks.ContainsKey(propertyName))
                //  {
                //    propLockObject = new object();
                //    _propertyLocks[propertyName] = propLockObject;
                //  }
                //  else propLockObject = _propertyLocks[propertyName];
                //}
                //lock (propLockObject)
                //{
                  PropertyAccessHelper.SetKVListProperty(info, xmlData, propertyValue);
                  objectsHash[propertyName] = propertyValue;
                //}

                //objectsHash[propertyName] = CreateKVList(propertyName);
            }
            else if (info.IsCfgType(CfgTypeMask.Structure))
            {
                if (info.IsCfgType(CfgTypeMask.List) == false)
                {
                    if (!(propertyValue is CfgBase))
                        throw new ArgumentException("The new value is not the right type. It should be CfgObject");

                    // import xml data
                    PropertyAccessHelper.SetStructureProperty(propertyValue, xmlData);

                    // update structures list
                    CfgBase myParent;
                    if (isStructure)
                        myParent = this.parent;
                    else
                        myParent = this;

                    objectsHash[propertyName] = CreateStructureClass(propertyName, myParent);
                }
                else
                {
                    // import xml data
                    PropertyAccessHelper.SetStructureCollectionProperty(propertyValue, info, xmlData);

                    // update structures list
                    CfgBase myParent;
                    if (isStructure)
                        myParent = this.parent;
                    else
                        myParent = this;

                    // create a new collection
                    ICfgListItemInfo classListAttr = info as ICfgListItemInfo;
                    IList collectionTemp = CreateStructureList(propertyName, myParent);
                    if ((collectionTemp != null) && (classListAttr != null))
                    {
                      Type structureClassType = CfgObjectActivator.GetType(classListAttr.ItemName);
                      Type cfgBrokerType = typeof (StructuresBroker<>).MakeGenericType(structureClassType);
                      object broker = Activator.CreateInstance(cfgBrokerType, new object[] {collectionTemp});
                      objectsHash[propertyName]= broker;
                    }
                    else
                    {
                      objectsHash[propertyName] = collectionTemp;
                    }
                }
            }
            else if (info.IsCfgType(CfgTypeMask.Link))
            {
                if (info.IsCfgType(CfgTypeMask.List) == false)
                {
                    PropertyAccessHelper.SetLinkProperty(propertyValue, info, xmlData);

                    // update hash
                    objectsHash.Remove(propertyName);
                }
                else
                {
                    PropertyAccessHelper.SetLinkColProperty(propertyValue, info, xmlData);

                    // this broker should be there, because all links are initialized at start
                    ICollectionsBroker broker = (ICollectionsBroker)objectsHash[propertyName];
                    broker.Refresh();
                }
            }

            // now if this is a structure, we should update it's parent. Otherwise, we have strange
        }

        internal bool RefreshXml()
        {
            AcquireWriterLock();
            bool br = false;

            try
            {
                br = RefreshXmlImpl();
            }
            catch
            {
                throw;
            }
            finally
            {
                ReleaseWriterLock();
            }

            return br;
        }

        /// <summary>
        /// This method refreshes the XML content of the object according to its (possibly) 
        /// changed member classes (such as structures).
        /// </summary>
        internal virtual bool RefreshXmlImpl()
        {
            bool refreshPerformed = false;

            foreach (CfgDescriptionAttribute info in dataClass.Attributes)
            {
                if (info.IsCfgType(CfgTypeMask.Structure))
                {
                    if (info.IsCfgType(CfgTypeMask.List))
                    {
                        IList structureCollection = (IList)objectsHash[info.SchemaName];

                        if (structureCollection != null)
                        {
                            foreach (object obj in structureCollection)
                            {
                              if (obj is CfgBase)
                                (obj as CfgBase).RefreshXmlImpl();
                            }
                            PropertyAccessHelper.SetStructureCollectionProperty(structureCollection, info, XmlData);
                            refreshPerformed = true;
                        }
                    }
                    else
                    {
                        CfgBase structure = (CfgBase)objectsHash[info.SchemaName];
                        // we try to refresh the structure in case there are some children
                        // that also need to be refreshed
                        if (structure != null)
                        {
                            structure.RefreshXmlImpl();
                            PropertyAccessHelper.SetStructureProperty(structure, XmlData);
                            refreshPerformed = true;
                        }
                    }
                }
                else if (info.IsCfgType(CfgTypeMask.KvList))
                {
                    KeyValueCollection col = (KeyValueCollection)objectsHash[info.SchemaName];

                    if (col != null)
                    {
                        PropertyAccessHelper.SetKVListProperty(info, XmlData, col);
                        refreshPerformed = true;
                    }
                }
            }

            return refreshPerformed;
        }

        /// <summary>
        /// Returns a string representation of the object.
        /// </summary>
        public override string ToString()
        {
            StringBuilder output = new StringBuilder();
            output.Append("CfgObject type = " + this.GetType().ToString() + "\n");
            output.Append("properties :\n");
            output.Append("{\n");

            StringBuilder propertiesOutput = ToStringProperties();

            // format properties output
            string propFormat = MiscConstants.ToStringIndent + propertiesOutput.ToString();
            propFormat = Regex.Replace(propFormat, "\n", "\n" + MiscConstants.ToStringIndent);
            propFormat = propFormat.TrimEnd(' ');
            output.Append(propFormat);

            output.Append("}");

            return output.ToString();
        }

        /// <exclude/>
        protected virtual StringBuilder ToStringProperties()
        {
          StringBuilder propertiesOutput = new StringBuilder();

          foreach (CfgDescriptionAttribute info in dataClass.Attributes)
          {
            //propertiesOutput.Append(info.SchemaName + " : ");

            // now we prepare the output of the values
            if (info.IsCfgType(CfgTypeMask.Link) && info.IsCfgType(CfgTypeMask.List) == false)
            {
              Nullable<int> linkDBID = GetLinkValue(info.SchemaName);
              //if (!linkDBID.HasValue)
              //  propertiesOutput.Append("null");
              //else
              //  propertiesOutput.Append(linkDBID.ToString());
              if (linkDBID.HasValue)
              {
                propertiesOutput.Append(info.SchemaName + " : ");
                propertiesOutput.Append(linkDBID.ToString());
                propertiesOutput.Append("\n");
              }
            }
            else
            {
              object property = this[info.SchemaName];

              //if (property == null)
              //{
              //  propertiesOutput.Append("null");
              //}
              //else
              if (property != null)
              {
                propertiesOutput.Append(info.SchemaName + " : ");
                if (info.CfgEnum == CfgObjectProperty.CFGPassword)
                {
                  propertiesOutput.Append("[output suppressed]");
                }
                else
                {
                  propertiesOutput.Append(property.ToString());
                }
                propertiesOutput.Append("\n");
              }
            }

            //propertiesOutput.Append("\n");
          }
          return propertiesOutput;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        internal virtual void UpdateChildStructuresSavedState()
        {
            if (IsStructure == true) throw new InvalidOperationException("Method not applicable to structures");

            foreach (CfgDescriptionAttribute info in dataClass.Attributes)
            {
                if (info.IsCfgType(CfgTypeMask.Structure))
                {
                    if (info.IsCfgType(CfgTypeMask.List))
                    {
                        IList structureCollection = (IList)objectsHash[info.SchemaName];

                        if (structureCollection == null) continue;

                        foreach (CfgStructure item in structureCollection)
                        {
                            item.IsSaved = IsSaved;
                        }
                    }
                    else
                    {
                        CfgBase structure = (CfgBase)objectsHash[info.SchemaName];

                        if (structure != null)
                        {
                            structure.IsSaved = IsSaved;
                        }
                    }
                }

            }
        }

        private static XmlNode GetSubNode(XmlNode node, string strName)
        {
            XmlNode tempNode = node.FirstChild;
            while (tempNode != null)
            {
                if (tempNode.Name == strName)
                    break;

                tempNode = tempNode.NextSibling;
            }

            return tempNode;
        }

        /// <summary>
        /// Provides an XML representation of the current object.
        /// </summary>
        /// <remarks>
        /// The XML returned is a copy, and will not 
        /// be updated should the object change -- unless this method 
        /// is called again.  Likewise, updates to the XML
        /// will never affect the object.        
        /// </remarks>
        /// <returns>an XML "snapshot" of the object</returns>
        public virtual XElement ToXml()
        {
            RefreshXml();

            return CfgObjectUpdateHelper.SortObjectAttributes(XmlData, this.dataClass);
        }

        /// <summary>
        /// Provides the URI of the Configuration Server to which this
        /// object belongs.
        /// </summary>
        public Endpoint Endpoint
        {
            get
            {
                ConfService confService = ConfigurationService as ConfService;

                return confService != null && confService.Protocol != null ?
                    confService.Protocol.Endpoint : null;
            }
        }

      internal static bool CompareObjects(Object object1, Object object2, CfgDescriptionAttribute attribute)
      {
        if (ReferenceEquals(object1, object2)) return true;
        if ((object1 == null) || (object2 == null)) return false;
        if (object1.GetType() != object2.GetType()) return false;
        var cfgBase = object1 as CfgBase;
        if (cfgBase != null)
        {
          return cfgBase.Equals(object2);
        }
        var broker = object1 as ICollectionsBroker;
        if (broker != null)
        {
          return broker.Equals(object2);
        }
        var dic1 = object1 as IDictionary;
        if (dic1 != null)
          return CompareDictionary(dic1, object2 as IDictionary);
        var list = object1 as IEnumerable;
        if (list != null)
          return CompareList(list, object2 as IEnumerable);
        return object1.Equals(object2);
      }
      internal static bool CompareDictionary(IDictionary dictionary1, IDictionary dictionary2)
      {
        if (ReferenceEquals(dictionary1,dictionary2)) return true;
        if ((dictionary1==null) || (dictionary2==null)) return false;
        if (dictionary1.GetType()!=dictionary2.GetType()) return false;
        if (dictionary1.Count!=dictionary2.Count) return false;
        foreach (DictionaryEntry entry in dictionary1)
        {
          if (!dictionary2.Contains(entry.Key)) return false;
          var value2 = dictionary2[entry.Key];
          if ((value2==null) && (entry.Value==null)) continue;
          if ((value2==null) || (entry.Value==null)) return false;
          if (!CompareObjects(entry.Value, value2, null)) return false;
        }
        return true;
      }
      internal static bool CompareList(IEnumerable list1, IEnumerable list2)
      {
        if (ReferenceEquals(list1, list2)) return true;
        if ((list1 == null) || (list2 == null)) return false;
        if (list1.GetType() != list2.GetType()) return false;
        if (list1 is String) return list1.Equals(list2);
        if (list1.Cast<object>().Count() != list2.Cast<object>().Count()) return false;
        var count1 = list1.Cast<object>().Count(arg => ((object)arg) != null);
        var count2 = list2.Cast<object>().Count(arg => ((object)arg) != null); ;
        if (count1!=count2) return false;
        foreach (Object value in list1)
        {
          bool found = false;
          foreach (Object value2 in list2)
          {
            if (CompareObjects(value, value2, null))
            {
              found = true;
              break;
            }
          }
          if (!found) return false;
        }
        return true;
      }
      private static int CalcObjectHashCode(object value)
      {
        if (value is String)
          return value.GetHashCode();
        var cfgBase = value as CfgBase;
        if (cfgBase != null)
        {
          return 31 * cfgBase.GetHashCode();
        }
        var broker = value as ICollectionsBroker;
        if (broker != null)
        {
          return 37 * broker.GetHashCode();
        }
        var dic1 = value as IDictionary;
        if (dic1 != null)
        {
          return 17 * CalcDictionaryHashCode(dic1);
        }
        var list1 = value as IEnumerable;
        if (list1 != null)
        {
          return 27 * CalcListHashCode(list1);
        }
        return 29 * value.GetHashCode();
      }

      private static int CalcListHashCode(IEnumerable list)
      {
        if (list == null) return typeof(IEnumerable).GetHashCode();
        var code = list.GetType().GetHashCode();
        return list.Cast<object>().Aggregate(code, (current, value) =>
        {
          current <<= 1;
          return current ^ CalcObjectHashCode(value);
        });
      }
      internal static int CalcDictionaryHashCode(IDictionary dictionary1)
      {
        if (dictionary1 == null) return typeof(IDictionary).GetHashCode();
        var code = dictionary1.GetType().GetHashCode();
        foreach (DictionaryEntry entry in dictionary1)
        {
          code ^= 19 * entry.Key.GetHashCode();
          if (entry.Value != null)
          {
            code ^= CalcObjectHashCode(entry.Value);
          }
        }
        return code;
      }

      /// <exclude/>
      public override bool Equals(object obj)
      {
        if (ReferenceEquals(this, obj)) return true;
        if (obj==null) return false;
        if (GetType()!=obj.GetType()) return false;
        var cfgBase = obj as CfgBase;
        if (cfgBase==null) return false;
        AcquireReaderLock();
        cfgBase.AcquireReaderLock();
        try
        {
          if (!IgnoreIsSavedFlag)
          {
            if (IsSaved != cfgBase.IsSaved) return false;
          }
          foreach (CfgDescriptionAttribute attribute in dataClass.Attributes)
          {
            var name = attribute.SchemaName;
            var value1 = GetPropertyValue(name, attribute);
            var value2 = cfgBase.GetPropertyValue(name);
            if ((value1==null) && (value2==null)) continue;
            if ((value1 == null) || (value2 == null)) return false;
            if (value1.GetType()!=value2.GetType()) return false;
            if (!CompareObjects(value1,value2, attribute))
              return false;
          }
        }
        finally
        {
          cfgBase.ReleaseReaderLock();
          ReleaseReaderLock();
        }
        return true;
      }

      private object GetPropertyValue(string name)
      {
        return GetPropertyValue(name, dataClass.GetAttribute(name));
      }
      private static bool IsDelta(XElement node)
      {
        return node.Name.LocalName.Contains("Delta");
      }
      internal static XElement GetSubNode(XElement node, string name)
      {
        if (node == null || name == null)
          return null;
        XElement res = node.Elements().FirstOrDefault(element => element.Name.LocalName.Equals(name));
        if (res == null && IsDelta(node))
        {
          XElement tempNode = node.Element(
              XName.Get(node.Name.LocalName.Remove(
                  node.Name.LocalName.IndexOf(
                      "Delta", StringComparison.CurrentCultureIgnoreCase), 5),
                         node.Name.NamespaceName));

          res = GetSubNode(tempNode, name);
        }

        return res;
      }
      private object GetPropertyValue(string name, CfgDescriptionAttribute attribute)
      {
        if (attribute==null)
          return GetPropertyImpl(name);
        if ((attribute!=null) && (attribute.IsCfgType(CfgTypeMask.Link)))
        {
          if (objectsHash.Contains(name))
            return objectsHash[name];
          XElement rootNode = GetSubNode(xmlData, name);
          if (rootNode == null) return null;
          var attr = rootNode.Attribute("value");
          if (attr==null) return null;
          string myValue = attr.Value;
          return int.Parse(myValue);
        }
        return GetPropertyImpl(name);
      }
      /// <exclude/>
      public override int GetHashCode()
      {
        var code = GetType().GetHashCode();
        AcquireReaderLock();
        try
        {
          foreach (CfgDescriptionAttribute attribute in dataClass.Attributes)
          {
            var name = attribute.SchemaName;
            var value = GetPropertyValue(name, attribute);
            if (value == null) continue;
            code ^=  13*name.GetHashCode();
            code ^= CalcObjectHashCode(value);
          }
        }
        finally
        {
          if (!IgnoreIsSavedFlag)
          {
            if (isSaved) code <<= 1;
          }
          ReleaseReaderLock();
        }
        return code;
      }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml.Linq;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
  /// <exclude/>
  public class CfgBriefInfo : CfgObject, ICfgBriefInfo
  {
    /// <summary>
    /// Constructor designed for usage from generated classes in deserializing constructors.
    /// </summary>
    /// <param name="confService">configuration service instance</param>
    /// <param name="xmlData">bound data from Configuration SDK message</param>
    /// <param name="additionalParameters"></param>
    /// <param name="dataClassName">name of internal COM data class</param>
    public CfgBriefInfo(IConfService confService, XElement xmlData, object[] additionalParameters, string dataClassName) 
      : base(confService, xmlData, additionalParameters, dataClassName)
    {
    }

    /// <summary>
    /// Constructor 
    /// </summary>
    /// <param name="confService">configuration service instance</param>
    /// <param name="className"></param>
    /// <param name="dataClassName">name of internal COM data class</param>
    public CfgBriefInfo(IConfService confService, string className, string dataClassName) 
      : base(confService, className, dataClassName)
    {
    }

    /// <exclude/>
    public virtual CfgID ID
    {
      get { return null; }
    }

    /// <exclude/>
    public ICfgObject CfgObject
    {
      get
      {
        return ConfigurationService.RetrieveObject(ObjectDbid, ObjectType);
      }
    }
    /// <exclude/>
    public override void Save()
    {
      throw new COMException("BriefInfo structures can't be saved");
    }
    internal override void UpdateChildStructuresSavedState()
    {
      // Do nothing
    }
    /// <exclude/>
    public override void Update(ICfgDelta deltaObject)
    {
      throw new COMException("BriefInfo structures can't be updated with delta");
    }
    /// <exclude/>
    public override XElement ToXml()
    {
      return CfgObjectUpdateHelper.SortObjectAttributes(XmlData, MetaData);
    }
  }
}

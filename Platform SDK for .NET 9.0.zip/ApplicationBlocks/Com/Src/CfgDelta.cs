//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using System.Xml;
using System.Collections;
using System.Xml.Linq;
using Genesyslab.Platform.Configuration.Protocols.Metadata;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// This is a base class for all Configuration Server delta objects
    /// </summary>

    public class CfgDelta : CfgObject, ICfgDelta
    {
        internal CfgDelta(IConfService srvc, XElement xmlData, object[] additionalParameters, string dataClassName) :
            base(srvc, xmlData, additionalParameters, dataClassName)
        {
        }

        /// <summary>
        /// This method returns a copy of the object's internally stored
        /// XML representation.
        /// </summary>
        /// <returns>an XML representation of this object</returns>
        public override XElement ToXml()
        {
            //The reason we override here is because the parent ToXML method
            //refreshes the existing XML creating unnecessary empty elements. 
            //Because all delta object properties are read only, it is sufficient
            //to just return a copy of the current XML as received from config server.

            return new XElement(XmlData);
        }
        /// <exclude/>
        protected override StringBuilder ToStringProperties()
        {
          StringBuilder propertiesOutput = base.ToStringProperties();
          CfgDescriptionClass baseClass = null;
          if (MetaData is ICfgClassOperationalInfo)
          {
            baseClass = ((ICfgClassOperationalInfo) MetaData).SubjectClassDescription;
          }
          if (baseClass == null) return propertiesOutput;

          foreach (CfgDescriptionAttribute info in baseClass.Attributes)
          {
            //propertiesOutput.Append(info.SchemaName + " : ");

            // now we prepare the output of the values
            if (info.IsCfgType(CfgTypeMask.Link) && info.IsCfgType(CfgTypeMask.List) == false)
            {
              Nullable<int> linkDBID = GetLinkValue(info.SchemaName);
              //if (!linkDBID.HasValue)
              //  propertiesOutput.Append("null");
              //else
              //  propertiesOutput.Append(linkDBID.ToString());
              if (linkDBID.HasValue)
              {
                propertiesOutput.Append(info.SchemaName + " : ");
                propertiesOutput.Append(linkDBID.ToString());
                propertiesOutput.Append("\n");
              }
            }
            else
            {
              object property = this[info.SchemaName];

              //if (property == null)
              //{
              //  propertiesOutput.Append("null");
              //}
              //else
              if (property != null)
              {
                if (info.Operation == CfgOperation.Add)
                {
                  string temp = info.SchemaName;
                  if (!String.IsNullOrEmpty(temp))
                  {
                    propertiesOutput.Append("added").Append(Char.ToUpper(temp[0])).Append(temp.Remove(0, 1)).Append(" : ");
                  }
                }
                else
                {
                  propertiesOutput.Append(info.SchemaName + " : ");
                }
                propertiesOutput.Append(property.ToString());
                propertiesOutput.Append("\n");
              }
            }
            //propertiesOutput.Append("\n");

          }
          return propertiesOutput;
        }
        /// <exclude/>
        protected override int? GetLinkValue(string propertyName)
        {
            //var rwLock = LockObject;
            //rwLock.AcquireReaderLock(-1);
            AcquireReaderLock();
          try
          {
            return PropertyAccessHelper.GetLinkValue(propertyName, XmlData, this);
          }
          finally 
          {
                //rwLock.ReleaseReaderLock();
                ReleaseReaderLock();
            }
        }

    }
}

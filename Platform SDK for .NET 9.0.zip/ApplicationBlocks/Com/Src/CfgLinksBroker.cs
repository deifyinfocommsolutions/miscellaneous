//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal interface ICollectionsBroker
    {
        void Refresh();
    }

    /// <summary>
    /// Summary description for CfgConfigurationBroker.
    /// </summary>
    internal class CfgLinksBroker<T> : IList<T>, ICollectionsBroker
    {
        private bool initialized;
        private string propertyName;
        private IList<T> baseCollection;
        private CfgBase cfgObject;
        private object lockObject = new object();

        public CfgLinksBroker(CfgBase cfgObject, string propertyName)
        {
            initialized = false;
            baseCollection = null;
            this.cfgObject = cfgObject;
            this.propertyName = propertyName;
        }

        private void Initialize()
        {
            if (!initialized)
            {
                IList collectionTemp = cfgObject.CreateLinksList(propertyName);
                if (!(collectionTemp is IList<T>))
                    throw new InvalidCastException("We created a list of links : " + propertyName + ". The type, however, is invalid.");

                baseCollection = (IList<T>)collectionTemp;

                initialized = true;
            }
        }

        public void Refresh()
        {
            lock (lockObject)
            {
                if (!initialized)
                    return;

                // refresh the collection
                IList collectionTemp = cfgObject.CreateLinksList(propertyName);
                if (!(collectionTemp is IList<T>))
                    throw new InvalidCastException("We created a list of links : " + propertyName + ". The type, however, is invalid.");

                baseCollection = (IList<T>)collectionTemp;
            }
        }

        public override string ToString()
        {
            StringBuilder output = new StringBuilder();

            ICollection<int> linkDBIDs = cfgObject.GetLinkListCollection(propertyName);
            output.AppendFormat("A collection of DBIDs = ");
            if (linkDBIDs != null)
            {
                output.AppendFormat("list of {0} item(s) {{\n", linkDBIDs.Count);

                foreach (int i in linkDBIDs)
                {
                    output.Append(MiscConstants.ToStringIndent + i.ToString() + "\n");
                }

                output.Append("}");
            }
            else
                output.Append("NULL");

            return output.ToString();
        }

        #region IList<T> Members

        public int IndexOf(T item)
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                return baseCollection.IndexOf(item);
            }
        }

        public void Insert(int index, T item)
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                baseCollection.Insert(index, item);

                cfgObject[propertyName] = baseCollection;
            }
        }

        T IList<T>.this[int index]
        {
            get
            {
                lock (lockObject)
                {
                    if (!initialized)
                        Initialize();

                    return baseCollection[index];
                }
            }
            set
            {
                lock (lockObject)
                {
                    if (!initialized)
                        Initialize();

                    baseCollection[index] = value;

                    cfgObject[propertyName] = baseCollection;
                }
            }
        }

        public void RemoveAt(int index)
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                baseCollection.RemoveAt(index);

                cfgObject[propertyName] = baseCollection;
            }
        }
        #endregion

        #region ICollection<T> Members

        public void Add(T item)
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                baseCollection.Add(item);

                cfgObject[propertyName] = baseCollection;
            }
        }

        public bool Contains(T item)
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                return baseCollection.Contains(item);
            }
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                baseCollection.CopyTo(array, arrayIndex);
            }
        }

        public bool Remove(T item)
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                bool res = baseCollection.Remove(item);

                cfgObject[propertyName] = baseCollection;

                return res;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                lock (lockObject)
                {
                    if (!initialized)
                        Initialize();

                    return baseCollection.IsReadOnly;
                }
            }
        }

        public void Clear()
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                baseCollection.Clear();

                cfgObject[propertyName] = baseCollection;
            }
        }
        public int Count
        {
            get
            {
                lock (lockObject)
                {
                    if (!initialized)
                        Initialize();

                    return baseCollection.Count;
                }
            }
        }
        #endregion

        #region IEnumerable<T> Members

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                return baseCollection.GetEnumerator();
            }
        }

        #endregion

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            lock (lockObject)
            {
                if (!initialized)
                    Initialize();

                return baseCollection.GetEnumerator();
            }
        }

        #endregion

      public override int GetHashCode()
      {
        var code = GetType().GetHashCode();
        ICollection<int> linkDBIDs = cfgObject.GetLinkListCollection(propertyName);
        if (linkDBIDs!=null)
        foreach (int dbiD in linkDBIDs)
        {
          code ^= 37*dbiD;
        }
        return code;
      }

      public override bool Equals(object obj)
      {
        if (obj == null) return false;
        if (ReferenceEquals(obj, this)) return true;
        var broker = obj as CfgLinksBroker<T>;
        if (broker==null) return false;
        if (!propertyName.Equals(broker.propertyName)) return false;
        if ((cfgObject==null) && (broker.cfgObject==null)) return true;
        if ((cfgObject==null) || (broker.cfgObject==null)) return false;

        ICollection<int> linkDBIDs1 = cfgObject.GetLinkListCollection(propertyName);
        ICollection<int> linkDBIDs2 = broker.cfgObject.GetLinkListCollection(propertyName);
        return CfgBase.CompareList(linkDBIDs1, linkDBIDs2);

      }
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Collections;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Commons.Protocols.Internal;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.ApplicationBlocks.Commons;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Commons.Protocols;
using System.Xml.Linq;
using System.Linq;
using Genesyslab.Platform.Configuration.Protocols.Utilities;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Configuration.Protocols.Metadata;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// This is a base class for all standalone Configuration Server 
    /// objects. 
    /// </summary>
    public abstract class CfgObject : CfgBase, ICfgObject, ICloneable /*, IPredicate <ConfigurationEvent>*/
    {
        private XElement oldXmlData;
        private KeyValueCollection parameters;
        private string objectPath;

        internal CfgObject(IConfService confService, XElement xmlData, object[] additionalParameters, string dataClassName)
            : base(confService, xmlData, false, null, dataClassName)
        {
            //oldXmlData = new XElement(xmlData);
            oldXmlData = null;
            IsSaved = true;
            UpdateChildStructuresSavedState();

            if (additionalParameters != null)
            {
                if (additionalParameters[0] != null && (additionalParameters[0] is KeyValueCollection))
                    this.parameters = (KeyValueCollection)additionalParameters[0];

                if (additionalParameters[1] != null)
                    this.objectPath = additionalParameters[1].ToString();
            }

            CreateLogger(confService);

            // SubscribeToChange();
        }

        internal CfgObject(IConfService confService, string className, string dataClassName)
            : base(confService, className, false, null, dataClassName)
        {
            IsSaved = false;
            UpdateChildStructuresSavedState();
            CreateLogger(confService);
        }

        private void CreateLogger(IConfService confService)
        {
            ConfService cs = confService as ConfService;

            if (cs == null)
            {
                return;
            }

            EnableLogging(cs.GetChildLogger(this.GetType().Name));
        }

        /// <summary>
        /// Synchronizes changes in a class with Configuration Server. Internally generates the correct delta
        /// object and sends it to Configuration Server.
        /// </summary>
        public virtual void Save()
        {
            Save(ConfigurationService.Protocol);
        }

        internal void Save(IProtocol protocol)
        {
            AcquireWriterLock();

            try
            {
                RefreshXmlImpl();

                if (Logger.IsInfoEnabled)
                {
                    Logger.InfoFormat("Saving object... [{0}], Dbid: [{1}]", ObjectType, ObjectDbid);
                }

                if (IsSaved == false)
                {
                    CreateNewObject(protocol);
                }
                else
                {
                    UpdateSavedObject(protocol);
                }

                if (Logger.IsInfoEnabled)
                {
                    Logger.InfoFormat("Save operation successful. [{0}], Dbid: [{1}]", ObjectType, ObjectDbid);
                }

                if (ConfigurationService.Policy.CacheOnSave(this))
                {
                    UpdateCacheOnSave();
                }
            }
            catch (Exception e)
            {
                Logger.Error("Save caused an exception", e);
                throw;
            }
            finally
            {
                ReleaseWriterLock();
            }
        }

        private void UpdateCacheOnSave()
        {
            try
            {
                if (Logger.IsInfoEnabled)
                {
                    Logger.InfoFormat("Adding to cache. [{0}], Dbid: [{1}]", ObjectType, ObjectDbid);
                }

                ConfigurationService.Cache.Update(this);
            }
            catch (Exception ex)
            {
                if (Logger.IsWarnEnabled)
                {
                    Logger.Warn("Unable to add to cache! [" + ObjectType + "], Dbid [" + ObjectDbid + "]\r\n", ex);
                }
            }
        }

        private void UpdateSavedObject(IProtocol protocol)
        {
            string className = GlobalConfService.ObjectTypeToName(ObjectType);

            CfgUtilities util = new CfgUtilities(
                Utils.GetMetadata(protocol));

            XDocument oldDoc = new XDocument(
                new XElement(
                    XName.Get("ConfData", Utils.GetNamespace(protocol))));

            //It's necessary to sort old xml here to essentially clean up any "garbage" that 
            //may have been here -- for instance the "CSID" property of CfgID is not in the 
            //metadata for CfgID but it may have ended up here from the XML received by
            //config server. 
            oldDoc.Elements().First().Add(
                CfgObjectUpdateHelper.SortObjectAttributes(oldXmlData, MetaData));

            XDocument newDoc = new XDocument(
                new XElement(
                    XName.Get("ConfData", Utils.GetNamespace(protocol))));

            newDoc.Elements().First().Add(
                CfgObjectUpdateHelper.SortObjectAttributes(XmlData, MetaData));

            XDocument deltaDoc = null;

            try
            {
                deltaDoc = util.CreateDelta(oldDoc, newDoc);
            }
            catch (Exception ex)
            {
                Logger.Debug("Unable to create delta", ex);

                throw ex;
            }

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("This is an update of an existing object and it will be updated using the following delta:\r\n {0}", DocumentWriter.ToString(deltaDoc));
            }

            GlobalConfService.UpdateObject(protocol, ObjectType, deltaDoc, parameters);

            // update the next commitment point
            //oldXmlData = new XElement(XmlData);
            oldXmlData = null; // reset backup data
            UpdateChildStructuresSavedState();
        }

        private void CreateNewObject(IProtocol protocol)
        {
            XDocument deltaDoc = CfgObjectUpdateHelper.CreateDeltaForNewObject(this);

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("This is a new object and it will be created using the following XML:\r\n {0}", DocumentWriter.ToString(this.XmlData));
            }

            XElement newObjectXml;

            try
            {
                newObjectXml = GlobalConfService.CreateObject(protocol, ObjectType, deltaDoc, parameters);
            }
            catch (Exception ex)
            {
                if (Logger.IsWarnEnabled)
                {
                    Logger.Warn("Unable to create object! [" + ObjectType + "], Dbid: [" + ObjectDbid + "]\r\n", ex);
                }

                throw ex;
            }

            if (newObjectXml == null)
                return;

            this.ReloadObjectWithNewXml(newObjectXml);

            //oldXmlData = new XElement(newObjectXml);
            oldXmlData = null; // reset backup data
            IsSaved = true;
            UpdateChildStructuresSavedState();
        }

        /// <summary>
        /// Deletes the configuration object from the Configuration Server
        /// </summary>
        public void Delete()
        {
            AcquireWriterLock();

            try
            {
                Delete(ConfigurationService.Protocol);
            }
            catch
            {
                ReleaseWriterLock();

                throw;
            }

            IsSaved = false;

            UpdateChildStructuresSavedState();

            this[MiscConstants.DbidPropertyName] = 0;

            ReleaseWriterLock();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        internal void Delete(IProtocol protocol)
        {
            object idObj = this[MiscConstants.DbidPropertyName];

            if (IsSaved == false)
                throw new InvalidOperationException("This object has not been saved.");

            if (idObj == null)
                throw new InvalidOperationException();

            GlobalConfService.DeleteObject(protocol, ObjectType, Int32.Parse(idObj.ToString()));
            oldXmlData = null; // remove backup data

            if (Logger.IsInfoEnabled)
            {
                Logger.InfoFormat("Deleted object [{0}], Dbid: {1} from Configuration Server.", ObjectType, ObjectDbid);
            }

            if (ConfigurationService.Cache != null &&
                ConfigurationService.Cache.Policy != null &&
                ConfigurationService.Cache.Policy.RemoveOnDelete(this))
            {
                ConfigurationService.Cache.Remove(this);

                if (Logger.IsInfoEnabled)
                {
                    Logger.InfoFormat("Deleted object [{0}], Dbid: {1} from cache.", ObjectType, ObjectDbid);
                }

            }
        }

        /// <summary>
        /// Retrieves the latest data from the Configuration Server and updates the object's data
        /// </summary>
        public void Refresh()
        {
            Refresh(ConfigurationService.Protocol);
            oldXmlData = null; // remove backup data
        }

        internal void Refresh(IProtocol protocol)
        {
            AcquireWriterLock();

            try
            {
                CfgFilterBasedQuery query = new CfgFilterBasedQuery(ObjectType);
                query[MiscConstants.FilterDbidName] = this.ObjectDbid;

                Load(protocol, query, this is ICfgBriefInfo);

                if (Logger.IsInfoEnabled)
                {
                    Logger.InfoFormat("Refreshed object [{0}], Dbid: {1}.", ObjectType, ObjectDbid);
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                ReleaseWriterLock();
            }

        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        internal void Load(IProtocol protocol, CfgFilterBasedQuery query)
        {
          Load(protocol, query, false);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        internal void Load(IProtocol protocol, CfgFilterBasedQuery query, bool isBriefInfo)
        {
            CfgObjectType queryObjectType;
            XDocument resDoc;
            KeyValueCollection[] innerParameters;
            string[] objectPaths;

            GlobalConfService.InternalLoadObject(protocol, query, out resDoc, out queryObjectType, out innerParameters, out objectPaths, isBriefInfo);

            // make sure that this is the right type of the document
            if (queryObjectType != ObjectType)
            {
                throw new InvalidOperationException("Query is of invalid type!");
            }

            string ourName = GlobalConfService.ObjectTypeToName(ObjectType) + ((isBriefInfo) ? "Brief" : "");

            if (resDoc == null)
                throw new InvalidOperationException("Query returned an empty result!");

            int objectsCount = resDoc.Root.Elements().Count();

            if (objectsCount != 1 || resDoc.Root.Elements().First().Name.LocalName.CompareTo(ourName) != 0)
            {
                throw new InvalidOperationException("Query returned a result of invalid type!");
            }

            ReloadObjectWithNewXml(resDoc.Root.Elements().First());

            // TODO! Should we protect these two members from multiple-thread access?
            if (!isBriefInfo)
            {
              this.parameters = innerParameters[0];

              this.objectPath = objectPaths[0];
            }
        }

        /// <summary>
        /// Returns the configuration object type
        /// </summary>
        /// <returns></returns>
        public CfgObjectType ObjectType
        {
            get
            {
                CfgDescriptionObject objMetadata = MetaData as CfgDescriptionObject;

                return objMetadata == null ? CfgObjectType.CFGNoObject : objMetadata.CfgEnum;
            }
        }

        /// <summary>
        /// Returns the dbid of the current object, or 0 if object has not been saved.
        /// </summary>
        /// <returns>the dbid of the current object, or 0 if object has not been saved</returns>
        public int ObjectDbid
        {
            get
            {
                int? i = (int?)this[MiscConstants.DbidPropertyName];
                return (i == null ? 0 : (int)i);
            }
        }

        /// <summary>
        /// This property specifies DBID of the folder, in which the object resides in the Configuration Server.
        /// 
        /// <para>
        /// Zero value means that object read request was done without <see cref="ICfgFilterBasedQuery.DoRequestFolderId"/> option enabled, 
        /// configuration server did not return this value for some reason, or this multiple objects read response does not contain folders DBIDs for
        /// all the objects read.
        /// </para>
        /// <para>
        /// <b><i>Note:</i></b> Be aware that to track moving of the object to different folder
        /// in the configuration server, it is required to subscribe for <see cref="CfgFolder"/>'s changes
        /// and look which <see cref="CfgFolder"/> got updated to contain this particular member.
        /// </para>
        /// </summary>
        /// <returns>folder DBID or 0</returns>
        public int FolderId
        {
            get
            {
                if (parameters == null) return 0;
                if (!parameters.ContainsKey(MiscConstants.FolderDbidName)) return 0;
                return parameters.GetAsInt(MiscConstants.FolderDbidName);
            }
            set
            {
                if (IsSaved)
                {
                    throw new ConfigException(
                        "Can't change this property because object has been saved.");
                }

                if (parameters == null)
                {
                    parameters = new KeyValueCollection();
                }

                parameters[MiscConstants.FolderDbidName] = value;
            }
        }

        /// <summary>
        /// Returns path of the object in the Configuration Server.
        /// <para>
        /// Null value means that object read request was done without <see cref="ICfgFilterBasedQuery.DoRequestObjectPath"/>
        /// option enabled, configuration server did not return this value for some reason, or this multiple objects read response does not contain paths for
        /// all the objects read.
        /// </para>
        /// <para>
        /// <b><i>Note:</i></b> Be aware that to track moving of the object to different folder ("to different path") 
        /// in the configuration server, it is required to subscribe for <see cref="CfgFolder"/>'s changes
        /// and look which <see cref="CfgFolder"/> got updated to contain this particular object.
        /// </para>
        /// </summary>
        /// <returns>Object path or null</returns>
        public string ObjectPath
        {
            get
            {
                return objectPath;
            }
        }

        /// <summary>
        /// Retrieves a permission mask (see <code>ConfServerPermissions</code> enum) of accessing the object by a specified account (another configuration object).
        /// For example, called on CfgTenant with CfgAgent as a parameter, returns the set of permissions for this
        /// agent to access this tenant. 
        /// </summary>
        /// <param name="accountObject">Account (can be any Configuration Server class)</param>
        /// <returns>Permissions mask</returns>
        public int RetrieveAccountPermissions(CfgObject accountObject)
        {
            if (accountObject == null)
                throw new ArgumentNullException("accountObject");

            return GlobalConfService.ReadObjectPermissions(ConfigurationService.Protocol,
                                                     (int)this[MiscConstants.DbidPropertyName],
                                                    ObjectType,
                                                    (int)accountObject[MiscConstants.DbidPropertyName],
                                                    accountObject.ObjectType);

        }

        /// <summary>
        /// Retrieves a full list of permissions to access this object for all user accounts. See <code>Permission</code> class.
        /// </summary>
        /// <returns>A list of Permission objects</returns>
        public Collection<PermissionDescriptor> RetrievePermissions()
        {
            XDocument permissions = GlobalConfService.ReadPermissions(ConfigurationService.Protocol, 
            //                                        (int)this[MiscConstants.DbidPropertyName],
                                                    ObjectDbid, ObjectType);

            return XmlPermissionsHelper.GetPermissionsList(permissions);
        }

        /// <summary>
        /// Removes the specified account from the current object's access list.
        /// </summary>
        /// <param name="accountObject">the account object to remove from the access list</param>
        /// <param name="recursive">specifies whether to remove the account recursively from child objects</param>
        public void RemoveAccount(CfgObject accountObject, bool recursive)
        {
            if (accountObject == null)
                throw new ArgumentNullException("accountObject");

            GlobalConfService.RemoveAccount(
                ConfigurationService.Protocol,
                ObjectDbid,
                ObjectType,
                accountObject.ObjectDbid,
                accountObject.ObjectType, 1);
        }

        /// <summary>
        /// Changes the permissions on this object from the specified account.  This method
        /// sets the permissions recursively on all child objects by default.
        /// </summary>
        /// <param name="accountObject">Account (can be any Configuration Server class)</param>
        /// <param name="newPermissionsMask">New permissions mask. See <code>ConfServerPermissions</code> enum.</param>
        public void SetAccountPermissions(CfgObject accountObject, int newPermissionsMask)
        {
            if (accountObject == null)
                throw new ArgumentNullException("accountObject");

            GlobalConfService.UpdatePermissions(ConfigurationService.Protocol,
                                                     (int)this[MiscConstants.DbidPropertyName],
                                                    ObjectType,
                                                    (int)accountObject[MiscConstants.DbidPropertyName],
                                                    accountObject.ObjectType,
                                                    newPermissionsMask, 1);

        }

        /// <summary>
        /// Changes the permissions on this object from the specified account
        /// </summary>
        /// <param name="accountObject">Account (can be any Configuration Server class)</param>
        /// <param name="newPermissionsMask">New permissions mask. See <code>ConfServerPermissions</code> enum.</param>
        /// <param name="recursive">This flag, if set to TRUE, directs Configuration Server to remove permissions at the objects subordinate to the one specified in the <i>accountObject</i> parameter. This way all the subordinate objects will receive permissions identical to their parent object. However, this is not the way to set up an individual permission recursively. For this purpose the NoPropagate flag in the permission record should be used. The flag is only relevant to the following object types: CfgFolder, CfgTenant, CfgSwitch, CfgIVR, CfgEnumerator</param>
        public void SetAccountPermissions(CfgObject accountObject, int newPermissionsMask, bool recursive)
        {
            if (accountObject == null)
                throw new ArgumentNullException("accountObject");

            GlobalConfService.UpdatePermissions(ConfigurationService.Protocol,
                                                     (int)this[MiscConstants.DbidPropertyName],
                                                    ObjectType,
                                                    (int)accountObject[MiscConstants.DbidPropertyName],
                                                    accountObject.ObjectType,
                                                    newPermissionsMask, recursive ? 1 : 0);

        }

        #region ICloneable Members
        /// <exclude/>
        protected override void EnsureDataBackup()
        {
          base.EnsureDataBackup();
          if ((oldXmlData == null) && IsSaved)
          {
            oldXmlData = new XElement(XmlData);
          }
        }

      /**
      * This internal method is designed to be called before access
      * to the internal XML data to update it in case of changes
      * in child structures.
      *
      * @return true if refresh has been performed
      */

      internal override bool RefreshXmlImpl() {
        EnsureDataBackup();
        return base.RefreshXmlImpl();
      }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>A copy of the current object.</returns>
        public object Clone()
        {
          var obj = ConfigurationService.CreateObjectFromXml(ToXml(), true);
          if ((oldXmlData!=null) && (obj is CfgObject))
          {
            (obj as CfgObject).oldXmlData = new XElement(oldXmlData);
          }
          PostProcessingClonedObject(obj as CfgObject);
          return obj;
        }

        
        /// <summary>
        /// Updates the current object from the passed delta object
        /// </summary>
        /// <param name="deltaObject">the delta object received from configuration server</param>
        public virtual void Update(ICfgDelta deltaObject)
        {
            if (deltaObject == null) throw new ArgumentNullException("deltaObject");

            CfgUtilities util = new CfgUtilities(
                Utils.GetMetadata(ConfigurationService.Protocol));

            XName confData = XName.Get("ConfData", Utils.GetNamespace(
                ConfigurationService.Protocol));

            XDocument curXml = new XDocument(new XElement(confData));
            XDocument newXml = new XDocument(new XElement(confData));

            curXml.Root.Add(XmlData);
            newXml.Root.Add(deltaObject.ToXml());

            util.ApplyDelta(curXml, newXml);

            XElement objectXml = curXml.Root.Elements().First();

            this.ReloadObjectWithNewXml(objectXml);

            //oldXmlData = new XElement(objectXml);
            oldXmlData = null; // remove backup data
        }

        #endregion

      //public override int GetHashCode()
      //{
      //  var code =  base.GetHashCode();
      //  code ^= 41*CalcDictionaryHashCode(parameters);
      //  return code;
      //}

      //public override bool Equals(object obj)
      //{
      //  if (!base.Equals(obj)) return false;
      //  var cfgObj = obj as CfgObject;
      //  if (cfgObj==null) return false;
      //  if (!CompareDictionary(parameters, cfgObj.parameters)) return false;
      //  return true;
      //}
    }
}

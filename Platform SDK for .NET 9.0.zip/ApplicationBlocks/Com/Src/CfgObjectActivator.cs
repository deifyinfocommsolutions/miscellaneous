
//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2017 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using System.Xml;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Commons.Collections;
using System.Xml.Linq;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal static class CfgObjectActivator
    {        
        private static IDictionary<string, ICfgObjectFactory> objectsFactories;

        static CfgObjectActivator()
        {
          objectsFactories = new Dictionary<string, ICfgObjectFactory>();

          
        objectsFactories.Add("CfgSwitch", new CfgSwitchFactory());
        objectsFactories.Add("CfgDN", new CfgDNFactory());
        objectsFactories.Add("CfgPerson", new CfgPersonFactory());
        objectsFactories.Add("CfgPersonBrief", new CfgPersonBriefFactory());
        objectsFactories.Add("CfgPlace", new CfgPlaceFactory());
        objectsFactories.Add("CfgAgentGroup", new CfgAgentGroupFactory());
        objectsFactories.Add("CfgPlaceGroup", new CfgPlaceGroupFactory());
        objectsFactories.Add("CfgTenant", new CfgTenantFactory());
        objectsFactories.Add("CfgTenantBrief", new CfgTenantBriefFactory());
        objectsFactories.Add("CfgService", new CfgServiceFactory());
        objectsFactories.Add("CfgApplication", new CfgApplicationFactory());
        objectsFactories.Add("CfgHost", new CfgHostFactory());
        objectsFactories.Add("CfgPhysicalSwitch", new CfgPhysicalSwitchFactory());
        objectsFactories.Add("CfgScript", new CfgScriptFactory());
        objectsFactories.Add("CfgSkill", new CfgSkillFactory());
        objectsFactories.Add("CfgActionCode", new CfgActionCodeFactory());
        objectsFactories.Add("CfgAgentLogin", new CfgAgentLoginFactory());
        objectsFactories.Add("CfgTransaction", new CfgTransactionFactory());
        objectsFactories.Add("CfgDNGroup", new CfgDNGroupFactory());
        objectsFactories.Add("CfgStatDay", new CfgStatDayFactory());
        objectsFactories.Add("CfgStatTable", new CfgStatTableFactory());
        objectsFactories.Add("CfgAppPrototype", new CfgAppPrototypeFactory());
        objectsFactories.Add("CfgAccessGroup", new CfgAccessGroupFactory());
        objectsFactories.Add("CfgAccessGroupBrief", new CfgAccessGroupBriefFactory());
        objectsFactories.Add("CfgFolder", new CfgFolderFactory());
        objectsFactories.Add("CfgField", new CfgFieldFactory());
        objectsFactories.Add("CfgFormat", new CfgFormatFactory());
        objectsFactories.Add("CfgTableAccess", new CfgTableAccessFactory());
        objectsFactories.Add("CfgCallingList", new CfgCallingListFactory());
        objectsFactories.Add("CfgCampaign", new CfgCampaignFactory());
        objectsFactories.Add("CfgTreatment", new CfgTreatmentFactory());
        objectsFactories.Add("CfgFilter", new CfgFilterFactory());
        objectsFactories.Add("CfgTimeZone", new CfgTimeZoneFactory());
        objectsFactories.Add("CfgVoicePrompt", new CfgVoicePromptFactory());
        objectsFactories.Add("CfgIVRPort", new CfgIVRPortFactory());
        objectsFactories.Add("CfgIVR", new CfgIVRFactory());
        objectsFactories.Add("CfgAlarmCondition", new CfgAlarmConditionFactory());
        objectsFactories.Add("CfgEnumerator", new CfgEnumeratorFactory());
        objectsFactories.Add("CfgEnumeratorValue", new CfgEnumeratorValueFactory());
        objectsFactories.Add("CfgObjectiveTable", new CfgObjectiveTableFactory());
        objectsFactories.Add("CfgCampaignGroup", new CfgCampaignGroupFactory());
        objectsFactories.Add("CfgGVPReseller", new CfgGVPResellerFactory());
        objectsFactories.Add("CfgGVPCustomer", new CfgGVPCustomerFactory());
        objectsFactories.Add("CfgGVPIVRProfile", new CfgGVPIVRProfileFactory());
        objectsFactories.Add("CfgScheduledTask", new CfgScheduledTaskFactory());
        objectsFactories.Add("CfgRole", new CfgRoleFactory());
        objectsFactories.Add("CfgPersonLastLogin", new CfgPersonLastLoginFactory());
        objectsFactories.Add("CfgGroup", new CfgGroupFactory());
        objectsFactories.Add("CfgAddress", new CfgAddressFactory());
        objectsFactories.Add("CfgPhones", new CfgPhonesFactory());
        objectsFactories.Add("CfgOSinfo", new CfgOSFactory());
        objectsFactories.Add("CfgSwitchAccessCode", new CfgSwitchAccessCodeFactory());
        objectsFactories.Add("CfgDelSwitchAccess", new CfgDelSwitchAccessFactory());
        objectsFactories.Add("CfgDNAccessNumber", new CfgDNAccessNumberFactory());
        objectsFactories.Add("CfgPersonRank", new CfgAppRankFactory());
        objectsFactories.Add("CfgSkillLevel", new CfgSkillLevelFactory());
        objectsFactories.Add("CfgAgentLoginInfo", new CfgAgentLoginInfoFactory());
        objectsFactories.Add("CfgGroupDN", new CfgDNInfoFactory());
        objectsFactories.Add("CfgServerInfo", new CfgServerFactory());
        objectsFactories.Add("CfgSubcode", new CfgSubcodeFactory());
        objectsFactories.Add("CfgStatInterval", new CfgStatIntervalFactory());
        objectsFactories.Add("CfgCallingListInfo", new CfgCallingListInfoFactory());
        objectsFactories.Add("CfgCampaignGroupInfo", new CfgCampaignGroupInfoFactory());
        objectsFactories.Add("CfgDetectEvent", new CfgDetectEventFactory());
        objectsFactories.Add("CfgRemovalEvent", new CfgRemovalEventFactory());
        objectsFactories.Add("CfgID", new CfgIDFactory());
        objectsFactories.Add("CfgSolutionComponent", new CfgSolutionComponentFactory());
        objectsFactories.Add("CfgMemberID", new CfgMemberIDFactory());
        objectsFactories.Add("CfgOwnerID", new CfgOwnerIDFactory());
        objectsFactories.Add("CfgObjectID", new CfgObjectIDFactory());
        objectsFactories.Add("CfgResourceID", new CfgResourceIDFactory());
        objectsFactories.Add("CfgParentID", new CfgParentIDFactory());
        objectsFactories.Add("CfgACE", new CfgACEFactory());
        objectsFactories.Add("CfgACL", new CfgACLFactory());
        objectsFactories.Add("CfgACEID", new CfgACEIDFactory());
        objectsFactories.Add("CfgACLID", new CfgACLIDFactory());
        objectsFactories.Add("CfgConnectionInfo", new CfgConnInfoFactory());
        objectsFactories.Add("CfgSolutionComponentDefinition", new CfgSolutionComponentDefinitionFactory());
        objectsFactories.Add("CfgServiceInfo", new CfgServiceInfoFactory());
        objectsFactories.Add("CfgAgentInfo", new CfgAgentInfoFactory());
        objectsFactories.Add("CfgAppServicePermission", new CfgAppServicePermissionFactory());
        objectsFactories.Add("CfgObjectiveTableRecord", new CfgObjectiveTableRecordFactory());
        objectsFactories.Add("CfgObjectResource", new CfgObjectResourceFactory());
        objectsFactories.Add("CfgPortInfo", new CfgPortInfoFactory());
        objectsFactories.Add("CfgServerVersion", new CfgServerVersionFactory());
        objectsFactories.Add("CfgServerHostID", new CfgServerHostIDFactory());
        objectsFactories.Add("CfgUpdatePackageRecord", new CfgUpdatePackageRecordFactory());
        objectsFactories.Add("CfgRoleMember", new CfgRoleMemberFactory());
        objectsFactories.Add("CfgDeltaGroup", new CfgDeltaGroupFactory());
        objectsFactories.Add("CfgDeltaAgentInfo", new CfgDeltaAgentInfoFactory());
        objectsFactories.Add("CfgDeltaSwitch", new CfgDeltaSwitchFactory());
        objectsFactories.Add("CfgDeltaDN", new CfgDeltaDNFactory());
        objectsFactories.Add("CfgDeltaPerson", new CfgDeltaPersonFactory());
        objectsFactories.Add("CfgDeltaPlace", new CfgDeltaPlaceFactory());
        objectsFactories.Add("CfgDeltaAgentGroup", new CfgDeltaAgentGroupFactory());
        objectsFactories.Add("CfgDeltaPlaceGroup", new CfgDeltaPlaceGroupFactory());
        objectsFactories.Add("CfgDeltaTenant", new CfgDeltaTenantFactory());
        objectsFactories.Add("CfgDeltaService", new CfgDeltaServiceFactory());
        objectsFactories.Add("CfgDeltaApplication", new CfgDeltaApplicationFactory());
        objectsFactories.Add("CfgDeltaHost", new CfgDeltaHostFactory());
        objectsFactories.Add("CfgDeltaPhysicalSwitch", new CfgDeltaPhysicalSwitchFactory());
        objectsFactories.Add("CfgDeltaScript", new CfgDeltaScriptFactory());
        objectsFactories.Add("CfgDeltaSkill", new CfgDeltaSkillFactory());
        objectsFactories.Add("CfgDeltaActionCode", new CfgDeltaActionCodeFactory());
        objectsFactories.Add("CfgDeltaAgentLogin", new CfgDeltaAgentLoginFactory());
        objectsFactories.Add("CfgDeltaTransaction", new CfgDeltaTransactionFactory());
        objectsFactories.Add("CfgDeltaDNGroup", new CfgDeltaDNGroupFactory());
        objectsFactories.Add("CfgDeltaStatDay", new CfgDeltaStatDayFactory());
        objectsFactories.Add("CfgDeltaStatTable", new CfgDeltaStatTableFactory());
        objectsFactories.Add("CfgDeltaAppPrototype", new CfgDeltaAppPrototypeFactory());
        objectsFactories.Add("CfgDeltaAccessGroup", new CfgDeltaAccessGroupFactory());
        objectsFactories.Add("CfgDeltaFolder", new CfgDeltaFolderFactory());
        objectsFactories.Add("CfgDeltaField", new CfgDeltaFieldFactory());
        objectsFactories.Add("CfgDeltaFormat", new CfgDeltaFormatFactory());
        objectsFactories.Add("CfgDeltaTableAccess", new CfgDeltaTableAccessFactory());
        objectsFactories.Add("CfgDeltaCallingList", new CfgDeltaCallingListFactory());
        objectsFactories.Add("CfgDeltaCampaign", new CfgDeltaCampaignFactory());
        objectsFactories.Add("CfgDeltaTreatment", new CfgDeltaTreatmentFactory());
        objectsFactories.Add("CfgDeltaFilter", new CfgDeltaFilterFactory());
        objectsFactories.Add("CfgDeltaTimeZone", new CfgDeltaTimeZoneFactory());
        objectsFactories.Add("CfgDeltaVoicePrompt", new CfgDeltaVoicePromptFactory());
        objectsFactories.Add("CfgDeltaIVRPort", new CfgDeltaIVRPortFactory());
        objectsFactories.Add("CfgDeltaIVR", new CfgDeltaIVRFactory());
        objectsFactories.Add("CfgDeltaAlarmCondition", new CfgDeltaAlarmConditionFactory());
        objectsFactories.Add("CfgDeltaEnumerator", new CfgDeltaEnumeratorFactory());
        objectsFactories.Add("CfgDeltaEnumeratorValue", new CfgDeltaEnumeratorValueFactory());
        objectsFactories.Add("CfgDeltaObjectiveTable", new CfgDeltaObjectiveTableFactory());
        objectsFactories.Add("CfgDeltaCampaignGroup", new CfgDeltaCampaignGroupFactory());
        objectsFactories.Add("CfgDeltaGVPReseller", new CfgDeltaGVPResellerFactory());
        objectsFactories.Add("CfgDeltaGVPCustomer", new CfgDeltaGVPCustomerFactory());
        objectsFactories.Add("CfgDeltaGVPIVRProfile", new CfgDeltaGVPIVRProfileFactory());
        objectsFactories.Add("CfgDeltaScheduledTask", new CfgDeltaScheduledTaskFactory());
        objectsFactories.Add("CfgDeltaRole", new CfgDeltaRoleFactory());
        objectsFactories.Add("CfgDeltaPersonLastLogin", new CfgDeltaPersonLastLoginFactory());
        }

         /// <summary>
        /// Creates an instance of the specified configuration object.
        /// </summary>

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static CfgBase CreateInstance(string objectType, 
                                 IConfService confService, 
                                 XElement xmlData,
                                 object[] additionalParams)
        {
          ICfgObjectFactory factory = objectsFactories[objectType];

          if (factory != null) {
              return factory.Create(confService, xmlData, additionalParams);
          }

          throw new ArgumentException("Object Activator: invalid object type");
        }

        public static Type GetType(string objectType)
        {
            ICfgObjectFactory factory = objectsFactories[objectType];

            return factory==null ? null : factory.GetObjectType(objectType);
        }
    }
}
	
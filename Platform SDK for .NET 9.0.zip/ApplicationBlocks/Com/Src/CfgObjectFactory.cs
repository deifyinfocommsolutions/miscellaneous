//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols;
using System.Xml;
using System.Collections;
using System.Collections.ObjectModel;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests.Objects;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Events;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.Configuration.Protocols.Types;
using System.Xml.Linq;
using System.Linq;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// This is the object factory.
    /// </summary>
    internal class CfgObjectFactory
    {
        private IProtocol confProtocol;

        internal CfgObjectFactory(IProtocol confProtocol)
        {
            this.confProtocol = confProtocol;
        }

        internal ICfgObject RetrieveObject(ICfgQuery query, IConfService confService)
        {
          return RetrieveObject(query, confService, false);
        }
        internal ICfgObject RetrieveObject(ICfgQuery query, IConfService confService, bool isBriefInfo)
        {
            CfgObjectType queryObjectType;
            XDocument confObject;
            KeyValueCollection[] parameters;
            string[] objectPaths;

            GlobalConfService.InternalLoadObject(confProtocol, query, out confObject, out queryObjectType, out parameters, out objectPaths, isBriefInfo);

            if (confObject == null)
                return null;

            int objectsCount = confObject.Root.Elements().Count();

            if (objectsCount == 0)
                return null;

            if (objectsCount != 1)
                throw new InvalidOperationException("Query returned invalid number of objects. Should be 1.");

            object newObj = CfgObjectActivator.CreateInstance(GlobalConfService.ObjectTypeToName(queryObjectType)+(isBriefInfo?"Brief":""),
              confService, new XElement(confObject.Root.Elements().First()), new object[] {parameters==null? null: parameters[0], objectPaths == null ? null : objectPaths[0] });

            return (ICfgObject)newObj;
        }


        internal ICfgObject RetrieveObject(int dbId, CfgObjectType objectType, IConfService confService)
        {
            CfgFilterBasedQuery query = new CfgFilterBasedQuery(objectType);
            query[MiscConstants.FilterDbidName] = dbId;

            return RetrieveObject(query, confService);
        }

        internal IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, ConfService confService, AsyncCallback finishCallback, AsyncCallback dataCallback, long timeout, object state)
        {
            return GlobalConfService.BeginLoadObject(confProtocol, query, confService, finishCallback, dataCallback, timeout, state);
        }
        internal IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, ConfService confService, AsyncCallback finishCallback, AsyncCallback dataCallback, long timeout, object state, bool isBriefInfo)
        {
          return GlobalConfService.BeginLoadObject(confProtocol, query, confService, finishCallback, dataCallback, timeout, state, isBriefInfo);
        }

        internal List<T> RetrieveMultipleObjects<T>(ICfgQuery query, IConfService confService) where T : ICfgObject
        {
            CfgObjectType queryObjectType;
            XDocument confObject;
            KeyValueCollection[] parameters;
            string[] objectPaths;

            bool isBriefInfo = typeof(ICfgBriefInfo).IsAssignableFrom(typeof (T));

            GlobalConfService.InternalLoadObject(confProtocol, query, out confObject, out queryObjectType, out parameters, out objectPaths, isBriefInfo);

            if (confObject == null || confObject.Root.HasElements == false)
                return null;

            List<T> newObjs = new List<T>();
            int i = 0;

            foreach (XElement objXml in confObject.Root.Elements())
            {
                object newObj = CfgObjectActivator.CreateInstance(
                    GlobalConfService.ObjectTypeToName(queryObjectType), confService, objXml, new object[] { parameters[i], objectPaths[i] });

                if (!(newObj is T))
                    throw new ArgumentException("The query has returned invalid results of invalid type.");

                newObjs.Add((T)newObj);
                i++;
            }

            return newObjs;
        }
    }
}

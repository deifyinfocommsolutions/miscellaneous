//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Xml;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using System.Xml.Linq;
using System.Linq;
using Genesyslab.Platform.Configuration.Protocols.Metadata;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal static class CfgObjectUpdateHelper
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.ConfigException.#ctor(System.String)")]
        private static SortedList SortObjectAttributes(XElement docToSort, IEnumerable<CfgDescriptionAttribute> propertiesMetaData)
        {
            // now we have to reshuffle children according to their position. Otherwise, 
            // create request will fail

            SortedList newSortedNodes = new SortedList();

            //TODO: Re-examine this algorithm
            foreach (XElement propertyNode in docToSort.Elements())
            {
                CfgDescriptionAttribute info = null;

                foreach (CfgDescriptionAttribute infoTemp in propertiesMetaData)
                {
                    if (infoTemp.XName == propertyNode.Name)
                    {
                        info = infoTemp;

                        break;
                    }
                }

                if (info == null)
                    throw new ConfigException("We are trying to create an object, but it has invalid attributes");

                newSortedNodes.Add(info.Index, propertyNode);
            }

            return newSortedNodes;
        }

        internal static XDocument SortChildrenForNewObject(XElement data, CfgDescriptionClass metadata)
        {
            if (metadata == null) throw new ArgumentNullException("metadata");

            XDocument tempDeltaDoc = new XDocument(new XElement("tempRoot"));

            XElement rootDeltaNode = tempDeltaDoc.Root;
            string ns = data.Name.NamespaceName;

            foreach (CfgDescriptionAttribute attr in metadata.Attributes)
            {
                XElement nodeTemp = null;
                XElement childNode = data.Element(
                    attr.XName);

                if (childNode == null)
                    continue;

                if (attr.IsCfgType(CfgTypeMask.List) &&
                    attr.IsCfgType(CfgTypeMask.Structure))
                {
                    // here we sort the members of each structure in a collection
                    CfgDescriptionAttributeReferenceClassList attrStructList
                        = attr as CfgDescriptionAttributeReferenceClassList;

                    if (childNode.Elements().Count() > 0)
                    {
                        nodeTemp = new XElement(childNode.Name);
                    }

                    XElement newNode;

                    foreach (XElement element in childNode.Elements())
                    {
                        XDocument sortedChild = SortChildrenForNewObject(element, attrStructList.Class);

                        newNode = new XElement(element.Name);

                        nodeTemp.Add(newNode);

                        newNode.Add(sortedChild.Root.Elements());
                    }

                }
                else if (attr.IsCfgType(CfgTypeMask.Reference) &&
                     attr.IsCfgType(CfgTypeMask.Structure))
                {
                    // what we do here is sort the members of the structure by calling the method
                    // recursively
                    CfgDescriptionAttributeReferenceClass attrRefClass =
                        attr as CfgDescriptionAttributeReferenceClass;

                    if (attrRefClass == null)
                    {
                        throw new InvalidOperationException("Metadata is invalid");
                    }

                    XDocument sortedStructure = SortChildrenForNewObject(childNode, attrRefClass.Class);

                    if (sortedStructure == null || sortedStructure.Root == null || sortedStructure.Root.HasElements == false)
                        continue;

                    int count = sortedStructure.Root.Elements().Count();

                    if (count > 0)
                    {
                        nodeTemp = new XElement(childNode.Name);
                    }

                    nodeTemp.Add(sortedStructure.Root.Elements());

                }
                else
                {
                    nodeTemp = new XElement(childNode);
                }

                if (nodeTemp != null)
                {
                    rootDeltaNode.Add(nodeTemp);
                }
            }

            SortedList newSortedNodes =
                CfgObjectUpdateHelper.SortObjectAttributes(rootDeltaNode, metadata.Attributes);

            XDocument deltaDoc = new XDocument(new XElement("root"));

            foreach (XElement element in newSortedNodes.Values)
            {
                deltaDoc.Root.Add(element);
            }

            return deltaDoc;
        }


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.String.Format(System.String,System.Object)")]
        internal static XDocument CreateDeltaForNewObject(CfgObject cfgObject)
        {
            XName objectName = cfgObject.XmlData.Name;

            XDocument deltaDoc = new XDocument(
                new XElement(
                    XName.Get("ConfData", objectName.NamespaceName),
                    new XElement(objectName)));

            XDocument tempDoc = SortChildrenForNewObject(cfgObject.XmlData, cfgObject.MetaData);

            XElement root = deltaDoc.Root.Elements().First();

            foreach (XElement element in tempDoc.Root.Elements())
            {
                root.Add(element);
            }

            return deltaDoc;
        }

        internal static XElement SortObjectAttributes(XElement obj, CfgDescriptionClass metadata)
        {
            XDocument deltaDoc = SortChildrenForNewObject(
                obj, metadata);

            XElement root = new XElement(obj.Name);

            root.Add(deltaDoc.Root.Elements());

            return root;
        }
    }
}

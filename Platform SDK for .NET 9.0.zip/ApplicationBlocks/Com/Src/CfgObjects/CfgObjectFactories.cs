
//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2017 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects
{
  using System.Xml.Linq;
  using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
  using System;
	

  
  
    internal class CfgSwitchFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgSwitch);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgSwitch(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgDNFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDN);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgDN(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgPersonFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPerson);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgPerson(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgPersonBriefFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPersonBrief);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgPersonBrief(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgPlaceFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPlace);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgPlace(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgAgentGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAgentGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgAgentGroup(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgPlaceGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPlaceGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgPlaceGroup(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgTenantFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgTenant);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgTenant(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgTenantBriefFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgTenantBrief);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgTenantBrief(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgServiceFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgService);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgService(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgApplicationFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgApplication);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgApplication(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgHostFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgHost);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgHost(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgPhysicalSwitchFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPhysicalSwitch);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgPhysicalSwitch(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgScriptFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgScript);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgScript(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgSkillFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgSkill);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgSkill(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgActionCodeFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgActionCode);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgActionCode(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgAgentLoginFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAgentLogin);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgAgentLogin(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgTransactionFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgTransaction);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgTransaction(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgDNGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDNGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgDNGroup(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgStatDayFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgStatDay);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgStatDay(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgStatTableFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgStatTable);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgStatTable(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgAppPrototypeFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAppPrototype);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgAppPrototype(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgAccessGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAccessGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgAccessGroup(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgAccessGroupBriefFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAccessGroupBrief);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgAccessGroupBrief(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgFolderFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgFolder);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgFolder(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgFieldFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgField);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgField(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgFormatFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgFormat);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgFormat(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgTableAccessFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgTableAccess);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgTableAccess(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgCallingListFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgCallingList);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgCallingList(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgCampaignFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgCampaign);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgCampaign(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgTreatmentFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgTreatment);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgTreatment(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgFilterFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgFilter);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgFilter(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgTimeZoneFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgTimeZone);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgTimeZone(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgVoicePromptFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgVoicePrompt);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgVoicePrompt(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgIVRPortFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgIVRPort);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgIVRPort(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgIVRFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgIVR);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgIVR(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgAlarmConditionFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAlarmCondition);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgAlarmCondition(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgEnumeratorFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgEnumerator);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgEnumerator(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgEnumeratorValueFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgEnumeratorValue);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgEnumeratorValue(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgObjectiveTableFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgObjectiveTable);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgObjectiveTable(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgCampaignGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgCampaignGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgCampaignGroup(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  #pragma warning disable 618
    internal class CfgGVPResellerFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgGVPReseller);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgGVPReseller(
                   confService,
                   xmlData,
                   additionalParams);
    }
    #pragma warning restore 618
} 
  
  
  #pragma warning disable 618
    internal class CfgGVPCustomerFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgGVPCustomer);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgGVPCustomer(
                   confService,
                   xmlData,
                   additionalParams);
    }
    #pragma warning restore 618
} 
  
  
  
    internal class CfgGVPIVRProfileFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgGVPIVRProfile);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgGVPIVRProfile(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  #pragma warning disable 618
    internal class CfgScheduledTaskFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgScheduledTask);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgScheduledTask(
                   confService,
                   xmlData,
                   additionalParams);
    }
    #pragma warning restore 618
} 
  
  
    internal class CfgRoleFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgRole);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgRole(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
    internal class CfgPersonLastLoginFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPersonLastLogin);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        return new CfgPersonLastLogin(
                   confService,
                   xmlData,
                   additionalParams);
    }
    
} 
  
  
  
    internal class CfgGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgGroup(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgAddressFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAddress);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgAddress(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgPhonesFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPhones);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgPhones(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgOSFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgOS);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgOS(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgSwitchAccessCodeFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgSwitchAccessCode);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgSwitchAccessCode(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgDelSwitchAccessFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDelSwitchAccess);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgDelSwitchAccess(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgDNAccessNumberFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDNAccessNumber);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgDNAccessNumber(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgAppRankFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAppRank);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgAppRank(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgSkillLevelFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgSkillLevel);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgSkillLevel(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgAgentLoginInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAgentLoginInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgAgentLoginInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgDNInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDNInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgDNInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgServerFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgServer);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgServer(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgSubcodeFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgSubcode);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgSubcode(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgStatIntervalFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgStatInterval);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgStatInterval(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgCallingListInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgCallingListInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgCallingListInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgCampaignGroupInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgCampaignGroupInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgCampaignGroupInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgDetectEventFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDetectEvent);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgDetectEvent(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgRemovalEventFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgRemovalEvent);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgRemovalEvent(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgSolutionComponentFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgSolutionComponent);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgSolutionComponent(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgMemberIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgMemberID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgMemberID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgOwnerIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgOwnerID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgOwnerID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgObjectIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgObjectID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgObjectID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgResourceIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgResourceID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgResourceID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgParentIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgParentID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgParentID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgACEFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgACE);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgACE(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgACLFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgACL);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgACL(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgACEIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgACEID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgACEID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgACLIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgACLID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgACLID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgConnInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgConnInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgConnInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgSolutionComponentDefinitionFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgSolutionComponentDefinition);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgSolutionComponentDefinition(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgServiceInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgServiceInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgServiceInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgAgentInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAgentInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgAgentInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgAppServicePermissionFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgAppServicePermission);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgAppServicePermission(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgObjectiveTableRecordFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgObjectiveTableRecord);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgObjectiveTableRecord(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgObjectResourceFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgObjectResource);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgObjectResource(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgPortInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgPortInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgPortInfo(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgServerVersionFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgServerVersion);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgServerVersion(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgServerHostIDFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgServerHostID);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgServerHostID(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgUpdatePackageRecordFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgUpdatePackageRecord);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgUpdatePackageRecord(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    internal class CfgRoleMemberFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgRoleMember);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
        if ((additionalParams == null) || (additionalParams.Length < 1)
            || !(additionalParams[0] is ICfgObject)) {
            throw new ArgumentException("Object Creator: invalid parameters");
        }

        return new CfgRoleMember(
                   confService,
                   xmlData,
                   (ICfgObject) additionalParams[0]);
    }
    
} 
  
  
  
    
    
    
  
  
  
    
    
    
  
  
  
    
    
    
  
  
  
    
    
    
    
    
  
  
  
    
    
    
    
  
  
  
    
    
    
  
  
  
    
    
    
  
  
  
    
    
    
    
  
  
  
    
    
    
  
  
  
    
    
  
  
  
    
    
  
  
  
    
    
    
    
    
    
  
  
  
    
    
    
    
    
  
  
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
  
  
    internal class CfgDeltaGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaGroup(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaAgentInfoFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaAgentInfo);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaAgentInfo(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaSwitchFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaSwitch);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaSwitch(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaDNFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaDN);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaDN(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaPersonFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaPerson);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaPerson(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaPlaceFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaPlace);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaPlace(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaAgentGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaAgentGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaAgentGroup(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaPlaceGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaPlaceGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaPlaceGroup(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaTenantFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaTenant);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaTenant(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaServiceFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaService);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaService(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaApplicationFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaApplication);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaApplication(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaHostFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaHost);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaHost(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaPhysicalSwitchFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaPhysicalSwitch);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaPhysicalSwitch(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaScriptFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaScript);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaScript(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaSkillFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaSkill);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaSkill(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaActionCodeFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaActionCode);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaActionCode(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaAgentLoginFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaAgentLogin);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaAgentLogin(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaTransactionFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaTransaction);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaTransaction(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaDNGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaDNGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaDNGroup(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaStatDayFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaStatDay);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaStatDay(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaStatTableFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaStatTable);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaStatTable(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaAppPrototypeFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaAppPrototype);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaAppPrototype(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaAccessGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaAccessGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaAccessGroup(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaFolderFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaFolder);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaFolder(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaFieldFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaField);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaField(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaFormatFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaFormat);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaFormat(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaTableAccessFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaTableAccess);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaTableAccess(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaCallingListFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaCallingList);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaCallingList(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaCampaignFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaCampaign);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaCampaign(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaTreatmentFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaTreatment);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaTreatment(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaFilterFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaFilter);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaFilter(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaTimeZoneFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaTimeZone);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaTimeZone(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaVoicePromptFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaVoicePrompt);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaVoicePrompt(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaIVRPortFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaIVRPort);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaIVRPort(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaIVRFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaIVR);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaIVR(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaAlarmConditionFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaAlarmCondition);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaAlarmCondition(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaEnumeratorFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaEnumerator);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaEnumerator(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaEnumeratorValueFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaEnumeratorValue);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaEnumeratorValue(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaObjectiveTableFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaObjectiveTable);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaObjectiveTable(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaCampaignGroupFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaCampaignGroup);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaCampaignGroup(
                     confService,
                     xmlData);
    }
    
} 
  
  
  #pragma warning disable 618
    internal class CfgDeltaGVPResellerFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaGVPReseller);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaGVPReseller(
                     confService,
                     xmlData);
    }
    #pragma warning restore 618
} 
  
  
  #pragma warning disable 618
    internal class CfgDeltaGVPCustomerFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaGVPCustomer);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaGVPCustomer(
                     confService,
                     xmlData);
    }
    #pragma warning restore 618
} 
  
  
  
    internal class CfgDeltaGVPIVRProfileFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaGVPIVRProfile);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaGVPIVRProfile(
                     confService,
                     xmlData);
    }
    
} 
  
  
  #pragma warning disable 618
    internal class CfgDeltaScheduledTaskFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaScheduledTask);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaScheduledTask(
                     confService,
                     xmlData);
    }
    #pragma warning restore 618
} 
  
  
  
    internal class CfgDeltaRoleFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaRole);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaRole(
                     confService,
                     xmlData);
    }
    
} 
  
  
  
    internal class CfgDeltaPersonLastLoginFactory : ICfgObjectFactory 
    {
        public Type GetObjectType(string objectType)
        {
            return typeof(CfgDeltaPersonLastLogin);
        }

        public CfgBase Create(
                IConfService confService,
                XElement     xmlData,
                object[]     additionalParams) {
          return new CfgDeltaPersonLastLogin(
                     confService,
                     xmlData);
    }
    
} 
  

}
	
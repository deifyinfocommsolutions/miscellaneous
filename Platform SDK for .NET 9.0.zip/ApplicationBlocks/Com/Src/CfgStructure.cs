//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Genesyslab.Platform.Configuration.Protocols;
using System.Xml.Linq;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// The base class for all Configuration Server structures.
    /// </summary>
    public abstract class CfgStructure : CfgBase, ICfgStructure
    {
        internal CfgStructure(IConfService confService, XElement xmlData, ICfgObject parent, string dataClassName)
            : base(confService, xmlData, true, (CfgBase)parent, dataClassName)
        {
            IsSaved = false;
        }

        // this constructor is intended for creating of detached objects 
        internal CfgStructure(IConfService confService, string structureName, ICfgObject parent, string dataClassName)
            : base(confService, structureName, true, (CfgBase)parent, dataClassName)
        {
            IsSaved = false;
        }
        /// <summary>
        /// Returns the parent configuration server object that references this structure.
        /// </summary>
        /// <returns>An instance of a configuration server object</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        public new ICfgObject Parent
        {
            get
            {
                var parent = base.Parent;
                if (parent == null)
                    return null;
                else if (parent is ICfgObject)
                    return (ICfgObject) parent;
                else
                    throw new InvalidOperationException("Parent is of invalid type. It is not an object");
            }
        }

    }
}

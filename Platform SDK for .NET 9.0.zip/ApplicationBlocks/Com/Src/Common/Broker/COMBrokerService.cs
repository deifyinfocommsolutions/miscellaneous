//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using Genesyslab.Platform.ApplicationBlocks.Commons;
using System.Reflection;

using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    /// <summary>
    /// <c>BrokerServiceBase&lt;T&gt;</c> class implements the Publish/Subscribe pattern.
    /// </summary>
    /// <typeparam name="T">Type of event to be processed by subscribers.</typeparam>
    public class COMBrokerService<T> : AbstractLogEnabled, IPublishingService<T>, ISubscriptionService<T>, ISubscriptionService
    {
        #region Types

        sealed class DelegateSubscriber : ISubscriber<T>
        {
            #region Fields

            private readonly Action<T> handler;
            private readonly IPredicate<T> filter;

            #endregion Fields

            public DelegateSubscriber(Action<T> handler, IPredicate<T> filter)
            {
                this.handler = handler;
                this.filter = filter;
            }

            public Action<T> Handler
            {
                get { return this.handler; }
            }

            #region ISubscriber<T> Members

            public IPredicate<T> Filter
            {
                get { return this.filter; }
            }

            public void Handle(T obj)
            {
                this.handler.Invoke(obj);
            }

            #endregion
        }

        #endregion Types

        #region Fields

        private readonly List<ISubscriber<T>> subscribers;
        private readonly object subscribersLock;
        private volatile bool areSubscribersChanged;
        private ISubscriber<T>[] subscribersForNotification;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Creates an instance of <c>BrokerServiceBase</c> class.
        /// </summary>
        /// <param name="capacity">Defines the maximum number of subscribers the broker service will serve.</param>
        public COMBrokerService(int capacity)
        {
            this.subscribers = new List<ISubscriber<T>>(capacity);
            this.subscribersLock = new object();
            this.areSubscribersChanged = true;
        }

        /// <summary>
        /// Creates an instance of <c>BrokerServiceBase</c> class.
        /// </summary>
        public COMBrokerService()
            : this(32)
        {
        }

        #endregion Constructors

        #region IPublishingService<T> Members

        /// <summary>
        /// Implements Publish method of <c>IPublishingService&lt;T&gt;</c> interface. 
        /// The method publishes event obj.
        /// </summary>
        /// <param name="obj">Object that is used for event obj processing.</param>
        public virtual void Publish(T obj)
        {
            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Publishing {0} ...", obj);
            }

            OnPublish(obj);

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Publishing {0} is completed.", obj);
            }
        }

        #endregion

        #region ISubscriptionService<T> Members

        /// <summary>
        /// Implementation of <c>Register(ISubscriber&lt;T&gt; subscriber)</c> method of ISubscriptionService 
        /// interface. Registers a subscriber for notifications about and processing of publishing events.
        /// Implements subscription functionality of the Publish/Subscribe pattern.
        /// </summary>
        /// <param name="subscriber"><c>ISubscriber&lt;T&gt;</c> interface of subscriber object being registered.</param> 
        public void Register(ISubscriber<T> subscriber)
        {
            if (subscriber == null)
            {
                throw new ArgumentNullException("subscriber", "Subscriber is null.");
            }

            lock (this.subscribersLock)
            {
                if (subscribers.Contains(subscriber))
                {
                    throw new ArgumentException("Subscriber is already registered.", "subscriber");
                }

                this.subscribers.Add(subscriber);
                this.areSubscribersChanged = true;
            }
        }

        /// <summary>
        /// Implementation of <c>Register(Action&lt;T&gt; handler)</c> method of <c>ISubscriptionService&lt;T&gt;</c> 
        /// interface. Subscribes an action to be performed when a publishing event occurs. 
        /// Implements subscription functionality of the Publish/Subscribe pattern.
        /// The method also processes the filter custom attributes which allows a user to define filters 
        /// externally.
        /// </summary>
        /// <param name="handler">Represents the method that performs an action on the specified object
        /// when a publishing event occurs.</param> 
        public virtual void Register(Action<T> handler)
        {
            if (handler == null)
            {
                throw new ArgumentNullException("handler", "Handler is null.");
            }

            IPredicate<T> filter = null;

            SubscriptionFilterAttribute[] filterAttributes = (SubscriptionFilterAttribute[])handler.Method.GetCustomAttributes(typeof(SubscriptionFilterAttribute), true);
            if (filterAttributes.Length == 1)
            {
                filter = filterAttributes[0].GetFilter() as IPredicate<T>;
            }
            else if (filterAttributes.Length > 1)
            {
                OrPredicate<T> or = new OrPredicate<T>();

                foreach (SubscriptionFilterAttribute filterAttribute in filterAttributes)
                {
                    IPredicate<T> predicate = filterAttribute.GetFilter() as IPredicate<T>;
                    if (predicate != null)
                    {
                        or.AddPredicate(predicate);
                    }
                }

                if (or.Predicates.Count != 0)
                {
                    filter = or;
                }
            }

            Register(handler, filter); ;
        }

        /// <summary>
        /// Implementation of <c>Register(Action&lt;T&gt; handler, IPredicate&lt;T&gt; filter)</c> method of 
        /// <c>ISubscriptionService&lt;T&gt;</c> interface. Subscribes an action to be performed when a publishing 
        /// event occurs. Implements subscription functionality of the Publish/Subscribe pattern.
        /// </summary>
        /// <param name="handler">Represents the method that performs an action on the specified object
        /// when a publishing event occurs.</param>
        /// <param name="filter">Filter predicate that allows checking whether publishing event should 
        /// be processed or ignored.</param>
        public void Register(Action<T> handler, IPredicate<T> filter)
        {
            if (handler == null)
            {
                throw new ArgumentNullException("handler", "Handler is null.");
            }

            lock (this.subscribersLock)
            {
                foreach (ISubscriber<T> s in this.subscribers)
                {
                    DelegateSubscriber ds = s as DelegateSubscriber;
                    if (ds != null && ds.Handler == handler)
                    {
                        throw new ArgumentException("Handler is already registered.", "handler");
                    }
                }

                DelegateSubscriber subscriber = new DelegateSubscriber(handler, filter);

                this.subscribers.Add(subscriber);
                this.areSubscribersChanged = true;
            }
        }

        /// <summary>
        /// Implementation of <c>Unregister(ISubscriber&lt;T&gt; subscriber)</c> method of 
        /// <c>ISubscriptionService&lt;T&gt;</c> interface. Unregisters a subscriber from notifications about 
        /// publishing activities. Implements subscription functionality of the Publish/Subscribe pattern.
        /// </summary>
        /// <param name="subscriber">Interface of subscriber object being unregistered.</param>
        public void Unregister(ISubscriber<T> subscriber)
        {
            if (subscriber == null)
            {
                throw new ArgumentNullException("subscriber", "Subscriber is null.");
            }

            lock (this.subscribersLock)
            {
                if (this.subscribers.Remove(subscriber) == false)
                {
                    throw new ArgumentException("Subscriber is not registered.", "subscriber");
                }
                else
                {
                    this.areSubscribersChanged = true;
                }
            }
        }

        /// <summary>
        /// Implementation of <c>Unregister(ISubscriber&lt;T&gt;)</c> method of 
        /// <c>ISubscriptionService&lt;T&gt;</c> interface. Unregisters a subscriber from notifications about 
        /// publishing activities. Implements subscription functionality of the Publish/Subscribe pattern.
        /// </summary>
        /// <param name="handler">Represents the method that performs an action on the specified object
        /// when a publishing event occurs.</param>
        public void Unregister(Action<T> handler)
        {
            if (handler == null)
            {
                throw new ArgumentNullException("handler", "Handler is null.");
            }

            lock (this.subscribersLock)
            {
                foreach (ISubscriber<T> s in this.subscribers)
                {
                    DelegateSubscriber ds = s as DelegateSubscriber;
                    if (ds != null && ds.Handler == handler)
                    {
                        this.subscribers.Remove(ds);
                        this.areSubscribersChanged = true;
                        return;
                    }
                }
            }

            throw new ArgumentException("Handler is not registered.", "handler");
        }

        #endregion

        #region ISubscriptionService Members

#pragma warning disable 0693

        void ISubscriptionService.Register<T>(ISubscriber<T> subscriber)
        {
            ((ISubscriptionService<T>)this).Register(subscriber);
        }

        void ISubscriptionService.Register<T>(Action<T> handler)
        {
            ((ISubscriptionService<T>)this).Register(handler);
        }
        void ISubscriptionService.Register<T>(Action<T> handler, Genesyslab.Platform.ApplicationBlocks.Commons.IPredicate<T> filter)
        {
            ((ISubscriptionService<T>)this).Register(handler, filter);
        }

        void ISubscriptionService.Unregister<T>(ISubscriber<T> subscriber)
        {
            ((ISubscriptionService<T>)this).Unregister(subscriber);
        }

        void ISubscriptionService.Unregister<T>(Action<T> handler)
        {
            ((ISubscriptionService<T>)this).Unregister(handler);
        }

#pragma warning restore 0693

        #endregion

        #region Implementation Members

        /// <summary>
        /// Called when a "publish" operation occurs.
        /// </summary>
        /// <param name="obj">The object being published</param>
        virtual protected void OnPublish(T obj)
        {
            Notify(obj);
        }

        /// <summary>
        /// Calls subscribers' processing/handling methods to process publishing event
        /// </summary>
        /// <param name="obj">Object that is used for a publishing event processing</param>
        protected virtual void Notify(T obj)
        {
            PrepareSubscribers();
            if (this.subscribersForNotification == null)
            {
                return;
            }


            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Notifying {0} subscribers...", this.subscribersForNotification.Length);
            }
            int i = 0;

            foreach (ISubscriber<T> subscriber in this.subscribersForNotification)
            {
                try
                {
                    if (subscriber.Filter == null || subscriber.Filter.Invoke(obj))
                    {
                        subscriber.Handle(obj);

                        if (Logger.IsDebugEnabled)
                        {
                            Logger.DebugFormat("Subscriber {0} ({1}) with messageFilter {2} was notified.", subscriber, i, subscriber.Filter);
                        }
                    }
                }
                catch (Exception e)
                {
                    if (Logger.IsErrorEnabled)
                    {
                        Logger.ErrorFormat("Subscriber {0} ({1}) with messageFilter {2} had exception {3}.", subscriber, i, subscriber.Filter, e);
                    }

                    OnNotificationException(subscriber, e);
                }

                ++i;
            }

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Subscribers {0} of {1} were notified.", i, this.subscribers.Count);
            }
        }

        /// <summary>
        /// Allows to handle exceptions thrown by subscribers' publishing event processing methods
        /// </summary>
        /// <param name="subscriber">Exception originator</param>
        /// <param name="e">Thrown exception</param>
        protected virtual void OnNotificationException(ISubscriber<T> subscriber, Exception e)
        {
            throw e;
        }

        /// <summary>
        /// Unregisters all subscribers
        /// </summary>
        protected void UnregisterAll()
        {
            lock (this.subscribersLock)
            {
                this.subscribers.Clear();
            }
        }

        /// <exclude/>
        protected void PrepareSubscribers()
        {
            if (this.areSubscribersChanged)
            {
                lock (this.subscribersLock)
                {
                    if (this.subscribers.Count == 0)
                    {
                        this.subscribersForNotification = null;
                    }
                    else
                    {
                        this.subscribersForNotification = new ISubscriber<T>[this.subscribers.Count];
                        this.subscribers.CopyTo(this.subscribersForNotification);
                        this.areSubscribersChanged = false;
                    }
                }
            }
        }
        #endregion Implementation Members
    }
}

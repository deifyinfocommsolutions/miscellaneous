//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using System.Threading;
using System.Collections.ObjectModel;
using System.Collections;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Events;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{

    internal class ConfAsyncResult : AbstractLogEnabled,IAsyncResult
    {
        private bool completedSynchronously;
        private int referenceID;
        private AsyncCallback callback;
        private AsyncCallback dataCallback;
        private IConfService confService;
        private object state;
        private EventWaitHandle waitHandle = new EventWaitHandle(false, EventResetMode.ManualReset);
        private bool isCompleted;
        private ArrayList objectList;
        private ITimerActionTicket timeoutTicket;
        private long timeout = 30000;
        private Exception error = null;
        private bool _isBriefInfo = false;
        private Stopwatch _executingTime = null;
        internal IScheduler TimerScheduler { get; set; }

        public ConfAsyncResult()
        {
          TimerScheduler = null;
        }

  
        internal bool IsBriefInfo
        {
          get
          {
            return _isBriefInfo;
          }
          set
          {
            _isBriefInfo = value;
          }
        }
        internal ArrayList ObjectList
        {
            get
            {
                return objectList;
            }
            set
            {
                objectList = value;
            }
        }

        internal ArrayList GetCopyOfObjects()
        {
            if (objectList != null)
            {
                lock (objectList)
                {
                    return (ArrayList)objectList.Clone();
                }
            }
            return null;
        }

        internal int ReferenceID
        {
            get { return referenceID; }
            set { referenceID = value; }
        }

        internal AsyncCallback Callback
        {
            get { return callback; }
            set { callback = value; }
        }

        internal AsyncCallback DataCallback
        {
            get { return dataCallback; }
            set { dataCallback = value; }
        }

        internal IConfService ConfigurationService
        {
            get { return confService; }
            set { confService = value; }
        }

        internal long Timeout
        {
            get
            {
                return timeout;
            }
            set
            {
                timeout = value;
            }
        }

        public Exception Error
        {
            get
            {
                return error;
            }
            internal set
            {
                error = value;
            }
        }

        #region IAsyncResult Members

        public object AsyncState
        {
            get { return state; }
            set { state = value; }
        }

        public System.Threading.WaitHandle AsyncWaitHandle
        {
            get { return waitHandle; }
        }

        public bool CompletedSynchronously
        {
            get { return completedSynchronously; }
            set { completedSynchronously = value; }
        }

        public bool IsCompleted
        {
            get { return isCompleted; }
        }

        #endregion

        internal void ParseMessage(EventObjectsRead objRead)
        {
            ResetTimeout();
            ArrayList list = GlobalConfService.MessageToCfgObjects(objRead, confService);
            if (objectList == null)
                objectList = list;
            else
            {
                lock (objectList)
                {
                    objectList.AddRange(list);
                }
            }
            if (DataCallback != null)
                DataCallback.Invoke(this);
            StartTimer();
        }
        internal void ParseMessage(EventBriefInfo objRead)
        {
          ResetTimeout();
          ArrayList list = GlobalConfService.MessageToCfgObjects(objRead, confService);
          if (objectList == null)
            objectList = list;
          else
          {
            lock (objectList)
            {
              objectList.AddRange(list);
            }
          }
          if (DataCallback != null)
            DataCallback.Invoke(this);
          StartTimer();
        }


        internal void SetCompleted()
        {
            isCompleted = true;
            if (_executingTime != null) _executingTime.Stop();
            waitHandle.Set();
            if (Callback != null)
                Callback.Invoke(this);
          if ((Logger != null) && (Logger.IsDebugEnabled) && (_executingTime != null))
            Logger.DebugFormat("ConfAsyncOperation is completed in {0} ms",
              (1000.0*_executingTime.ElapsedTicks/Stopwatch.Frequency).ToString("N2"));
        }

        internal void ResetTimeout()
        {
            lock (this)
            {
              if (_executingTime != null) _executingTime.Stop();
              if (timeoutTicket != null)
                    timeoutTicket.Cancel();
              timeoutTicket = null;
            }
        }

        internal void StartTimer()
        {
            
            lock (this)
            {
              ResetTimeout();
              if (!isCompleted)
                timeoutTicket = (TimerScheduler??TimerFactory.Scheduler).Schedule(timeout, new TimoutAction(this));
              if (_executingTime == null) _executingTime = Stopwatch.StartNew(); else _executingTime.Start();
            }
        }

        internal class TimoutAction : ITimerAction
        {
            private ConfAsyncResult outer;
            public TimoutAction(ConfAsyncResult outer)
            {
                this.outer = outer;
            }

            #region ITimerAction Members

            public void OnTimer()
            {
                if (outer.IsCompleted)
                    return;
                if ((outer.Logger != null) && (outer.Logger.IsDebugEnabled))
                  outer.Logger.DebugFormat("ConfAsyncResult: Receiving of responses have been timed out [{1} ms] for request ID=[{0}]",
                    outer.ReferenceID,outer.Timeout);                
                outer.error = new OperationCanceledException("Receiving of responses have been timed out");
                outer.SetCompleted();
            }

            #endregion
        }
    }
}

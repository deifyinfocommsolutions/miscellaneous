//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using System.Xml;
using System.Xml.XPath;
using Genesyslab.Platform.Configuration.Protocols.Types;
using System.Xml.Linq;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// Describes the configuration event types that can be received from Configuration Server.
    /// </summary>
    public enum ConfEventType
    {
        /// <summary>
        /// The event signifies the creation of a Configuration Server object
        /// </summary>
        ObjectCreated,
        /// <summary>
        /// The event signifies the deletion of a Configuration Server object
        /// </summary>
        ObjectDeleted,
        /// <summary>
        /// The event signifies the update of a Configuration Server object
        /// </summary>
        ObjectUpdated,
    }

    /// <summary>
    /// This class represents an event fired by Configuration Server
    /// </summary>
    public class ConfEvent
    {
        private XDocument deltaObj;
        private ConfEventType eventType;
        private int objectId;
        private CfgObjectType objectType;
        private CfgDelta deltaObject;
        private bool isUnsolicited;
        private readonly int _unsolicitedEventNumber;

        internal ConfEvent(int objectId, CfgObjectType objectType, ConfEventType eventType,
                               XDocument deltaObj, int unsolicitedEventId)
        {
            this.deltaObj = deltaObj;
            this.eventType = eventType;
            this.objectId = objectId;
            this.objectType = objectType;
            _unsolicitedEventNumber = unsolicitedEventId;
        }

        internal ConfEvent(int objectId, ConfEventType eventType, XDocument deltaObj, CfgDelta delta, int unsolicitedEventId) :
            this(objectId, delta.ObjectType, eventType, deltaObj, unsolicitedEventId)
        {
            deltaObject = delta;
        }

        /// <summary>
        /// Exposes unsolicited notification event's number. 
        /// Returned value can be used with <see cref="Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests.Connectivity.RequestHistoryLog">RequestHistoryLog</see> to
        /// poll previously sent notifications from Configuration Server.  
        /// </summary>
        /// <returns>Event ID or 0 if event is not unsolicited</returns>
        public int UnsolicitedEventNumber {
          get { return _unsolicitedEventNumber; }
        }

        internal bool IsUnsolicited
        {
            get { return isUnsolicited; }
            set { isUnsolicited = value; }

        }
        /// <summary>
        /// The XML representation of the delta object received with this event.  If no delta
        /// object is applicable, the property is NULL.
        /// </summary>
        public XDocument XmlDelta
        {
            get
            {
                return deltaObj;
            }
        }

        /// <summary>
        /// The type of event received.
        /// </summary>
        public ConfEventType EventType
        {
            get
            {
                return this.eventType;
            }
        }

        /// <summary>
        /// The type of the object about which we're receiving the event.
        /// </summary>
        public CfgObjectType ObjectType
        {
            get
            {
                return this.objectType;
            }
        }

        /// <summary>
        ///The ID of the object about which we're receiving the event.
        /// </summary>
        public int ObjectId
        {
            get
            {
                return this.objectId;
            }
        }

        /// <summary>
        /// The object oriented representation of the Delta received with this event.  NULL if not
        /// available.
        /// </summary>
        public ICfgDelta Delta
        {
            get
            {
                return this.deltaObject;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns>A string representation of the Configuration Server event</returns>
        public override string ToString()
        {
            StringBuilder output = new StringBuilder();
            output.AppendFormat("ConfigurationEvent : Event Type = ({0}), Object Type = ({1}), Object Id = ({2})", EventType, ObjectType, ObjectId);

            return output.ToString();
        }
    }
}

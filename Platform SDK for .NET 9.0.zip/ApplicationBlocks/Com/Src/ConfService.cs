//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System.Reflection;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Configuration.Protocols.Utilities;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    using Genesyslab.Platform.Configuration.Protocols;
    using Genesyslab.Platform.Configuration.Protocols.ConfServer;
    using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests;
    using Genesyslab.Platform.Configuration.Protocols.ConfServer.Events;
    using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests.Objects;
    using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests.Locale;
    using Genesyslab.Platform.Commons.Connection;
    using Genesyslab.Platform.Commons.Collections;
    using Genesyslab.Platform.Commons.Logging;
    using Genesyslab.Platform.Commons.Protocols;

    using System;
    using System.Collections;
    using System.Collections.ObjectModel;
    using System.Collections.Generic;
    using System.Xml;
    using System.Xml.XPath;
    using System.Threading;

    using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
    using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;

    using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;
    using Genesyslab.Platform.ApplicationBlocks.Commons;
    using System.Runtime.Serialization;
    using Genesyslab.Platform.Configuration.Protocols.Types;
    using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache;

    using System.Linq;
    using System.Xml.Linq;

    using Genesyslab.Platform.Configuration.Protocols.Metadata;

    /// <summary>
    /// This is a basic exception that application block throws in case of abnormal flow (such as 'nothing was found in 
    /// Configuration Server', 'invalid parameters of connection', etc).
    /// </summary>

    [Serializable]
    public class ConfigException : Exception
    {
        /// <summary>
        /// Creates the exception class.
        /// </summary>
        public ConfigException()
            : base()
        {
        }

        /// <summary>
        /// Creates the exception class.
        /// <param name="innerException">the inner exception</param>
        /// <param name="message">exception message</param>
        /// </summary>
        public ConfigException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Creates the exception class.
        /// </summary>
        /// <param name="message">Exception Message.</param>
        public ConfigException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Creates the exception class.
        /// <param name="context">see context parameter for Exception class</param>
        /// <param name="info">see info parameter for Exception class</param>
        /// </summary>

        protected ConfigException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

    }

    /// <summary>
    /// This class holds a reference to the connection to Configuration Server (and the protocol instance).
    /// Please, use this class to create new instances of configuration objects, subscribe to events, and register for
    /// notifications.  A simple example below shows how to retrieve information
    /// about the Environment tenant using this service:
    /// <code>
    /// 
    ///CfgTenantQuery query = new CfgTenantQuery();
    ///query.Dbid = WellKnownDBIDs.EnvironmentDBID;
    ///CfgTenant envTenant = 
    ///     service.RetrieveObject&lt;CfgTenant&gt;(query);
    /// </code>
    /// </summary>
    public sealed class ConfService : AbstractLogEnabled, IConfService, ISubscriber<IMessage>
    {
        private IProtocol confProtocol;
        private EventService eventService;
        private CfgObjectFactory factory;
        private IConfCache cache;
        private CfgMetadata metaData;
        private IConfServicePolicy policy;
        private IScheduler _timerScheduler = Genesyslab.Platform.Commons.Connection.Timer.TimerFactory.Scheduler;
        internal IScheduler TimerScheduler { get { return _timerScheduler; }}

      /// <summary>
      /// Creates a new instance of the class
      /// </summary>
      /// <param name="protocol">A reference to a connection to Configuration Server</param>
      internal ConfService(IProtocol protocol)
        :this(protocol,false)
      {
        
      }
      /// <summary>
      /// Creates a new instance of the class
      /// </summary>
      /// <param name="protocol">A reference to a connection to Configuration Server</param>
      /// <param name="internalSubscribe">if true - use internal message receiver</param>
      internal ConfService(IProtocol protocol, bool internalSubscribe)
        {
            this.confProtocol = protocol;
            this.eventService = new EventService(confProtocol);
            this.factory = new CfgObjectFactory(confProtocol);
            this.policy = new DefaultConfServicePolicy();

            if (protocol is ConfServerProtocol)
            {
                metaData = ((ConfServerProtocol)protocol).Context.CfgMetadata;
            }
            else
            {
              using (var csp = new ConfServerProtocol(new Endpoint(new Uri("tcp://test:123"))))
              {
                //csp.UseConfDataNs = true;
                metaData = csp.Context.CfgMetadata;
              }
            }
            if (internalSubscribe)
            {
              protocol.Received += OnMessageReceivedEvent;
            }
            protocol.Opened += OnChannelOpened;
        }

        internal void InternalUnsubscribe()
        {
          if (confProtocol != null)
          {
            confProtocol.Received -= OnMessageReceivedEvent;
            confProtocol.Opened -= OnChannelOpened;
          }
        }

        private void OnChannelOpened(object sender, EventArgs e)
        {
          var defCache = Cache as DefaultConfCache;
          var protocol = confProtocol;
          if ((defCache != null) && (protocol != null))
          {
            var endpoint = protocol.Endpoint;
            if ((endpoint != null) && (!endpoint.IsUndefined))
            {
              defCache.AddEndpoint(endpoint);
            }
          }
        }
        private void OnMessageReceivedEvent(object sender, EventArgs e)
        {
          MessageEventArgs args = e as MessageEventArgs;
          if (args != null)
          {
            if (Logger.IsDebugEnabled && (args.Message != null))
            {
              Logger.DebugFormat("Received message {0}", args.Message.ToString());
              var err = args.Message as EventError;
              if (err!=null)
              {
                Logger.DebugFormat("EventError is received: {0}", CfgUtilities.GetErrorCode(err.ErrorCode).ToString());
              }
            }
            ((ISubscriber<IMessage>) eventService).Handle(args.Message);
          }
        }

        /// <exclude/>
        public CfgMetadata MetaData
        {
            get { return metaData; }
        }

        /// <exclude/>
        protected override void OnEnableLogging(ILogger logger)
        {
            if (logger == null) 
                throw new ArgumentNullException("logger", "logger is null.");

            base.OnEnableLogging(logger);
            if (TimerScheduler is AbstractLogEnabled)
              ((AbstractLogEnabled)TimerScheduler).EnableLogging(logger.CreateChildLogger("IScheduler"));

            if (cache is AbstractLogEnabled)
                ((AbstractLogEnabled)cache).EnableLogging(logger.CreateChildLogger(cache.GetType().ToString()));

            if (Logger.IsInfoEnabled)
            {
                Logger.Info("COM Logging started.");
                Logger.InfoFormat("Caching enabled: {0}", cache != null);
                Logger.InfoFormat("Protocol state: {0}", Protocol.State);
            }
        }

        internal void SetCache(IConfCache lCache)
        {
            DefaultConfCache defCache = lCache as DefaultConfCache;

            if (defCache != null && Protocol != null && Protocol.Endpoint != null)
            {
                if (defCache.EndpointCount > 0)
                {
                    throw new InvalidOperationException("This cache has been previously associated with a configuration service.");
                }

                defCache.AddEndpoint(Protocol.Endpoint);
            }

            this.cache = lCache;
        }

        internal void SetPolicy(IConfServicePolicy lPolicy)
        {
            if (lPolicy == null) throw new ArgumentNullException("lPolicy");

            this.policy = lPolicy;
        }

        internal EventService EventService
        {
            get { return eventService; }
        }

        /// <summary>
        /// Returns an instance of the configuration cache
        /// used by this ConfService, or null if caching is not
        /// enabled.
        /// </summary>
        public IConfCache Cache
        {
            get { return cache; }
        }

        /// <summary>
        /// Returns the policy associated with this ConfService.
        /// </summary>
        public IConfServicePolicy Policy
        {
            get { return policy; }
        }

        /// <summary>
        /// Returns a reference to the protocol connection to Configuration Server
        /// </summary>
        /// <returns></returns>
        public IProtocol Protocol
        {
            get
            {
                return confProtocol;
            }
        }

        /// <summary>
        /// Updates the specified object in the Configuration Server
        /// </summary>
        /// <param name="cfgObject">the object to update</param>
        public void SaveObject(ICfgObject cfgObject)
        {
            if (cfgObject == null)
                throw new ArgumentNullException("cfgObject");

            cfgObject.Save();
        }

        /// <summary>
        /// Deletes the specified object in the Configuration Server
        /// </summary>
        /// <param name="cfgObject">the object to delete</param>
        public void DeleteObject(ICfgObject cfgObject)
        {
            if (cfgObject == null)
                throw new ArgumentNullException("cfgObject");

            cfgObject.Delete();
        }

        /// <summary>
        /// Refreshes the specified object with the latest information from Configuration Server
        /// </summary>
        /// <param name="cfgObject">the object to refresh</param>
        public void RefreshObject(ICfgObject cfgObject)
        {
            if (cfgObject == null)
                throw new ArgumentNullException("cfgObject");

            cfgObject.Refresh();
        }

        /// <summary>
        /// Retrieves a Configuration Server object based on the specified query
        /// </summary>
        /// <param name="query">the query by which to retrieve the object</param>
        /// <returns>The retrieved Configuration Object</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2223:MembersShouldDifferByMoreThanReturnType"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2223:MembersShouldDifferByMoreThanReturnType"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2223:MembersShouldDifferByMoreThanReturnType")]
        public ICfgObject RetrieveObject(ICfgQuery query)
        {
          return RetrieveObject(query, false);
        }

      /// <summary>
      /// Retrieves a Configuration Server object based on the specified query
      /// </summary>
      /// <param name="query">the query by which to retrieve the object</param>
      /// <param name="isBriefInfo">flag for objects' brief info request</param>
      /// <returns>The retrieved Configuration Object</returns>
      [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2223:MembersShouldDifferByMoreThanReturnType"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2223:MembersShouldDifferByMoreThanReturnType"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2223:MembersShouldDifferByMoreThanReturnType")]
        public ICfgObject RetrieveObject(ICfgQuery query, bool isBriefInfo)
        {
            ICfgObject obj = null;

            if (Logger.IsInfoEnabled)
            {
                Logger.InfoFormat("Retrieving object using query: \r\n\r\n{0}", query);
            }
            if (!isBriefInfo)
            if (policy.QueryCacheOnRetrieve(query))
            {
                if (Logger.IsDebugEnabled)
                {
                    Logger.Debug("Querying cache... ");
                }

                obj = cache.Retrieve<ICfgObject>(query);
            }

            if (obj == null)
            {
                if (Logger.IsDebugEnabled)
                {
                    Logger.Debug("Querying configuration server...");
                }

                obj = factory.RetrieveObject(query, this, isBriefInfo);

                if ((obj != null) && (!isBriefInfo))
                {
                    AddToCache(obj);
                }
            }

            if (Logger.IsInfoEnabled && obj != null)
            {
                Logger.InfoFormat("Retrieved object [{0}], dbid: [{1}]", obj.ObjectType, obj.ObjectDbid);
            }

            if (Logger.IsDebugEnabled && obj != null)
            {
                Logger.DebugFormat("Object content: \r\n\r\n{0}", obj.ToString());
            }

            return obj;
        }
        /// <summary>
        /// Retrieves a typed Configuration Server object based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the object</param>
        /// <returns>The retrieved Configuration Object</returns>
        public T RetrieveObject<T>(ICfgQuery query) where T : ICfgObject
        {
          CheckObjectClass<T>(query);
          return (T)(ICfgObject)RetrieveObject(query, typeof(ICfgBriefInfo).IsAssignableFrom(typeof(T)));
        }

        /// <summary>
        /// Retrieves a Configuration Server object based its dbid and type
        /// </summary>
        /// <param name="dbId">the dbid of the object to retrieve</param>
        /// <param name="objectType">the object's type</param>
        /// <returns>the retrieved object</returns>
        public ICfgObject RetrieveObject(int dbId, CfgObjectType objectType)
        {
          return RetrieveObject(dbId, objectType, false);
        }
        /// <summary>
        /// Retrieves a Configuration Server object based its dbid and type
        /// </summary>
        /// <param name="dbId">the dbid of the object to retrieve</param>
        /// <param name="objectType">the object's type</param>
        /// <param name="isBriefInfo">flag (if "true" - request brief infos) </param>
        /// <returns>the retrieved object</returns>
        public ICfgObject RetrieveObject(int dbId, CfgObjectType objectType, bool isBriefInfo)
        {
            CfgFilterBasedQuery query = new CfgFilterBasedQuery(objectType);

            query.Filter[MiscConstants.FilterDbidName] = dbId;

            return RetrieveObject(query, isBriefInfo);
        }

        /// <summary>
        /// Retrieves a list of typed Configuration Server objects based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of objects to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <returns>a list of retrieved objects</returns>
        public ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query) where T : ICfgObject
        {
          return RetrieveMultipleObjects<T>(query, null, null, (long)confProtocol.Timeout.TotalMilliseconds);
        }

        /// <summary>
        /// Retrieves a list of typed Configuration Server objects based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of objects to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        /// <returns>a list of retrieved objects</returns>
        public ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query, long timeout) where T : ICfgObject
        {
          return RetrieveMultipleObjects<T>(query, null, null, timeout);
        }

        /// <summary>
        /// Retrieves a list of typed Configuration Server objects based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of objects to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
        /// <param name="dataCallback">the callback to notify receiving of each portion of data from server (can be null).</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        /// <returns>a list of retrieved objects</returns>
        public ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query, 
            AsyncCallback finishCallback, AsyncCallback dataCallback, long timeout) where T : ICfgObject
        {
          CheckObjectClass<T>(query);
          return
            EndRetrieveMultipleObjects<T>(BeginRetrieveMultipleObjects(query, finishCallback, dataCallback, null,
                                                                       timeout, typeof (ICfgBriefInfo).IsAssignableFrom(typeof (T))));
        }

        private List<T> RetrieveMultipleFromCache<T>(ICfgQuery query) where T : ICfgObject
        {
            if (Logger.IsDebugEnabled)
            {
                Logger.Debug("Querying cache...");
            }

            IEnumerable<T> objs = Cache.RetrieveMultiple<T>(query);

            if (Logger.IsInfoEnabled)
            {
                Logger.InfoFormat("Retrieved {0} objects from cache.", objs.Count());
            }

            return objs.ToList<T>();
        }

        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="callback">the callback to notify when retrieve operation is complete</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        public IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback callback, Object state)
        {
            return BeginRetrieveMultipleObjects(query, callback, null, state, (long)confProtocol.Timeout.TotalMilliseconds, false);
        }
        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="callback">the callback to notify when retrieve operation is complete</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="isBriefInfo">flag (if "true" - request brief infos) </param>
        public IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback callback, Object state, bool isBriefInfo)
        {
          return BeginRetrieveMultipleObjects(query, callback, null, state, (long)confProtocol.Timeout.TotalMilliseconds, isBriefInfo);
        }

        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        public IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback finishCallback, Object state, long timeout)
        {
            return BeginRetrieveMultipleObjects(query, finishCallback, null, state, timeout, false);
        }

      /// <summary>
      /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
      /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
      /// or immediately, which will block the calling thread until results are available.
      /// </summary>
      /// <param name="query">the query by which to retrieve the objects</param>
      /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
      /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
      /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
      /// (excluding parsing time of messages)</param>
      /// <param name="isBriefInfo">flag (if "true" - request brief infos) </param>
      public IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback finishCallback, Object state, long timeout, bool isBriefInfo)
        {
          return BeginRetrieveMultipleObjects(query, finishCallback, null, state, timeout, isBriefInfo);
        }

        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
        /// <param name="dataCallback">the callback to notify receiving of each portion of data from server (can be null).</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        public IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback finishCallback, AsyncCallback dataCallback, Object state, long timeout)
        {
          return BeginRetrieveMultipleObjects(query, finishCallback, dataCallback, state, timeout, false);
        }

      /// <summary>
      /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
      /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
      /// or immediately, which will block the calling thread until results are available.
      /// </summary>
      /// <param name="query">the query by which to retrieve the objects</param>
      /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
      /// <param name="dataCallback">the callback to notify receiving of each portion of data from server (can be null).</param>
      /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
      /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
      /// (excluding parsing time of messages)</param>
      /// <param name="isBriefInfo">flag (if "true" - request brief infos)</param>
      public IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback finishCallback, AsyncCallback dataCallback, Object state, long timeout, bool isBriefInfo)
        {
            if (Logger.IsInfoEnabled)
            {
                Logger.InfoFormat("Beginning multiple retrieve operation using query: \r\n\r\n{0}", query);
            }
            if (!isBriefInfo)
            if (policy.QueryCacheOnRetrieveMultiple(query))
            {
                List<ICfgObject> objs = RetrieveMultipleFromCache<ICfgObject>(query);

                if (objs != null && objs.Count() > 0)
                {
                    ConfAsyncResult res = new ConfAsyncResult();
                    res.CompletedSynchronously = true;
                    res.ObjectList = new ArrayList(objs);
                    res.Callback = finishCallback;
                    res.DataCallback = dataCallback;
                    res.SetCompleted();
                    res.EnableLogging(GetChildLogger("ConfAsyncResult"));
                    return res;
                }
            }

            if (Logger.IsDebugEnabled)
            {
                Logger.Debug("Querying configuration server...");
            }

            return factory.BeginRetrieveMultipleObjects(query, this, finishCallback, dataCallback, timeout, state, isBriefInfo);
        }

        /// <summary>
        /// Called to retrieve the result of asynchronous RetrieveMultipleObjects operation.  Should be called on 
        /// execution of AsyncCallback passed to BeginRetrieveMultiple objects. Will block
        /// calling thread until results are received if called before operation is completed. 
        /// </summary>
        /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
        /// <returns>A list of retrieved objects</returns>
        /// <typeparam name="T">Type of returned object. It must implement ICfgObject interface.</typeparam>
        public ICollection<T> EndRetrieveMultipleObjects<T>(IAsyncResult asyncResult) where T : ICfgObject
        {
            if (asyncResult == null) 
                throw new ArgumentNullException("asyncResult");

            if (asyncResult.CompletedSynchronously)
            {
                IEnumerable objList = ProcessSyncResult(asyncResult);
                Collection<T> col = new Collection<T>();
                if (objList != null)
                {
                    foreach (ICfgObject obj in objList)
                    {
                        col.Add((T)obj);
                    }
                }
                return col;
            }

            if (asyncResult.AsyncWaitHandle == null ||
                asyncResult.AsyncWaitHandle.SafeWaitHandle == null ||
                asyncResult.AsyncWaitHandle.SafeWaitHandle.IsInvalid)
            {
                throw new ArgumentException("Invalid AsyncWaitHandle");
            }

            try
            {
                asyncResult.AsyncWaitHandle.WaitOne();
            }
            catch (ObjectDisposedException ode)
            {
                throw new ConfigException("Error while retrieving multiple objects", ode);
            }
            catch (AbandonedMutexException ame)
            {
                throw new ConfigException("Error while retrieving multiple objects", ame);
            }
            finally
            {
                EventService.RemoveRetrieveWait(asyncResult);
            }

            Collection<T> res = new Collection<T>();
            ConfAsyncResult result = asyncResult as ConfAsyncResult;
            if (result == null) return res;
            if (result.Error != null)
            {
                throw result.Error;
            }

            ArrayList lst = result.ObjectList;
            if (lst == null)
                return res;
            foreach (ICfgObject obj in lst)
            {
                if (Logger.IsInfoEnabled && obj != null)
                {
                    Logger.InfoFormat("Retrieved object [{0}], dbid: [{1}]", obj.ObjectType, obj.ObjectDbid);
                }

                if (Logger.IsDebugEnabled && obj != null)
                {
                    Logger.DebugFormat("Object content: \r\n\r\n{0}", obj.ToString());
                }
                if (asyncResult is ConfAsyncResult)
                {
                  if (!(asyncResult as ConfAsyncResult).IsBriefInfo) AddToCache(obj);
                } else AddToCache(obj);
                if (!(obj is T))
                    throw new ArgumentException("The query has returned invalid results of invalid type.");
                res.Add((T)obj);
            }

            return res;
        }

        /// <summary>
        /// Asynchronously gets currently received and parsed array of objects, which are getting by
        /// BeginRetrieveMultipleObjects method.
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="result">The IAsyncResult object used to track the current request</param>
        /// <returns>A list of retrieved objects</returns>
        public IEnumerable<T> PartialGet<T>(IAsyncResult result)
        {
            ConfAsyncResult res = result as ConfAsyncResult;
            if (res == null)
                return null;
            ArrayList lst = res.GetCopyOfObjects();
            if(lst != null)
                return lst.Cast<T>();
            return null;
        }

        private IEnumerable ProcessSyncResult(IAsyncResult asyncResult)
        {
            ConfAsyncResult confAsyncResult = asyncResult as ConfAsyncResult;

            if (confAsyncResult != null)
            {
                if (confAsyncResult.CompletedSynchronously == true &&
                    confAsyncResult.ObjectList != null)
                {
                    return confAsyncResult.ObjectList;
                }
            }

            return null;
        }


        #region ISubscriptionService<ConfigurationEvent> Members

        /// <summary>
        /// Registers a subscriber object for receiving notifications from Configuration Server.
        /// </summary>
        /// <param name="subscriber">the "subscriber" object which will handle the notifications</param>
        public void Register(ISubscriber<ConfEvent> subscriber)
        {
            if (Logger.IsDebugEnabled && subscriber != null)
            {
                Logger.DebugFormat("Registering subscriber {0}", subscriber.ToString());
            }

            eventService.Register(subscriber);
        }

        /// <summary>
        /// Registers a delegate for receiving notifications from Configuration Server. Should be used in conjunction
        /// with <code>Subscribe</code> method so that Configuration Server sends the correct notifications
        /// 
        /// </summary>
        /// <param name="handler"></param>
        public void Register(Action<ConfEvent> handler)
        {
            if (Logger.IsDebugEnabled && handler != null)
            {
                Logger.DebugFormat("Registering handler {0}", handler.ToString());
            }

            eventService.Register(handler);
        }

        /// <summary>
        /// Registers a delegate for receiving notifications from Configuration Server
        /// based on the specified filter.
        /// 
        /// </summary>
        /// <param name="handler">The delegate which will handle the event</param>
        /// <param name="filter">A filter to apply to the event</param>
        public void Register(Action<ConfEvent> handler, IPredicate<ConfEvent> filter)
        {
            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Registering handler {0} with filter {1}",
                    handler != null ? handler.ToString() : "",
                    filter != null ? filter.ToString() : "");
            }

            eventService.Register(handler, filter);
        }

        /// <summary>
        /// Unregisters the subscriber from event notifications
        /// </summary>
        /// <param name="subscriber">the subscriber to unregister</param>
        public void Unregister(ISubscriber<ConfEvent> subscriber)
        {
            if (Logger.IsDebugEnabled && subscriber != null)
            {
                Logger.DebugFormat("Unregistering subscriber {0}", subscriber.ToString());
            }

            eventService.Unregister(subscriber);
        }

        /// <summary>
        /// Unregisters the specified delegate from notifications
        /// </summary>
        /// <param name="handler">the function to unregister</param>
        public void Unregister(Action<ConfEvent> handler)
        {
            if (Logger.IsDebugEnabled && handler != null)
            {
                Logger.DebugFormat("Unregistering handler {0}", handler.ToString());
            }

            eventService.Unregister(handler);
        }

        #endregion

        #region Notifications

        /// <summary>
        /// Subscribes to receiving notifications from Configuration Server. Should be used in conjunction
        /// with <code>Register</code> method so that events reach the event handler.  This method 
        /// allows the user to specify the subscription details using the "NotificationQuery"
        /// object passed as a parameter.
        /// </summary>
        /// <param name="query">the query specifying the subscription details</param>
        public Subscription Subscribe(NotificationQuery query)
        {
            return eventService.Subscribe(query);
        }

        /// <summary>
        /// Subscribes to receiving notifications from Configuration Server. Should be used in conjunction
        /// with <code>Register</code> method so that events reach the event handler.  This method
        /// subscribes to events for the object passed as the parameter.
        /// </summary>
        /// <param name="obj">the object about which we want to receive notifications</param>
        public Subscription Subscribe(ICfgObject obj)
        {
            return eventService.Subscribe(obj);
        }

        internal void LogWarning(String message)
        {
          if ((Logger!=null) && (Logger.IsWarnEnabled))
            Logger.Warn(message);
        }

        /// <summary>
        /// Creates a single COM configuration object using the passed parameters
        /// </summary>
        /// <param name="confObject">The XML node describing a single configuration object as received from Configuration Server.</param>
        /// <param name="objectPath">The folder path of the object in Configuration Server </param>
        /// <param name="folderDbid">The DBID of the folder in which the object resides</param>
        /// <param name="isSaved">Specifies whether the object has been previously saved in the configuration database</param>
        /// <returns>the newly created object</returns>
        public ICfgObject CreateObjectFromXml(XElement confObject, string objectPath, int folderDbid, bool isSaved)
        {
            if (confObject == null) throw new ArgumentNullException("confObject");

            KeyValueCollection param = new KeyValueCollection();

            param.Set(MiscConstants.FolderDbidName, folderDbid);

            CfgBase obj = CfgObjectActivator.CreateInstance(
                    confObject.Name.LocalName, this, confObject,
                    new object[] { param, objectPath });

            obj.IsSaved = isSaved;

            CfgObject cfgObject = obj as CfgObject;

            return obj as ICfgObject;
        }

        /// <summary>
        /// Creates a single COM configuration object using the passed parameters
        /// </summary>
        /// <param name="confObject">The XML node describing a single configuration object as received from Configuration Server.</param>
        /// <param name="isSaved">Specifies whether the object has been previously saved in the configuration database</param>
        /// <returns>the newly created object</returns>
        public ICfgObject CreateObjectFromXml(XElement confObject, bool isSaved)
        {
            return CreateObjectFromXml(confObject, null, 0, isSaved);
        }

        /// <summary>
        /// Creates a list of configuration objects based on XML received from Configuration Server
        /// </summary>
        /// <param name="receivedObjects">the XDocument in the format of the Genesyslab.Platform.Configuration.Protocols.ConfServer.Events.EventObjectsRead.ConfObject property</param>
        /// <param name="objectPaths">Array of strings representing a list of paths for the objects in receivedObjects (should be in the same order) </param>
        /// <param name="folderDbids">integer array of folder DBIDs, should be in the same order as the receivedObjects list</param>
        /// <returns>a list of newly created objects</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Convert.ToInt32(System.Object)")]
        public ICollection<ICfgObject> CreateMultipleObjectsFromXml(XDocument receivedObjects, Array objectPaths, Array folderDbids)
        {
            if (receivedObjects == null) throw new ArgumentNullException("receivedObjects");
            var objPaths = objectPaths;
            var folderIds = folderDbids;
            //if (objPaths != null && folderIds != null && objPaths.Length != folderIds.Length) throw new ArgumentNullException("objectPaths length should equal to folderDbids lengths");

            int objectsCount = receivedObjects.Root.Elements().Count();

            if (folderIds != null && folderIds.Length != objectsCount)
            //throw new ArgumentOutOfRangeException("folderDbid array size does not match received objects list.");
            {
              folderIds = null;
              LogWarning("folderDbid array size does not match received objects list - skipping folderDbid's");
            }
            if (objPaths != null && objPaths.Length != objectsCount)
              //throw new ArgumentOutOfRangeException("objectPaths array size does not match received objects list.");
            {  
              objPaths = null;
              LogWarning("objectPaths array size does not match received objects list - skipping objectPaths");
            }

            Collection<ICfgObject> res = new Collection<ICfgObject>();
            ICfgObject obj;
            int i = 0;

            foreach (XElement confObj in receivedObjects.Root.Elements())
            {
                obj = CreateObjectFromXml(confObj,
                    objPaths != null ? objPaths.GetValue(i) as string : null,
                    folderIds != null ? Convert.ToInt32(folderIds.GetValue(i)) : 0,
                    true);

                if (obj != null)
                {
                    res.Add(obj);
                }

                i++;
            }

            return res;
        }

        /// <summary>
        /// Creates a list of configuration objects based on XML received from Configuration Server
        /// </summary>
        /// <param name="receivedObjects">the XDocument in the format of the Genesyslab.Platform.Configuration.Protocols.ConfServer.Events.EventObjectsRead.ConfObject property</param>
        /// <returns>a list of newly created objects</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Convert.ToInt32(System.Object)")]
        public ICollection<ICfgObject> CreateMultipleObjectsFromXml(XDocument receivedObjects)
        {
            return CreateMultipleObjectsFromXml(receivedObjects, null, null);
        }

        /// <summary>
        /// Unsubscribes from receiving notifications from Configuration Server
        /// </summary>
        /// <param name="subscription"></param>
        public void Unsubscribe(Subscription subscription)
        {
            eventService.Unsubscribe(subscription);
        }

        internal void Unsubscribe(ICfgObject obj)
        {
            NotificationQuery query = new NotificationQuery();

            query.ObjectDbid = (int)obj[MiscConstants.DbidPropertyName];
            query.ObjectType = obj.ObjectType;

            eventService.Unsubscribe(new Subscription(query));
        }

        #endregion Notifications

        #region ISubscriber<IMessage> Members

        IPredicate<IMessage> ISubscriber<IMessage>.Filter
        {
            get
            {
                return eventService.Filter;
            }
        }

        void ISubscriber<IMessage>.Handle(IMessage obj)
        {
            if (Logger.IsDebugEnabled && obj != null)
            {
                Logger.DebugFormat("Received message {0}", obj.ToString());
            }

            ((ISubscriber<IMessage>)eventService).Handle(obj);
        }

        #endregion

        internal ICfgObject ResolveLink(int dbid, CfgObjectType objectType)
        {
            ICfgObject obj = null;

            if (policy.AttemptLinkResolutionThroughCache(objectType))
            {
                if (Logger.IsDebugEnabled)
                {
                    Logger.DebugFormat("Resolving link through cache... [{0}], dbid: [{1}]", objectType, dbid);
                }

                obj = Cache.Retrieve<ICfgObject>(objectType, dbid);
            }

            if (obj == null)
            {
                if (Logger.IsDebugEnabled)
                {
                    Logger.DebugFormat("Resolving link through configuration server... [{0}], dbid: [{1}]", objectType, dbid);
                }

                obj = factory.RetrieveObject(dbid, objectType, this);

                AddToCache(obj);
            }


            return obj;
        }

        private void AddToCache(ICfgObject obj)
        {
          if (obj is ICfgBriefInfo) return;
            if (obj != null && policy.CacheOnRetrieve(obj))
            {
                if (cache.Contains(obj) && policy.OverwriteCachedVersionOnRetrieve(obj))
                {
                    if (Logger.IsDebugEnabled)
                    {
                        Logger.DebugFormat("Updating object in cache [{0}], dbid: [{1}]", obj.ObjectType, obj.ObjectDbid);
                    }

                    Cache.Update(obj);
                }
                else
                {
                    try
                    {
                        if (Logger.IsDebugEnabled)
                        {
                            Logger.DebugFormat("Adding object to cache [{0}], dbid: [{1}]", obj.ObjectType, obj.ObjectDbid);
                        }

                        Cache.Add(obj);
                    }
                    catch(Exception ex)
                    {
                        if (Logger.IsWarnEnabled)
                        {
                            Logger.WarnFormat("Error adding to cache! [{0}], dbid: [{1}]. Exception: {2}", obj.ObjectType, obj.ObjectDbid, ex);
                        }
                    }
                }
            }
        }

        internal ILogger GetChildLogger(string name)
        {
            return Logger.CreateChildLogger(name);
        }
    private void CheckObjectClass<T>(ICfgQuery query) 
    {
        CfgObjectType? qotype = null;
        if (query is ICfgFilterBasedQuery)
        {
          qotype = ((ICfgFilterBasedQuery) query).QueryObjectType;
        }
        else if (query is CfgXPathBasedQuery)
        {
          qotype = ((CfgXPathBasedQuery) query).ObjectType;
        }
        else {
        	throw new ArgumentException("unsupported query type");
        }
        if (qotype != null) {
            FieldInfo typeField = null;
            CfgObjectType? objtype = null;
            try
            {
              typeField = typeof(T).GetField("OBJECT_TYPE", BindingFlags.Static | BindingFlags.Public);
            } catch (Exception) { if (typeField==null) return; }
            if (typeField != null) {
              try {
                objtype = (CfgObjectType) typeField.GetValue(null);
              } catch (Exception) { if (objtype==null) return; }
            }
            if (objtype != null) {
                if (objtype != qotype) {
                    throw new ConfigException(
                            "Incompatible result and query types");
                }
            }
        }
    }
    }
}

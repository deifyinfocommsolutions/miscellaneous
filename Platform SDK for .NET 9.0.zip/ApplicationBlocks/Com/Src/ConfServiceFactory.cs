//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// This class is used to create an instance of the Configuration Service. 
    /// An instance of the service must be created before any Configuration
    /// Server requests can be made. For example:
    /// <code>
    /// IConfService service =  ConfServiceFactory.CreateConfService(protocol);
    /// </code>
    /// </summary>
    public sealed class ConfServiceFactory
    {
        private static IDictionary<int, ConfServiceInfo> createdServices =
            new Dictionary<int, ConfServiceInfo>();

        private class ConfServiceInfo
        {
            ISubscriptionService subscriptionService;
            ConfService confService;

            internal ConfServiceInfo(ConfService cs, ISubscriptionService ss)
            {
                confService = cs;
                subscriptionService = ss;
            }

            public ConfService ConfService
            {
                get { return confService; }
                set { confService = value; }
            }

            public ISubscriptionService SubscriptionService
            {
                get { return subscriptionService; }
                set { subscriptionService = value; }
            }

        }

        internal static ConfService CreateConfServiceInternal(IProtocol protocol)
        {
          return CreateConfServiceInternal(protocol, null);
        }
        internal static ConfService CreateConfServiceInternal(IProtocol protocol, ISubscriptionService subscriptionService)
        {
            if (protocol == null)
                throw new ArgumentNullException("protocol");
            //if (protocol.Endpoint == null)
            //    throw new ArgumentException("No endpoint specified in the protocol.");
            //if (subscriptionService == null)
            //    throw new ArgumentNullException("Subscription service not specified! Provide a subscription service such as 'EventBrokerService' to register the created configuration service for events.");

            if (createdServices.ContainsKey(protocol.ProtocolId) == true)
            {
                throw new ArgumentException(
                        "ConfService has already been created for this protocol.");
            }
            //foreach (ConfServiceInfo info in createdServices.Values)
            //{
            //    if (Utils.EndpointsEqual(info.ConfService.Protocol.Endpoint, protocol.Endpoint))
            //    {
            //        throw new ArgumentException("A ConfService has already been created for this protocol's endpoint");
            //    }
            //}

            ConfService srvc = new ConfService(protocol,subscriptionService==null);

            if (subscriptionService!=null)
              subscriptionService.Register<IMessage>(srvc);

            createdServices[protocol.ProtocolId] =
                new ConfServiceInfo(srvc, subscriptionService);

            return srvc;
        }


        /// <summary>
        /// This method creates an instance of a Configuration Service based on 
        /// the specified protocol.
        /// </summary>
        /// <param name="protocol">The configuration service protocol</param>
        /// <param name="subscriptionService">The subscription service with which to register the created service
        /// for config server events (see example in the description of the ConfServiceFactory class).</param>
        /// <returns>a new Configuration Service</returns>
        [Obsolete("Subscription service is obsolete. Please use CreateConfService(IProtocol protocol)")]        
        public static IConfService CreateConfService(IProtocol protocol, ISubscriptionService subscriptionService)
        {
          return CreateConfServiceInternal(protocol, subscriptionService);
        }
        /// <summary>
        /// This method creates an instance of a Configuration Service based on 
        /// the specified protocol.If protocol was created with ProtocolManager, 
        /// it will be incompatible with ProtocolManager. 
        /// Receiver of ProtocolManager will not receive any messages.
        /// </summary>
        /// <param name="protocol">The configuration service protocol</param>
        /// <returns>a new Configuration Service</returns>
        public static IConfService CreateConfService(IProtocol protocol)
        {
          return CreateConfServiceInternal(protocol);
        }



        /// <summary>
        /// Creates a configuration service with the specified
        /// policy information. The created service will
        /// have caching enabled by default with the cache using
        /// the specified cache policy. 
        /// If protocol was created with ProtocolManager, 
        /// it will be incompatible with ProtocolManager. 
        /// Receiver of ProtocolManager will not receive any messages.
        /// </summary>
        /// <param name="protocol">
        ///     Configuration Server protocol
        /// </param>
        /// <param name="confServicePolicy">
        ///     The policy for the created configuration service.</param>
        /// <param name="confCachePolicy">
        ///     The policy for the cache.
        /// </param>
        /// <returns>The created configuration service</returns>
        public static IConfService CreateConfService(
            IProtocol protocol,
            IConfServicePolicy confServicePolicy,
            IConfCachePolicy confCachePolicy)
        {
          ConfService srvc = CreateConfServiceInternal(protocol);

          srvc.SetPolicy(confServicePolicy != null ? confServicePolicy : new DefaultConfServicePolicy());

          DefaultConfCacheStorage storage = new DefaultConfCacheStorage();

          DefaultConfCache confCache = new DefaultConfCache(
                  confCachePolicy, storage, new DefaultConfCacheQueryEngine(storage));

          srvc.SetCache(confCache);

          srvc.Register(confCache);

          return srvc;
        }

      /// <summary>
        /// Creates a configuration service with the specified
        /// policy information. The created service will
        /// have caching enabled by default with the cache using
        /// the specified cache policy.
        /// </summary>
        /// <param name="protocol">
        ///     Configuration Server protocol
        /// </param>
        /// <param name="subscriptionService">The subscription service with which to register the created service
        /// for config server events (see example in the description of the ConfServiceFactory class).</param>
        /// <param name="confServicePolicy">
        ///     The policy for the created configuration service.</param>
        /// <param name="confCachePolicy">
        ///     The policy for the cache.
        /// </param>
        /// <returns>The created configuration service</returns>
        [Obsolete("Subscription service is obsolete. Please use CreateConfService(IProtocol protocol,IConfServicePolicy confServicePolicy,IConfCachePolicy confCachePolicy)")]
        public static IConfService CreateConfService(
            IProtocol protocol,
            ISubscriptionService subscriptionService,
            IConfServicePolicy confServicePolicy,
            IConfCachePolicy confCachePolicy)
        {
            ConfService srvc = CreateConfServiceInternal(protocol, subscriptionService);

            srvc.SetPolicy(confServicePolicy != null ? confServicePolicy : new DefaultConfServicePolicy());

            DefaultConfCacheStorage storage = new DefaultConfCacheStorage();

            DefaultConfCache confCache = new DefaultConfCache(
                    confCachePolicy, storage, new DefaultConfCacheQueryEngine(storage));

            srvc.SetCache(confCache);

            srvc.Register(confCache);

            return srvc;
        }


        /// <summary>
        /// Creates a configuration service with the specified 
        /// policy information. The created service will
        /// have caching enabled if a cache object is passed as a parameter.
        /// If protocol was created with ProtocolManager, 
        /// it will be incompatible with ProtocolManager. 
        /// Receiver of ProtocolManager will not receive any messages.
        /// </summary>
        /// <param name="protocol">
        ///     Configuration Server protocol
        /// </param>
        /// <param name="confServicePolicy">
        ///     The policy for the service
        /// </param>
        /// <param name="cache">
        ///     An object implementing the IConfCache interface
        /// </param>
        /// <returns>The created configuration service</returns>
        public static IConfService CreateConfService(
            IProtocol protocol,
            IConfServicePolicy confServicePolicy,
            IConfCache cache)
        {
          ConfService srvc = CreateConfServiceInternal(protocol);

          srvc.SetPolicy(confServicePolicy != null ? confServicePolicy : new DefaultConfServicePolicy());
          srvc.SetCache(cache);

          ISubscriber<ConfEvent> subscriber =
              cache as ISubscriber<ConfEvent>;

          if (subscriber != null)
          {
            srvc.Register(subscriber);
          }

          return srvc;
        }
        /// <summary>
        /// Creates a configuration service with the specified 
        /// policy information. The created service will
        /// have caching enabled if a cache object is passed as a parameter.
        /// </summary>
        /// <param name="protocol">
        ///     Configuration Server protocol
        /// </param>
        /// <param name="subscriptionService">The subscription service with which to register the created service
        /// for config server events (see example in the description of the ConfServiceFactory class).</param>
        /// <param name="confServicePolicy">
        ///     The policy for the service
        /// </param>
        /// <param name="cache">
        ///     An object implementing the IConfCache interface
        /// </param>
        /// <returns>The created configuration service</returns>
        [Obsolete("Subscription service is obsolete. Please use CreateConfService(IProtocol protocol,IConfServicePolicy confServicePolicy,IConfCache cache)")]
        public static IConfService CreateConfService(
            IProtocol protocol,
            ISubscriptionService subscriptionService,
            IConfServicePolicy confServicePolicy,
            IConfCache cache)
        {
            ConfService srvc = CreateConfServiceInternal(protocol, subscriptionService);

            srvc.SetPolicy(confServicePolicy != null ? confServicePolicy : new DefaultConfServicePolicy());
            srvc.SetCache(cache);

            ISubscriber<ConfEvent> subscriber =
                cache as ISubscriber<ConfEvent>;

            if (subscriber != null)
            {
                srvc.Register(subscriber);
            }

            return srvc;
        }

        /// <summary>
        /// This method creates an instance of a Configuration Service based on 
        /// the specified protocol. If caching is enabled, the default caching policy
        /// will be used. If caching is disabled, all policy flags related to caching will
        /// be "false."
        /// If protocol was created with ProtocolManager, 
        /// it will be incompatible with ProtocolManager. 
        /// Receiver of ProtocolManager will not receive any messages.
        /// </summary>
        /// <param name="protocol">
        ///     The configuration service protocol
        /// </param>
        /// <param name="enableCaching">
        ///     If set to true caching functionality will be turned on
        /// </param>
        /// <returns>a new Configuration Service</returns>
        public static IConfService CreateConfService(
            IProtocol protocol, bool enableCaching)
        {
          ConfService srvc = CreateConfServiceInternal(protocol);

          if (enableCaching)
          {
            DefaultConfCacheStorage storage = new DefaultConfCacheStorage();
            DefaultConfCache cache = new DefaultConfCache(
                    null, storage, new DefaultConfCacheQueryEngine(storage));

            srvc.SetCache(cache);
            srvc.SetPolicy(new CachingConfServicePolicy());

            srvc.Register(cache);
          }

          return srvc;
        }

      /// <summary>
        /// This method creates an instance of a Configuration Service based on 
        /// the specified protocol. If caching is enabled, the default caching policy
        /// will be used. If caching is disabled, all policy flags related to caching will
        /// be "false."
        /// </summary>
        /// <param name="protocol">
        ///     The configuration service protocol
        /// </param>
        /// <param name="subscriptionService">The subscription service with which to register the created service
        /// for config server events (see example in the description of the ConfServiceFactory class).</param>
        /// <param name="enableCaching">
        ///     If set to true caching functionality will be turned on
        /// </param>
        /// <returns>a new Configuration Service</returns>
        [Obsolete("Subscription service is obsolete. Please use CreateConfService(IProtocol protocol,bool enableCaching)")]
        public static IConfService CreateConfService(
            IProtocol protocol, ISubscriptionService subscriptionService, bool enableCaching)
        {
            ConfService srvc = CreateConfServiceInternal(protocol, subscriptionService);

            if (enableCaching)
            {
                DefaultConfCacheStorage storage = new DefaultConfCacheStorage();
                DefaultConfCache cache = new DefaultConfCache(
                        null, storage, new DefaultConfCacheQueryEngine(storage));

                srvc.SetCache(cache);
                srvc.SetPolicy(new CachingConfServicePolicy());

                srvc.Register(cache);
            }

            return srvc;
        }

        /// <summary>
        /// Retrieves an instance of the Configuration Service based on the specified endpoint.<br/>
        /// It checks registered ConfService instances for active Endpoint usage.
        /// <para/>
 	      /// <i><b>Note:</b> This method is not recommended for usage. It does not track WarmStandby
        ///  switchovers, so, in some cases it may be unable to work properly.</i>
        /// </summary>
        /// <param name="ep">A unique endpoint identifier</param>
        /// <returns>An instance of the associated Configuration Service, or null if not found</returns>
        public static IConfService RetrieveConfService(Endpoint ep)
        {
            if (ep == null) return null;

            foreach (ConfServiceInfo csi in createdServices.Values)
            {
              if (csi.ConfService.Protocol.Endpoint==null) continue;
              if (csi.ConfService.Protocol.Endpoint.IsUndefined) continue;
              if (Utils.EndpointsEqual(csi.ConfService.Protocol.Endpoint, ep))
                {
                    return csi.ConfService;
                }
            }

            return null;
        }

        /// <summary>
        /// Retrieves an instance of the Configuration Service based on the specified protocol
        /// </summary>
        /// <param name="protocol">An instance of configuration protocol associated with a previously created
        /// configuration service</param>
        /// <returns>An instance of the associated Configuration Service, or null if not found</returns>
        public static IConfService RetrieveConfService(IProtocol protocol)
        {
          if (protocol == null) return null;
          return RetrieveConfService(protocol.ProtocolId);
        }
        
        internal static IConfService RetrieveConfService(int protocolId)
        {
          foreach (ConfServiceInfo csi in createdServices.Values)
          {
            if (protocolId == csi.ConfService.Protocol.ProtocolId)
            {
              return csi.ConfService;
            }
          }

          return null;
        }

        /// <summary>
        /// Removes the specified configuration service from the internal list and unregisters
        /// it using the subscription service with which it had been registered. This method
        /// should be called when a configuration service which had been created using one of the factory's
        /// "Create" methods is no longer needed.
        /// </summary>
        /// <param name="confService">The configuration service to release</param>
        public static void ReleaseConfService(IConfService confService)
        {
            ConfService cs = confService as ConfService;

            if (cs == null) throw new ArgumentException("This type of configuration service is not supported by the factory.", "confService");
            if (cs.Protocol == null) throw new ArgumentOutOfRangeException("The configuration service does not have an associated protocol", "confService");

            int protocolId = cs.Protocol.ProtocolId;

            if (createdServices.ContainsKey(protocolId) == false)
            {
                throw new InvalidOperationException(
                    "The specified object has either already been released or was not created with this factory.");
            }

            ConfServiceInfo info = createdServices[protocolId];

            if (info.ConfService != confService)
            {
                throw new ArgumentException("The specified configuration service was not created with this factory.");
            }

            if (info.SubscriptionService!=null)
              info.SubscriptionService.Unregister(info.ConfService);
            createdServices.Remove(protocolId);
            cs.InternalUnsubscribe();
        }
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;
using Genesyslab.Platform.ApplicationBlocks.Commons;
using System.Xml;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Events;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Commons.Collections;
using System.Xml.Linq;
using System.Linq;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal class EventService : ISubscriptionService<ConfEvent>, ISubscriber<IMessage>
    {
        COMBrokerService<ConfEvent> myBrokerService;
        IProtocol confProtocol;
        private IPredicate<IMessage> _messageFilter;
        //MessageFilter messageFilter;
        private readonly Dictionary<int, ConfAsyncResult> _messageWaitList = new Dictionary<int, ConfAsyncResult>();

        private class MessageFilterPredicate : IPredicate<IMessage>
        {
          private readonly IProtocol _protocol;
          public MessageFilterPredicate(IProtocol protocol)
          {
            _protocol = protocol;
          }
          public bool Invoke(IMessage obj)
          {
            return ((obj != null) && (obj.ProtocolId == _protocol.ProtocolId));
          }
        }

        internal EventService(IProtocol confProtocol)
        {
            myBrokerService = new COMBrokerService<ConfEvent>();
            this.confProtocol = confProtocol;

            //messageFilter = new MessageFilter(confProtocol.ProtocolId);
            _messageFilter = new MessageFilterPredicate(confProtocol);
            confProtocol.Closed += new EventHandler(confProtocol_Closed);
        }

      private void confProtocol_Closed(object sender, EventArgs eventArgs)
      {
        ConfAsyncResult[] copyMwList = null;
        Exception exception = null;
        lock (_messageWaitList)
        {
          if (_messageWaitList.Count > 0)
          {
            var closedEventArgs = eventArgs as ClosedEventArgs;

            if ((closedEventArgs != null) && (closedEventArgs.Cause != null))
            {
              exception = closedEventArgs.Cause;
            }
            else
            {
              exception = new OperationCanceledException(
                "Connection channel has been closed");
            }

            copyMwList = new ConfAsyncResult[_messageWaitList.Count];

            _messageWaitList.Values.CopyTo(copyMwList, 0);
            _messageWaitList.Clear();
          }
        }
        if (copyMwList != null)
          foreach (ConfAsyncResult res in copyMwList)
          {
            res.Error = exception;
            res.SetCompleted();
          }
      }

      #region ISubscriptionService<ConfigurationEvent> Members
        public void Register(ISubscriber<ConfEvent> subscriber)
        {
            myBrokerService.Register(subscriber);
        }

        public void Register(Action<ConfEvent> handler)
        {
            myBrokerService.Register(handler);
        }

        public void Register(Action<ConfEvent> handler, Genesyslab.Platform.ApplicationBlocks.Commons.IPredicate<ConfEvent> filter)
        {
            myBrokerService.Register(handler, filter);
        }

        public void Unregister(ISubscriber<ConfEvent> subscriber)
        {
            myBrokerService.Unregister(subscriber);
        }

        public void Unregister(Action<ConfEvent> handler)
        {
            myBrokerService.Unregister(handler);
        }

        #endregion

        public void AddRetrieveWait(ConfAsyncResult result)
        {
          lock (_messageWaitList)
          {
            if (_messageWaitList.ContainsKey(result.ReferenceID) == false)
            {
              _messageWaitList[result.ReferenceID] = result;
            }
          }
        }


        internal IPredicate<IMessage> Filter
        {
            get
            {
                return _messageFilter;
            }
        }

        internal Subscription Subscribe(NotificationQuery query)
        {
            return GlobalConfService.Subscribe(confProtocol, query);
        }

        internal Subscription Subscribe(ICfgObject obj)
        {
            return GlobalConfService.Subscribe(confProtocol, obj);
        }

        internal void Unsubscribe(Subscription subscription)
        {
            GlobalConfService.Unsubscribe(confProtocol, subscription);
        }

        #region ISubscriber<IMessage> Members

        IPredicate<IMessage> ISubscriber<IMessage>.Filter
        {
            get
            {
                return _messageFilter;
            }
        }

        private ConfAsyncResult GetConfAsyncResult(int id)
        {
          lock (_messageWaitList)
          {
            return _messageWaitList.ContainsKey(id) ? _messageWaitList[id] : null;
          }
        }
        void ISubscriber<IMessage>.Handle(IMessage obj)
        {
            if (obj == null)
                return;

            ConfEvent newEvent = null;

            switch (obj.Id)
            {
                case EventError.MessageId:
                {
                  EventError objError = obj as EventError;
                  if (objError!=null)
                  {
                    ConfAsyncResult res = GetConfAsyncResult(objError.ReferenceId);
                    if (res != null)
                    {
                      res.ResetTimeout();
                      res.Error = GlobalConfService.CreateConfigServerException(objError);
                      res.ObjectList = null;
                      res.SetCompleted();
                    }
                  }
                  break;
                }
                case EventObjectsSent.MessageId:
                    {
                        var objSent = obj as EventObjectsSent;
                        if (objSent!=null)
                        {
                          ConfAsyncResult res = GetConfAsyncResult(objSent.ReferenceId);
                          if (res != null)
                          {
                            res.ResetTimeout();
                            res.SetCompleted();
                          }
                        }
                        break;
                    }
                case EventObjectsRead.MessageId:
                    {
                        var objRead = obj as EventObjectsRead;
                        if (objRead!=null) 
                        {
                          ConfAsyncResult res = GetConfAsyncResult(objRead.ReferenceId);
                          if (res != null)
                          {
                            res.ParseMessage(objRead);
                          }
                        }
                        break;
                    }
                case EventBriefInfo.MessageId:
                    {
                      var objRead = obj as EventBriefInfo;
                      if (objRead!=null)
                      {
                        ConfAsyncResult res = GetConfAsyncResult(objRead.ReferenceId);
                        if (res != null)
                        {
                          res.ParseMessage(objRead);
                        }
                      }
                      break;
                    }
                case EventObjectUpdated.MessageId:
                    {
                      var upMessage = obj as EventObjectUpdated;
                      if (upMessage != null)
                      {
                        XDocument confObj = upMessage.ConfObject;

                        if (confObj != null)
                        {
                          newEvent =
                            new ConfEvent(
                              GlobalConfService.GetDbidFromDelta(confObj),
                              ConfEventType.ObjectUpdated,
                              confObj,
                              CreateDelta(confObj, upMessage.ProtocolId),
                              upMessage.UnsolisitedEventNumber);
                        }
                        else
                        {
                          newEvent = new ConfEvent(
                            -1, (CfgObjectType) upMessage.ObjectType,
                            ConfEventType.ObjectUpdated, null, upMessage.UnsolisitedEventNumber);
                        }

                        newEvent.IsUnsolicited = upMessage.ReferenceId == 0;
                      }
                      break;
                    }
                case EventObjectCreated.MessageId:
                    {
                      EventObjectCreated upMessage = obj as EventObjectCreated;
                      if (upMessage != null)
                      {
                        XDocument xmlObj = upMessage.ConfObject;
                        KeyValueCollection param = new KeyValueCollection();

                        param.Set(MiscConstants.FolderDbidName, upMessage.FolderDbid);

                        if (xmlObj==null)
                          throw new InvalidOperationException("[EventService.ISubscriber<IMessage>.Handle] EventObjectCreated is wrong");
                        var confData = xmlObj.Element(XName.Get("ConfData", Utils.GetNamespace(confProtocol)));
                        if (confData==null)
                          throw new InvalidOperationException("[EventService.ISubscriber<IMessage>.Handle] EventObjectCreated doesn't contain ConfData");
                        XElement curObj = confData.Elements().First();

                        CfgObject confObj =
                          CfgObjectActivator.CreateInstance(
                            curObj.Name.LocalName,
                            ConfServiceFactory.RetrieveConfService(upMessage.Endpoint),
                            curObj, new object[] {param, new string[] {""}}) as CfgObject;

                        newEvent =
                          new ConfEventObjectCreated(
                            confObj, xmlObj, upMessage.UnsolisitedEventNumber);

                        newEvent.IsUnsolicited = upMessage.ReferenceId == 0;
                      }
                      break;
                    }
                case EventObjectDeleted.MessageId:
                    {
                      var upMessage = obj as EventObjectDeleted;
                      if (upMessage != null)
                      {
                        newEvent = new ConfEvent(upMessage.Dbid, (CfgObjectType) upMessage.ObjectType,
                          ConfEventType.ObjectDeleted, null, upMessage.UnsolisitedEventNumber);

                        newEvent.IsUnsolicited = upMessage.ReferenceId == 0;
                      }
                      break;
                    }
                default:
                    {
                        break;
                    }
            }

            if (newEvent != null)
            {
                myBrokerService.Publish(newEvent);
            }
        }

        private static CfgDelta CreateDelta(XDocument confObj, Endpoint ep)
        {
            if (confObj == null || ep == null || confObj.Root == null ||
                confObj.Root.FirstNode == null)
            {
                throw new ArgumentOutOfRangeException("confObj");
            }
            return CreateDelta(confObj, ConfServiceFactory.RetrieveConfService(ep));
        }
        private static CfgDelta CreateDelta(XDocument confObj, int protocolId)
        {
          if (confObj == null || confObj.Root == null || confObj.Root.FirstNode == null)
          {
            throw new ArgumentOutOfRangeException("confObj");
          }
          return CreateDelta(confObj, ConfServiceFactory.RetrieveConfService(protocolId));
        }
        private static CfgDelta CreateDelta(XDocument confObj, IConfService srvc)
        {
          CfgDelta delta = null;
          if (srvc != null)
          {
            string deltaTypeName = confObj.Root.Elements().First().Name.LocalName;
            delta = CfgObjectActivator.CreateInstance(
                deltaTypeName,
                srvc,
                confObj.Root.Elements().First(), null) as CfgDelta;
          }
          return delta;
        }

        #endregion

        internal void RemoveRetrieveWait(IAsyncResult asyncResult)
        {
          ConfAsyncResult result = asyncResult as ConfAsyncResult;
          lock (_messageWaitList)
          {
            if (result != null && _messageWaitList.ContainsKey(result.ReferenceID))
            {
              _messageWaitList.Remove(result.ReferenceID);
            }
          }
        }
    }
}

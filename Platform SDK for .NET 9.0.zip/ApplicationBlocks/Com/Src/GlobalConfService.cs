//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Text;
using System.Collections;
using System.Xml;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using System.Xml.XPath;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests.Objects;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Requests.Security;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer.Events;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.Configuration.Protocols.Metadata;
using Genesyslab.Platform.Configuration.Protocols.Types;
using System.Xml.Linq;
using System.Linq;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal class GlobalConfService
    {
        private static Hashtable objectTypes;
        private static int maxObjects = 43;

        private GlobalConfService()
        {
        }

        static GlobalConfService()
        {
            // For future developers! Make sure that when objects are added to configuration
            // server, this constructor is changed as well. Or change the scheme into external xml file
            objectTypes = new Hashtable(GlobalConfService.maxObjects);

            objectTypes.Add("NoObject", 0);
            objectTypes.Add("Switch", 1);
            objectTypes.Add("DN", 2);
            objectTypes.Add("Person", 3);
            objectTypes.Add("Place", 4);
            objectTypes.Add("AgentGroup", 5);
            objectTypes.Add("PlaceGroup", 6);
            objectTypes.Add("Tenant", 7);
            objectTypes.Add("Service", 8);
            objectTypes.Add("Application", 9);
            objectTypes.Add("Host", 10);
            objectTypes.Add("PhysicalSwitch", 11);
            objectTypes.Add("Script", 12);
            objectTypes.Add("Skill", 13);
            objectTypes.Add("ActionCode", 14);
            objectTypes.Add("AgentLogin", 15);
            objectTypes.Add("Transaction", 16);
            objectTypes.Add("DNGroup", 17);
            objectTypes.Add("StatDay", 18);
            objectTypes.Add("StatTable", 19);
            objectTypes.Add("AppPrototype", 20);
            objectTypes.Add("AccessGroup", 21);
            objectTypes.Add("Folder", 22);
            objectTypes.Add("Field", 23);
            objectTypes.Add("Format", 24);
            objectTypes.Add("TableAccess", 25);
            objectTypes.Add("CallingList", 26);
            objectTypes.Add("Campaign", 27);
            objectTypes.Add("Treatment", 28);
            objectTypes.Add("Filter", 29);
            objectTypes.Add("TimeZone", 30);
            objectTypes.Add("VoicePrompt", 31);
            objectTypes.Add("IVRPort", 32);
            objectTypes.Add("IVR", 33);
            objectTypes.Add("AlarmCondition", 34);
            objectTypes.Add("Enumerator", 35);
            objectTypes.Add("EnumeratorValue", 36);
            objectTypes.Add("ObjectiveTable", 37);
            objectTypes.Add("CampaignGroup", 38);
            objectTypes.Add("GVPReseller", 39);
            objectTypes.Add("GVPCustomer", 40);
            objectTypes.Add("GVPIVRProfile", 41);
            objectTypes.Add("ScheduledTask", 42);
            objectTypes.Add("MaxObjectType", 43);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal static int GetDbidFromDelta(XDocument deltaDoc)
        {
            XPathNavigator nav = deltaDoc.CreateNavigator();

            XmlNamespaceManager manager = new XmlNamespaceManager(nav.NameTable);

            manager.AddNamespace("ns", deltaDoc.Root.Name.NamespaceName);

            XElement element = deltaDoc.XPathSelectElement("//ns:DBID", manager);

            if (element == null) return -1;

            return Int32.Parse(element.Attribute("value").Value);
        }

        internal static string ObjectTypeToName(CfgObjectType objType)
        {
            string tempString = objType.ToString();

            return tempString.Replace("CFG", "Cfg");
        }

        internal static string NameToDelta(string objName)
        {
            string deltaName = objName.Substring(0, 3) + "Delta" + objName.Substring(3);

            return deltaName;
        }


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.ConfigException.#ctor(System.String)")]
        internal static XElement CreateObject(IProtocol protocol, CfgObjectType objectType, XDocument deltaDoc, KeyValueCollection parameters)
        {
            RequestCreateObject mes = RequestCreateObject.Create((int)objectType, deltaDoc, parameters);

            IMessage myEvent = protocol.Request(mes);
            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when creating object! We received null event as a result.");

                throw ex;
            }
            else if (myEvent.Name == EventObjectCreated.MessageName)
            {
                // everything went fine. The object has been created. We now have to reload the object
                // so that it has all new attributes, including DBID.
                var createdEvent = myEvent as EventObjectCreated;
                if (createdEvent==null)
                  throw new ConfigException("[GlobalConfServoce.CreateObject] Can't create object from broken message");
                XDocument newObjectXml = createdEvent.ConfObject;
                if ((newObjectXml == null) || (newObjectXml.Root==null))
                  throw new ConfigException("[GlobalConfServoce.CreateObject] Can't create object from invalid message");
                /* earlier, we would create a new instance of the class. Now we just reload the old one, changing data
                 Type newObjectType = Type.GetType(CfgConfigurationBroker.CfgObjectsNamespace + "." + ConfService.ObjectTypeToName(objectType));
                object newObj = Activator.CreateInstance(newObjectType, new object[] {this, (XmlNode) newObjectXml.DocumentElement.ChildNodes[0]});*/

                return newObjectXml.Root.Elements().First();
            }
            else if (myEvent.Name == EventError.MessageName)
            {
              var err = myEvent as EventError;
              if (err==null)
                throw new ConfigException("[GlobalConfServoce.CreateObject] event error is broken");
              ConfigServerException ex = CreateConfigServerException(err);
              throw ex;
            }
            else
            {
                throw new ConfigException("Unknown event received as a result of update operation");
            }
        }

        internal static ConfigServerException CreateConfigServerException(EventError eventError)
        {
            CfgErrorType errorType =
                (CfgErrorType)(eventError.ErrorCode & 0xFF);
            CfgObjectType objType =
                (CfgObjectType)((eventError.ErrorCode >> 8) & 0xFF);
            CfgObjectProperty property =
                (CfgObjectProperty)(eventError.ErrorCode >> 16);

            string message = eventError.Description;

            return new ConfigServerException(errorType, objType, property, message);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.ConfigException.#ctor(System.String)")]
        internal static void UpdateObject(IProtocol protocol, CfgObjectType objectType, XDocument deltaDoc, KeyValueCollection parameters)
        {
            RequestUpdateObject mes = RequestUpdateObject.Create((int)objectType, deltaDoc, parameters);

            IMessage myEvent = protocol.Request(mes);
            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when updating object! We received null event as a result.");

                throw ex;
            }
            else if (myEvent.Name == EventObjectUpdated.MessageName)
            {
                // everything went fine.

                return;
            }
            else if (myEvent.Name == EventError.MessageName)
            {
              var err = myEvent as EventError;
              if (err == null)
                throw new ConfigException("[GlobalConfServoce.UpdateObject] event error is broken");
              ConfigServerException ex = CreateConfigServerException(err);
              throw ex;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.ConfigException.#ctor(System.String)")]
        internal static void DeleteObject(IProtocol protocol, CfgObjectType objectType, int objectDbid)
        {
            RequestDeleteObject mes = RequestDeleteObject.Create((int)objectType, objectDbid);
            IMessage myEvent = protocol.Request(mes);
            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when deleting object! We received null event as a result.");

                throw ex;
            }
            else if (myEvent.Name == EventObjectDeleted.MessageName)
            {
                // everything went fine.

                return;
            }
            else if (myEvent.Name == EventError.MessageName)
            {
              var err = myEvent as EventError;
              if (err == null)
                throw new ConfigException("[GlobalConfServoce.DeleteObject] event error is broken");
              ConfigServerException ex = CreateConfigServerException(err);
              throw ex;
            }
        }

        private static IMessage CreateRequestReadObjectOrBriefInfo(ICfgQuery query, out CfgObjectType queryObjectType, bool isBriefInfo)
        {
          if (query == null)
            throw new ArgumentNullException("query", "Unspecified query");

          KeyValueCollection objectFilter;

          queryObjectType = 0;
          var cfgXPathBasedQuery = query as ICfgXPathBasedQuery;
          if (cfgXPathBasedQuery != null) // ICfgXPathBasedQuery
          {
            queryObjectType = (cfgXPathBasedQuery).ObjectType;
            return RequestReadObjects2.Create((int)cfgXPathBasedQuery.ObjectType, cfgXPathBasedQuery.XPath);
          }
          if (query is ICfgFilterBasedQuery)
          {
            Hashtable filter = (query as ICfgFilterBasedQuery).Filter;
            objectFilter = new KeyValueCollection();
            string strKey;

            foreach (DictionaryEntry de in filter)
            {
              strKey = de.Key as string;
              if (de.Value is Enum)
                objectFilter.Add(strKey, (int)de.Value);
              else
                objectFilter.Add(strKey, de.Value);
            }
            filter = (query as ICfgFilterBasedQuery).ExtraFilter;
            if (filter!=null)
            foreach (DictionaryEntry de in filter)
            {
              strKey = de.Key as string;
              if (objectFilter.ContainsKey(strKey)) continue;
              if (de.Value is Enum)
                objectFilter.Add(strKey, (int)de.Value);
              else
                objectFilter.Add(strKey, de.Value);
            }

            queryObjectType = ((ICfgFilterBasedQuery)query).QueryObjectType;
          }
          else
          {
            // we don't support any other queries
            throw new ArgumentException("Invalid type of a query");
          }

          // here we are adding a special entry that causes Configuration Server to return
          // additional folder information
          //objectFilter.Add(MiscConstants.ReadFolderInfoFilterName, 0);
          //objectFilter.Add(MiscConstants.ReadObjectPathFilterName, 0);

          if (isBriefInfo) return RequestGetBriefInfo.Create((int)queryObjectType, objectFilter);
          return RequestReadObjects.Create((int) queryObjectType, objectFilter);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static IAsyncResult BeginLoadObject(IProtocol protocol, ICfgQuery query,
            ConfService confService, AsyncCallback finishCallback, AsyncCallback dataCallback,
            long timeout, object state)
        {
          return BeginLoadObject(protocol, query, confService, finishCallback, dataCallback, timeout, state, false);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static IAsyncResult BeginLoadObject(IProtocol protocol, ICfgQuery query,
            ConfService confService, AsyncCallback finishCallback, AsyncCallback dataCallback,
            long timeout, object state, bool isBriefInfo)
        {
            //if (query == null)
            //    throw new ArgumentNullException("query");

            //KeyValueCollection objectFilter = new KeyValueCollection();

            CfgObjectType queryObjectType = 0;

            //if (query is ICfgFilterBasedQuery)
            //{
            //    Hashtable filter = query.Filter;
            //    string strKey;

            //    foreach (DictionaryEntry de in filter)
            //    {
            //        strKey = de.Key as string;
            //        if (de.Value is Enum)
            //            objectFilter.Add(strKey, (int)de.Value);
            //        else
            //            objectFilter.Add(strKey, de.Value);
            //    }

            //    queryObjectType = ((ICfgFilterBasedQuery)query).QueryObjectType;
            //}
            //else
            //{
            //    // we don't support any other queries
            //    throw new ArgumentException("Invalid type of a query");
            //}

            //// here we are adding a special entry that causes Configuration Server to return
            //// additional folder information
            //objectFilter.Add(MiscConstants.ReadFolderInfoFilterName, 0);
            //objectFilter.Add(MiscConstants.ReadObjectPathFilterName, 0);

            //IMessage message = RequestReadObjects.Create((int)queryObjectType, objectFilter);
            IMessage message = CreateRequestReadObjectOrBriefInfo(query, out queryObjectType, isBriefInfo);
            ConfAsyncResult confAsyncResult = new ConfAsyncResult();
            confAsyncResult.IsBriefInfo = isBriefInfo;
            confAsyncResult.AsyncState = state;
            confAsyncResult.ConfigurationService = confService;
            confAsyncResult.Timeout = timeout;
            confAsyncResult.TimerScheduler = confService.TimerScheduler;
            confAsyncResult.EnableLogging(confService.GetChildLogger("ConfAsyncResult"));

            int r = (int)protocol.ReferenceBuilder.CreateReference();

            confAsyncResult.ReferenceID = r;
            confAsyncResult.Callback = finishCallback;
            confAsyncResult.DataCallback = dataCallback;

            protocol.ReferenceBuilder.UpdateReference(message, r);

            confService.EventService.AddRetrieveWait(confAsyncResult);

            try
            {
              protocol.Send(message);
            }
            catch (Exception ex)
            {

              throw new ConfigException("Exception on sending request", ex);
            }

            confAsyncResult.StartTimer();

            return confAsyncResult;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Convert.ToInt32(System.Object)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")]
        internal static void InternalLoadObject(IProtocol protocol,
                                                       ICfgQuery query,
                                                        out XDocument confObject,
                                                        out CfgObjectType queryObjectType,
                                                        out KeyValueCollection[] parameters,
                                                        out string[] objectPaths)
        {
          InternalLoadObject(protocol, query, out confObject, out queryObjectType, out parameters, out objectPaths, false);
        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Convert.ToInt32(System.Object)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")]
        internal static void InternalLoadObject(IProtocol protocol,
                                                        ICfgQuery query,
                                                        out XDocument confObject,
                                                        out CfgObjectType queryObjectType,
                                                        out KeyValueCollection[] parameters,
                                                        out string[] objectPaths,
                                                        bool isBriefInfo)
        {
            parameters = null;
            confObject = null;
            objectPaths = null;
            //if (query == null)
            //    throw new ArgumentNullException("query", "Unspecified query");

            //KeyValueCollection objectFilter = new KeyValueCollection();


            //if (query is ICfgFilterBasedQuery)
            //{
            //    Hashtable filter = query.Filter;
            //    string strKey;

            //    foreach (DictionaryEntry de in filter)
            //    {
            //        strKey = de.Key as string;
            //        if (de.Value is Enum)
            //            objectFilter.Add(strKey, (int)de.Value);
            //        else
            //            objectFilter.Add(strKey, de.Value);
            //    }

            //    queryObjectType = ((ICfgFilterBasedQuery)query).QueryObjectType;
            //}
            //else
            //{
            //    // we don't support any other queries
            //    throw new ArgumentException("Invalid type of a query");
            //}

            //// here we are adding a special entry that causes Configuration Server to return
            //// additional folder information
            //objectFilter.Add(MiscConstants.ReadFolderInfoFilterName, 0);
            //objectFilter.Add(MiscConstants.ReadObjectPathFilterName, 0);

            //IMessage message = RequestReadObjects.Create((int)queryObjectType, objectFilter);
            IMessage message = CreateRequestReadObjectOrBriefInfo(query, out queryObjectType, isBriefInfo);
            IMessage response = null;
            try
            {
              response = protocol.Request(message);
            }catch(Exception ex)
            {
              
              throw new ConfigException("Exception on sending request", ex);
            }

          //            protocol.Send(message);

            if (response is EventObjectsRead)
            {
              EventObjectsRead realResponse = response as EventObjectsRead;
              if (realResponse == null || realResponse.ConfObject == null)
              {
                return;
              }

              confObject = realResponse.ConfObject;

              Array foldersDbids = realResponse.FolderDbids;
              int objectsCount = confObject.Root.Elements().Count();
              if ((foldersDbids!=null) && (foldersDbids.GetLength(0) < objectsCount))
                throw new InvalidOperationException("There are not enough folder dbids in the Read request result");

              objectPaths = realResponse.ObjectPaths as string[];


              parameters = new KeyValueCollection[objectsCount];

              for (int i = 0; i < objectsCount; i++)
              {
                parameters[i] = new KeyValueCollection();
                if (foldersDbids!=null)
                  parameters[i].Add(MiscConstants.FolderDbidName, Convert.ToInt32(foldersDbids.GetValue(i)));
              }
            }
            if (response is EventBriefInfo)
            {
              EventBriefInfo realResponse = response as EventBriefInfo;
              if (realResponse == null || realResponse.BriefInfo == null)
              {
                return;
              }

              confObject = realResponse.BriefInfo;
            }


        }

        internal static Subscription Subscribe(IProtocol protocol, NotificationQuery query)
        {
            KeyValueCollection objectFilter = new KeyValueCollection();
            Hashtable filter = query.Filter;
            foreach (DictionaryEntry de in filter)
            {
                objectFilter.Add((string)de.Key, de.Value);
            }

            KeyValueCollection subscriptionFilter = new KeyValueCollection();
            subscriptionFilter.Set(MiscConstants.SubscriptionKey, objectFilter);

            IMessage registerNotification = RequestRegisterNotification.Create(subscriptionFilter);
            IMessage eventMessage = protocol.Request(registerNotification);
            EventError errMessage = eventMessage as EventError;

            if (errMessage != null)
            {
                ConfigServerException ex =
                    CreateConfigServerException((EventError)errMessage);

                throw ex;
            }

            return new Subscription(query);
        }

        internal static Subscription Subscribe(IProtocol protocol, ICfgObject obj)
        {
            NotificationQuery query = new NotificationQuery();
            query.ObjectDbid = (int)obj[MiscConstants.DbidPropertyName];
            query.ObjectType = obj.ObjectType;

            return Subscribe(protocol, query);
        }

        internal static void Unsubscribe(IProtocol protocol, Subscription subscription)
        {
            KeyValueCollection objectFilter = new KeyValueCollection();
            Hashtable filter = subscription.Query.Filter;
            foreach (DictionaryEntry de in filter)
            {
                objectFilter.Add((string)de.Key, de.Value);
            }

            KeyValueCollection subscriptionFilter = new KeyValueCollection();
            subscriptionFilter.Set(MiscConstants.SubscriptionKey, objectFilter);

            IMessage unregisterNotification = RequestUnregisterNotification.Create(subscriptionFilter);
            protocol.Request(unregisterNotification);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.ConfigException.#ctor(System.String)")]
        internal static int ReadObjectPermissions(IProtocol protocol,
                                             int objectDbid,
                                             CfgObjectType objectType,
                                             int accountDbid,
                                             CfgObjectType accountType)
        {
            string ns = Utils.GetNamespace(protocol);

            XDocument objectDoc = XmlPermissionsHelper.CreatePermissionsObjectXml(objectDbid, (int)objectType, ns);
            XDocument accountDoc = XmlPermissionsHelper.CreatePermissionsObjectXml(accountDbid, (int)accountType, ns);
            RequestReadObjectPermissions mes = RequestReadObjectPermissions.Create(objectDoc, accountDoc);

            IMessage myEvent = protocol.Request(mes);

            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when reading object permissions! We received null event as a result.");

                throw ex;
            }

            if (myEvent.Name == EventObjectPermissionsRead.MessageName)
            {
                // everything went fine.
              var realEvent = myEvent as EventObjectPermissionsRead;
              if (realEvent==null)
                throw new ConfigException("[GlobalConfService.ReadObjectPermissions] EventObjectPermissionsRead is broken");
                // XmlDocument permissions = (XmlDocument) realEvent.ConfPermissions;
                // permissions.Save("permissions.xml");
              return realEvent.Permissions;
            }
            else if (myEvent.Name == EventError.MessageName)
            {
              var err = myEvent as EventError;
              if (err == null)
                throw new ConfigException("[GlobalConfServoce.ReadObjectPermissions] event error is broken");
              ConfigServerException ex = CreateConfigServerException(err);
              throw ex;
            }
            else
            {
                ConfigException ex = new ConfigException("Received unknown event when reading permissions! " + mes.ToString());

                throw ex;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.ConfigException.#ctor(System.String)")]
        internal static XDocument ReadPermissions(IProtocol protocol,
                                             int objectDbid,
                                             CfgObjectType objectType)
        {
            XDocument objectDoc = XmlPermissionsHelper.CreatePermissionsObjectXml(objectDbid, (int)objectType, Utils.GetNamespace(protocol));

            RequestReadPermissions mes = RequestReadPermissions.Create(objectDoc);

            IMessage myEvent = protocol.Request(mes);

            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when reading permissions! We received null event as a result.");

                throw ex;
            }

            if (myEvent.Name == EventPermissionsRead.MessageName)
            {
                // everything went fine.
                var realEvent = myEvent as EventPermissionsRead;
                if (realEvent==null)
                  throw new ConfigException("[GlobalConfService.ReadPermissions] EventPermissionsRead is broken");
                // XmlDocument permissions = (XmlDocument) realEvent.ConfPermissions;
                // permissions.Save("permissions.xml");
                return realEvent.ConfPermissions;
            }
            else if (myEvent.Name == EventError.MessageName)
            {
              var err = myEvent as EventError;
              if (err == null)
                throw new ConfigException("[GlobalConfServoce.ReadPermissions] event error is broken");
              ConfigServerException ex = CreateConfigServerException(err);
              throw ex;
            }
            else
            {
                ConfigException ex = new ConfigException("Received unknown event when reading permissions! " + mes.ToString());

                throw ex;
            }
        }

        internal static void RemoveAccount(
                                     IProtocol protocol,
                                     int objectDbid,
                                     CfgObjectType objectType,
                                     int accountDbid,
                                     CfgObjectType accountType,
                                     int recursion)
        {
            // First, read object permissions:
            XDocument objectDoc = XmlPermissionsHelper.CreatePermissionsObjectXml(objectDbid, (int)objectType, Utils.GetNamespace(protocol));
            RequestReadPermissions mes = RequestReadPermissions.Create(objectDoc);

            IMessage myEvent = protocol.Request(mes);

            XDocument oldPermissionsDoc = null;
            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when reading permissions during update! We received null event as a result.");

                throw ex;
            }

            if (myEvent.Name == EventPermissionsRead.MessageName)
            {
              var evt = myEvent as EventPermissionsRead;
              if (evt==null)
                throw new ConfigException("[GlobalConfServoce.RemoveAccount] EventPermissionsRead is broken");
                // everything went fine.
              oldPermissionsDoc = evt.ConfPermissions;
            }
            else
            {
                ConfigException ex = new ConfigException("Received unknown event when reading permissions! " + mes.ToString());

                throw ex;
            }

            // Second, update permissions
            XDocument newDoc = XmlPermissionsHelper.RemoveAccountFromPermissionsXml(
                oldPermissionsDoc, accountDbid, (int)accountType);

            if (newDoc == null)
                return;

#if DEBUG
            ((XDocument)newDoc.CreateNavigator().UnderlyingObject).Save("permissions.xml");
#endif
            RequestUpdatePermissions messageUpdate = RequestUpdatePermissions.Create(newDoc, recursion);

            myEvent = protocol.Request(messageUpdate);

            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when updating permissions! We received null event as a result.");

                throw ex;
            }

            if (myEvent.Name == EventPermissionsUpdated.MessageName)
            {
                // everything went fine.
                return;
            }
            else if (myEvent.Name == EventError.MessageName)
            {
              var evt = myEvent as EventError;
              if (evt == null)
                throw new ConfigException("[GlobalConfServoce.RemoveAccount] EventError is broken");

              ConfigServerException ex = CreateConfigServerException(evt);

              throw ex;
            }
            else
            {
                ConfigException ex = new ConfigException("Received unknown event when updating permissions! " + mes.ToString());

                throw ex;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.ConfigException.#ctor(System.String)")]
        internal static void UpdatePermissions(IProtocol protocol,
                                             int objectDbid,
                                             CfgObjectType objectType,
                                             int accountDbid,
                                             CfgObjectType accountType,
                                             int newPermissionsMask,
                                             int recursion)
        {
            // First, read object permissions:
            XDocument objectDoc = XmlPermissionsHelper.CreatePermissionsObjectXml(objectDbid, (int)objectType, Utils.GetNamespace(protocol));
            RequestReadPermissions mes = RequestReadPermissions.Create(objectDoc);

            IMessage myEvent = protocol.Request(mes);
            XDocument oldPermissionsDoc = null;
            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when reading permissions during update! We received null event as a result.");

                throw ex;
            }

            if (myEvent.Name == EventPermissionsRead.MessageName)
            {
              var evt = myEvent as EventPermissionsRead;
              if (evt == null)
                throw new ConfigException("[GlobalConfServoce.UpdatePermissions] EventPermissionsRead is broken");
              // everything went fine.
              oldPermissionsDoc = evt.ConfPermissions;
            }
            else
            {
                ConfigException ex = new ConfigException("Received unknown event when reading permissions! " + mes.ToString());

                throw ex;
            }

            // Second, update permissions
            XDocument newDoc = XmlPermissionsHelper.CreateUpdateXml(oldPermissionsDoc, accountDbid, (int)accountType, newPermissionsMask);
            if (newDoc == null)
                return;

#if DEBUG
            ((XDocument)newDoc.CreateNavigator().UnderlyingObject).Save("permissions.xml");
#endif
            RequestUpdatePermissions messageUpdate = RequestUpdatePermissions.Create(newDoc, recursion);

            myEvent = protocol.Request(messageUpdate);
            if (myEvent == null)
            {
                ConfigException ex = new ConfigException("Error occurred when updating permissions! We received null event as a result.");

                throw ex;
            }

            if (myEvent.Name == EventPermissionsUpdated.MessageName)
            {
                // everything went fine.
                return;
            }
            else if (myEvent.Name == EventError.MessageName)
            {
                var evt = myEvent as EventError;
                if (evt == null)
                  throw new ConfigException("[GlobalConfServoce.UpdatePermissions] EventError is broken");
                
                ConfigServerException ex = CreateConfigServerException(evt);

                throw ex;
            }
            else
            {
                ConfigException ex = new ConfigException("Received unknown event when updating permissions! " + mes.ToString());

                throw ex;
            }
        }

        internal static ArrayList MessageToCfgObjects(EventObjectsRead realResponse, IConfService confService)
        {
            ArrayList result = new ArrayList();

            CfgObjectType queryObjectType = (CfgObjectType)realResponse.ObjectType;
            XDocument confObject = realResponse.ConfObject;
            if (confObject == null)
                return result;

            Array foldersDbids = realResponse.FolderDbids;
            int objectsCount = confObject.Root.Elements().Count();

            if ((foldersDbids != null) && (foldersDbids.GetLength(0) < objectsCount))
            //    throw new InvalidOperationException("There are not enough folder dbids in the Read request result");
            {
              foldersDbids = null;
              var service = (confService as ConfService);
              if (service!=null) 
                service.LogWarning("folderDbid array size does not match received objects list - skipping folderDbid's");
            }

            string[] objectPaths = realResponse.ObjectPaths as string[];

            if ((objectPaths != null) && (objectPaths.Length < objectsCount))
            //    throw new InvalidOperationException("There are not enough object paths in the Read request result");
            {
              objectPaths = null;
              var service = (confService as ConfService);
              if (service!=null) 
                service.LogWarning("objectPaths array size does not match received objects list - skipping objectPaths");
            }

            KeyValueCollection[] parameters = new KeyValueCollection[objectsCount];
            
            int i = 0;
            if (foldersDbids != null)
            for (i = 0; i < objectsCount; i++)
            {
              parameters[i] = new KeyValueCollection();
              parameters[i].Add(MiscConstants.FolderDbidName, Convert.ToInt32(foldersDbids.GetValue(i)));
            }

            i = 0;
            // if there are many objects, return a list
            foreach (XElement element in confObject.Root.Elements())
            {
                object newObj = CfgObjectActivator.CreateInstance(
                    GlobalConfService.ObjectTypeToName(queryObjectType), confService, element,
                    ((foldersDbids==null)&&(objectPaths==null))?null:
                    new object[] { parameters[i], (objectPaths==null)?null:objectPaths[i] });

                result.Add(newObj);
                i++;
            }
            return result;
        }
        internal static ArrayList MessageToCfgObjects(EventBriefInfo realResponse, IConfService confService)
        {
          if (realResponse == null) return null;
          XDocument confObject = realResponse.BriefInfo;
          if ((confObject == null) || (confObject.Root==null))return null;
          var result = new ArrayList();
          int objectsCount = confObject.Root.Elements().Count();
          if (objectsCount > 0)
          {
            foreach (ICfgObject cfgObject in confService.CreateMultipleObjectsFromXml(confObject.Document)) result.Add(cfgObject);
          }
          return result;
        }


        /// <summary>
        ///  Reads "Logon As" account for the CfgAppliaction object of the server type.
        /// </summary>
        /// <param name="confService">service to communicate with Configuration Server.</param>
        /// <param name="application">CfgAppliaction which account should be read.</param>
        /// <returns>object that identifies logon account for this application</returns>
        /// <exception cref="ArgumentNullException">if confService or application is null.</exception>
        /// <exception cref="ConfigException">if logon account can't be read from server</exception>
        internal static CfgACEID GetLogonAs(IConfService confService, CfgApplication application)
        {
            if (confService == null)
                throw new ArgumentNullException("confService", "can't be null");
            if (application == null)
                throw new ArgumentNullException("application", "can't be null");

            IProtocol protocol = confService.Protocol;
            var nameSpace = Utils.GetNamespace(protocol);

            XDocument appId = XmlPermissionsHelper.CreateCfgIdXml(application.DBID, (int) CfgObjectType.CFGApplication,
                nameSpace);
            RequestReadAccount request = RequestReadAccount.Create(appId);

            IMessage response;
            try
            {
                response = protocol.Request(request);
            }
            catch (ProtocolException ex)
            {
                throw new ConfigException("Exception on object read request", ex);
            }

            if (response == null)
            {
                throw new ConfigException(
                    "Error occurred when reading account: got null event as a result.");
            }
            if (response.Id == EventAccountRead.MessageId)
            {
                var account = (EventAccountRead) response;
                return new CfgACEID(confService, XmlPermissionsHelper.GetCfgId(account.AccountId), null);
            }
            if (response.Id == EventError.MessageId)
            {
                throw CreateConfigServerException((EventError) response);
            }
            throw new ConfigException(
                "Unexpected response on object update request: " + response);
        }


        /// <summary>
        /// Sets "Logon As" account for the CfgAppliaction object of the server type.
        /// </summary>
        /// <param name="confService">service to communicate with Configuration Server.</param>
        /// <param name="application">CfgAppliaction which account should be updated.</param>
        /// <param name="accountType">supported types are CfgPerson and CfgAccessGroup.</param>
        /// <param name="accountDBID">dbid of the person or an access group object.</param>
        /// <exception cref="ArgumentNullException">confService or application is null.</exception>
        /// <exception cref="ArgumentException">account dbid zero or negative, unexpected account type.</exception>
        /// <exception cref="ConfigException">if account wasn't updated</exception>
        internal static void SetLogonAs(IConfService confService, CfgApplication application, CfgObjectType accountType,
            int accountDBID)
        {
            if (confService == null)
                throw new ArgumentNullException("confService", "confService can't be null");
            if (application == null)
                throw new ArgumentNullException("application", "application can't be null");
            if (accountDBID < 1)
            {
                throw new ArgumentException("Account dbid can't be zero or negative");
            }
            if (accountType != CfgObjectType.CFGPerson && accountType != CfgObjectType.CFGAccessGroup)
            {
                throw new ArgumentException("Account should be either CFGPerson or CFGAccessGroup");
            }

            IProtocol protocol = confService.Protocol;
            var nameSpace = Utils.GetNamespace(protocol);

            XDocument appId = XmlPermissionsHelper.CreateCfgIdXml(application.DBID, (int) CfgObjectType.CFGApplication, nameSpace);
            XDocument accId = XmlPermissionsHelper.CreateCfgIdXml(accountDBID, (int) accountType, nameSpace);
            RequestUpdateAccount request = RequestUpdateAccount.Create(appId, accId);
            IMessage response;

            try
            {
                response = protocol.Request(request);
            }
            catch (ProtocolException ex)
            {
                throw new ConfigException("Exception on object update request", ex);
            }

            if (response == null)
            {
                throw new ConfigException(
                    "Error occurred when updating account: got null event as a result.");
            }
            if (response.Id == EventAccountUpdated.MessageId)
            {
                return;
            }
            if (response.Id == EventError.MessageId)
            {
                throw CreateConfigServerException((EventError) response);
            }
            throw new ConfigException(
                    "Unexpected response on object update request: " + response);
        }

    }
}

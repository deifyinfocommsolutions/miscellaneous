//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Xml;
using System.Collections;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    using Genesyslab.Platform.Configuration.Protocols.ConfServer;
    using Genesyslab.Platform.Configuration.Protocols.Metadata;
    using System.Collections.Generic;

    /// <summary>
    /// An interface that should be supported by all configuration classes (objects that can be independently
    /// retrieved from Config Server).
    /// </summary>
    public interface ICfgObject : ICfgBase
    {
        /// <summary>
        /// Returns object type
        /// </summary>
        /// <returns></returns>
        CfgObjectType ObjectType
        {
            get;
        }

        /// <summary>
        ///Returns the dbid of the current object, or 0 if object has not been saved
        /// </summary>
        int ObjectDbid
        {
            get;
        }

        /// <summary>
        /// Synchronizes changes in a class with Configuration Server. Internally generates the correct delta
        /// object and sends it to Configuration Server.
        /// </summary>
        void Save();

        /// <summary>
        /// Updates the current object with the latest state from the configuration
        /// server.
        /// </summary>
        void Refresh();

        /// <summary>
        /// Deletes the current object from the configuration.
        /// </summary>
        void Delete();

        /// <summary>
        /// Updates the current object from the passed delta object
        /// </summary>
        /// <param name="deltaObject">the delta object representing the changes to be made</param>
        void Update(ICfgDelta deltaObject);
    }

    /// <summary>
    /// An interface that should be supported by all configuration structures (configuration objects that are 
    /// dependent on other configuration objects and can only be retrieved as part of some other object (class)
    /// </summary>
    public interface ICfgStructure : ICfgBase
    {
        /// <summary>
        /// Returns the structure's parent object. Should be a configuration class.
        /// </summary>
        /// <returns></returns>
        ICfgObject Parent
        {
            get;
        }

        /*
                /// <summary>
                /// A general method for obtaining the value of an arbitrary property of the object
                /// </summary>
                /// <param name="propertyName"></param>
                /// <returns>Property value</returns>
                object GetProperty(string propertyName);*/
    }

    /// <exclude/>
    public interface ICfgDelta : ICfgBase
    {

    }


    /// <summary>
    /// The base interface for all Configuration Server brief info structures.
    /// </summary>
    public interface ICfgBriefInfo : ICfgObject
    {

      /// <summary>
      /// Returns object identification structure of the current object.<br/>
      /// It contains object type and dbid.
      /// </summary>
      /// <returns>Configuration object ID</returns>
      CfgID ID { get; }
    }

  /*
	public interface ICfgObjectData : IConfigurationData
	{
        CfgObjectType ObjectType
        {
            get;
        }
	}

	internal interface ICfgStructureData : IConfigurationData
	{
	}

	public interface IConfigurationData
	{
        CfgDescriptionAttribute GetProperty(
            string className, string propertyName);

		IEnumerable<CfgDescriptionAttribute> GetAllProperties();
        // this method is used to distinguish between classes like CfgPerson, where in case of changed
        // structures, the changes are written into the main root object and classes like CfgAgentGroup,
        // where changes are written into delta node.
        bool DeltaHasRootObject
        {
            get;
        }
	}*/
}

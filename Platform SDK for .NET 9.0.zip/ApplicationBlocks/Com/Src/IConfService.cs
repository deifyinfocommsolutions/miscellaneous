//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Cache;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.Configuration.Protocols.Types;
using System.Xml;
using System.Xml.XPath;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.ApplicationBlocks.Commons.Broker;
using System.Xml.Linq;
using Genesyslab.Platform.Configuration.Protocols.Metadata;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
  /// <exclude/>
  public interface IConfService : ISubscriptionService<ConfEvent>
    {
      /// <exclude/>
        CfgMetadata MetaData
        {
            get;
        }

        /// <summary>
        /// Returns a reference to the protocol connection to Configuration Server
        /// </summary>
        /// <returns></returns>
        IProtocol Protocol
        {
            get;
        }

        /// <summary>
        /// Returns an instance of the configuration cache or null if caching is not
        /// enabled.
        /// </summary>
        IConfCache Cache
        {
            get;
        }

        /// <summary>
        /// Returns the policy associated with this service
        /// </summary>
        IConfServicePolicy Policy
        {
            get;
        }

        /// <summary>
        /// Updates the specified object
        /// </summary>
        /// <param name="cfgObject">the object to update</param>
        void SaveObject(ICfgObject cfgObject);

        /// <summary>
        /// Deletes the specified object
        /// </summary>
        /// <param name="cfgObject">the object to delete</param>
        void DeleteObject(ICfgObject cfgObject);

        /// <summary>
        /// Refreshes the specified object with the latest information
        /// </summary>
        /// <param name="cfgObject">the object to refresh</param>
        void RefreshObject(ICfgObject cfgObject);

        /// <summary>
        /// Retrieves an object based on the specified query
        /// </summary>
        /// <param name="query">the query by which to retrieve the object</param>
        /// <returns>The retrieved object</returns>
        ICfgObject RetrieveObject(ICfgQuery query);
        /// <summary>
        /// Retrieves an object based on the specified query
        /// </summary>
        /// <param name="query">the query by which to retrieve the object</param>
        /// <param name="isBriefInfo">flag for objects' brief info request</param>
        /// <returns>The retrieved object</returns>
        ICfgObject RetrieveObject(ICfgQuery query, bool isBriefInfo);

        /// <summary>
        /// Retrieves a typed object based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the object</param>
        /// <returns>The retrieved object</returns>
        T RetrieveObject<T>(ICfgQuery query) where T : ICfgObject;

        /// <summary>
        /// Retrieves an object based its dbid and type
        /// </summary>
        /// <param name="dbId">the dbid of the object to retrieve</param>
        /// <param name="objectType">the object's type</param>
        /// <returns>the retrieved object</returns>
        ICfgObject RetrieveObject(int dbId, CfgObjectType objectType);
        /// <summary>
        /// Retrieves an object based its dbid and type
        /// </summary>
        /// <param name="dbId">the dbid of the object to retrieve</param>
        /// <param name="objectType">the object's type</param>
        /// <param name="isBriefInfo">flag for objects' brief info request</param>
        /// <returns>the retrieved object</returns>
        ICfgObject RetrieveObject(int dbId, CfgObjectType objectType, bool isBriefInfo);

        /// <summary>
        /// Retrieves a list of typed objects based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of objects to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <returns>a list of retrieved objects</returns>
        ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query) where T : ICfgObject;

        /// <summary>
        /// Retrieves a list of typed Configuration Server objects based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of objects to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        /// <returns>a list of retrieved objects</returns>
        ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query, long timeout) where T : ICfgObject;

        /// <summary>
        /// Retrieves a list of typed Configuration Server objects based on the specified query
        /// </summary>
        /// <typeparam name="T">The type of objects to retrieve</typeparam>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
        /// <param name="dataCallback">the callback to notify receiving of each portion of data from server (can be null).</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        /// <returns>a list of retrieved objects</returns>
        ICollection<T> RetrieveMultipleObjects<T>(ICfgQuery query,
            AsyncCallback finishCallback, AsyncCallback dataCallback, long timeout) where T : ICfgObject;

        /// <summary>
        /// Begins to asynchronously retrieve a list of objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="callback">the callback to notify when retrieve operation is complete</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback callback, Object state);
        /// <summary>
        /// Begins to asynchronously retrieve a list of objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="callback">the callback to notify when retrieve operation is complete</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="isBriefInfo">flag for objects' brief info request</param>
        IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback callback, Object state, bool isBriefInfo);

        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="callback">the callback to notify when retrieve operation is complete</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback callback, Object state, long timeout);
        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="callback">the callback to notify when retrieve operation is complete</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        /// <param name="isBriefInfo">flag for objects' brief info request</param>
        IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback callback, Object state, long timeout, bool isBriefInfo);

        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
        /// <param name="dataCallback">the callback to notify receiving of each portion of data from server (can be null).</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback finishCallback, AsyncCallback dataCallback, Object state, long timeout);
        /// <summary>
        /// Begins to asynchronously retrieve a list of Configuration Server objects based on the specified query.
        /// EndRetrieveMultipleObjects should then be called, either upon callback for asynchronous notification,
        /// or immediately, which will block the calling thread until results are available.
        /// </summary>
        /// <param name="query">the query by which to retrieve the objects</param>
        /// <param name="finishCallback">the callback to notify when retrieve operation is complete</param>
        /// <param name="dataCallback">the callback to notify receiving of each portion of data from server (can be null).</param>
        /// <param name="state">a user-defined object that qualifies or contains information about an asynchronous operation.</param>
        /// <param name="timeout">timeout in milliseconds which will be used for waiting messages from server 
        /// (excluding parsing time of messages)</param>
        /// <param name="isBriefInfo">flag for objects' brief info request</param>
        IAsyncResult BeginRetrieveMultipleObjects(ICfgQuery query, AsyncCallback finishCallback, AsyncCallback dataCallback, Object state, long timeout, bool isBriefInfo);

        /// <summary>
        /// Called to retrieve the result of asynchronous RetrieveMultipleObjects operation.  Should be called on 
        /// execution of AsyncCallback passed to BeginRetrieveMultipleObjects. Will block
        /// calling thread until results are received if called before operation is completed. 
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
        /// <returns>A list of retrieved objects</returns>
        /// 
        ICollection<T> EndRetrieveMultipleObjects<T>(IAsyncResult asyncResult) where T : ICfgObject;

        /// <summary>
        /// Asynchronously gets currently received and parsed array of objects, which are getting by
        /// BeginRetrieveMultipleObjects method.
        /// </summary>
        /// <typeparam name="T">The type of object to retrieve</typeparam>
        /// <param name="result">The IAsyncResult object used to track the current request</param>
        /// <returns>A list of retrieved objects</returns>
        IEnumerable<T> PartialGet<T>(IAsyncResult result);

        /// <summary>
        /// Creates a single COM configuration object using the passed parameters
        /// </summary>
        /// <param name="confObject">XML describing a single configuration object as received from Configuration Server.</param>
        /// <param name="isSaved">Specifies whether the object has been previously saved in the configuration database</param>
        /// <returns>the newly created object</returns>
        ICfgObject CreateObjectFromXml(XElement confObject, bool isSaved);

        /// <summary>
        /// Creates a single COM configuration object using the passed parameters
        /// </summary>
        /// <param name="confObject">XML describing a single configuration object as received from Configuration Server.</param>
        /// <param name="objectPath">The folder path of the object in Configuration Server </param>
        /// <param name="folderDbid">The DBID of the folder in which the object resides</param>
        /// <param name="isSaved">Specifies whether the object has been previously saved in the configuration database</param>
        /// <returns>the newly created object</returns>
        ICfgObject CreateObjectFromXml(XElement confObject, string objectPath, int folderDbid, bool isSaved);

        /// <summary>
        /// Creates a list of configuration objects based on XML received from Configuration Server
        /// </summary>
        /// <param name="receivedObjects">the XDocument in the format of the Genesyslab.Platform.Configuration.Protocols.ConfServer.Events.EventObjectsRead.ConfObject property</param>
        /// <param name="objectPaths">Array of strings representing a list of paths for the objects in receivedObjects (should be in the same order) </param>
        /// <param name="folderDbids">integer array of folder DBIDs, should be in the same order as the receivedObjects list</param>
        /// <returns>a list of newly created objects</returns>
        ICollection<ICfgObject> CreateMultipleObjectsFromXml(XDocument receivedObjects, Array objectPaths, Array folderDbids);

        /// <summary>
        /// Creates a list of configuration objects based on XML received from Configuration Server
        /// </summary>
        /// <param name="receivedObjects">the XDocument in the format of the Genesyslab.Platform.Configuration.Protocols.ConfServer.Events.EventObjectsRead.ConfObject property</param>
        /// <returns>a list of newly created objects</returns>
        ICollection<ICfgObject> CreateMultipleObjectsFromXml(XDocument receivedObjects);

        /// <summary>
        /// Subscribes to receiving notifications. This method 
        /// allows the user to specify the subscription details using the "NotificationQuery"
        /// object passed as a parameter.
        /// </summary>
        /// <param name="query">the query specifying the subscription details</param>
        Subscription Subscribe(NotificationQuery query);

        /// <summary>
        /// Subscribes to receiving notifications. This method
        /// subscribes to events for the object passed as the parameter.
        /// </summary>
        /// <param name="obj">the object about which we want to receive notifications</param>
        Subscription Subscribe(ICfgObject obj);

        /// <summary>
        /// Unsubscribes from receiving notifications from Configuration Server
        /// </summary>
        /// <param name="subscription"></param>
        void Unsubscribe(Subscription subscription);

    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// The interface to be implemented when defining a policy for the configuration
    /// service.
    /// </summary>
    /// <remarks>
    /// The cache-related properties are only valid when caching is enabled.
    /// </remarks>
    public interface IConfServicePolicy
    {
        /// <summary>
        /// Determines whether the cache should be queried before a retrieve operation
        /// is performed.
        /// </summary>
        /// <param name="query">The query for the retrieve operation</param>
        /// <returns>true if the cache should be queried first, false otherwise.</returns>
        bool QueryCacheOnRetrieve(ICfgQuery query);

        /// <summary>
        /// Determines whether the cache should be queried before a retrieve multiple
        /// operation is performed.
        /// </summary>
        /// <param name="query">The query for the retrieve operation</param>
        /// <returns>true if the cache should be queried first, false otherwise.</returns>
        bool QueryCacheOnRetrieveMultiple(ICfgQuery query);

        /// <summary>
        /// Determines whether the specified object should be cached upon being
        /// retrieved from the configuration server.
        /// </summary>
        /// <param name="obj">The retrieved configuration object</param>
        /// <returns>true if the object should be cached, false otherwise</returns>
        bool CacheOnRetrieve(ICfgObject obj);

        /// <summary>
        /// Determines whether the specified object should be cached upon being
        /// saved in the configuration server.
        /// </summary>
        /// <param name="obj">The configuration object being saved</param>
        /// <returns>true if the object should be cached, false otherwise</returns>
        bool CacheOnSave(ICfgObject obj);

        /// <summary>
        /// Determines whether link resolution should be attempted through the cache
        /// before querying the configuration server (link resolution refers to
        /// the automatic retrieval of configuration objects when certain 
        /// properties are accessed).
        /// </summary>
        /// <param name="objectType">The type of object for which link resolution
        /// is to be attempted</param>
        /// <returns>true if link resolution should be attempted through the cache, 
        /// false if configuration server should be queried</returns>
        bool AttemptLinkResolutionThroughCache(CfgObjectType objectType);

        /// <summary>
        /// Determines whether an existing cached object should be overwritten 
        /// if a newer copy is retrieved from configuration server. 
        /// </summary>
        /// <param name="newObj">the new version of a cached object</param>
        /// <returns>true if the object should be overwritten in the cache, false otherwise</returns>
        bool OverwriteCachedVersionOnRetrieve(ICfgObject newObj);

        /// <summary>
        /// Determines whether the properties of an object should be validated
        /// for correctness before a save operation is attempted.
        /// </summary>
        bool ValidateBeforeSave
        {
            get;
            set;
        }
    }
}

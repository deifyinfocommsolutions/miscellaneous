//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal class MiscConstants
    {
        private MiscConstants()
        {
        }

        internal const string DbidPropertyName = "DBID";
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        internal const string CfgObjectsNamespace = "Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects";
        internal const string SubscriptionKey = "subscription";
        internal const string ToStringIndent = "    ";
        internal const string FolderDbidName = "folder_dbid";
        internal const string ReadFolderInfoFilterName = "read_folder_dbid";
        internal const string ReadObjectPathFilterName = "object_path";
        internal const string FilterDbidName = "dbid";
    }
    /// <summary>
    /// This enumeration summarizes standard DBID in Configuration Server
    /// </summary>
    public class WellKnownDbids
    {
        /// <summary>
        /// Environment tenant
        /// </summary>
        public const int EnvironmentDbid = 1;

        /// <summary>
        /// Everyone account
        /// </summary>
        public const int EveryoneDbid = 97;

        /// <summary>
        /// System account
        /// </summary>
        public const int SystemDbid = 98;

        /// <summary>
        ///  Conf server app template
        /// </summary>
        public const int ConfServerAppPrototypeDbid = 99;
        /// <summary>
        /// Primary conf server
        /// </summary>
        public const int ConfServerDbid = 99;
        /// <summary>
        /// Default user
        /// </summary>
        public const int EnvironmentSupervisorDbid = 100;

        /// <summary>
        /// Config manager application template
        /// </summary>
        public const int ConfManagerAppPrototypeDbid = 100;

        /// <summary>
        /// DBID of config manager app
        /// </summary>
        public const int ConfManagerDbid = 100;

        /// <summary>
        /// Tenant in single tenant environment
        /// </summary>
        public const int EnterpriseModeTenantDbid = 101;

        /// <summary>
        /// Configuration root folder.
        /// </summary>
        public const int ConfigurationRootFolderDBID = 119;
    }
}

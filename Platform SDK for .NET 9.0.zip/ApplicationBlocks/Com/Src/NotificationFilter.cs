//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.ApplicationBlocks.Commons;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// This class is used to retrieve events from the Configuration Server. 
    /// </summary>
    public class NotificationFilter : IPredicate<ConfEvent>
    {
        private NotificationQuery query;

        /// <summary>
        /// Creates a new instance of the NotificationFilter
        /// </summary>
        /// <param name="query">the query which this filter is baed on</param>
        public NotificationFilter(NotificationQuery query)
        {
            this.query = query;
        }

        #region IPredicate<ConfigurationEvent> Members
        /// <summary>
        /// Used to evaluate whether the specified event passes this filter.
        /// </summary>
        /// <param name="obj">the event to evaluate</param>
        /// <returns>true if the event passes the filter, false otherwise</returns>
        public bool Invoke(ConfEvent obj)
        {
            if (obj == null) return false;

            // this is a case when no filter is specified. In this case, all objects are fine
            if (query.ObjectType == CfgObjectType.CFGNoObject && query.ObjectDbid == -1 && query.TenantDbid == -1)
            {
                return true;
            }

            if ((query.ObjectType != CfgObjectType.CFGNoObject) && (query.ObjectType != obj.ObjectType))
            {
                return false;
            }

            if (query.ObjectDbid != -1 && query.ObjectDbid != obj.ObjectId)
            {
                return false;
            }

            // with tenant dbids we don't know what the tenantdbid of the object is 
            // and we just pass all events. TODO! Describe it in the documentation

            return true;
        }
        #endregion
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Genesyslab.Platform.ApplicationBlocks.Commons;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal class BaseNotificationQuery
    {
        private Hashtable filter;

        internal BaseNotificationQuery()
        {
            filter = new Hashtable();
        }

        internal object this[string name]
        {
            set
            {
                filter[name] = value;
            }

            get
            {
                if (!filter.ContainsKey(name))
                    return null;

                return filter[name];
            }
        }


        internal Hashtable Filter
        {
            get
            {
                return filter;
            }
        }
    }

    /// <summary>
    /// This class is used to subscribe to notifications from the Configuration Server. 
    /// </summary>
    public class NotificationQuery
    {
        private const string objectDbid = "object_dbid";
        private const string tenantDbid = "tenant_id";
        private const string objectType = "object_type";

        private BaseNotificationQuery baseQuery;

        /// <summary>
        /// Creates a new instance of the object
        /// </summary>
        public NotificationQuery()
        {
            baseQuery = new BaseNotificationQuery();
        }

        /// <summary>
        /// This property is used if the client wants to follow changes in a specific object
        /// </summary>
        public int ObjectDbid
        {
            set
            {
                baseQuery[NotificationQuery.objectDbid] = value;
            }
            get
            {
                object myValue = baseQuery[NotificationQuery.objectDbid];

                if (myValue == null)
                    return -1;

                return (int)myValue;
            }
        }

        /// <summary>
        /// This property is used if the client wants to subscribe to all events happening at the specific
        /// Tenant
        /// </summary>
        public int TenantDbid
        {
            set
            {
                baseQuery[NotificationQuery.tenantDbid] = value;
            }
            get
            {
                object myValue = baseQuery[NotificationQuery.tenantDbid];

                if (myValue == null)
                    return -1;

                return (int)myValue;
            }
        }

        /// <summary>
        /// This property is used if the client wants to subscribe to all events happening with all objects
        /// of a the specific type
        /// </summary>
        public CfgObjectType ObjectType
        {
            set
            {
                baseQuery[NotificationQuery.objectType] = (int)value;
            }
            get
            {
                object myValue = baseQuery[NotificationQuery.objectType];

                if (myValue == null)
                    return CfgObjectType.CFGNoObject;

                return (CfgObjectType)myValue;
            }
        }


        internal Hashtable Filter
        {
            get
            {
                return baseQuery.Filter;
            }
        }
    }
}

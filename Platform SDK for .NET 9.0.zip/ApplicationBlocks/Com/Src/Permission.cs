//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    /// <summary>
    /// This class represents access permissions of an associated Configuration Server object. 
    /// </summary>
    public class PermissionDescriptor
    {
        private int objectDbid;
        private int objectType;
        private int accessMask;

        internal PermissionDescriptor(int objectDbid, int objectType, int accessMask)
        {
            this.objectDbid = objectDbid;
            this.objectType = objectType;
            this.accessMask = accessMask;
        }

        /// <summary>
        /// Retrieves an instance of the object specified by the dbid and object type
        /// properties of this object
        /// </summary>
        /// <param name="service">The configuration service to use to retrieve the data</param>
        /// <returns>An object retrieved from Configuration Server</returns>
        public ICfgObject RetrieveObject(IConfService service)
        {
            if (service == null) return null;

            return service.RetrieveObject(objectDbid, (CfgObjectType)objectType);
        }

        /// <summary>
        /// The access mask applicable to the specified object.
        /// </summary>
        public int AccessMask
        {
            get
            {
                return accessMask;
            }
        }

        /// <summary>
        /// The dbid of the specified object.
        /// </summary>
        public int ObjectDbid
        {
            get
            {
                return objectDbid;
            }
        }

        /// <summary>
        /// The object type of the specified object
        /// </summary>
        public CfgObjectType ObjectType
        {
            get
            {
                return (CfgObjectType)objectType;
            }
        }

        /// <summary>
        /// Returns a string representing the Configuration Server permissions of the specified
        /// object.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder output = new StringBuilder();
            output.AppendFormat("Permission : Access Mask = ({0}), Object Type = ({1}), Object Id = ({2})", AccessMask, ObjectType, ObjectDbid);

            return output.ToString();
        }
    }
}

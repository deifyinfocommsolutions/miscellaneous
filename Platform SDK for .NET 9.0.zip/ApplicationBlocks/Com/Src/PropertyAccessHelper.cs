//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Collections;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Configuration.Protocols.Utilities.Extensions;
using Genesyslab.Platform.Configuration.Protocols.Types;
using System.Xml.Linq;
using System.Linq;
using Genesyslab.Platform.Configuration.Protocols.Metadata;
using Genesyslab.Utils;


namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    static class PropertyAccessHelper
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        internal static object GetSimpleProperty(CfgDescriptionAttribute info,
                                                 XElement xmlData)
        {
            XElement rootNode = GetSubNode(xmlData, info.XName);

            if (rootNode == null || rootNode.Attribute("value") == null)
                return null;

            string myValue = rootNode.Attribute("value").Value;


            if (info.IsCfgType(CfgTypeMask.Time))
            {
                if (myValue == null || myValue.Equals(String.Empty))
                    return null;
                int timeValue = int.Parse(myValue);
                return Utils.UnixTimeToWindowsTime(timeValue);
            }
            else if (info.IsCfgType(CfgTypeMask.Integer | CfgTypeMask.Enum))
            {
                if (myValue == null || myValue.Equals(String.Empty))
                    return null;
                return int.Parse(myValue);
            }
            else if (info.IsCfgType(CfgTypeMask.String))
                return myValue;
            else
                throw new InvalidOperationException("GetSimpleProperty: Unsupported object type!");
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.ToString"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static void SetSimpleProperty(CfgDescriptionAttribute info, XElement xmlData, object propertyValue)
        {
            XElement myNode = GetSubNode(xmlData, info.XName);

            if (myNode == null)
            {
                // create the node
                XElement newNode = new XElement(info.XName);
                newNode.Add(new XAttribute(XmlAccessConstants.valueXmlName, ""));
                xmlData.Add(newNode);
                myNode = newNode;
            }

            if (info.IsCfgType(CfgTypeMask.Time))
            {
                if (!(propertyValue is DateTime))
                    throw new ArgumentException("The new value is not an DateTime type");

                DateTime winTime = (DateTime)propertyValue;
                int unixTime = Utils.WindowsTimeToUnixTime(winTime);
                myNode.Attribute("value").Value = unixTime.ToString();
            }
            else if (info.IsCfgType(CfgTypeMask.Integer) || info.IsCfgType(CfgTypeMask.Enum))
            {
                if (!(propertyValue is int) && !(propertyValue is Enum))
                    throw new ArgumentException("The new value is not an int type");

                myNode.Attribute("value").Value = ((int)propertyValue).ToString();
            }
            else if (info.IsCfgType(CfgTypeMask.String))
                myNode.Attribute("value").Value = propertyValue.ToString();
            else
                throw new InvalidOperationException("SetSimpleProperty: Unsupported object type!");
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static void SetKVListProperty(CfgDescriptionAttribute info, XElement xmlData, object propertyValue)
        {
            XElement myNode = GetSubNode(xmlData, info.XName);

            if (!(propertyValue is KeyValueCollection))
                throw new ArgumentException("The new value is not a KeyValueCollection");

            KeyValueCollection newValue = (KeyValueCollection)propertyValue;

            //No need to add an empty node if there are no values being assigned
            if ((newValue == null || newValue.Count == 0) && myNode == null)
                return;

            if (myNode == null)
            {
                // create the node
                myNode = new XElement(info.XName);
                xmlData.Add(myNode);
            }

            myNode.RemoveAll();

            BuildXmlFromKVList(xmlData, newValue, myNode);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        private static void BuildXmlFromKVList(XElement xmlData, KeyValueCollection newValue, XElement myNode)
        {
            if (newValue == null || myNode == null)
                return;

            foreach (DictionaryEntry de in newValue)
            {
                string xac = XmlAccessConstants.strOptionXmlName;
                if (de.Value is int)
                    xac = XmlAccessConstants.intOptionXmlName;
                else if (de.Value is KeyValueCollection)
                    xac = XmlAccessConstants.sectionXmlName;
                else if (de.Value is byte[])
                    xac = XmlAccessConstants.binOptionXmlName;
                XElement newOptionNode = new XElement(XName.Get(xac, xmlData.Name.NamespaceName));
                newOptionNode.Add(new XAttribute(XmlAccessConstants.kvListKeyName, de.Key));
                if (de.Value is KeyValueCollection)
                    BuildXmlFromKVList(xmlData, (KeyValueCollection)de.Value, newOptionNode);
                else
                {
                    string sVal = "";
                  if (de.Value is byte[])
                        sVal = StringConvertUtils.ToHexString(de.Value as byte[]);
                        //sVal = new SoapHexBinary(de.Value as byte[]).ToString();
                    else
                        sVal = de.Value.ToString();
                    newOptionNode.Add(new XAttribute(XmlAccessConstants.valueXmlName, sVal));
                }
                myNode.Add(newOptionNode);
            }
        }

        internal static void SetStructureProperty(object propertyValue, XElement xmlData)
        {
            CfgBase newObject = (CfgBase)propertyValue;

            // write to the xml data
            XElement newStructureNode = newObject.XmlData;

            XElement oldStructureNode = GetSubNode(xmlData, newStructureNode.Name);

            if (oldStructureNode == null)
                xmlData.Add(newStructureNode);
            else
                oldStructureNode.ReplaceWith(newStructureNode);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static void SetStructureCollectionProperty(object propertyValue, CfgDescriptionAttribute info, XElement xmlData)
        {
            if (!(propertyValue is ICollection))
                throw new ArgumentException("The new value is not the right type. It should be ICollection");

            ICollection structures = (ICollection)propertyValue;

            XElement myNode = GetSubNode(xmlData, info.XName);

            //No need to add an empty node if there are no values being assigned
            if ((structures == null || structures.Count == 0) && myNode == null)
                return;

            if (myNode == null)
            {
                // create the node
                myNode = new XElement(info.XName);
                xmlData.Add(myNode);
            }
            else
                myNode.RemoveAll();

            foreach (object elem in structures)
            {
                if (!(elem is CfgBase))
                    throw new ArgumentException("The new value is not the right type. It should be IConfigurationData");

                CfgBase newObject = (CfgBase)elem;
                if (!newObject.IsStructure)
                    throw new ArgumentException("The new value is not the right type. It should be a structure.");

                myNode.Add(newObject.XmlData);
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.ToString"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static void SetLinkProperty(object propertyValue, CfgDescriptionAttribute info, XElement xmlData)
        {
            int id = 0;

            if (propertyValue is int)
            {
                id = (int)propertyValue;
            }
            else if (propertyValue is CfgObject)
            {
                CfgObject newObject = (CfgObject)propertyValue;

                if (newObject.IsSaved == false)
                    throw new ArgumentException("Cannot assign a link because the object has not been saved yet.");

                id = newObject.ObjectDbid;
                if (id == 0)
                    throw new ArgumentException("Cannot assign a link - no positive dbid (object has not been saved)");
            }
            else
            {
                throw new ArgumentException("The new value is not the right type. It should be ICfgObject or int. We have: "
                            + propertyValue.GetType().ToString());
            }

            XElement myNode = GetSubNode(xmlData, info.XName);

            if (myNode == null)
            {
                // create the node
                myNode = new XElement(info.XName);
                xmlData.Add(myNode);
            }

            XAttribute attr = myNode.Attribute(XmlAccessConstants.valueXmlName);
            if (attr != null)
                attr.Value = id.ToString();
            else
            {
                attr = new XAttribute(XmlAccessConstants.valueXmlName, id.ToString());
                myNode.Add(attr);
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.ToString"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static void SetLinkColProperty(object propertyValue, CfgDescriptionAttribute info, XElement xmlData)
        {
            if (!(propertyValue is ICollection))
                throw new ArgumentException("The new value is not the right type. It should be ICollection");

            ICollection links = (ICollection)propertyValue;

            XElement myNode = GetSubNode(xmlData, info.XName);

            if (myNode == null)
            {
                // create the node
                myNode = new XElement(info.XName);
                xmlData.Add(myNode);
            }
            myNode.RemoveAll();

            foreach (object elem in links)
            {
                int id = 0;

                if (elem is int)
                    id = (int)elem;
                else if (elem is CfgObject)
                {
                    CfgObject newObject = (CfgObject)elem;

                    if (!newObject.IsSaved)
                        throw new ArgumentException("Cannot assign a link because the object has not been saved yet.");

                    id = newObject.ObjectDbid;
                    if (id == 0)
                        throw new ArgumentException("Cannot assign a link - no positive dbid (object has not been saved)");
                }
                else
                    throw new ArgumentException("The new value is not the right type. It should be ICfgObject or int");

                // create the node
                XElement newNode = new XElement(XName.Get("DBID", xmlData.Name.NamespaceName));
                XAttribute valueAttr = new XAttribute(XmlAccessConstants.valueXmlName, id.ToString());
                newNode.Add(valueAttr);
                myNode.Add(newNode);
            }
        }

        public static ICfgObject CreateLinkObject(CfgDescriptionAttribute info,
            IConfService confService, XElement xmlData)
        {

            if (!info.IsCfgType(CfgTypeMask.Link) || info.IsCfgType(CfgTypeMask.List))
                throw new ArgumentException("The property " + info.Name + " is not a link type.");

            XElement rootNode = GetSubNode(xmlData, info.SchemaName.GetXName());
            if (rootNode == null || rootNode.Attributes("value") == null)
                return null;

            string myValue = rootNode.Attribute("value").Value;
            if (myValue == null || myValue.Equals(string.Empty) || myValue == "0")
            {
                return null;
            }

            // here we can change it into linked objects broker
            CfgDescriptionObject linkClass = null;
            var refLink = info as CfgDescriptionAttributeReferenceLink;
            if (refLink != null)
              linkClass = refLink.Class as CfgDescriptionObject;

            if (linkClass == null)
                throw new InvalidOperationException("The link description is invalid in metadata for class " + info.Name);

            // here we can change it into linked objects broker
            CfgObjectType objectType = linkClass.CfgEnum;

            return ResolveLink(confService, objectType, int.Parse(myValue));
        }

        private static ILogger AskLogger(IConfService confService)
        {
            ILogger logger = null;
            if (confService is ILogger)
                logger = ((ILogger)confService).CreateChildLogger("PropertyAccessHelper");
            else
                logger = new NullLogger();
            return logger;
        }

        internal static ICfgObject ResolveLink(IConfService confService, CfgObjectType objectType, int dbid)
        {
            ICfgObject obj = null;
            ILogger logger = AskLogger(confService);
            if (confService.Policy.AttemptLinkResolutionThroughCache(objectType))
            {
                logger.DebugFormat("Resolving link through cache... [{0}], dbid: [{1}]", objectType, dbid);
                obj = confService.Cache.Retrieve<ICfgObject>(objectType, dbid);
            }

            if (obj == null)
            {
                logger.DebugFormat("Resolving link through configuration server... "
                                + "[{0}], dbid: [{1}]", objectType, dbid);
                try
                {
                    obj = confService.RetrieveObject(dbid, objectType);
                }
                catch (ConfigException ex)
                {
                    logger.Error("Exception on linked object retrieve", ex);
                    throw;
                }
            }
            return obj;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal static int? GetLinkValue(string propertyName, CfgDescriptionClass dataClass, XElement xmlData)
        {
            CfgDescriptionAttribute info = dataClass.GetAttribute(propertyName);

            if (info == null)
                return null;

            if (!info.IsCfgType(CfgTypeMask.Link) || info.IsCfgType(CfgTypeMask.List))
                throw new ArgumentException("The property " + propertyName + " is not a pure link type.");

            XElement rootNode = GetSubNode(xmlData, info.XName);

            if (rootNode == null || rootNode.Attributes("value") == null)
                return null;

            if (rootNode.Attribute("value") != null)
            {
                string myValue = rootNode.Attribute("value").Value;
                return int.Parse(myValue);
            }
            return null;
        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal static int? GetLinkValue(string propertyName, XElement xmlData, CfgDelta delta)
        {
          CfgDescriptionAttribute info = delta.GetAttributeInfo(propertyName);

          if (info == null)
            return null;

          if (!info.IsCfgType(CfgTypeMask.Link) || info.IsCfgType(CfgTypeMask.List))
            throw new ArgumentException("The property " + propertyName + " is not a pure link type.");

          XElement rootNode = GetSubNode(xmlData, info.XName);

          if (rootNode == null || rootNode.Attributes("value") == null)
            return null;

          if (rootNode.Attribute("value") != null)
          {
            string myValue = rootNode.Attribute("value").Value;
            return int.Parse(myValue);
          }
          return null;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static IList CreateLinksList(string attributeName,
                                       CfgDescriptionClass dataClass,
                                       IConfService confService,
                                       XElement xmlData)
        {
            CfgDescriptionAttributeReference info =
                GetAttributeInfo(dataClass, attributeName) as CfgDescriptionAttributeReference;

            if (info == null)
                throw new ArgumentException("There is no property " + attributeName + " in this class.");

            if (!info.IsCfgType(CfgTypeMask.Link) || !info.IsCfgType(CfgTypeMask.List))
                throw new ArgumentException("The property " + attributeName + " is not a link list type.");

            string typeName = "";
            if (info.Class.IsCfgType(CfgTypeMask.Structure))
            {
                CfgDescriptionStructure str = info.Class as CfgDescriptionStructure;
                if (str!=null) typeName = str.AliasName;
            }
            else if (info.Class.IsCfgType(CfgTypeMask.Class))
            {
                CfgDescriptionClass cl = info.Class as CfgDescriptionClass;
                if (cl!=null) typeName = cl.Name;
            }
            Type linkClassType = Type.GetType(MiscConstants.CfgObjectsNamespace + "." + typeName);

            Type listType = typeof(List<>).MakeGenericType(linkClassType);
            IList links = (IList)Activator.CreateInstance(listType);

            XElement rootNode = GetSubNode(xmlData, info.XName);

            if (rootNode == null)
                return links;

            CfgObjectType objectType = ((CfgDescriptionObject)info.Class).CfgEnum;

            XAttribute attr;

            foreach (XElement element in rootNode.Elements())
            {
                attr = element.Attribute("value");
                if (attr == null)
                    continue;

                try
                {
                    object newObject = ResolveLink(confService, objectType, int.Parse(attr.Value));
                    if (newObject != null)
                        links.Add(newObject);
                }
                catch (ConfigException e)
                {
                    AskLogger(confService).Error("Exception getting linked object", e);
                    throw;
                }
            }
            return links;
        }

        internal static ICollection<int> GetLinkListCollection(string propertyName,
            CfgDescriptionClass dataClass, XElement xmlData)
        {
            CfgDescriptionAttributeReferenceLink info = GetAttributeInfo(dataClass, propertyName) as
                CfgDescriptionAttributeReferenceLink;
            if (info == null)
                return null;
            if (!info.IsCfgType(CfgTypeMask.List) || !info.IsCfgType(CfgTypeMask.Link))
                throw new ArgumentException("The property " + propertyName + " is not a link list type.");

            XElement rootNode = GetSubNode(xmlData, info.XName);
            if (rootNode == null)
                return null;
            if (rootNode.Elements().Count() == 0)
                return null;

            List<int> lst = new List<int>();
            foreach (XElement element in rootNode.Elements())
            {
                XAttribute attr = element.Attribute("value");
                if (attr != null)
                    lst.Add(int.Parse(attr.Value));
            }
            return lst;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal static int[] GetLinkListValue(string propertyName,
                                               CfgDescriptionClass dataClass, XElement xmlData)
        {
            ICollection<int> collection = GetLinkListCollection(propertyName, dataClass, xmlData);
            if (collection != null)
                return collection.ToArray();
            return null;
        }

        //TODO: Re-write CreateDeltaStrutureList

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static IList CreateDeltaStructureList(string propertyName,
                                            object classRef,
                                            CfgDescriptionClass dataClass,
                                            IConfService confService,
                                            XElement xmlData)
        {
            var info = dataClass[propertyName] as ICfgAttributeOperationalInfo;
            if (info == null)
                throw new ArgumentException("There is no property " + propertyName + " in this class.");

            var infoRef = info as CfgDescriptionAttributeReference;
            if (infoRef==null)
              throw new ArgumentException("There is an invalid property '" + propertyName + "' in this class.");

            var attrClass = info.SubjectAttributeDescription as CfgDescriptionAttributeReferenceClassList;
            if (attrClass == null)
                throw new ArgumentException("Invalid class information provided");

            var descStructure = attrClass.Class as CfgDescriptionStructure;
            if (descStructure == null)
                throw new ArgumentException("Provided metadata does not contain valid information");

            Type structureClassType = CfgObjectActivator.GetType(attrClass.Class.Name);
            Type listType = typeof(List<>).MakeGenericType(structureClassType);
            IList structures = null;
            XElement rootNode = GetSubNode(xmlData, infoRef.XName);
            if (rootNode == null)
                return structures;

            CfgDescriptionAttribute key;
            //if (descStructure.AliasName == null || descStructure.Keys == null ||
            //    (key = descStructure.Keys.FirstOrDefault()) == null)
            //    return structures;
            if (descStructure.Keys == null || (key = descStructure.Keys.FirstOrDefault()) == null)
              return structures;

            string descStructName = descStructure.AliasName;
            if (descStructName == null) descStructName = descStructure.Name;
            structures = (IList)Activator.CreateInstance(listType);

            foreach (XElement element in rootNode.Elements())
            {
                //XElement root = new XElement(descStructure.AliasName.GetXName());
                XElement root = new XElement(descStructName.GetXName());
                XElement property = new XElement(key.XName);
                XAttribute attr = element.Attribute("value");
                if (attr != null)
                    property.Add(new XAttribute("value", attr.Value));
                root.Add(property);
                object newStructure = CfgObjectActivator.CreateInstance(
                        infoRef.Class.Name, confService, root, new object[] { classRef });
                structures.Add(newStructure);
            }
            return structures;
        }


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static IList CreateStructureList(string propertyName,
                                                    object classRef,
                                                    CfgDescriptionClass dataClass,
                                                    IConfService confService,
                                                    XElement xmlData)
        {
            CfgDescriptionAttributeReference info =
                dataClass.GetAttribute(propertyName) as CfgDescriptionAttributeReference;

            if (info == null)
                throw new ArgumentException("There is no property " + propertyName + " in this class.");

            if (!info.IsCfgType(CfgTypeMask.Structure) || !info.IsCfgType(CfgTypeMask.List))
                throw new ArgumentException("The property " + propertyName + " is not a structure list type.");

            try
            {
                Type structureClassType = CfgObjectActivator.GetType(info.Class.Name);

                Type listType = typeof(List<>).MakeGenericType(structureClassType);
                IList structures = (IList)Activator.CreateInstance(listType);

                XElement rootNode = GetSubNode(xmlData, info.XName);
                if (rootNode == null)
                {
                  if (dataClass.IsCfgType(CfgTypeMask.Delta) || (classRef is CfgDelta)) return null;
                  return structures;
                }

              foreach (XElement element in rootNode.Elements())
                {
                    object newStructure = CfgObjectActivator.CreateInstance(
                        info.Class.Name, confService, element, new object[] { classRef });
                    structures.Add(newStructure);
                }
                return structures;
            }
            catch (Exception ex)
            {
                AskLogger(confService).Error("Exception occurred in CreateStructureList()", ex);
                throw;
            }
        }

        /// <summary>
        /// This method creates a class, based on XML property
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="classRef"></param>
        /// <param name="dataClass"></param>
        /// <param name="confService"></param>
        /// <param name="xmlData"></param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static object CreateStructureClass(string propertyName,
                                            object classRef,
                                            CfgDescriptionClass dataClass,
                                                    IConfService confService,
                                                    XElement xmlData)
        {
            CfgDescriptionAttributeReferenceClass info =
                dataClass.GetAttribute(propertyName) as CfgDescriptionAttributeReferenceClass;

            if (info == null)
                throw new ArgumentException("There is no property " + propertyName + " in this class.");

            if (!info.IsCfgType(CfgTypeMask.Structure) || info.IsCfgType(CfgTypeMask.List))
                throw new ArgumentException("The property " + info.Name + " is not a pure structure type.");

            XElement rootNode = GetSubNode(xmlData, info.XName);
            if (rootNode == null)
                return null;

            try
            {
                return CfgObjectActivator.CreateInstance(
                    info.Class.Name, confService, rootNode, new object[] { classRef });
            }
            catch (Exception ex)
            {
                AskLogger(confService).Error("Exception occurred in CreateStructureClass()", ex);
                throw;
            }
        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static KeyValueCollection CreateKVList(string propertyName,
                                   CfgDescriptionClass dataClass,
                                   XElement xmlData)
        {
          return CreateKVList(propertyName, null, dataClass, xmlData);
        }

      [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static KeyValueCollection CreateKVList(string propertyName,
                                   object classRef,
                                   CfgDescriptionClass dataClass,
                                   XElement xmlData)
        {
            CfgDescriptionAttribute info =
                dataClass.GetAttribute(propertyName) as CfgDescriptionAttribute;

            if (info == null)
                throw new ArgumentException("There is no property " + propertyName + " in this class.");

            if (!info.IsCfgType(CfgTypeMask.KvList))
                throw new ArgumentException("The property " + propertyName + " is not a kv-list type.");

            XElement rootNode = GetSubNode(xmlData, info.XName);
            if (rootNode == null)
            {
              if (dataClass.IsCfgType(CfgTypeMask.Delta) || (classRef is ICfgDelta)) return null;
              return new KeyValueCollection();
            }

        IEnumerable<XElement> sections =
                from s in rootNode.Elements()
                where s.Name.LocalName == XmlAccessConstants.sectionXmlName
                select s;

            return BuildKVList(sections);
        }

        internal static KeyValueCollection BuildKVList(IEnumerable<XElement> sectionsList)
        {
            KeyValueCollection sections = new KeyValueCollection();

            // for each section
            if (sectionsList == null)
                return sections;

            foreach (XElement xmlSection in sectionsList)
            {
                if (!xmlSection.HasAttributes || xmlSection.Name == null)
                    continue;
                XAttribute xmlOptsKey = xmlSection.Attribute(XmlAccessConstants.kvListKeyName);
                if (xmlOptsKey == null)
                    continue;

                string strKey = xmlOptsKey.Value;
                if (strKey == null)
                    continue;

                object objValue = null;
                if (xmlSection.Name.LocalName.Equals(XmlAccessConstants.sectionXmlName))
                    objValue = BuildKVList(xmlSection.Elements());
                else
                {
                    XAttribute xmlValue = xmlSection.Attribute("value");
                    if (xmlSection.Name.LocalName.Equals(XmlAccessConstants.strOptionXmlName))
                    {
                        objValue = (xmlValue != null) ? xmlValue.Value : "";
                    }
                    else if (xmlSection.Name.LocalName.Equals(XmlAccessConstants.intOptionXmlName))
                    {
                        if (xmlValue != null && xmlValue.Value != null)
                            objValue = int.Parse(xmlValue.Value);
                    }
                    else if (xmlSection.Name.LocalName.Equals(XmlAccessConstants.binOptionXmlName))
                    {
                        if (xmlValue != null && xmlValue.Value != null)
                            objValue = StringConvertUtils.FromHexString(xmlValue.Value);
                            //objValue = SoapHexBinary.Parse(xmlValue.Value).Value;
                    }
                }
                if (objValue != null)
                    sections.Add(strKey, objValue);
            }
            return sections;
        }

        private static bool IsDelta(XElement node)
        {
            return node.Name.LocalName.Contains("Delta");
        }

        private static CfgDescriptionAttribute GetAttributeInfo(
            CfgDescriptionClass dataClass, string propertyName)
        {
            CfgDescriptionAttribute info = dataClass.GetAttribute(propertyName);

            if (info == null && dataClass is ICfgClassOperationalInfo)
            {
                ICfgClassOperationalInfo delta = (ICfgClassOperationalInfo)dataClass;
                info = delta.SubjectClassDescription.GetAttribute(propertyName);
            }
            return info;
        }

        private static XElement GetSubNode(XElement node, XName name)
        {
            if (node == null || name == null)
                return null;

      //IEnumerable<XElement> query =
      //from s in node.Elements()
      //where s.Name == name
      //select s;

      //XElement res = query.FirstOrDefault();

            XElement res = node.Element(String.IsNullOrEmpty(node.Name.NamespaceName) 
                ? XName.Get(name.LocalName, "") 
                : name);

            if (res == null && IsDelta(node))
            {
                XElement tempNode = node.Element(
                    XName.Get(node.Name.LocalName.Remove(
                        node.Name.LocalName.IndexOf(
                            "Delta", StringComparison.CurrentCultureIgnoreCase), 5),
                               node.Name.NamespaceName));

                res = GetSubNode(tempNode, name);
            }
            return res;
        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        public static object CreateLinksListBroker(
            IConfService confService,
            CfgBase obj,
            CfgBase parent,
            CfgDescriptionClass metadata,
            CfgDescriptionAttribute info)
        {
          if (info == null)
          {
            throw new ArgumentNullException("There is no property information specified ('info' parameter).");
          }

          if (!info.IsCfgType(CfgTypeMask.Link)
              || !info.IsCfgType(CfgTypeMask.List))
          {
            throw new ArgumentException(
              "The property '" + info.SchemaName + "' is not a link list type.");
          }

          if (GetSubNode(obj.XmlData, info.XName) == null)
          {
            if (metadata.IsCfgType(CfgTypeMask.Delta)
                || (parent != null && parent.MetaData.IsCfgType(CfgTypeMask.Delta))
                || (obj is ICfgDelta))
            {
              return null;
            }
          }
          CfgDescriptionAttributeReferenceLink attrLinkList = info as CfgDescriptionAttributeReferenceLink;
          if (attrLinkList == null) return null;
          Type linkClassType = CfgObjectActivator.GetType(attrLinkList.Class.Name);
          Type cfgBrokerType = typeof (CfgLinksBroker<>).MakeGenericType(linkClassType);
          object broker = Activator.CreateInstance(cfgBrokerType, new object[] {obj, info.SchemaName});
          return broker;
        }
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries
{
    using System;
    using System.Collections;
    using Genesyslab.Platform.Configuration.Protocols.ConfServer;
    using Genesyslab.Platform.Configuration.Protocols.Types;
    using System.Text;

    /// <summary>
    /// A general class that can hold arbitrary values of filter keys and values. It contains a collection of 
    /// filter key-value pairs. If you have a need to work with multiple queries for objects, type of which 
    /// is not known in compile-time, use this class. If you know the type of the objects, please, use more 
    /// specific CfgXXXQuery classes.
    /// </summary>
    public class CfgFilterBasedQuery : CfgQuery, ICfgFilterBasedQuery
    {
        private CfgObjectType objectType;
        private readonly Hashtable filter = new Hashtable();
        private readonly Hashtable _extraFilter = new Hashtable();

        /// <summary>
        /// Creates a new instance of the class
        /// </summary>
        /// <param name="objectType">The type of object returned by this query</param>
        /// <param name="confService">An instance of IConfService to be used for query execution</param>
        public CfgFilterBasedQuery(CfgObjectType objectType, IConfService confService)
            : base(confService)
        {
            this.objectType = objectType;
            //this.filter.Add(MiscConstants.ReadFolderInfoFilterName,0);
            //this.filter.Add(MiscConstants.ReadObjectPathFilterName, 0);
            _extraFilter.Add(MiscConstants.ReadFolderInfoFilterName, 0);
            _extraFilter.Add(MiscConstants.ReadObjectPathFilterName, 0);
        }

        /// <summary>
        /// Creates a new instance of the class.
        /// </summary>
        /// <param name="objectType">Object Type</param>
        public CfgFilterBasedQuery(CfgObjectType objectType)
            : this(objectType, null)
        {
        }

        /// <summary>
        /// This property is used to access the filter key-value pair
        /// </summary>
        /// <param name="key">Filter key</param>

        public object this[string key]
        {
            set
            {
                if (value == null)
                {
                    if (filter.ContainsKey(key))
                    {
                        filter.Remove(key);
                    }
                }
                else
                {
                    filter[key] = value;
                }
            }
            get
            {
                if (!filter.ContainsKey(key))
                    return null;

                return filter[key];
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal int GetInt(string name)
        {
            if (!filter.ContainsKey(name))
                return 0;

            if (filter[name] == null)
                return 0;

            if (filter[name] is Enum)
            {                
                return (int) filter[name];
            }
            return Int32.Parse(filter[name].ToString());
        }

        internal string GetString(string name)
        {
            if (!filter.ContainsKey(name))
                return null;

            object val = filter[name];

            return val == null ? null : val.ToString();
        }

        /// <summary>
        /// The type of configuration object returned by this query
        /// </summary>
        CfgObjectType ICfgFilterBasedQuery.QueryObjectType
        {
            get
            {
                return this.objectType;
            }
        }

        /// <summary>
        /// Gets hashtable collection with filter's key-value pairs.
        /// </summary>
        public Hashtable Filter
        {
            get
            {
                return this.filter;
            }
        }

      /// <exclude/>
      public Hashtable ExtraFilter 
      { 
        get
        {
          return _extraFilter;
          /*
          if (DoRequestFolderId || DoRequestObjectPath)
          {
            var eFilter = new Hashtable();
            if (DoRequestFolderId)
              eFilter.Add(MiscConstants.ReadFolderInfoFilterName,0);
            if (DoRequestObjectPath)
              eFilter.Add(MiscConstants.ReadObjectPathFilterName, 0);
            return eFilter;
          }
          return null;
          */
        }
      }



      /// <summary>
      /// Gets/Sets filter option for notification of configuration server about need
      /// of the object path information to be collected and sent with the main objects data
      /// </summary>
      public bool DoRequestObjectPath 
      {
        get { return _extraFilter.Contains(MiscConstants.ReadObjectPathFilterName); }
        set
        {
          if (value)
            _extraFilter[MiscConstants.ReadObjectPathFilterName] = 0;
          else  
            _extraFilter.Remove(MiscConstants.ReadObjectPathFilterName);
        }
      }

      /// <summary>
      /// Gets/Sets filter option for notification of configuration server about need
      /// of the folder DBID information to be sent with the main objects data
      /// </summary>
      public bool DoRequestFolderId 
      {
        get { return _extraFilter.Contains(MiscConstants.ReadFolderInfoFilterName); }
        set
        {
          if (value) 
            _extraFilter[MiscConstants.ReadFolderInfoFilterName]= 0;
          else 
            _extraFilter.Remove(MiscConstants.ReadFolderInfoFilterName);
        }
      }
      /// <exclude/>
      public override string ToString()
      {
        StringBuilder res = new StringBuilder();

        res.AppendFormat("Query object type: {0}", objectType);
        res.AppendLine();
        res.AppendFormat("Query filters:");
        res.AppendLine();

        foreach (DictionaryEntry entry in filter)
        {
          res.AppendFormat("  Key: {0}, Value: {1}", entry.Key, entry.Value).AppendLine();
        }
        foreach (DictionaryEntry entry in _extraFilter)
        {
          res.AppendFormat("  ExtraKey: {0}, Value: {1}", entry.Key, entry.Value).AppendLine();
        }
        return res.ToString();
      }
      /// <exclude/>
      public override bool Equals(object obj)
      {
        if (this == obj) return true;
        if (obj == null) return false;
        if (obj.GetType() != GetType()) return false;
        var query = obj as CfgFilterBasedQuery;
        if (query == null) return false;
        if (objectType != query.objectType) return false;
        if (!CfgBase.CompareDictionary(filter,query.filter)) return false;
        if (!CfgBase.CompareDictionary(_extraFilter, query._extraFilter)) return false;
        return true;
      }

      /// <exclude/>
      public override int GetHashCode()
      {
        var code = GetType().GetHashCode();
        code ^= 13 * objectType.GetHashCode();
        code ^= 17*CfgBase.CalcDictionaryHashCode(filter);
        code ^= 19*CfgBase.CalcDictionaryHashCode(_extraFilter);
        return code;
      }


    }
}

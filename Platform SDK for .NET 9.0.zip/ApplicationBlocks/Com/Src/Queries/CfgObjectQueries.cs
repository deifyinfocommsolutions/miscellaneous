
//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007-2017 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using System.Collections.Generic;
  
namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries
{
  using Genesyslab.Platform.Configuration.Protocols.ConfServer;


  /// <summary>
      ///The query class used to retrieve an object of type CfgTenant
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgTenantQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgTenantQuery class. This query will not be executable.
      /// </summary>
      public CfgTenantQuery() : base(CfgObjectType.CFGTenant)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgTenantQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgTenantQuery(IConfService confService) : base(CfgObjectType.CFGTenant, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgTenant object retrieved as a result of this operation</returns>
      public CfgTenant ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgTenant>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgTenant objects
      ///
      /// </summary>
      /// <returns>A collection of CfgTenant objects</returns>       
      public ICollection<CfgTenant> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgTenant>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgTenant objects</returns>
      public ICollection<CfgTenant> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgTenant>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant. If
	  ///specified, Configuration Server will return information only about
	  ///this tenant.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a tenant. Shall be specified
	  ///as a character string. If specified, Configuration Server will
	  ///return information only about the tenant(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Current state of a tenant (see 
	  ///<c><see cref="CfgObjectState"/></c>).
	  ///If specified, Configuration Server
	  ///will return information only about tenants that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///If specified , Configuration
	  ///Server will return information about all tenants including tenant
	  ///with DBID=1. Otherwise the tenant with DBID=1 (environment) is not considered for search request.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int AllTenants
      {
          set
          {
              this["all_tenants"] = value;
          }
          get
          {
              return GetInt("all_tenants");
          }
      }
      
  }









  /// <summary>
      ///The query class used to retrieve an object of type CfgService
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgServiceQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgServiceQuery class. This query will not be executable.
      /// </summary>
      public CfgServiceQuery() : base(CfgObjectType.CFGService)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgServiceQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgServiceQuery(IConfService confService) : base(CfgObjectType.CFGService, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgService object retrieved as a result of this operation</returns>
      public CfgService ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgService>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgService objects
      ///
      /// </summary>
      /// <returns>A collection of CfgService objects</returns>       
      public ICollection<CfgService> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgService>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgService objects</returns>
      public ICollection<CfgService> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgService>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a service.
	  ///If specified, Configuration Server will return information only
	  ///about this service.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a service. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the service(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the services this tenant is subscribed to. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Type of the application (see 
	  ///<c><see cref="CfgAppType"/></c>). If specified, Configuration Server will return information
	  ///only about the services that involve this application type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgAppType? AppType
      {
          set
          {
              this["app_type"] = value;
          }
          get
          {
              return (CfgAppType?)GetInt("app_type");
          }
      }
      
        /// <summary>
	  ///Current state of a service (see 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about services that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an application.
	  ///If specified, Configuration Server will return information only
	  ///about the Solutions that involve this application. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int AppDbid
      {
          set
          {
              this["app_dbid"] = value;
          }
          get
          {
              return GetInt("app_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a Service
	  ///Control Server. If specified, Configuration Server will return
	  ///information only about the solutions controlled by this SCS.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ScsDbid
      {
          set
          {
              this["scs_dbid"] = value;
          }
          get
          {
              return GetInt("scs_dbid");
          }
      }
      
        /// <summary>
	  ///The type of the solution. If specified,
	  ///Configuration Server will return information only about the solutions
	  ///of specified type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Type
      {
          set
          {
              this["type"] = value;
          }
          get
          {
              return GetInt("type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a folder.
	  ///If specified, Configuration Server will return information only
	  ///about the services located immediately under this folder. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FolderDbid
      {
          set
          {
              this["folder_dbid"] = value;
          }
          get
          {
              return GetInt("folder_dbid");
          }
      }
      
  }










  /// <summary>
      ///The query class used to retrieve an object of type CfgPhysicalSwitch
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgPhysicalSwitchQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgPhysicalSwitchQuery class. This query will not be executable.
      /// </summary>
      public CfgPhysicalSwitchQuery() : base(CfgObjectType.CFGPhysicalSwitch)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgPhysicalSwitchQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgPhysicalSwitchQuery(IConfService confService) : base(CfgObjectType.CFGPhysicalSwitch, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgPhysicalSwitch object retrieved as a result of this operation</returns>
      public CfgPhysicalSwitch ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgPhysicalSwitch>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgPhysicalSwitch objects
      ///
      /// </summary>
      /// <returns>A collection of CfgPhysicalSwitch objects</returns>       
      public ICollection<CfgPhysicalSwitch> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgPhysicalSwitch>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgPhysicalSwitch objects</returns>
      public ICollection<CfgPhysicalSwitch> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgPhysicalSwitch>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a physical switch.
	  ///If specified, Configuration Server will return information only
	  ///about this physical switch.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a physical switch. Shall be
	  ///specified as a character string. If specified, Configuration Server
	  ///will return information only about the physical switch with that
	  ///name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Current state of a physical switch
	  ///(see <c><see cref="CfgObjectState"/></c>). 
	  ///If specified, Configuration Server will return information only about physical switches that
	  ///are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a folder.
	  ///If specified, Configuration Server will return information only
	  ///about the physical switches located immediately under this folder. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FolderDbid
      {
          set
          {
              this["folder_dbid"] = value;
          }
          get
          {
              return GetInt("folder_dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgSwitch
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgSwitchQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgSwitchQuery class. This query will not be executable.
      /// </summary>
      public CfgSwitchQuery() : base(CfgObjectType.CFGSwitch)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgSwitchQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgSwitchQuery(IConfService confService) : base(CfgObjectType.CFGSwitch, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgSwitch object retrieved as a result of this operation</returns>
      public CfgSwitch ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgSwitch>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgSwitch objects
      ///
      /// </summary>
      /// <returns>A collection of CfgSwitch objects</returns>       
      public ICollection<CfgSwitch> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgSwitch>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgSwitch objects</returns>
      public ICollection<CfgSwitch> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgSwitch>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a switch. If
	  ///specified, Configuration Server will return information only about
	  ///this switch.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a switch. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the switch(es) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Current state of a switch (see type 
	  ///<c><see cref="CfgObjectState"/></c>). 
	  ///If specified, Configuration Server will return information only about switches that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the switches that belong to this tenant.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a T-Server.
	  ///If specified, Configuration Server will return information only
	  ///about the switch that is associated with this T-Server.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TserverDbid
      {
          set
          {
              this["tserver_dbid"] = value;
          }
          get
          {
              return GetInt("tserver_dbid");
          }
      }
      
  }






  /// <summary>
      ///The query class used to retrieve an object of type CfgDN
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgDNQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgDNQuery class. This query will not be executable.
      /// </summary>
      public CfgDNQuery() : base(CfgObjectType.CFGDN)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgDNQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgDNQuery(IConfService confService) : base(CfgObjectType.CFGDN, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgDN object retrieved as a result of this operation</returns>
      public CfgDN ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgDN>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgDN objects
      ///
      /// </summary>
      /// <returns>A collection of CfgDN objects</returns>       
      public ICollection<CfgDN> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgDN>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgDN objects</returns>
      public ICollection<CfgDN> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgDN>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a DN. If specified, Configuration Server
	  ///will return information only about this DN.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant. If specified, Configuration
	  ///Server will return information only about the DNs that belong to this
	  ///tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a switch. If specified, Configuration
	  ///Server will return information only about the DNs that belong to this
	  ///switch. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int SwitchDbid
      {
          set
          {
              this["switch_dbid"] = value;
          }
          get
          {
              return GetInt("switch_dbid");
          }
      }
      
        /// <summary>
	  ///Type of the DN (see <c><see cref="CfgDNType"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about the DNs of this type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgDNType? DnType
      {
          set
          {
              this["dn_type"] = value;
          }
          get
          {
              return (CfgDNType?)GetInt("dn_type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a place. If specified, Configuration
	  ///Server will return information only about the DNs that are associated
	  ///with this place.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int PlaceDbid
      {
          set
          {
              this["place_dbid"] = value;
          }
          get
          {
              return GetInt("place_dbid");
          }
      }
      
        /// <summary>
	  ///Configuration Server will return information only about the DN(s)
	  ///that ) that are allowed to be assigned to the place and not associated
	  ///with any place.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int NoPlaceDbid
      {
          set
          {
              this["no_place_dbid"] = value;
          }
          get
          {
              return GetInt("no_place_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the group of DNs.
	  ///If specified, Configuration Server will return information only
	  ///about the DNs that are associated with this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int GroupDbid
      {
          set
          {
              this["group_dbid"] = value;
          }
          get
          {
              return GetInt("group_dbid");
          }
      }
      
        /// <summary>
	  ///An entity associated with a DN. Shall be
	  ///specified as a character string. If specified, Configuration Server
	  ///will return information only about the DN(s) that are associated
	  ///with this entity.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Association
      {
          set
          {
              this["association"] = value;
          }
          get
          {
              return GetString("association");
          }
      }
      
        /// <summary>
	  ///Current state of a DN (see <c><see cref="CfgObjectState"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about DNs that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Directory number of a DN. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the DN(s) with that number.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string DnNumber
      {
          set
          {
              this["dn_number"] = value;
          }
          get
          {
              return GetString("dn_number");
          }
      }
      
        /// <summary>
	  ///Name of a DN. Shall be specified as a character
	  ///string. If specified, Configuration Server will return information
	  ///only about the DN(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an IVR object (see <c><see cref="CfgIVR"/></c>). If
	  ///specified, Configuration Server will return information only about
	  ///the DN(s) which assigned to IVR Ports (see <c><see cref="CfgIVRPort"/></c>)
	  ///of this IVR object.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int IvrDbid
      {
          set
          {
              this["ivr_dbid"] = value;
          }
          get
          {
              return GetInt("ivr_dbid");
          }
      }
      
  }






  /// <summary>
      ///The query class used to retrieve an object of type CfgPlace
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgPlaceQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgPlaceQuery class. This query will not be executable.
      /// </summary>
      public CfgPlaceQuery() : base(CfgObjectType.CFGPlace)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgPlaceQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgPlaceQuery(IConfService confService) : base(CfgObjectType.CFGPlace, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgPlace object retrieved as a result of this operation</returns>
      public CfgPlace ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgPlace>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgPlace objects
      ///
      /// </summary>
      /// <returns>A collection of CfgPlace objects</returns>       
      public ICollection<CfgPlace> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgPlace>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgPlace objects</returns>
      public ICollection<CfgPlace> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgPlace>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a place. If
	  ///specified, Configuration Server will return information only about
	  ///this place.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant. If specified, Configuration
	  ///Server will return information only about the places that belong
	  ///to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a place. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the place(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Current state of a place (see 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about places that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a place
	  ///group. If specified, Configuration Server will return information
	  ///only about the places that form this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int GroupDbid
      {
          set
          {
              this["group_dbid"] = value;
          }
          get
          {
              return GetInt("group_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a DN. If
	  ///specified, Configuration Server will return information only about
	  ///the place this DN is assigned to.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int DnDbid
      {
          set
          {
              this["dn_dbid"] = value;
          }
          get
          {
              return GetInt("dn_dbid");
          }
      }
      
        /// <summary>
	  ///Configuration Server will return
	  ///information only about the place(s) without DNs assigned to.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int NoDnDbid
      {
          set
          {
              this["no_dn_dbid"] = value;
          }
          get
          {
              return GetInt("no_dn_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a person.
	  ///If specified, Configuration Server will return information only
	  ///about place associated with this person. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int PersonDbid
      {
          set
          {
              this["person_dbid"] = value;
          }
          get
          {
              return GetInt("person_dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgPerson
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgPersonQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgPersonQuery class. This query will not be executable.
      /// </summary>
      public CfgPersonQuery() : base(CfgObjectType.CFGPerson)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgPersonQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgPersonQuery(IConfService confService) : base(CfgObjectType.CFGPerson, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgPerson object retrieved as a result of this operation</returns>
      public CfgPerson ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgPerson>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgPerson objects
      ///
      /// </summary>
      /// <returns>A collection of CfgPerson objects</returns>       
      public ICollection<CfgPerson> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgPerson>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgPerson objects</returns>
      public ICollection<CfgPerson> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgPerson>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the persons that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Indicator of whether a person
	  ///is an agent. If set to <c>CFGTrue</c>, Configuration Server will return
	  ///information only about the persons who are agents. If set to <c>CFGFalse</c>, 
	  ///Configuration Server will return information only about the persons
	  ///who are not agents.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int IsAgent
      {
          set
          {
              this["is_agent"] = value;
          }
          get
          {
              return GetInt("is_agent");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a skill.
	  ///If specified, Configuration Server will return information only
	  ///about the agents who have this skill.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int SkillDbid
      {
          set
          {
              this["skill_dbid"] = value;
          }
          get
          {
              return GetInt("skill_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an agent
	  ///group. If specified, Configuration Server will return information
	  ///only about the agents who form this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int GroupDbid
      {
          set
          {
              this["group_dbid"] = value;
          }
          get
          {
              return GetInt("group_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a person (see type 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about persons that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Employee ID of a person. Shall
	  ///be specified as a character string. If specified, Configuration
	  ///Server will return information only about the person(s) with this
	  ///employee ID.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string EmployeeId
      {
          set
          {
              this["employee_id"] = value;
          }
          get
          {
              return GetString("employee_id");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an agent
	  ///login. If specified, Configuration Server will return information
	  ///only about the agent this login is currently assigned to.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int LoginDbid
      {
          set
          {
              this["login_dbid"] = value;
          }
          get
          {
              return GetInt("login_dbid");
          }
      }
      
        /// <summary>
	  ///User name of a person. Shall
	  ///be specified as a character string. If specified, Configuration
	  ///Server will return information only about the person with this user
	  ///name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string UserName
      {
          set
          {
              this["user_name"] = value;
          }
          get
          {
              return GetString("user_name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a person. If
	  ///specified, Configuration Server will return information only about
	  ///this person.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Configuration Server will
	  ///return information only about the agent(s) without login is currently
	  ///assigned to.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int NoLoginDbid
      {
          set
          {
              this["no_login_dbid"] = value;
          }
          get
          {
              return GetInt("no_login_dbid");
          }
      }
      
        /// <summary>
	  ///Configuration Server will return the information only about
	  ///the agents that do not have default places associated with.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int NoPlaceDbid
      {
          set
          {
              this["no_place_dbid"] = value;
          }
          get
          {
              return GetInt("no_place_dbid");
          }
      }
      
        /// <summary>
	  ///The name of a person. Shall
	  ///be specified as a character string. If specified, Configuration
	  ///Server will return information only about the person with this name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string FirstName
      {
          set
          {
              this["first_name"] = value;
          }
          get
          {
              return GetString("first_name");
          }
      }
      
        /// <summary>
	  ///The last name of a person. Shall
	  ///be specified as a character string. If specified, Configuration
	  ///Server will return information only about the person with this last
	  ///name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string LastName
      {
          set
          {
              this["last_name"] = value;
          }
          get
          {
              return GetString("last_name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a Switch.
	  ///If specified, Configuration Server will return information only
	  ///about the agent(s) that have associated Agent Logins belonged to
	  ///that Switch.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int SwitchDbid
      {
          set
          {
              this["switch_dbid"] = value;
          }
          get
          {
              return GetInt("switch_dbid");
          }
      }
      
  }
















  /// <summary>
      ///The query class used to retrieve an object of type CfgAgentLogin
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgAgentLoginQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgAgentLoginQuery class. This query will not be executable.
      /// </summary>
      public CfgAgentLoginQuery() : base(CfgObjectType.CFGAgentLogin)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgAgentLoginQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgAgentLoginQuery(IConfService confService) : base(CfgObjectType.CFGAgentLogin, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgAgentLogin object retrieved as a result of this operation</returns>
      public CfgAgentLogin ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgAgentLogin>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgAgentLogin objects
      ///
      /// </summary>
      /// <returns>A collection of CfgAgentLogin objects</returns>       
      public ICollection<CfgAgentLogin> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgAgentLogin>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgAgentLogin objects</returns>
      public ICollection<CfgAgentLogin> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgAgentLogin>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the agent logins that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a switch.
	  ///If specified, Configuration Server will return information only
	  ///about the agent logins that belong to this switch. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int SwitchDbid
      {
          set
          {
              this["switch_dbid"] = value;
          }
          get
          {
              return GetInt("switch_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of an agent login (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about agent logins that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Agent login code. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the agent login(s) with this code.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string LoginCode
      {
          set
          {
              this["login_code"] = value;
          }
          get
          {
              return GetString("login_code");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an agent login.
	  ///If specified, Configuration Server will return information only
	  ///about this agent login.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Configuration Server will return information only about agent
	  ///logins that currently are not associated with any person.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int NoPersonDbid
      {
          set
          {
              this["no_person_dbid"] = value;
          }
          get
          {
              return GetInt("no_person_dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgHost
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgHostQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgHostQuery class. This query will not be executable.
      /// </summary>
      public CfgHostQuery() : base(CfgObjectType.CFGHost)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgHostQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgHostQuery(IConfService confService) : base(CfgObjectType.CFGHost, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgHost object retrieved as a result of this operation</returns>
      public CfgHost ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgHost>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgHost objects
      ///
      /// </summary>
      /// <returns>A collection of CfgHost objects</returns>       
      public ICollection<CfgHost> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgHost>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgHost objects</returns>
      public ICollection<CfgHost> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgHost>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///Type of the operating system (see
	  ///<c><see cref="CfgOSType"/></c>). If specified, Configuration Server
	  ///will return information only about the hosts that use operating
	  ///systems of this type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgOSType? OsType
      {
          set
          {
              this["os_type"] = value;
          }
          get
          {
              return (CfgOSType?)GetInt("os_type");
          }
      }
      
        /// <summary>
	  ///Type of the host (see <c><see cref="CfgHostType"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about the hosts of this type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgHostType? HostType
      {
          set
          {
              this["host_type"] = value;
          }
          get
          {
              return (CfgHostType?)GetInt("host_type");
          }
      }
      
        /// <summary>
	  ///Current state of a host (see <c><see cref="CfgObjectState"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about hosts that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of a host. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the host(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a host. If
	  ///specified, Configuration Server will return information only about
	  ///this host.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of SCS. If
	  ///specified, Configuration Server will return information only about
	  ///hosts controlled by this SCS.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ScsDbid
      {
          set
          {
              this["scs_dbid"] = value;
          }
          get
          {
              return GetInt("scs_dbid");
          }
      }
      
  }








  /// <summary>
      ///The query class used to retrieve an object of type CfgApplication
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgApplicationQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgApplicationQuery class. This query will not be executable.
      /// </summary>
      public CfgApplicationQuery() : base(CfgObjectType.CFGApplication)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgApplicationQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgApplicationQuery(IConfService confService) : base(CfgObjectType.CFGApplication, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgApplication object retrieved as a result of this operation</returns>
      public CfgApplication ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgApplication>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgApplication objects
      ///
      /// </summary>
      /// <returns>A collection of CfgApplication objects</returns>       
      public ICollection<CfgApplication> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgApplication>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgApplication objects</returns>
      public ICollection<CfgApplication> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgApplication>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///Type of the application (see 
	  ///<c><see cref="CfgAppType"/></c>). If specified, Configuration Server will
	  ///return information only about the applications of this type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgAppType? AppType
      {
          set
          {
              this["app_type"] = value;
          }
          get
          {
              return (CfgAppType?)GetInt("app_type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the applications that are associated with this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///An indicator of whether this
	  ///application can be a server to some other applications. Depending
	  ///on value specified, Configuration Server will return information
	  ///only about the application(s) that are either servers or non-servers.
	  ///See <c><see cref="CfgFlag"/></c>.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgFlag? IsServer
      {
          set
          {
              this["is_server"] = value;
          }
          get
          {
              return (CfgFlag?)GetInt("is_server");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an application.
	  ///If specified, Configuration Server will return information only
	  ///about the applications that are clients to this application.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ServerDbid
      {
          set
          {
              this["server_dbid"] = value;
          }
          get
          {
              return GetInt("server_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an application. If specified, Configuration
	  ///Server will return information only about the application that is
	  ///backup to this application.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int PrimaryServerDbid
      {
          set
          {
              this["primary_server_dbid"] = value;
          }
          get
          {
              return GetInt("primary_server_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an application. If specified, Configuration
	  ///Server will return information only about the application that is
	  ///primary to this application.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int BackupServerDbid
      {
          set
          {
              this["backup_server_dbid"] = value;
          }
          get
          {
              return GetInt("backup_server_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an application prototype. If specified,
	  ///Configuration Server will return information only about the applications
	  ///that are based on this prototype.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int AppPrototypeDbid
      {
          set
          {
              this["app_prototype_dbid"] = value;
          }
          get
          {
              return GetInt("app_prototype_dbid");
          }
      }
      
        /// <summary>
	  ///Type of the object that may be used as an account for a daemon application 
	  ///(see <c><see cref="CfgObjectType"/></c>). 
	  ///Makes sense only if used with the filter <c>account_dbid</c> (see below). 
	  ///If both <c>account_type</c> and <c>account_dbid</c>
	  ///are specified, Configuration Server will return information only
	  ///about the applications associated with this account. Such information
	  ///will only be provided to the clients that have privileges to read
	  ///access control list of this application.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectType? AccountType
      {
          set
          {
              this["account_type"] = value;
          }
          get
          {
              return (CfgObjectType?)GetInt("account_type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///object that may be used as an account for a daemon application (see
	  ///type <c>CfgObjectType</c>). Makes sense only if used
	  ///with the filter <c>account_type</c> (see below). Makes sense
	  ///only if used with the filter <c>account_dbid</c> (see below).
	  ///If both <c>account_type</c> and <c>account_dbid</c>
	  ///are specified, Configuration Server will return information only
	  ///about the applications associated with this account. Such information
	  ///will only be provided to the clients that have privileges to read
	  ///access control list of this application.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int AccountDbid
      {
          set
          {
              this["account_dbid"] = value;
          }
          get
          {
              return GetInt("account_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a host.
	  ///If specified, Configuration Server will return information only
	  ///about the applications currently assigned to this host.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int HostDbid
      {
          set
          {
              this["host_dbid"] = value;
          }
          get
          {
              return GetInt("host_dbid");
          }
      }
      
        /// <summary>
	  ///A server communication port. If specified, Configuration
	  ///Server will return information only about the applications currently
	  ///registered at ports with this number. Consider using this filter
	  ///with filter <c>host_dbid</c> (see above).
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Port
      {
          set
          {
              this["port"] = value;
          }
          get
          {
              return GetInt("port");
          }
      }
      
        /// <summary>
	  ///Current state of an application (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about applications that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of an application. Shall be
	  ///specified as a character string. If specified, Configuration Server
	  ///will return information only about the application with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an application.
	  ///If specified, Configuration Server will return information only
	  ///about this application.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Configuration Server will return information only about applications
	  ///currently registered on same host and port. Filter is intended to
	  ///avoid the configuration collisions.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int SameHostAndPort
      {
          set
          {
              this["same_host_and_port"] = value;
          }
          get
          {
              return GetInt("same_host_and_port");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///switch. If specified, Configuration Server will return information
	  ///only about T-Servers/HAProxies associated with this switch (see 
	  ///<c>flexibleProperties</c> above). The filter makes
	  ///sense for application types T-Server and High Availability Proxy
	  ///(<c>CFGTServer; CFGHAProxy.</c>)
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int SwitchDbid
      {
          set
          {
              this["switch_dbid"] = value;
          }
          get
          {
              return GetInt("switch_dbid");
          }
      }
      
        /// <summary>
	  ///A version of the application. Shall be
	  ///specified as a character string. If specified, Configuration 
	  ///Server will return information only about applications with 
	  ///that version. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Version
      {
          set
          {
              this["version"] = value;
          }
          get
          {
              return GetString("version");
          }
      }
      
        /// <summary>
	  ///If specified, Configuration Server will return information
	  ///only about T-Servers/ HAProxies that are not associated with any
	  ///switches (see 
	  ///<c>flexibleProperties</c> above). The filter makes
	  ///sense for application types T-Server and High Availability Proxy
	  ///(<c> CFGTServer; CFGHAProxy.</c>)
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int NoSwitchDbid
      {
          set
          {
              this["no_switch_dbid"] = value;
          }
          get
          {
              return GetInt("no_switch_dbid");
          }
      }
      
        /// <summary>
	  ///If specified, Configuration Server will return information
	  ///only about applications/servers which do not have any clients (there
	  ///is no connection to this applications) configured.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int NoClientDbid
      {
          set
          {
              this["no_client_dbid"] = value;
          }
          get
          {
              return GetInt("no_client_dbid");
          }
      }
      
        /// <summary>
	  ///Startup type of the application (see 
	  ///<c><see cref="CfgStartupType"/></c>). If specified, Configuration Server will
	  ///return information only about the applications of this startup type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgStartupType? StartupType
      {
          set
          {
              this["startup_type"] = value;
          }
          get
          {
              return (CfgStartupType?)GetInt("startup_type");
          }
      }
      
  }










  /// <summary>
      ///The query class used to retrieve an object of type CfgScript
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgScriptQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgScriptQuery class. This query will not be executable.
      /// </summary>
      public CfgScriptQuery() : base(CfgObjectType.CFGScript)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgScriptQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgScriptQuery(IConfService confService) : base(CfgObjectType.CFGScript, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgScript object retrieved as a result of this operation</returns>
      public CfgScript ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgScript>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgScript objects
      ///
      /// </summary>
      /// <returns>A collection of CfgScript objects</returns>       
      public ICollection<CfgScript> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgScript>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgScript objects</returns>
      public ICollection<CfgScript> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgScript>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the script(s) that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Type of the script (see <c><see cref="CfgScriptType"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about the script(s) of this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgScriptType? ScriptType
      {
          set
          {
              this["script_type"] = value;
          }
          get
          {
              return (CfgScriptType?)GetInt("script_type");
          }
      }
      
        /// <summary>
	  ///Current state of a script (see 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about scripts that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a script. If
	  ///specified, Configuration Server will return information only about
	  ///this script.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a script. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the script(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of Tenant. If specified, Configuration
	  ///Server will return information only about the script that is associated
	  ///with specified tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int CapacityTenantDbid
      {
          set
          {
              this["capacity_tenant_dbid"] = value;
          }
          get
          {
              return GetInt("capacity_tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of Person/Agent. If specified, Configuration
	  ///Server will return information only about the script that is associated
	  ///with specified agent. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int CapacityAgentDbid
      {
          set
          {
              this["capacity_agent_dbid"] = value;
          }
          get
          {
              return GetInt("capacity_agent_dbid");
          }
      }
      
        /// <summary>
	  ///Unique identifier of an AgentGroup. If specified, Configuration
	  ///Server will return information only about the script that associated
	  ///with agent group. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int CapacityAgentGroupDbid
      {
          set
          {
              this["capacity_agent_group_dbid"] = value;
          }
          get
          {
              return GetInt("capacity_agent_group_dbid");
          }
      }
      
        /// <summary>
	  ///Unique identifier of a Place. If specified, Configuration
	  ///Server will return information only about the script that is associated
	  ///with specified place. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int CapacityPlaceDbid
      {
          set
          {
              this["capacity_place_dbid"] = value;
          }
          get
          {
              return GetInt("capacity_place_dbid");
          }
      }
      
        /// <summary>
	  ///Unique identifier of a PlaceGroup. If specified, Configuration
	  ///Server will return information only about the script that is associated
	  ///with specified place group. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int CapacityPlaceGroupDbid
      {
          set
          {
              this["capacity_place_group_dbid"] = value;
          }
          get
          {
              return GetInt("capacity_place_group_dbid");
          }
      }
      
        /// <summary>
	  ///A flag controlling how the <c>bytecode</c> 
	  ///binary option from the <c>userProperties</c> field will be returned. If 
	  ///set in the filter, Configuration Server will return an empty list under this 
	  ///option without regard to the actual content.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ExcludeBytecode
      {
          set
          {
              this["exclude_bytecode"] = value;
          }
          get
          {
              return GetInt("exclude_bytecode");
          }
      }
      
        /// <summary>
	  ///A flag controlling how the string options longer that 255 chars <c>userProperties</c> field ( or <c>options</c> for objects that support them) field will be returned. If 
	  ///set in the filter, Configuration Server will return an empty string under this 
	  ///option if value is changed to more than 255
	  ///Note: this option is also applicable to all configuration objects, not only Script
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ExcludeLongstrings
      {
          set
          {
              this["exclude_longstrings"] = value;
          }
          get
          {
              return GetInt("exclude_longstrings");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgSkill
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgSkillQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgSkillQuery class. This query will not be executable.
      /// </summary>
      public CfgSkillQuery() : base(CfgObjectType.CFGSkill)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgSkillQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgSkillQuery(IConfService confService) : base(CfgObjectType.CFGSkill, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgSkill object retrieved as a result of this operation</returns>
      public CfgSkill ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgSkill>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgSkill objects
      ///
      /// </summary>
      /// <returns>A collection of CfgSkill objects</returns>       
      public ICollection<CfgSkill> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgSkill>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgSkill objects</returns>
      public ICollection<CfgSkill> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgSkill>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the skill(s) that belong to this tenant.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a skill (see 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server will return
	  ///information only about skills that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a skill. If
	  ///specified, Configuration Server will return information only about
	  ///this skill.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a skill. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the skill(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgActionCode
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgActionCodeQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgActionCodeQuery class. This query will not be executable.
      /// </summary>
      public CfgActionCodeQuery() : base(CfgObjectType.CFGActionCode)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgActionCodeQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgActionCodeQuery(IConfService confService) : base(CfgObjectType.CFGActionCode, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgActionCode object retrieved as a result of this operation</returns>
      public CfgActionCode ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgActionCode>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgActionCode objects
      ///
      /// </summary>
      /// <returns>A collection of CfgActionCode objects</returns>       
      public ICollection<CfgActionCode> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgActionCode>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgActionCode objects</returns>
      public ICollection<CfgActionCode> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgActionCode>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the action codes that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Type of the action code (see
	  ///<c><see cref="CfgActionCodeType"/></c>). If specified, Configuration Server will return
	  ///information only about the action codes of this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgActionCodeType? CodeType
      {
          set
          {
              this["code_type"] = value;
          }
          get
          {
              return (CfgActionCodeType?)GetInt("code_type");
          }
      }
      
        /// <summary>
	  ///Current state of an action code (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server will return
	  ///information only about action codes that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an action code.
	  ///If specified, Configuration Server will return information only
	  ///about this action code.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of an action code. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the action code(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
  }






  /// <summary>
      ///The query class used to retrieve an object of type CfgTransaction
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgTransactionQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgTransactionQuery class. This query will not be executable.
      /// </summary>
      public CfgTransactionQuery() : base(CfgObjectType.CFGTransaction)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgTransactionQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgTransactionQuery(IConfService confService) : base(CfgObjectType.CFGTransaction, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgTransaction object retrieved as a result of this operation</returns>
      public CfgTransaction ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgTransaction>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgTransaction objects
      ///
      /// </summary>
      /// <returns>A collection of CfgTransaction objects</returns>       
      public ICollection<CfgTransaction> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgTransaction>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgTransaction objects</returns>
      public ICollection<CfgTransaction> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgTransaction>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the transactions that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Type of the object (see <c><see cref="CfgTransactionType"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about the transactions of this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgTransactionType? ObjectType
      {
          set
          {
              this["object_type"] = value;
          }
          get
          {
              return (CfgTransactionType?)GetInt("object_type");
          }
      }
      
        /// <summary>
	  ///Current state of a transaction (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about transactions that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a transaction.
	  ///If specified, Configuration Server will return information only
	  ///about this transaction.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a transaction. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the transaction(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgStatTable
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgStatTableQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgStatTableQuery class. This query will not be executable.
      /// </summary>
      public CfgStatTableQuery() : base(CfgObjectType.CFGStatTable)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgStatTableQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgStatTableQuery(IConfService confService) : base(CfgObjectType.CFGStatTable, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgStatTable object retrieved as a result of this operation</returns>
      public CfgStatTable ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgStatTable>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgStatTable objects
      ///
      /// </summary>
      /// <returns>A collection of CfgStatTable objects</returns>       
      public ICollection<CfgStatTable> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgStatTable>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgStatTable objects</returns>
      public ICollection<CfgStatTable> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgStatTable>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the tables that are defined within this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Type of the table. If specified,
	  ///Configuration Server will return information only about the tables
	  ///of this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TableType
      {
          set
          {
              this["table_type"] = value;
          }
          get
          {
              return GetInt("table_type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a group.
	  ///If specified, Configuration Server will return information only
	  ///about the tables assigned to this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int GroupDbid
      {
          set
          {
              this["group_dbid"] = value;
          }
          get
          {
              return GetInt("group_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a stat table (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about tables that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a table. If
	  ///specified, Configuration Server will return information only about
	  ///this table.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a table. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the table(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a
	  ///stat day. If specified, Configuration Server will return information
	  ///only about the tables containing this stat day.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int StatDayDbid
      {
          set
          {
              this["stat_day_dbid"] = value;
          }
          get
          {
              return GetInt("stat_day_dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgStatDay
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgStatDayQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgStatDayQuery class. This query will not be executable.
      /// </summary>
      public CfgStatDayQuery() : base(CfgObjectType.CFGStatDay)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgStatDayQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgStatDayQuery(IConfService confService) : base(CfgObjectType.CFGStatDay, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgStatDay object retrieved as a result of this operation</returns>
      public CfgStatDay ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgStatDay>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgStatDay objects
      ///
      /// </summary>
      /// <returns>A collection of CfgStatDay objects</returns>       
      public ICollection<CfgStatDay> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgStatDay>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgStatDay objects</returns>
      public ICollection<CfgStatDay> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgStatDay>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the days that are defined within this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a stat
	  ///table. If specified, Configuration Server will return information
	  ///only about the days that are defined within this table. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TableDbid
      {
          set
          {
              this["table_dbid"] = value;
          }
          get
          {
              return GetInt("table_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a stat day (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about stat days that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a day. If specified,
	  ///Configuration Server will return information only about this day.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a day. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the day(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Type of a stat day (see
	  ///<c><see cref="CfgStatDayType"/></c>). If specified, Configuration Server
	  ///will return information only about stat days have this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgStatDayType? StatdayType
      {
          set
          {
              this["statday_type"] = value;
          }
          get
          {
              return (CfgStatDayType?)GetInt("statday_type");
          }
      }
      
  }










  /// <summary>
      ///The query class used to retrieve an object of type CfgAgentGroup
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgAgentGroupQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgAgentGroupQuery class. This query will not be executable.
      /// </summary>
      public CfgAgentGroupQuery() : base(CfgObjectType.CFGAgentGroup)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgAgentGroupQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgAgentGroupQuery(IConfService confService) : base(CfgObjectType.CFGAgentGroup, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgAgentGroup object retrieved as a result of this operation</returns>
      public CfgAgentGroup ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgAgentGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgAgentGroup objects
      ///
      /// </summary>
      /// <returns>A collection of CfgAgentGroup objects</returns>       
      public ICollection<CfgAgentGroup> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgAgentGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgAgentGroup objects</returns>
      public ICollection<CfgAgentGroup> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgAgentGroup>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the agent groups that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a person.
	  ///If specified, Configuration Server will return information only
	  ///about the agent groups this person is assigned to. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int PersonDbid
      {
          set
          {
              this["person_dbid"] = value;
          }
          get
          {
              return GetInt("person_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of an agent group (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about agent groups that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of an agent group. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the agent group(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a group. If
	  ///specified, Configuration Server will return information only about
	  ///this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgPlaceGroup
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgPlaceGroupQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgPlaceGroupQuery class. This query will not be executable.
      /// </summary>
      public CfgPlaceGroupQuery() : base(CfgObjectType.CFGPlaceGroup)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgPlaceGroupQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgPlaceGroupQuery(IConfService confService) : base(CfgObjectType.CFGPlaceGroup, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgPlaceGroup object retrieved as a result of this operation</returns>
      public CfgPlaceGroup ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgPlaceGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgPlaceGroup objects
      ///
      /// </summary>
      /// <returns>A collection of CfgPlaceGroup objects</returns>       
      public ICollection<CfgPlaceGroup> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgPlaceGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgPlaceGroup objects</returns>
      public ICollection<CfgPlaceGroup> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgPlaceGroup>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the place groups that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a place.
	  ///If specified, Configuration Server will return information only
	  ///about the place groups that include this place. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int PlaceDbid
      {
          set
          {
              this["place_dbid"] = value;
          }
          get
          {
              return GetInt("place_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a place group (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about place groups that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of a place group. Shall be specified
	  ///as a character string. If specified, Configuration Server will
	  ///return information only about the place group(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a group. If
	  ///specified, Configuration Server will return information only about
	  ///this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgDNGroup
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgDNGroupQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgDNGroupQuery class. This query will not be executable.
      /// </summary>
      public CfgDNGroupQuery() : base(CfgObjectType.CFGDNGroup)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgDNGroupQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgDNGroupQuery(IConfService confService) : base(CfgObjectType.CFGDNGroup, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgDNGroup object retrieved as a result of this operation</returns>
      public CfgDNGroup ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgDNGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgDNGroup objects
      ///
      /// </summary>
      /// <returns>A collection of CfgDNGroup objects</returns>       
      public ICollection<CfgDNGroup> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgDNGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgDNGroup objects</returns>
      public ICollection<CfgDNGroup> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgDNGroup>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the DN groups that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Type of a DN group (see <c><see cref="CfgDNGroupType"/></c>). If
	  ///specified, Configuration Server will return information only about
	  ///the DN groups of this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgDNGroupType? DnGroupType
      {
          set
          {
              this["dn_group_type"] = value;
          }
          get
          {
              return (CfgDNGroupType?)GetInt("dn_group_type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a DN. If
	  ///specified, Configuration Server will return information only about
	  ///the DN groups this DN is assigned to. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int DnDbid
      {
          set
          {
              this["dn_dbid"] = value;
          }
          get
          {
              return GetInt("dn_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a DN group (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about DN groups that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of a DN group. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the agent group(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a group. If
	  ///specified, Configuration Server will return information only about
	  ///this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }






  /// <summary>
      ///The query class used to retrieve an object of type CfgAccessGroup
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgAccessGroupQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgAccessGroupQuery class. This query will not be executable.
      /// </summary>
      public CfgAccessGroupQuery() : base(CfgObjectType.CFGAccessGroup)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgAccessGroupQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgAccessGroupQuery(IConfService confService) : base(CfgObjectType.CFGAccessGroup, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgAccessGroup object retrieved as a result of this operation</returns>
      public CfgAccessGroup ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgAccessGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgAccessGroup objects
      ///
      /// </summary>
      /// <returns>A collection of CfgAccessGroup objects</returns>       
      public ICollection<CfgAccessGroup> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgAccessGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgAccessGroup objects</returns>
      public ICollection<CfgAccessGroup> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgAccessGroup>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the access groups that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a Person. If
	  ///specified, Configuration Server will return information only about
	  ///the access groups this Person is assigned to. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int PersonDbid
      {
          set
          {
              this["person_dbid"] = value;
          }
          get
          {
              return GetInt("person_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of an access group (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about access groups that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of an access group. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the access group(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a group. If
	  ///specified, Configuration Server will return information only about
	  ///this group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgAppPrototype
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgAppPrototypeQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgAppPrototypeQuery class. This query will not be executable.
      /// </summary>
      public CfgAppPrototypeQuery() : base(CfgObjectType.CFGAppPrototype)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgAppPrototypeQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgAppPrototypeQuery(IConfService confService) : base(CfgObjectType.CFGAppPrototype, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgAppPrototype object retrieved as a result of this operation</returns>
      public CfgAppPrototype ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgAppPrototype>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgAppPrototype objects
      ///
      /// </summary>
      /// <returns>A collection of CfgAppPrototype objects</returns>       
      public ICollection<CfgAppPrototype> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgAppPrototype>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgAppPrototype objects</returns>
      public ICollection<CfgAppPrototype> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgAppPrototype>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///Type of the application (see type 
	  ///<c><see cref="CfgAppType"/></c>). If specified, Configuration Server will
	  ///return information only about the application prototypes that relates
	  ///to the applications of this type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgAppType? AppType
      {
          set
          {
              this["app_type"] = value;
          }
          get
          {
              return (CfgAppType?)GetInt("app_type");
          }
      }
      
        /// <summary>
	  ///Current state of an application prototype
	  ///(see <c><see cref="CfgObjectState"/></c>). If specified, Configuration
	  ///Server will return information only about application prototypes
	  ///that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of an application prototype.
	  ///Shall be specified as a character string. If specified,
	  ///Configuration Server will return information only about the application
	  ///prototype with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an application.
	  ///If specified, Configuration Server will return information only
	  ///about this application prototype.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A version of the application. Shall be specified 
	  ///as a character string. If specified, Configuration Server will return 
	  ///information only about application prototypes with that version.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Version
      {
          set
          {
              this["version"] = value;
          }
          get
          {
              return GetString("version");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgField
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgFieldQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgFieldQuery class. This query will not be executable.
      /// </summary>
      public CfgFieldQuery() : base(CfgObjectType.CFGField)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgFieldQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgFieldQuery(IConfService confService) : base(CfgObjectType.CFGField, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgField object retrieved as a result of this operation</returns>
      public CfgField ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgField>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgField objects
      ///
      /// </summary>
      /// <returns>A collection of CfgField objects</returns>       
      public ICollection<CfgField> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgField>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgField objects</returns>
      public ICollection<CfgField> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgField>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration Server will return information
	  ///only about the fields that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a field. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the field(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Current state of the field (See type 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about the fields that are currently
	  ///in this state. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A data type of field in data base(See
	  ///type <c><see cref="CfgDataType"/></c>). If specified, Configuration Server
	  ///will return information only about fields that have this data type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgDataType? Type
      {
          set
          {
              this["type"] = value;
          }
          get
          {
              return (CfgDataType?)GetInt("type");
          }
      }
      
        /// <summary>
	  ///A field type (See type <c><see cref="CfgFieldType"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about fields that have this field type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgFieldType? FieldType
      {
          set
          {
              this["field_type"] = value;
          }
          get
          {
              return (CfgFieldType?)GetInt("field_type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a field. If
	  ///specified, configuration server will return information only about
	  ///this field.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of format.
	  ///If specified, configuration server will return information only
	  ///about fields that belong to this format.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FormatDbid
      {
          set
          {
              this["format_dbid"] = value;
          }
          get
          {
              return GetInt("format_dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgFormat
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgFormatQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgFormatQuery class. This query will not be executable.
      /// </summary>
      public CfgFormatQuery() : base(CfgObjectType.CFGFormat)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgFormatQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgFormatQuery(IConfService confService) : base(CfgObjectType.CFGFormat, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgFormat object retrieved as a result of this operation</returns>
      public CfgFormat ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgFormat>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgFormat objects
      ///
      /// </summary>
      /// <returns>A collection of CfgFormat objects</returns>       
      public ICollection<CfgFormat> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgFormat>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgFormat objects</returns>
      public ICollection<CfgFormat> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgFormat>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration server will return information
	  ///only about the formats that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of the format (See
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about the formats that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a format.
	  ///If specified, configuration server will return information only
	  ///about this format.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a format. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the format(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the field.
	  ///If specified, Configuration Server will return information only
	  ///about the format(s) which consists this field.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FieldDbid
      {
          set
          {
              this["field_dbid"] = value;
          }
          get
          {
              return GetInt("field_dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgTableAccess
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgTableAccessQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgTableAccessQuery class. This query will not be executable.
      /// </summary>
      public CfgTableAccessQuery() : base(CfgObjectType.CFGTableAccess)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgTableAccessQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgTableAccessQuery(IConfService confService) : base(CfgObjectType.CFGTableAccess, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgTableAccess object retrieved as a result of this operation</returns>
      public CfgTableAccess ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgTableAccess>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgTableAccess objects
      ///
      /// </summary>
      /// <returns>A collection of CfgTableAccess objects</returns>       
      public ICollection<CfgTableAccess> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgTableAccess>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgTableAccess objects</returns>
      public ICollection<CfgTableAccess> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgTableAccess>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a table access.
	  ///If specified, configuration server will return information only
	  ///about this table access.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration server will return information
	  ///only about the table accesses that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a table access. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the table access(es) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A type of table (See <c><see cref="CfgTableType"/></c>). If
	  ///specified, Configuration Server will return information only about
	  ///the table(s) of that type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgTableType? Type
      {
          set
          {
              this["type"] = value;
          }
          get
          {
              return (CfgTableType?)GetInt("type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the data base access point through
	  ///which the table can be accessed. If specified, Configuration Server
	  ///will return information only about the table access(es) which consists
	  ///this data base access point.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int DbaccessDbid
      {
          set
          {
              this["dbaccess_dbid"] = value;
          }
          get
          {
              return GetInt("dbaccess_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of format
	  ///of the table. If specified, Configuration Server will return information
	  ///only about the table(s) with that format.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FormatDbid
      {
          set
          {
              this["format_dbid"] = value;
          }
          get
          {
              return GetInt("format_dbid");
          }
      }
      
        /// <summary>
	  ///Name of the table. Shall be specified as a character string.
	  ///If specified, Configuration Server will return information only
	  ///about the table access(es) for that table.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string DbTableName
      {
          set
          {
              this["db_table_name"] = value;
          }
          get
          {
              return GetString("db_table_name");
          }
      }
      
        /// <summary>
	  ///Current state of the table access
	  ///(See <c><see cref="CfgObjectState"/></c>). If specified, Configuration
	  ///Server will return information only about the table access(es) that
	  ///are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgCallingList
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgCallingListQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgCallingListQuery class. This query will not be executable.
      /// </summary>
      public CfgCallingListQuery() : base(CfgObjectType.CFGCallingList)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgCallingListQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgCallingListQuery(IConfService confService) : base(CfgObjectType.CFGCallingList, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgCallingList object retrieved as a result of this operation</returns>
      public CfgCallingList ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgCallingList>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgCallingList objects
      ///
      /// </summary>
      /// <returns>A collection of CfgCallingList objects</returns>       
      public ICollection<CfgCallingList> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgCallingList>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgCallingList objects</returns>
      public ICollection<CfgCallingList> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgCallingList>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the calling
	  ///list. If specified, configuration server will return information
	  ///only about this calling list.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration server will return information
	  ///only about the calling list(s) that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a calling list. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the calling list(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the table access. If
	  ///specified, Configuration Server will return information only about
	  ///the calling lists(s) engaged with that table access.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TableAccessDbid
      {
          set
          {
              this["table_access_dbid"] = value;
          }
          get
          {
              return GetInt("table_access_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///filter. If specified, Configuration Server will return information
	  ///only about the calling list(s) with that filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FilterDbid
      {
          set
          {
              this["filter_dbid"] = value;
          }
          get
          {
              return GetInt("filter_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the treatment. If specified, Configuration
	  ///Server will return information only about the calling list(s) with
	  ///that treatment.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TreatmentDbid
      {
          set
          {
              this["treatment_dbid"] = value;
          }
          get
          {
              return GetInt("treatment_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the log table access. If
	  ///specified, Configuration Server will return information only about
	  ///the calling lists(s) engaged with that log table access.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int LogTableAccessDbid
      {
          set
          {
              this["log_table_access_dbid"] = value;
          }
          get
          {
              return GetInt("log_table_access_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///calling list script. If specified, Configuration Server will return
	  ///information only about the calling list(s) with that script.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ScriptDbid
      {
          set
          {
              this["script_dbid"] = value;
          }
          get
          {
              return GetInt("script_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of the campaign (See
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about the campaign(s) that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }






  /// <summary>
      ///The query class used to retrieve an object of type CfgCampaignGroup
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgCampaignGroupQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgCampaignGroupQuery class. This query will not be executable.
      /// </summary>
      public CfgCampaignGroupQuery() : base(CfgObjectType.CFGCampaignGroup)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgCampaignGroupQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgCampaignGroupQuery(IConfService confService) : base(CfgObjectType.CFGCampaignGroup, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgCampaignGroup object retrieved as a result of this operation</returns>
      public CfgCampaignGroup ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgCampaignGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgCampaignGroup objects
      ///
      /// </summary>
      /// <returns>A collection of CfgCampaignGroup objects</returns>       
      public ICollection<CfgCampaignGroup> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgCampaignGroup>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgCampaignGroup objects</returns>
      public ICollection<CfgCampaignGroup> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgCampaignGroup>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the calling
	  ///list. If specified, configuration server will return information
	  ///only about this campaign group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration server will return information
	  ///only about the campaign group(s) that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a calling list. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the campaign group(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of group<c>.</c> If
	  ///specified, Configuration Server will return information only about
	  ///the campaign group(s) related to that (Agent or Place) group 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int GroupDbid
      {
          set
          {
              this["group_dbid"] = value;
          }
          get
          {
              return GetInt("group_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of camapign. If specified, Configuration Server will return information only about the campaign group(s) with that campaign.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int CampaignDbid
      {
          set
          {
              this["campaign_dbid"] = value;
          }
          get
          {
              return GetInt("campaign_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of the campaign group (See
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about the campaign group(s) that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgCampaign
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgCampaignQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgCampaignQuery class. This query will not be executable.
      /// </summary>
      public CfgCampaignQuery() : base(CfgObjectType.CFGCampaign)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgCampaignQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgCampaignQuery(IConfService confService) : base(CfgObjectType.CFGCampaign, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgCampaign object retrieved as a result of this operation</returns>
      public CfgCampaign ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgCampaign>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgCampaign objects
      ///
      /// </summary>
      /// <returns>A collection of CfgCampaign objects</returns>       
      public ICollection<CfgCampaign> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgCampaign>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgCampaign objects</returns>
      public ICollection<CfgCampaign> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgCampaign>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the campaign.
	  ///If specified, configuration server will return information only
	  ///about this campaign.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration server will return information
	  ///only about the campaign(s) that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a campaign. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the campaign(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of group<c>.</c> If
	  ///specified, Configuration Server will return information only about
	  ///the campaign(s) with that group.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int GroupDbid
      {
          set
          {
              this["group_dbid"] = value;
          }
          get
          {
              return GetInt("group_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of calling list. If specified,
	  ///Configuration Server will return information only about the campaign(s)
	  ///with that calling list.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int CallingListDbid
      {
          set
          {
              this["calling_list_dbid"] = value;
          }
          get
          {
              return GetInt("calling_list_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///campaign script. If specified, Configuration Server will return
	  ///information only about the campaign(s) with that script.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ScriptDbid
      {
          set
          {
              this["script_dbid"] = value;
          }
          get
          {
              return GetInt("script_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of the campaign (See
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about the campaign(s) that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgTreatment
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgTreatmentQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgTreatmentQuery class. This query will not be executable.
      /// </summary>
      public CfgTreatmentQuery() : base(CfgObjectType.CFGTreatment)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgTreatmentQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgTreatmentQuery(IConfService confService) : base(CfgObjectType.CFGTreatment, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgTreatment object retrieved as a result of this operation</returns>
      public CfgTreatment ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgTreatment>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgTreatment objects
      ///
      /// </summary>
      /// <returns>A collection of CfgTreatment objects</returns>       
      public ICollection<CfgTreatment> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgTreatment>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgTreatment objects</returns>
      public ICollection<CfgTreatment> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgTreatment>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the treatment.
	  ///If specified, configuration server will return information only
	  ///about this treatment.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration server will return information
	  ///only about the treatment(s) that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a treatment. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the treatment(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A call result related to this
	  ///treatment (See <c><see cref="GctiCallState"/></c>). If specified, Configuration
	  ///Server will return information only about the treatments(s) with
	  ///that call result.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public GctiCallState? CallResult
      {
          set
          {
              this["call_result"] = value;
          }
          get
          {
              return (GctiCallState?)GetInt("call_result");
          }
      }
      
        /// <summary>
	  ///A record action code(See <c><see cref="CfgRecActionCode"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about the treatments(s) with that record action code.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgRecActionCode? RecActionCode
      {
          set
          {
              this["rec_action_code"] = value;
          }
          get
          {
              return (CfgRecActionCode?)GetInt("rec_action_code");
          }
      }
      
        /// <summary>
	  ///A unique identifier of destination
	  ///dn. If specified, Configuration Server will return information only
	  ///about the treatments(s) with that destination dn specified.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int DestDnDbid
      {
          set
          {
              this["dest_dn_dbid"] = value;
          }
          get
          {
              return GetInt("dest_dn_dbid");
          }
      }
      
        /// <summary>
	  ///A call action code(See <c><see cref="CfgCallActionCode"/></c>). If
	  ///specified, Configuration Server will return information only about
	  ///the treatments(s) with that call action code.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgCallActionCode? CallActionCode
      {
          set
          {
              this["call_action_code"] = value;
          }
          get
          {
              return (CfgCallActionCode?)GetInt("call_action_code");
          }
      }
      
        /// <summary>
	  ///Current state of the table access
	  ///(See <c><see cref="CfgObjectState"/></c>). If specified, Configuration
	  ///Server will return information only about the table access(s) that
	  ///are currently in this state. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgFilter
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgFilterQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgFilterQuery class. This query will not be executable.
      /// </summary>
      public CfgFilterQuery() : base(CfgObjectType.CFGFilter)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgFilterQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgFilterQuery(IConfService confService) : base(CfgObjectType.CFGFilter, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgFilter object retrieved as a result of this operation</returns>
      public CfgFilter ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgFilter>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgFilter objects
      ///
      /// </summary>
      /// <returns>A collection of CfgFilter objects</returns>       
      public ICollection<CfgFilter> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgFilter>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgFilter objects</returns>
      public ICollection<CfgFilter> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgFilter>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the filter.
	  ///If specified, configuration server will return information only
	  ///about this filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the tenant. If specified, Configuration
	  ///server will return information only about the filter(s) that belong to
	  ///this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a filter. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the filter(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of format
	  ///this filter relates to. If specified, Configuration Server will
	  ///return information only about the filter(s) with that format.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FormatDbid
      {
          set
          {
              this["format_dbid"] = value;
          }
          get
          {
              return GetInt("format_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of the filter (See
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about the filter(s) that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgTimeZone
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgTimeZoneQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgTimeZoneQuery class. This query will not be executable.
      /// </summary>
      public CfgTimeZoneQuery() : base(CfgObjectType.CFGTimeZone)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgTimeZoneQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgTimeZoneQuery(IConfService confService) : base(CfgObjectType.CFGTimeZone, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgTimeZone object retrieved as a result of this operation</returns>
      public CfgTimeZone ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgTimeZone>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgTimeZone objects
      ///
      /// </summary>
      /// <returns>A collection of CfgTimeZone objects</returns>       
      public ICollection<CfgTimeZone> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgTimeZone>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgTimeZone objects</returns>
      public ICollection<CfgTimeZone> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgTimeZone>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of the time zone.
	  ///If specified, configuration server will return information only
	  ///about this time zone.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the
	  ///tenant. If specified, Configuration server will return information
	  ///only about the time zone(s) that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of a time zone. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the time zone with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A time zone offset. If specified,
	  ///Configuration Server will return information only about the time
	  ///zone(s) with that offset. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Offset
      {
          set
          {
              this["offset"] = value;
          }
          get
          {
              return GetInt("offset");
          }
      }
      
        /// <summary>
	  ///A pointer to the time zone
	  ///name used by Netscape Navigator browser. Shall be
	  ///specified as a character string. If specified, Configuration
	  ///Server will return information only about the time zone(s) with
	  ///that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string NameNetscape
      {
          set
          {
              this["name_netscape"] = value;
          }
          get
          {
              return GetString("name_netscape");
          }
      }
      
        /// <summary>
	  ///A pointer to the time zone 
	  ///name used by Microsoft browser. Shall be specified as a character 
	  ///string. If specified, Configuration Server will return information only
	  ///about the time zone(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string NameMsexplorer
      {
          set
          {
              this["name_msexplorer"] = value;
          }
          get
          {
              return GetString("name_msexplorer");
          }
      }
      
        /// <summary>
	  ///Current state of the time zone (See
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about the time zone(s) that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgIVRPort
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgIVRPortQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgIVRPortQuery class. This query will not be executable.
      /// </summary>
      public CfgIVRPortQuery() : base(CfgObjectType.CFGIVRPort)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgIVRPortQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgIVRPortQuery(IConfService confService) : base(CfgObjectType.CFGIVRPort, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgIVRPort object retrieved as a result of this operation</returns>
      public CfgIVRPort ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgIVRPort>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgIVRPort objects
      ///
      /// </summary>
      /// <returns>A collection of CfgIVRPort objects</returns>       
      public ICollection<CfgIVRPort> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgIVRPort>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgIVRPort objects</returns>
      public ICollection<CfgIVRPort> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgIVRPort>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the IVR ports that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a IVR port (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about IVR ports that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the IVR.
	  ///If specified, Configuration Server will return the information only
	  ///about the IVR ports that belong to this IVR.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int IvrDbid
      {
          set
          {
              this["ivr_dbid"] = value;
          }
          get
          {
              return GetInt("ivr_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the DN.
	  ///If specified, configuration Server will return the information about
	  ///IVR port associated with this DN.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int DnDbid
      {
          set
          {
              this["dn_dbid"] = value;
          }
          get
          {
              return GetInt("dn_dbid");
          }
      }
      
        /// <summary>
	  ///A port number. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the port(s) with that number.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string PortNumber
      {
          set
          {
              this["port_number"] = value;
          }
          get
          {
              return GetString("port_number");
          }
      }
      
        /// <summary>
	  ///A unique identifier of the IVR port.
	  ///If specified, Configuration Server will return information only
	  ///about this IVR port.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgIVR
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgIVRQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgIVRQuery class. This query will not be executable.
      /// </summary>
      public CfgIVRQuery() : base(CfgObjectType.CFGIVR)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgIVRQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgIVRQuery(IConfService confService) : base(CfgObjectType.CFGIVR, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgIVR object retrieved as a result of this operation</returns>
      public CfgIVR ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgIVR>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgIVR objects
      ///
      /// </summary>
      /// <returns>A collection of CfgIVR objects</returns>       
      public ICollection<CfgIVR> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgIVR>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgIVR objects</returns>
      public ICollection<CfgIVR> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgIVR>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the DNs that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Name of IVR. Shall be
	  ///specified as a character string. If specified, Configuration
	  ///Server will return information only about the IVR with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Type of the IVR (see type <c><see cref="CfgIVRType"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about the IVR of this type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgIVRType? Type
      {
          set
          {
              this["type"] = value;
          }
          get
          {
              return (CfgIVRType?)GetInt("type");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an IVR interface server. If specified,
	  ///Configuration Server will return information only about the IVRs
	  ///that associated with this IVR interface server.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int IvrServerDbid
      {
          set
          {
              this["ivr_server_dbid"] = value;
          }
          get
          {
              return GetInt("ivr_server_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of an IVR (see <c><see cref="CfgObjectState"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about IVRs that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an IVR. If
	  ///specified, Configuration Server will return information only about
	  ///this IVR.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgAlarmCondition
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgAlarmConditionQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgAlarmConditionQuery class. This query will not be executable.
      /// </summary>
      public CfgAlarmConditionQuery() : base(CfgObjectType.CFGAlarmCondition)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgAlarmConditionQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgAlarmConditionQuery(IConfService confService) : base(CfgObjectType.CFGAlarmCondition, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgAlarmCondition object retrieved as a result of this operation</returns>
      public CfgAlarmCondition ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgAlarmCondition>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgAlarmCondition objects
      ///
      /// </summary>
      /// <returns>A collection of CfgAlarmCondition objects</returns>       
      public ICollection<CfgAlarmCondition> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgAlarmCondition>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgAlarmCondition objects</returns>
      public ICollection<CfgAlarmCondition> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgAlarmCondition>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///Current state of an alarm condition
	  ///(see <c><see cref="CfgObjectState"/></c>). If specified, Configuration
	  ///Server will return information only about alarm conditions that
	  ///are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of an alarm condition. Shall be
	  ///specified as a character string. If specified, Configuration Server
	  ///will return information only about the alarm condition(s) with that
	  ///name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an alarm condition.
	  ///If specified, Configuration Server will return information only
	  ///about this alarm condition.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }






  /// <summary>
      ///The query class used to retrieve an object of type CfgVoicePrompt
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgVoicePromptQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgVoicePromptQuery class. This query will not be executable.
      /// </summary>
      public CfgVoicePromptQuery() : base(CfgObjectType.CFGVoicePrompt)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgVoicePromptQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgVoicePromptQuery(IConfService confService) : base(CfgObjectType.CFGVoicePrompt, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgVoicePrompt object retrieved as a result of this operation</returns>
      public CfgVoicePrompt ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgVoicePrompt>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgVoicePrompt objects
      ///
      /// </summary>
      /// <returns>A collection of CfgVoicePrompt objects</returns>       
      public ICollection<CfgVoicePrompt> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgVoicePrompt>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgVoicePrompt objects</returns>
      public ICollection<CfgVoicePrompt> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgVoicePrompt>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a voice prompt.
	  ///If specified, Configuration Server will return information only
	  ///about this voice prompt.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a voice prompt. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the voice prompts(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the voice prompts that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a switch.
	  ///If specified, Configuration Server will return information only
	  ///about the voice prompts that belong to this switch. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int SwitchDbid
      {
          set
          {
              this["switch_dbid"] = value;
          }
          get
          {
              return GetInt("switch_dbid");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a script.
	  ///If specified, Configuration Server will return information only
	  ///about the voice prompts that refer to this script.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ScriptDbid
      {
          set
          {
              this["script_dbid"] = value;
          }
          get
          {
              return GetInt("script_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a voice prompt (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about voice prompts that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgEnumerator
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgEnumeratorQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgEnumeratorQuery class. This query will not be executable.
      /// </summary>
      public CfgEnumeratorQuery() : base(CfgObjectType.CFGEnumerator)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgEnumeratorQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgEnumeratorQuery(IConfService confService) : base(CfgObjectType.CFGEnumerator, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgEnumerator object retrieved as a result of this operation</returns>
      public CfgEnumerator ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgEnumerator>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgEnumerator objects
      ///
      /// </summary>
      /// <returns>A collection of CfgEnumerator objects</returns>       
      public ICollection<CfgEnumerator> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgEnumerator>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgEnumerator objects</returns>
      public ICollection<CfgEnumerator> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgEnumerator>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of an enumerator.
	  ///If specified, Configuration Server will return information only
	  ///about this enumerator.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///System name of an enumerator. Shall
	  ///be specified as a character string. If specified, Configuration
	  ///Server will return information only about the enumerator(s) with
	  ///that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the enumerators that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of an enumerator (see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about enumerators that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an enumerator type. If specified,
	  ///Configuration Server will return information only about enumerators
	  ///of this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int EnumeratorType
      {
          set
          {
              this["enumerator_type"] = value;
          }
          get
          {
              return GetInt("enumerator_type");
          }
      }
      
        /// <summary>
	  ///Display name of an enumerator.
	  ///Shall be specified as a character string. If specified, Configuration
	  ///Server will return information only about the enumerator(s) with
	  ///that display name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string DisplayName
      {
          set
          {
              this["display_name"] = value;
          }
          get
          {
              return GetString("display_name");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgEnumeratorValue
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgEnumeratorValueQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgEnumeratorValueQuery class. This query will not be executable.
      /// </summary>
      public CfgEnumeratorValueQuery() : base(CfgObjectType.CFGEnumeratorValue)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgEnumeratorValueQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgEnumeratorValueQuery(IConfService confService) : base(CfgObjectType.CFGEnumeratorValue, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgEnumeratorValue object retrieved as a result of this operation</returns>
      public CfgEnumeratorValue ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgEnumeratorValue>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgEnumeratorValue objects
      ///
      /// </summary>
      /// <returns>A collection of CfgEnumeratorValue objects</returns>       
      public ICollection<CfgEnumeratorValue> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgEnumeratorValue>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgEnumeratorValue objects</returns>
      public ICollection<CfgEnumeratorValue> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgEnumeratorValue>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of an enumerator. If specified, Configuration
	  ///Server will return information only about enumerator values for
	  ///this enumerator.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int EnumeratorDbid
      {
          set
          {
              this["enumerator_dbid"] = value;
          }
          get
          {
              return GetInt("enumerator_dbid");
          }
      }
      
        /// <summary>
	  ///A default value of an enumerator. If specified, Configuration
	  ///Server will return information only about enumerator values with
	  ///this flag set to <c>CFGTrue</c>.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int DefaultValue
      {
          set
          {
              this["default_value"] = value;
          }
          get
          {
              return GetInt("default_value");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an enumerator
	  ///value. If specified, Configuration Server will return information
	  ///only about this enumerator value.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///System name of an enumerator value.
	  ///Shall be specified as a character string. If specified, Configuration
	  ///Server will return information only about the enumerator value(s)
	  ///with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the enumerator values that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a enumerator value(see
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about enumerator values that are currently
	  ///in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Display name of an enumerator
	  ///value. Shall be specified as a character string. If specified, Configuration
	  ///Server will return information only about the enumerator(s) with
	  ///that display name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string DisplayName
      {
          set
          {
              this["display_name"] = value;
          }
          get
          {
              return GetString("display_name");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgObjectiveTable
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgObjectiveTableQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgObjectiveTableQuery class. This query will not be executable.
      /// </summary>
      public CfgObjectiveTableQuery() : base(CfgObjectType.CFGObjectiveTable)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgObjectiveTableQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgObjectiveTableQuery(IConfService confService) : base(CfgObjectType.CFGObjectiveTable, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgObjectiveTable object retrieved as a result of this operation</returns>
      public CfgObjectiveTable ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgObjectiveTable>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgObjectiveTable objects
      ///
      /// </summary>
      /// <returns>A collection of CfgObjectiveTable objects</returns>       
      public ICollection<CfgObjectiveTable> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgObjectiveTable>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgObjectiveTable objects</returns>
      public ICollection<CfgObjectiveTable> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgObjectiveTable>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of an objective
	  ///table. If specified, Configuration Server will return information
	  ///only about this objective table.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of an objective table. Shall
	  ///be specified as a character string. If specified, Configuration
	  ///Server will return information only about the objective table(s)
	  ///with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the objective tables that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of an objective table (see <c><see cref="CfgObjectState"/></c>). If specified, Configuration Server will return information only about objective tables that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }






  /// <summary>
      ///The query class used to retrieve an object of type CfgFolder
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgFolderQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgFolderQuery class. This query will not be executable.
      /// </summary>
      public CfgFolderQuery() : base(CfgObjectType.CFGFolder)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgFolderQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgFolderQuery(IConfService confService) : base(CfgObjectType.CFGFolder, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgFolder object retrieved as a result of this operation</returns>
      public CfgFolder ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgFolder>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgFolder objects
      ///
      /// </summary>
      /// <returns>A collection of CfgFolder objects</returns>       
      public ICollection<CfgFolder> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgFolder>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgFolder objects</returns>
      public ICollection<CfgFolder> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgFolder>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a folder. If
	  ///specified, Configuration Server will return information only about
	  ///this folder.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a folder. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the folder(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of an owner
	  ///object. If specified, Configuration Server will return information
	  ///only about the folders that belong to this object. Must be used
	  ///in conjunction with the <c>owner_type</c> filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int OwnerDbid
      {
          set
          {
              this["owner_dbid"] = value;
          }
          get
          {
              return GetInt("owner_dbid");
          }
      }
      
        /// <summary>
	  ///A type of an owner object. Must
	  ///be used in conjunction with the <c>owner_dbid</c> filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int OwnerType
      {
          set
          {
              this["owner_type"] = value;
          }
          get
          {
              return GetInt("owner_type");
          }
      }
      
        /// <summary>
	  ///A type of a folder. If specified,
	  ///Configuration Server will return information only about folders
	  ///of this type.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Type
      {
          set
          {
              this["type"] = value;
          }
          get
          {
              return GetInt("type");
          }
      }
      
        /// <summary>
	  ///A flag which selects among the folders belonging to some
	  ///owner object the topmost one, e.g. that which does not have a parent
	  ///folder above. Must be used in conjunction with 
	  ///<c>owner_type</c> and <c>owner_dbid</c> filters.
	  ///Most likely will be used with <c>type</c> filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int DefaultFolder
      {
          set
          {
              this["default_folder"] = value;
          }
          get
          {
              return GetInt("default_folder");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a subordinate
	  ///object. If specified, Configuration Server will return information
	  ///only about the folder that contains this object. Must be used in
	  ///conjunction with the <c>object_type</c> filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ObjectDbid
      {
          set
          {
              this["object_dbid"] = value;
          }
          get
          {
              return GetInt("object_dbid");
          }
      }
      
        /// <summary>
	  ///A type of a subordinate object.
	  ///Must be used in conjunction with the <c>object_dbid</c> filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int ObjectType
      {
          set
          {
              this["object_type"] = value;
          }
          get
          {
              return GetInt("object_type");
          }
      }
      
        /// <summary>
	  ///Current state of a folder (see type 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about folders that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///A class of a folder. If specified,
	  ///Configuration Server will return information only about folders
	  ///of this class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int FolderClass
      {
          set
          {
              this["folder_class"] = value;
          }
          get
          {
              return GetInt("folder_class");
          }
      }
      
  }














  /// <summary>
      ///The query class used to retrieve an object of type CfgGVPIVRProfile
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgGVPIVRProfileQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgGVPIVRProfileQuery class. This query will not be executable.
      /// </summary>
      public CfgGVPIVRProfileQuery() : base(CfgObjectType.CFGGVPIVRProfile)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgGVPIVRProfileQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgGVPIVRProfileQuery(IConfService confService) : base(CfgObjectType.CFGGVPIVRProfile, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgGVPIVRProfile object retrieved as a result of this operation</returns>
      public CfgGVPIVRProfile ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgGVPIVRProfile>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgGVPIVRProfile objects
      ///
      /// </summary>
      /// <returns>A collection of CfgGVPIVRProfile objects</returns>       
      public ICollection<CfgGVPIVRProfile> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgGVPIVRProfile>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgGVPIVRProfile objects</returns>
      public ICollection<CfgGVPIVRProfile> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgGVPIVRProfile>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a folder. If
	  ///specified, Configuration Server will return information only about
	  ///this folder.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a GVP IVR Profile. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the GVP IVR Profiles with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a tenant.
	  ///If specified, Configuration Server will return information only
	  ///about the GVP Voice Application Profiles that belong to this tenant. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int TenantDbid
      {
          set
          {
              this["tenant_dbid"] = value;
          }
          get
          {
              return GetInt("tenant_dbid");
          }
      }
      
        /// <summary>
	  ///Current state of a GVP IVR Profile (see type 
	  ///<c><see cref="CfgObjectState"/></c>). If specified, Configuration Server
	  ///will return information only about GVP IVR Profiles that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgScheduledTask
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgScheduledTaskQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgScheduledTaskQuery class. This query will not be executable.
      /// </summary>
      public CfgScheduledTaskQuery() : base(CfgObjectType.CFGScheduledTask)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgScheduledTaskQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgScheduledTaskQuery(IConfService confService) : base(CfgObjectType.CFGScheduledTask, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgScheduledTask object retrieved as a result of this operation</returns>
      public CfgScheduledTask ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgScheduledTask>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgScheduledTask objects
      ///
      /// </summary>
      /// <returns>A collection of CfgScheduledTask objects</returns>       
      public ICollection<CfgScheduledTask> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgScheduledTask>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgScheduledTask objects</returns>
      public ICollection<CfgScheduledTask> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgScheduledTask>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///Type of the ScheduledTask (see <c><see cref="CfgTaskType"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about the ScheduledTasks of this type. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgTaskType? TaskType
      {
          set
          {
              this["task_type"] = value;
          }
          get
          {
              return (CfgTaskType?)GetInt("task_type");
          }
      }
      
        /// <summary>
	  ///Current state of a ScheduledTask (see <c><see cref="CfgObjectState"/></c>).
	  ///If specified, Configuration Server will return information only
	  ///about ScheduledTasks that are currently in this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///Name of a ScheduledTask. Shall be specified
	  ///as a character string. If specified, Configuration Server will return
	  ///information only about the ScheduledTask(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///A unique identifier of a ScheduledTask. If
	  ///specified, Configuration Server will return information only about
	  ///this ScheduledTask.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
  }




  /// <summary>
      ///The query class used to retrieve an object of type CfgRole
      /// </summary>
      

[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
  public class CfgRoleQuery : CfgFilterBasedQuery
      {
      /// <summary>
      ///Creates an instance of the CfgRoleQuery class. This query will not be executable.
      /// </summary>
      public CfgRoleQuery() : base(CfgObjectType.CFGRole)
      {
      }

      /// <summary>
      ///Creates an instance of the CfgRoleQuery class. If an instance of the configuration service
      ///is provided, the query will be executable.
      ///</summary>
      ///<param name="confService">The configuration service to use when executing this query</param>
      public CfgRoleQuery(IConfService confService) : base(CfgObjectType.CFGRole, confService)
      {
      }

      /// <summary>
      /// Executes a query the result of which is a single object. Exception will
      /// be thrown if multiple objects are returned by the configuration server
      ///
      /// </summary>
      /// <returns>the CfgRole object retrieved as a result of this operation</returns>
      public CfgRole ExecuteSingleResult()
      {
#pragma warning disable 618
        return (this as ICfgQuery).ExecuteSingleResult<CfgRole>();
#pragma warning restore 618
      }

      /// <summary>
      /// Executes the query and returns a list of CfgRole objects
      ///
      /// </summary>
      /// <returns>A collection of CfgRole objects</returns>       
      public ICollection<CfgRole> Execute()
      {
#pragma warning disable 618
        return (this as ICfgQuery).Execute<CfgRole>();
#pragma warning restore 618
      }

      /// <summary>
      /// Called to retrieve the result of asynchronous BeginExecute operation.  Should be called on
      /// execution of AsyncCallback passed to BeginExecute. Will block
      /// calling thread until results are received if called before operation is completed.
      ///
      /// </summary>
      /// <param name="asyncResult">The IAsyncResult object used to track the current request</param>
      /// <returns>A list of CfgRole objects</returns>
      public ICollection<CfgRole> EndExecute(IAsyncResult asyncResult)
      {
#pragma warning disable 618
        return (this as ICfgQuery).EndExecute<CfgRole>(asyncResult);
#pragma warning restore 618
      }

                
        /// <summary>
	  ///A unique identifier of a role. If
	  ///specified, Configuration Server will return information only about
	  ///this role.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public int Dbid
      {
          set
          {
              this["dbid"] = value;
          }
          get
          {
              return GetInt("dbid");
          }
      }
      
        /// <summary>
	  ///Name of a role. Shall be specified
	  ///as a character string. If specified, Configuration Server will
	  ///return information only about the role(s) with that name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string Name
      {
          set
          {
              this["name"] = value;
          }
          get
          {
              return GetString("name");
          }
      }
      
        /// <summary>
	  ///Current state of a role (see 
	  ///<c><see cref="CfgObjectState"/></c>).
	  ///If specified, Configuration Server
	  ///will return information only about roles that are currently in
	  ///this state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public CfgObjectState? State
      {
          set
          {
              this["state"] = value;
          }
          get
          {
              return (CfgObjectState?)GetInt("state");
          }
      }
      
        /// <summary>
	  ///If specified , Configuration
	  ///Server will return information about all roles including current application user and containing userProperties string specified by filter.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
        public string RbacAppNs
      {
          set
          {
              this["rbac_app_ns"] = value;
          }
          get
          {
              return GetString("rbac_app_ns");
          }
      }
      
  }




}	
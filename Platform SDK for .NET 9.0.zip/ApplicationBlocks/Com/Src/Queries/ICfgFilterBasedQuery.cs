//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries
{
    using Genesyslab.Platform.Configuration.Protocols.ConfServer;
    using Genesyslab.Platform.Configuration.Protocols.Types;

    /// <summary>
    /// Each filter-based query object should implement this general interface
    /// </summary>
    public interface ICfgFilterBasedQuery
    {
        /// <summary>
        /// Used to retrieve filters by key for the current query
        /// </summary>
        /// <param name="key">filter name</param>
        /// <returns>filter value</returns>
        object this[string key] { get; set; }

        /// <summary>
        /// The Configuration Server object that the query corresponds to
        /// </summary>
        CfgObjectType QueryObjectType
        {
            get;
        }

        /// <summary>
        /// Gets hashtable collection with filter's key-value pairs.
        /// </summary>
        Hashtable Filter
        {
            get;
        }
        /// <summary>
        /// Gets hashtable collection with additional filter's key-value pairs which is in use only with sending request to server
        /// </summary>
        Hashtable ExtraFilter
        {
          get;
        }
        /// <summary>
        /// Gets/Sets filter option for notification of configuration server about need
        /// of the object path information to be collected and sent with the main objects data
        /// </summary>
        bool DoRequestObjectPath { get; set; }
        /// <summary>
        /// Gets/Sets filter option for notification of configuration server about need
        /// of the folder DBID information to be sent with the main objects data
        /// </summary>
        bool DoRequestFolderId { get; set; }
    }
}

//===============================================================================
// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using Genesyslab.Platform.Configuration.Protocols;
using System.Collections.ObjectModel;
using System.Xml.Linq;

namespace Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel
{
    internal class XmlPermissionsHelper
    {
        private XmlPermissionsHelper()
        {
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.ToString")]
        internal static XDocument CreatePermissionsObjectXml(int dbid, int type, string ns)
        {
            XDocument xmlObjectDocument = new XDocument();

            XDeclaration declarationNode = new XDeclaration("1.0", "UTF-8", "");
            xmlObjectDocument.Declaration = declarationNode;

            XElement xmlElement = new XElement(
                XName.Get("ConfData", ns));
            xmlObjectDocument.Add(xmlElement);

            XElement xmlObject = new XElement(
                XName.Get("CfgID", ns));

            XElement xmlCsidElement = new XElement(
                XName.Get("CSID", ns));

            xmlCsidElement.Add(new XAttribute("value", "0"));

            XElement xmlDbidElement = new XElement(
                XName.Get("DBID", ns));

            xmlDbidElement.Add(new XAttribute("value", dbid.ToString()));

            XElement xmlTypeElement = new XElement(
                XName.Get("type", ns));

            xmlTypeElement.Add(new XAttribute("value", type.ToString()));

            xmlObject.Add(xmlCsidElement);
            xmlObject.Add(xmlDbidElement);
            xmlObject.Add(xmlTypeElement);

            xmlObjectDocument.Root.Add(xmlObject);

            return xmlObjectDocument;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal static Collection<PermissionDescriptor> GetPermissionsList(XDocument doc)
        {
            Collection<PermissionDescriptor> resultList = new Collection<PermissionDescriptor>();

            XPathNavigator nav = doc.CreateNavigator();

            XmlNamespaceManager manager = new XmlNamespaceManager(nav.NameTable);

            manager.AddNamespace("ns", doc.Root.Name.NamespaceName);

            XPathNodeIterator iter = nav.Select("ns:ConfData/ns:CfgACL/ns:ACEs/ns:CfgACE", manager);

            while (iter.MoveNext())
            {
                int dbid = 0;
                int type = 0;
                int accessMask = 0;

                XPathNavigator dbidNode = iter.Current.SelectSingleNode("./ns:CfgACEID/ns:DBID", manager);

                if (dbidNode != null)
                {
                    dbid = Int32.Parse(dbidNode.GetAttribute("value", String.Empty));
                }

                XPathNavigator typeNode = iter.Current.SelectSingleNode("./ns:CfgACEID/ns:type", manager);

                if (typeNode != null)
                {
                    type = Int32.Parse(typeNode.GetAttribute("value", String.Empty));
                }

                XPathNavigator accessMaskNode = iter.Current.SelectSingleNode("./ns:accessMask", manager);

                if (accessMaskNode != null)
                {
                    accessMask = Int32.Parse(accessMaskNode.GetAttribute("value", String.Empty));
                }

                PermissionDescriptor permission = new PermissionDescriptor(dbid, type, accessMask);

                resultList.Add(permission);
            }

            return resultList;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.String.Format(System.String,System.Object,System.Object,System.Object)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.ToString"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.Parse(System.String)")]
        internal static XDocument CreateUpdateXml(XDocument oldDocNavigator, int accountDbid, int accountType, int newMask)
        {
            XDocument doc = new XDocument(oldDocNavigator);

            XPathNavigator nav = doc.CreateNavigator();

            XmlNamespaceManager manager = new XmlNamespaceManager(nav.NameTable);
            manager.AddNamespace("ns", doc.Root.Name.NamespaceName);

            string xpath = "/ns:ConfData/ns:CfgACL/ns:ACEs/ns:CfgACE[ns:CfgACEID/ns:DBID/@value='" + accountDbid.ToString() + "' and ns:CfgACEID/ns:type/@value = '" + accountType.ToString() + "']/ns:accessMask";

            XElement accessMaskNode = doc.XPathSelectElement(xpath, manager);

            if (accessMaskNode == null)
            {
                // no such dbid in users. Add a new entry
                xpath = "/ns:ConfData/ns:CfgACL/ns:ACEs";
                XElement newEntryNode = doc.XPathSelectElement(xpath, manager);

                if (newEntryNode == null)
                {
                    // this is some kind of mistake. The xml file that we get does not contain required entries
                    return null;
                }

                string newChild = String.Format("<CfgACE><CfgACEID><CSID value=\"0\" /><DBID value='{0}' /><type value='{1}' /></CfgACEID><accessMask value='{2}' /></CfgACE>",
                                                accountDbid, accountType, newMask);
                newEntryNode.Add(XElement.Parse(newChild));

                xpath = "/ns:ConfData/ns:CfgACL/ns:count";
                XElement countNode = doc.XPathSelectElement(xpath, manager);
                countNode.SetAttributeValue("value", Int32.Parse(countNode.Attribute("value").Value) + 1);
            }
            else
            {
                accessMaskNode.SetAttributeValue("value", newMask.ToString());
            }

            return doc;
        }

        internal static XDocument RemoveAccountFromPermissionsXml(XDocument oldPermissionsDoc, int accountDbid, int accountType)
        {
            if (oldPermissionsDoc == null) throw new ArgumentNullException("oldPermissionsDoc");

            XDocument doc = new XDocument(oldPermissionsDoc);

            XPathNavigator nav = doc.CreateNavigator();

            XmlNamespaceManager manager = new XmlNamespaceManager(nav.NameTable);
            manager.AddNamespace("ns", doc.Root.Name.NamespaceName);

            string xpath = "/ns:ConfData/ns:CfgACL/ns:ACEs/ns:CfgACE[ns:CfgACEID/ns:DBID/@value='" + accountDbid.ToString() + "' and ns:CfgACEID/ns:type/@value = '" + accountType.ToString() + "']";

            XElement aceNode = doc.XPathSelectElement(xpath, manager);

            if (aceNode != null)
            {
                aceNode.Remove();

                xpath = "/ns:ConfData/ns:CfgACL/ns:count";
                XElement countNode = doc.XPathSelectElement(xpath, manager);
                countNode.SetAttributeValue("value", Int32.Parse(countNode.Attribute("value").Value) - 1);
            }

            return doc;
        }

        
        internal static XDocument CreateCfgIdXml(int dbid, int type, string ns)
        {
            var doc = new XDocument();

            var declarationNode = new XDeclaration("1.0", "UTF-8", "");
            doc.Declaration = declarationNode;

            var confData = new XElement(XName.Get("ConfData", ns));
            doc.Add(confData);

            var csId = new XElement(XName.Get("CSID", ns));
            csId.Add(new XAttribute("value", "0"));

            var dbId = new XElement(XName.Get("DBID", ns));
            dbId.Add(new XAttribute("value", dbid.ToString(CultureInfo.InvariantCulture)));

            var cfgType = new XElement(XName.Get("type", ns));
            cfgType.Add(new XAttribute("value", type.ToString(CultureInfo.InvariantCulture)));

            var cfgId = new XElement(XName.Get("CfgID", ns));
            cfgId.Add(csId);
            cfgId.Add(dbId);
            cfgId.Add(cfgType);

            confData.Add(cfgId);

            return doc;
        }

        internal static XElement GetCfgId(XDocument confDoc)
        {
            if (confDoc == null) throw new ConfigException("confDoc in null");
            if (confDoc.Root == null) throw new ConfigException("confDoc's root element is null");

            var ns = confDoc.Root.Name.NamespaceName;
            var confData = confDoc.Element(XName.Get("ConfData", ns));
            if (confData == null)
                throw new ConfigException("missing ConfData node in" + confDoc);
            return confData.Element(XName.Get("CfgID", ns));
        }
    }
}

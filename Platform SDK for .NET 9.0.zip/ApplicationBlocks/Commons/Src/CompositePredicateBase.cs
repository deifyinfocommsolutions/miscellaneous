//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;

namespace Genesyslab.Platform.ApplicationBlocks.Commons
{
    /// <summary>
    /// <c>CompositePredicateBase&lt;T&gt;</c> class is an abstract base class that can consist of a set 
    /// of atomic predicates.
    /// </summary>
    /// <typeparam name="T">Type of the object to be used for checking the predicate condition.</typeparam>
    public abstract class CompositePredicateBase<T> : PredicateBase<T>
    {
        #region Fields

        private readonly List<IPredicate<T>> predicates;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Creates an instance of <c>CompositePredicateBase</c> class.
        /// </summary>
        /// <param name="isNegated">If true the predicate is considered as negated: 
        /// an analog of the logical '!' operation.</param>
        protected CompositePredicateBase(bool isNegated)
            : base(isNegated)
        {
            this.predicates = new List<IPredicate<T>>(2);
        }

        /// <summary>
        /// Creates an instance of <c>CompositePredicateBase</c> class.
        /// Composite predicate created with this constructor is an analog of a binary logical operation.
        /// </summary>
        /// <param name="p0">The first predicate.</param>
        /// <param name="p1">The second predicate.</param>
        protected CompositePredicateBase(IPredicate<T> p0, IPredicate<T> p1)
            : this()
        {
            AddPredicate(p0);
            AddPredicate(p1);
        }

        /// <summary>
        /// Creates an instance of <c>CompositePredicateBase</c> class.
        /// </summary>
        protected CompositePredicateBase()
            : base()
        {
            this.predicates = new List<IPredicate<T>>();
        }

        #endregion Constructors

        /// <summary>
        /// Adds a predicate to the predicates' set.
        /// </summary>
        /// <param name="predicate">Predicate to be added to the predicates' set.</param>
        public void AddPredicate(IPredicate<T> predicate)
        {
            if (predicate == null)
            {
                throw new ArgumentNullException("predicate", "predicate is null.");
            }

            if (this.predicates.Contains(predicate))
            {
                throw new ArgumentException("predicate was already added.", "predicate");
            }

            this.predicates.Add(predicate);
        }

        /// <summary>
        /// Removes a predicate from the predicates' set.
        /// </summary>
        /// <param name="predicate">Predicate to be removed from the predicates' set.</param>
        public void RemovePredicate(IPredicate<T> predicate)
        {
            if (predicate == null)
            {
                throw new ArgumentNullException("predicate", "predicate is null.");
            }

            if (this.predicates.Contains(predicate) == false)
            {
                throw new ArgumentException("predicate was not added.", "predicate");
            }

            this.predicates.Remove(predicate);
        }
        /// <exclude/>
        public IList<IPredicate<T>> Predicates
        {
            get { return this.predicates; }
        }
    }
}

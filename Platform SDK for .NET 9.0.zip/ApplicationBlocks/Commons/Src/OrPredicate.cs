//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

namespace Genesyslab.Platform.ApplicationBlocks.Commons
{
    /// <summary>
    /// <c>OrPredicate&lt;T&gt;</c> class realizes 'OR' logical operation.
    /// </summary>
    /// <typeparam name="T">Type of the object to be used for checking the predicate condition.</typeparam>
    public sealed class OrPredicate<T> : CompositePredicateBase<T>
    {
        #region Constructors

        /// <summary>
        ///  Creates an instance of <c>OrPredicate</c> class.
        /// <c>OrPredicate</c> predicate created with this constructor is an analog of an 'OR' binary logical operation.
        /// </summary>
        /// <param name="p0">The first predicate.</param>
        /// <param name="p1">The second predicate.</param>
        public OrPredicate(IPredicate<T> p0, IPredicate<T> p1)
            : base(p0, p1)
        {
        }

        /// <summary>
        ///  Creates an instance of <c>OrPredicate</c> class
        /// </summary>
        public OrPredicate()
            : base()
        {
        }

        /// <summary>
        /// Creates an instance of <c>OrPredicate</c> class.
        /// </summary>
        /// <param name="isNegated">If true the predicate is considered as negated: an analog of the logical 'NOT' operation.</param>
        public OrPredicate(bool isNegated)
            : base(isNegated)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Evaluates predicate's condition of being true or false.
        /// </summary>
        /// <param name="obj">Object to be used for checking the predicate condition.</param>
        /// <returns>Represents the truth or false of the predicate's condition.</returns>
        protected override bool Evaluate(T obj)
        {
            foreach (IPredicate<T> predicate in this.Predicates)
            {
                if (predicate.Invoke(obj) == true)
                {
                    return true;
                }
            }

            return false;
        }
    }
}

//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    ///<summary>
    /// Message Broker Application Block is deprecated. 
    /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
    /// </summary>
    /// <remarks>
    /// <c>BrokerServiceFactory</c> class implements factory for broker services,
    /// <see cref="EventReceivingBrokerService"/> and <see cref="RequestReceivingBrokerService"/> in particular.
    /// <p/>
    /// Example:
    /// <example>
    /// <code>
    ///    StatServerProtocol statProtocol = ...;
    ///    IAsyncInvoker invoker = new SingleThreadInvoker("statEventHandler");
    ///    EventReceivingBrokerService eventBroker =
    ///            BrokerServiceFactory.CreateEventBroker(statProtocol, invoker);
    ///
    ///    // register handler for the stat protocol messages:
    ///    eventBroker.Register(
    ///        new MyStatAction(),
    ///        new MessageFilter(statProtocol.ProtocolDescription)
    ///    );
    /// </code>
    /// </example>
    /// </remarks>
    [Obsolete("Use protocol.Received event to handle incoming messages asynchronously.")]
    public static class BrokerServiceFactory
    {
        /// <summary>
        /// Creates and activates an instance of <c>EventBrokerService</c> class.
        /// </summary>
        /// <param name="receiver">Initializes event message receiver</param>
        [Obsolete("Use overloaded method")]
        public static EventBrokerService CreateEventBroker(IMessageReceiver receiver)
        {
          EventBrokerService eventBroker=null;
          try
          {
            eventBroker = new EventBrokerService(receiver);
            eventBroker.Activate();
          }catch(Exception)
          {
            if (eventBroker!=null) eventBroker.Dispose();
            throw;
          }
          return eventBroker;
        }

        /// <summary>
        /// Creates and activates an instance of <c>RequestBrokerService</c> class.
        /// </summary>
        /// <param name="receiver">Initializes request message receiver</param>
        [Obsolete("Use overloaded method")]
        public static RequestBrokerService CreateRequestBroker(IRequestReceiver receiver)
        {
          RequestBrokerService requestBroker = null;
          try
          {
            requestBroker = new RequestBrokerService(receiver);
            requestBroker.Activate();
          }
          catch (Exception)
          {
            if (requestBroker!=null)
              requestBroker.Dispose();
            throw;
          }
          return requestBroker;
        }

        /// <summary>
        /// Creates broker service and initializes client protocol with it as with "external receiver".
        /// <p/>
        /// It is possible to use created service for other protocol connections:
        /// <example>
        /// <code>[C#]
        ///     EventReceivingBrokerService eventBroker =
        ///             BrokerServiceFactory.CreateEventBroker(statProtocol, invoker);
        ///
        ///     ixnProtocol.SetReceiver(eventBroker);
        ///     routingProtocol.SetReceiver(eventBroker);
        ///
        ///     // register handler for the stat protocol messages:
        ///     eventBroker.Register(
        ///         new MyStatAction(),
        ///         new MessageFilter(statProtocol.ProtocolDescription)
        ///     );
        ///
        ///     // register handler for all of the protocols messages:
        ///     eventBroker.Register(new MyAction(), null);
        ///     ...
        /// </code>
        /// </example>
        /// <see cref="IMessageReceiverManagement.SetReceiver"/>
        /// </summary>
        /// <param name="protocol">client protocol connection to distribute messages from (usually it's some protocol connection)</param>
        /// <param name="invoker">invoker to be used for messages publishing</param>
        /// <returns>initialized broker service instance</returns>
        public static EventReceivingBrokerService CreateEventBroker(IMessageReceiverManagement protocol,
                 IAsyncInvoker invoker)
        {
            EventReceivingBrokerService broker = new EventReceivingBrokerService(invoker);
            protocol.SetReceiver(broker);
            return broker;
        }

        /// <summary>
        /// Creates broker service and initializes server channel with it as with "external receiver".
        /// <p/>
        /// When the brokers' invoker handles some client message, all other clients/requests are waiting,
        /// so, server side handler must execute request messages fast and schedule long tasks to other threads.
        /// <see cref="IRequestReceiverManagement.SetReceiver"/>
        /// </summary>
        /// <param name="protocol">server channel to distribute clients requests from (it can be some ServerChannel instance)</param>
        /// <param name="invoker">invoker to be used for requests messages handling</param>
        /// <returns>initialized broker service instance</returns>
        public static RequestReceivingBrokerService CreateRequestBroker(IRequestReceiverManagement protocol,
                IAsyncInvoker invoker)
        {
            RequestReceivingBrokerService broker = new RequestReceivingBrokerService(invoker);
            protocol.SetReceiver(broker);
            return broker;
        }
    }
}

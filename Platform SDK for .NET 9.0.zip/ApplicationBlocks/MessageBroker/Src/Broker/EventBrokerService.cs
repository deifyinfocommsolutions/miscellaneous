//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    ///<summary>
    /// Message Broker Application Block is deprecated. 
    /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
    /// </summary>
    /// <remarks>
    /// <c>EventBrokerService</c> class is designed to work with event/response messages.
    /// <example>
    /// <code>[c#]
    ///     const string protocolName = "Configuration";
    /// 
    ///     public void Initialize()
    ///     {
    ///         Endpoint endpoint = new Endpoint(protocolName, "hostname", 9999);
    ///         ConfServerProtocol protocol = new ConfServerProtocol(endpoint);
    ///         protocol.ClientType = (int)ConfServerClientType.SCE;
    ///		    protocol.ClientName = "clientname";
    ///		    protocol.UserName = "default";
    ///		    protocol.UserPassword = "password";
    /// 
    ///         EventBrokerService eventBroker = BrokerServiceFactory.CreateEventBroker(protocol);
    ///         eventBroker.Register(this.OnConfServerEvent);
    ///     }
    /// 
    ///     [MessageRangeFilter(
    ///             new int[]   {     
    ///                             EventError.Id, 
    ///                             EventObjectDeleted.Id, 
    ///                             EventObjectsRead.Id, 
    ///                             EventObjectCreated.Id, 
    ///                             EventObjectUpdated.Id 
    ///                         }, 
    ///             ProtocolName = protocolName)]
    ///     private void OnConfServerEvent(IMessage obj)
    ///     {
    ///         Console.WriteLine(obj);
    ///     }
    /// </code>
    /// </example>   
    /// </remarks>
    [Obsolete("Use protocol.Received event to handle incoming messages asynchronously.")]
    public sealed class EventBrokerService : MessageBrokerService<IMessage>
    {
        #region Fields

        private IMessageReceiver receiver;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Creates an instance of <c>EventBrokerService</c> class. 
        /// When using this constructor the following additional steps should be done to set the service in working state:
        /// setting the invoker - property <c>Invoker</c>;
        /// setting the receiver - property <c>Receiver</c>;
        /// calling <c>Activation</c> method.
        /// </summary>
        public EventBrokerService()
        {
        }

        /// <summary>
        /// Creates an instance of <c>EventBrokerService</c> class.
        /// </summary>
        /// <param name="receiver">Initializes message receiver.</param>
        public EventBrokerService(IMessageReceiver receiver)
            : base(new SingleThreadInvoker("messageBroker.defaultInvoker"))
        {
            if (receiver == null)
            {
                throw new ArgumentNullException("receiver", "Receiver can't be null.");
            }
            this.receiver = receiver;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets/sets message receiver.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String,System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentNullException.#ctor(System.String,System.String)")]
        public IMessageReceiver Receiver
        {
            get
            {
                return this.receiver;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value", "Value can't be null.");
                }

                lock (this.lifecycleLock)
                {
                    if (this.status == LifecycleStage.Disposed)
                    {
                        throw new ObjectDisposedException(this.GetType().Name);
                    }

                    if (this.status != LifecycleStage.Initialized)
                    {
                        throw new InvalidOperationException("Can't change Receiver when broker is active.");
                    }

                    this.receiver = value;
                }
            }
        }

        #endregion Properties

        #region Implementation Members

        /// <summary>
        /// Disposes of the service. Implements the Basic Dispose Pattern.
        /// </summary>
        /// <param name="disposing">
        /// <c>false</c> indicates that the method was invoked from the finalizer,
        /// in this case reference objects should not be accessed.
        /// </param>
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            if (disposing)
            {
                this.receiver = null;
            }
        }

        /// <summary>
        /// Receives event messages.
        /// </summary>
        /// <returns>Returns an event message.</returns>
        protected override IMessage Receive()
        {
            return Receiver.Receive();
        }

        /// <summary>
        /// Gets/sets generic receiver. Generic receiver is able to receive both: event and request messages.
        /// </summary>
        protected override IReceiver GenericReceiver
        {
            get
            {
                return Receiver;
            }
        }

        #endregion Implementation Members
    }
}

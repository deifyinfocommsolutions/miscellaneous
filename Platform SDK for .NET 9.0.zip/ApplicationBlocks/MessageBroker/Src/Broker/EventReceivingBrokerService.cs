// ===============================================================================
//
//  Any authorized distribution of any copy of this code (including any related
//  documentation) must reproduce the following restrictions, disclaimer and copyright
//  notice:
//
//  The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name
//  (even as a part of another name), endorse and/or promote products derived from
//  this code without prior written permission from Genesys Telecommunications
//  Laboratories, Inc.
//
//  The use, copy, and/or distribution of this code is subject to the terms of the Genesys
//  Developer License Agreement.  This code shall not be used, copied, and/or
//  distributed under any other license agreement.
//
//  THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC.
//  ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY
//  DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND
//  WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT
//  NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
//  PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL
//  NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
//  EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT
//  NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).
//
//  Copyright (c) 2007-2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.
// ===============================================================================
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;
using System;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
   ///<summary>
   /// Message Broker Application Block is deprecated. 
   /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
   /// </summary>
    /// <remarks>
   /// <c>EventReceivingBrokerService</c> class was designed to work with event/response messages.
   ///  See also <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event.
   /// <example>
   /// <code>[C#]
   ///     string protocolName = "Configuration";
   ///     ConfServerProtocol protocol;
   ///     EventReceivingBrokerService eventBroker;
   ///
   ///     public void Initialize() 
   ///     {
   ///         Endpoint endpoint = new Endpoint(protocolName, "hostname", 9999);
   ///         protocol = new ConfServerProtocol(endpoint);
   ///         protocol.ClientApplicationType = CfgAppType.CFGSCE;
   ///         protocol.ClientName = "clientname";
   ///         protocol.UserName = "user1";
   ///         protocol.UserPassword = "user1-password";
   ///
   ///         eventBroker = new EventReceivingBrokerService(
   ///                         new SingleThreadInvoker("EventReceivingBrokerService-1"));
   ///         protocol.SetReceiver(eventBroker);
   ///         eventBroker.Register(
   ///             new Action&lt;IMessage&gt;(handle),
   ///             new MessageFilter(protocol.ProtocolDescription)
   ///         );
   ///     }
   ///
   ///     public void handle(IMessage msg) 
   ///     {
   ///         Console.WriteLine("Incoming message: " + msg);
   ///     }
   /// </code>   
   ///    
   /// </example>    
   /// 
   /// Broker service can be shared between several protocol connections (may be of different type):
   /// 
   /// <example>
   /// <code>[C#]
   ///     ...
   ///     statProtocol.SetReceiver(eventBroker);
   ///     ixnProtocol.SetReceiver(eventBroker);
   ///     routingProtocol.SetReceiver(eventBroker);
   ///
   ///     // register handler for the stat protocol messages:
   ///     eventBroker.Register(
   ///         new MyStatAction(),
   ///         new MessageFilter(statProtocol.ProtocolDescription)
   ///     );
   ///
   ///     // register handler for all of the protocols messages:
   ///     eventBroker.Register(new MyAction(), null);
   ///     ...
   /// </code>
   /// 
   ///
   /// By this way <code>eventBroker</code> will handle all incoming messages from all initialized
   /// protocols one by one, using its invoker.
   ///
   /// </example>
   /// </remarks>  
    [Obsolete("Use protocol.Received event to handle incoming messages asynchronously.")]
    public class EventReceivingBrokerService : AsyncBrokerServiceBase<IMessage>, IMessageReceiverSupport
    {
        /// <summary>
        /// Creates an instance of <code>EventReceivingBrokerService</code> class.
        /// <see cref="AsyncBrokerServiceBase&lt;T&gt;.Invoker"/>
        /// </summary>
        public EventReceivingBrokerService()
        {
        }

        /// <summary>
        /// Creates an instance of <code>EventReceivingBrokerService</code> class.
        /// </summary>
        /// <param name="invoker">invoker to be used for requests messages handling</param>
        public EventReceivingBrokerService(IAsyncInvoker invoker)
            : base(invoker)
        {
        }

        #region IMessageReceiverSupport Members

        /// <exclude/>
        public void ProcessMessage(IMessage message)
        {
            Publish(message);
        }

        #endregion

        #region IMessageReceiver Members

        /// <exclude/>
        public IMessage Receive(System.TimeSpan timeout)
        {
            throw new NotSupportedException("BrokerService delivers messages by subscription");
        }

        /// <exclude/>
        public IMessage Receive()
        {
            throw new NotSupportedException("BrokerService delivers messages by subscription");
        }

        #endregion

        #region IReceiver Members

        /// <exclude/>
        public void ClearInput()
        {
            // We have no own queue to clear, so - do nothing
        }

        /// <exclude/>
        public int InputSize
        {
            get
            {
                // We have no own queue - all messages are passed through
                return 0;
            }
            set
            {
                // We have no own queue
            }
        }

        /// <exclude/>
        public void ReleaseReceivers()
        {
        }

        #endregion
    }
}

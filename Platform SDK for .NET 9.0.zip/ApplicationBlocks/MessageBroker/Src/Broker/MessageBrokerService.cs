//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Threading;

using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    ///<summary>
    /// Message Broker Application Block is deprecated. 
    /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
    /// </summary>
    /// <remarks>
    /// <c>MessageBrokerService&lt;T&gt;</c> class implements the Publish/Subscribe pattern.
    /// See also <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event.
    /// </remarks>
    /// <typeparam name="T">Type of event to be processed by subscribers.</typeparam>
    [Obsolete("Use protocol.Received event to handle incoming messages asynchronously.")]
    public abstract class MessageBrokerService<T> : BrokerServiceBase<T>, IDisposable
    {
        #region Types

        internal enum LifecycleStage
        {
            Initialized,
            Activated,
            Disposed
        }

        #endregion Types

        #region Fields

        internal volatile LifecycleStage status;
        internal readonly object lifecycleLock;
        internal readonly object invokerLock;
        private volatile bool isActive;
        private IAsyncInvoker invoker;
        private bool disposeInvoker;
        private readonly AutoResetEvent activationEvent;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Creates an instance of <c>MessageBrokerService</c> class.
        /// </summary>
        /// <param name="invoker">Initializes asynchronous invoker.</param>
        protected MessageBrokerService(IAsyncInvoker invoker)
            : this()
        {
            this.invoker = invoker;
            this.disposeInvoker = true;
        }

        /// <summary>
        /// Creates an instance of <c>MessageBrokerService</c> class.
        /// </summary>
        protected MessageBrokerService()
        {
            this.activationEvent = new AutoResetEvent(false);
            this.lifecycleLock = new object();
            this.invokerLock = new object();
            this.status = LifecycleStage.Initialized;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets/sets asynchronous invoker.
        /// </summary>
        public IAsyncInvoker Invoker
        {
            get
            {
                lock (this.invokerLock)
                {
                    if (this.invoker == null)
                    {
                        this.disposeInvoker = true;
                        this.invoker = new SingleThreadInvoker("messageBroker.defaultInvoker");
                    }
                    return this.invoker;
                }
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value", "Value can't be null.");
                }

                lock (this.lifecycleLock)
                {
                    if (this.status == LifecycleStage.Disposed)
                    {
                        throw new ObjectDisposedException(this.GetType().Name);
                    }

                    if (this.status != LifecycleStage.Initialized)
                    {
                        throw new InvalidOperationException("Can't change Invoker when broker is active.");
                    }

                    lock (this.invokerLock)
                    {
                        DisposeInvoker();
                        this.invoker = value;
                    }
                }
            }
        }

        /// <summary>
        /// Checks if the service is active.
        /// </summary>
        public bool IsActive
        {
            get
            {
                return this.status == LifecycleStage.Activated;
            }
        }

        #endregion Properties

        /// <summary>
        /// Activates the service.
        /// </summary>
        public void Activate()
        {
            lock (this.lifecycleLock)
            {
                if (this.status == LifecycleStage.Disposed)
                {
                    throw new ObjectDisposedException(this.GetType().Name);
                }

                if (this.status == LifecycleStage.Activated)
                    return;

                if (Invoker == null)
                {
                    throw new InvalidOperationException("Invoker is null.");
                }

                if (GenericReceiver == null)
                {
                    throw new InvalidOperationException("Receiver is null.");
                }

                this.isActive = true;
                Invoker.Invoke(this.Process, null);
                this.activationEvent.WaitOne();

                this.status = LifecycleStage.Activated;
            }
        }

        /// <summary>
        /// Deactivates the service.
        /// </summary>
        public void Deactivate()
        {
            lock (this.lifecycleLock)
            {
                if (this.status == LifecycleStage.Disposed)
                {
                    throw new ObjectDisposedException(this.GetType().Name);
                }

                if (this.status == LifecycleStage.Initialized)
                    return;

                this.isActive = false;
                GenericReceiver.ReleaseReceivers();
                this.activationEvent.WaitOne();

                this.status = LifecycleStage.Initialized;
            }
        }

        #region IDisposable Members

        /// <summary>
        /// Disposes of the service. Implements the Basic Dispose Pattern.
        /// </summary>
        public void Dispose()
        {
            lock (this.lifecycleLock)
            {
                if (this.status != LifecycleStage.Disposed)
                {
                    Dispose(true);
                    this.status = LifecycleStage.Disposed;
                    GC.SuppressFinalize(this);
                }
            }
        }

        #endregion

        #region Implementation Members

        /// <summary>
        /// Disposes of the service. Implements the Basic Dispose Pattern.
        /// </summary>
        /// <param name="disposing">
        /// <c>false</c> indicates that the method was invoked from the finalizer,
        /// in this case reference objects should not be accessed.
        /// </param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (IsActive)
                {
                    Deactivate();
                }

                this.activationEvent.Close();
                DisposeInvoker();
                UnregisterAll();
            }
        }

        private void DisposeInvoker()
        {
            if (this.disposeInvoker)
            {
                IDisposable disposable = this.invoker as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
                this.disposeInvoker = false;
            }

            this.invoker = null;
        }

        private void Process(object state)
        {
            this.activationEvent.Set();

            while (this.isActive)
            {
                T obj = Receive();

                if ((obj as object) != null)
                {
                    try
                    {
                        Publish(obj);
                    }
                    catch (Exception ex)
                    {
                        if (Logger.IsErrorEnabled)
                        {
                            Logger.ErrorFormat("Exception in Message Broker working thread: {0} \n", ex);
                        }
                    }
                }

            }

            this.activationEvent.Set();
        }

        /// <summary>
        /// Receives messages. An abstract method to be defined in subclasses.
        /// </summary>
        /// <returns>Returns received message object.</returns>
        protected abstract T Receive();

        /// <summary>
        /// Gets message receiver. An abstract property to be defined in subclasses.
        /// </summary>
        protected abstract IReceiver GenericReceiver
        {
            get;
        }

        #endregion Implementation Members
    }
}

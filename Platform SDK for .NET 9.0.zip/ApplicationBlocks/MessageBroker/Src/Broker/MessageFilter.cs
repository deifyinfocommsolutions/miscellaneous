//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    ///<summary>
    /// Message Broker Application Block is deprecated. 
    /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
    /// </summary>
    /// <remarks>
    /// <c>MessageFilter</c> class is designed for filtering messages using protocol description and endpoint 
    /// name as evaluation criteria.
    /// </remarks>
    [Obsolete("Message Broker Application Block is deprecated")]
    public class MessageFilter : PredicateBase<IMessage>
    {
        #region Fields

        private ProtocolDescription protocolDescription;
        private string endpointName;
        private int? protocolId;

        #endregion Fields

        #region Constructors

        /// <summary>
        ///  Creates an instance of <c>MessageFilter</c> class.
        /// </summary>
        /// <param name="isNegated">If <c>true</c> - the predicate is considered as negated: an analog of the logical 'NOT' operation.</param>
        /// <param name="protocolDescription">Description of protocol.</param>
        /// <param name="endpointName">Name of endpoint.</param>
        public MessageFilter(bool isNegated, ProtocolDescription protocolDescription, string endpointName)
            : base(isNegated)
        {
            this.protocolDescription = protocolDescription;
            this.endpointName = endpointName;
        }

        /// <summary>
        ///  Creates an instance of <c>MessageFilter</c> class.
        /// </summary>
        /// <param name="protocolDescription">Description of protocol.</param>
        /// <param name="endpointName">Name of endpoint.</param>
        public MessageFilter(ProtocolDescription protocolDescription, string endpointName)
            : this(false, protocolDescription, endpointName)
        {
        }

        /// <summary>
        ///  Creates an instance of <c>MessageFilter</c> class.
        /// </summary>
        /// <param name="isNegated">If <c>true</c> - the predicate is considered as negated: an analog of the logical 'NOT' operation.</param>
        /// <param name="protocolDescription">Description of protocol.</param>
        public MessageFilter(bool isNegated, ProtocolDescription protocolDescription)
            : this(isNegated, protocolDescription, null)
        {
        }

        /// <summary>
        ///  Creates an instance of <c>MessageFilter</c> class.
        /// </summary>
        /// <param name="protocolDescription">Description of protocol.</param>
        public MessageFilter(ProtocolDescription protocolDescription)
            : this(false, protocolDescription, null)
        {
        }

        /// <summary>
        ///  Creates an instance of <c>MessageFilter</c> class.
        /// </summary>
        /// <param name="isNegated">If <c>true</c> - the predicate is considered as negated: an analog of the logical 'NOT' operation.</param>
        public MessageFilter(bool isNegated)
            : base(isNegated)
        {
        }

        /// <summary>
        ///  Creates an instance of <c>MessageFilter</c> class.
        /// </summary>
        public MessageFilter()
        {
        }

        /// <summary>
        ///  Creates an instance of <c>MessageFilter</c> class.
        /// </summary>
        /// <param name="protocolId">The protocol's unique identifier as specified by its ProtocolId property</param>
        public MessageFilter(int protocolId)
        {
            this.protocolId = protocolId;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the value of the protocol's unique identifier
        /// </summary>
        public int? ProtocolId
        {
            get { return protocolId; }
        }

        /// <summary>
        ///  Gets/Sets protocol description
        /// </summary>
        public ProtocolDescription ProtocolDescription
        {
            get
            {
                return this.protocolDescription;
            }
            set
            {
                this.protocolDescription = value;
            }
        }

        /// <summary>
        ///  Gets/Sets endpoint name
        /// </summary>
        public string EndpointName
        {
            get
            {
                return this.endpointName;
            }
            set
            {
                this.endpointName = value;
            }
        }

        #endregion Properties

        /// <summary>
        /// Evaluates a message using protocol description, endpoint name, and protocolId as criteria.
        /// </summary>
        /// <remarks>
        /// The filter is evaluated as an "and" comparison of those of the above attributes which
        /// have been assigned a value. For example, if the protocol description and endpoint are 
        /// specified while protocolId isn't, protocolId will be ignored in the evaluation and this method
        /// will return true if both the endpoint and protocol description match the values
        /// in IMessage.
        /// </remarks>
        /// <param name="obj">A message targeted for evaluation.</param>
        /// <returns>Returns <c>true</c> if the filter's properties match their counterparts in 
        /// IMessage,otherwise returns <c>false</c>.
        /// </returns>
        protected override bool Evaluate(IMessage obj)
        {
            if (obj == null)
            {
                throw new ArgumentNullException("obj");
            }

            if (ProtocolId != null && !ProtocolId.Equals(obj.ProtocolId))
            {
                return false;
            }

            if (ProtocolDescription != null && !ProtocolDescription.Equals(obj.ProtocolDescription))
            {
                return false;
            }

            if (!string.IsNullOrEmpty(EndpointName) && string.Compare(EndpointName, obj.Endpoint.Name) != 0)
            {
                return false;
            }

            return true;
        }
    }
}

//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    ///<summary>
    /// Message Broker Application Block is deprecated. 
    /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
    /// </summary>
    /// <remarks>
    /// <c>MessageNameFilterAttribute</c> indicates <c>MessageNameFilter</c> for a method that will handle a message.
    /// </remarks>
    [Obsolete("Message Broker Application Block is deprecated")]
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    public sealed class MessageNameFilterAttribute : SubscriptionFilterAttribute
    {
        #region Fields

        private bool isNegated;
        private string protocolName;
        private string sdkName;
        private string messageName;

        #endregion Fields

        #region Constructors

        /// <summary>
        ///  Creates an instance of <c>MessageNameFilterAttribute</c> class.
        /// </summary>
        /// <param name="messageName">Initializes message name property.</param>
        public MessageNameFilterAttribute(string messageName)
        {
            if (messageName == null)
            {
                throw new ArgumentNullException("messageName", "MessageName is null.");
            }
            this.messageName = messageName;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets/Sets negated state of the attribute. 
        /// If an object is in negated state a logical 'NOT' is applied to all the object's logical operations.
        /// </summary>
        public bool IsNegated
        {
            get { return this.isNegated; }
            set { this.isNegated = value; }
        }

        /// <summary>
        /// Gets/Sets protocol name. 
        /// </summary>
        public string ProtocolName
        {
            get { return this.protocolName; }
            set { this.protocolName = value; }
        }

        /// <summary>
        /// Gets/Sets sdk name. 
        /// </summary>
        public string SdkName
        {
            get { return this.sdkName; }
            set { this.sdkName = value; }
        }

        /// <summary>
        /// Gets/Sets message name. 
        /// </summary>
        public string MessageName
        {
            get { return this.messageName; }
        }

        #endregion Properties

        public override object GetFilter()
        {
            return new MessageNameFilter(this.isNegated, new ProtocolDescription(SdkName, ProtocolName), this.messageName);
        }
    }
}

//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    ///<summary>
    /// Message Broker Application Block is deprecated. 
    /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
    /// </summary>
    /// <remarks>
    /// <c>MessageRangeFilter</c> uses message id as evaluation criteria.
    /// <c>MessageRangeFilter</c> contains a set of valid message ids that is used for checking if a message's id
    /// present in the set.
    /// </remarks>
    [Obsolete("Message Broker Application Block is deprecated")]
    public sealed class MessageRangeFilter : MessageFilter
    {
        #region Fields

        private int[] messages;

        #endregion Fields

        #region Constructors

        /// <summary>
        ///  Creates an instance of <c>MessageRangeFilter</c> class.
        /// </summary>
        /// <param name="messagesRange">Initializes message range.</param>
        public MessageRangeFilter(int[] messagesRange)
            : base()
        {
            Validate(messagesRange);
            Initialize(messagesRange);
        }

        /// <summary>
        ///  Creates an instance of <c>MessageRangeFilter</c> class.
        /// </summary>
        /// <param name="isNegated">If <c>true</c> - the predicate is considered as negated: an analog of the logical 'NOT' operation.</param>
        /// <param name="messagesRange">Initializes message range..</param>
        public MessageRangeFilter(bool isNegated, int[] messagesRange)
            : base(isNegated)
        {
            Validate(messagesRange);
            Initialize(messagesRange);
        }

        /// <summary>
        ///  Creates an instance of <c>MessageRangeFilter</c> class.
        /// </summary>
        /// <param name="protocolDescription">Initializes protocol description..</param>
        /// <param name="messagesRange">Initializes message range..</param>
        public MessageRangeFilter(ProtocolDescription protocolDescription, int[] messagesRange)
            : base(protocolDescription)
        {
            Validate(messagesRange);
            Initialize(messagesRange);
        }

        /// <summary>
        ///  Creates an instance of <c>MessageRangeFilter</c> class.
        /// </summary>
        /// <param name="isNegated">If <c>true</c> - the predicate is considered as negated: an analog of the logical 'NOT' operation.</param>
        /// <param name="protocolDescription">Initializes protocol description.</param>
        /// <param name="messagesRange">Initializes message range.</param>
        public MessageRangeFilter(bool isNegated, ProtocolDescription protocolDescription, int[] messagesRange)
            : base(isNegated, protocolDescription)
        {
            Validate(messagesRange);
            Initialize(messagesRange);
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        ///  Gets/Sets the set of valid message ids
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public int[] MessagesRange
        {
            get
            {
                return this.messages;
            }
            set
            {
                Validate(value);
                Initialize(value);
            }

        }

        #endregion Properties

        /// <summary>
        /// Evaluates a message using message id as evaluation criteria.
        /// </summary>
        /// <param name="obj">A message targeted for evaluation.</param>
        /// <returns>Returns <c>true</c> if the obj's message id present in the set of the valid message ids,
        /// otherwise retuens <c>false</c>
        /// </returns>
        protected override bool Evaluate(IMessage obj)
        {
            if (!base.Evaluate(obj))
            {
                return false;
            }

            return (Array.BinarySearch<int>(this.messages, obj.Id) >= 0);
        }

        #region Implementation Members

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2208:InstantiateArgumentExceptionsCorrectly")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String,System.String)")]
        private static void Validate(int[] messagesRange)
        {
            if (messagesRange == null)
            {
                throw new ArgumentNullException("messageName", "messageName is null.");
            }

            if (messagesRange.Length == 0)
            {
                throw new ArgumentException("messageName is empty.", "messageName");
            }
        }

        private void Initialize(int[] messagesRange)
        {
            this.messages = new int[messagesRange.Length];
            messagesRange.CopyTo(this.messages, 0);
            Array.Sort<int>(this.messages);
        }

        #endregion Implementation Members
    }
}

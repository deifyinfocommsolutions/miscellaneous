//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;

using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Broker
{
    ///<summary>
    /// Message Broker Application Block is deprecated. 
    /// Use <see cref="Genesyslab.Platform.Commons.Protocols.DuplexChannel.Received"></see> event to handle incoming messages asynchronously.
    /// </summary>
    /// <remarks>
    /// <c>RequestBrokerService</c> class is designed to work with request messages.
    /// <example>
    /// <code>[c#]
    ///     public void Initialize()
    ///     {
    ///         ExternalServiceProtocolListener requestListener = 
    ///             new ExternalServiceProtocolListener(new Endpoint(Program.ServerName, new Uri("tcp://localhost:9999")));
    ///         this.requestBroker = BrokerServiceFactory.CreateRequestBroker(requestListener);
    ///         this.requestBroker.Register(OnRequest);
    ///         requestListener.Open();
    ///     }
    ///     
    ///     private void OnRequest(IRequestContext msg)
    ///     {
    ///        if( this.logger.IsInfoEnabled ) this.logger.InfoFormat("New Request Arrived: {0}", msg);
    ///     }
    /// </code>
    /// </example>
    /// </remarks>
    [Obsolete("Use protocol.Received event to handle incoming messages asynchronously.")]
    public sealed class RequestBrokerService : MessageBrokerService<IRequestContext>
    {
        #region Fields

        private IRequestReceiver receiver;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Creates an instance of <c>RequestBrokerService</c> class.
        /// When using this constructor the following additional steps should be done to set the service in working state:
        /// setting the invoker - property <c>Invoker</c>;
        /// setting the receiver - property <c>Receiver</c>;
        /// calling <c>Activation</c> method.
        /// </summary>
        public RequestBrokerService()
        {
        }

        /// <summary>
        /// Creates an instance of <c>RequestBrokerService</c> class.
        /// </summary>
        /// <param name="receiver">Initializes request receiver</param>
        public RequestBrokerService(IRequestReceiver receiver)
            : base(new SingleThreadInvoker("messageBroker.defaultInvoker"))
        {
            if (receiver == null)
            {
                throw new ArgumentNullException("receiver", "Receiver can't be null.");
            }
            this.receiver = receiver;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets/sets request receiver.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String,System.String)")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentNullException.#ctor(System.String,System.String)")]
        public IRequestReceiver Receiver
        {
            get
            {
                return this.receiver;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value", "Value can't be null.");
                }

                lock (this.lifecycleLock)
                {
                    if (this.status == LifecycleStage.Disposed)
                    {
                        throw new ObjectDisposedException(this.GetType().Name);
                    }

                    if (this.status != LifecycleStage.Initialized)
                    {
                        throw new InvalidOperationException("Can't change Receiver when broker is active.");
                    }

                    this.receiver = value;
                }
            }
        }

        #endregion Properties

        #region ISubscriptionService<T> Members

        /// <summary>
        /// Implementation of <c>Register(Action&lt;T&gt; handler)</c> method of <c>ISubscriptionService&lt;T&gt;</c> 
        /// interface. Registers an action to be performed upon receiving a request message.
        /// Implements subscription functionality of the Publish/Subscribe pattern.
        /// The method also processes the filter custom attributes which allows a user to define filters 
        /// externally.
        /// </summary>
        /// <param name="handler">Represents the method that performs an action on the specified object
        /// when a publishing event occurs.</param> 
        public override void Register(Action<IRequestContext> handler)
        {
            if (handler == null)
            {
                throw new ArgumentNullException("handler", "Handler is null.");
            }

            IPredicate<IRequestContext> filter = null;

            SubscriptionFilterAttribute[] filterAttributes = (SubscriptionFilterAttribute[])handler.Method.GetCustomAttributes(typeof(SubscriptionFilterAttribute), true);
            if (filterAttributes.Length == 1)
            {
                IPredicate<IRequestContext> requestFilter = filterAttributes[0].GetFilter() as IPredicate<IRequestContext>;
                if (requestFilter == null)
                {
                    IPredicate<IMessage> messageFilter = filterAttributes[0].GetFilter() as IPredicate<IMessage>;
                    if (messageFilter != null)
                    {
                        requestFilter = new RequestFilter(messageFilter);
                    }
                }

                filter = requestFilter;
            }
            else if (filterAttributes.Length > 1)
            {
                OrPredicate<IRequestContext> or = new OrPredicate<IRequestContext>();

                foreach (SubscriptionFilterAttribute filterAttribute in filterAttributes)
                {

                    IPredicate<IRequestContext> requestFilter = filterAttribute.GetFilter() as IPredicate<IRequestContext>;
                    if (requestFilter == null)
                    {
                        IPredicate<IMessage> messageFilter = filterAttribute.GetFilter() as IPredicate<IMessage>;
                        if (messageFilter != null)
                        {
                            requestFilter = new RequestFilter(messageFilter);
                        }
                    }

                    if (requestFilter != null)
                    {
                        or.AddPredicate(requestFilter);
                    }
                }

                if (or.Predicates.Count != 0)
                {
                    filter = or;
                }
            }

            Register(handler, filter); ;
        }

        /// <summary>
        /// Implementation of 'Register(Action&lt;T&gt; handler, IPredicate&lt;T&gt; filter)' method of ISubscriptionService interface.
        /// Subscribes an action to be performed when upon receiving a request message.
        /// Implements subscription functionality of the Publish/Subscribe pattern.
        /// </summary>
        /// <param name="handler">Represents the method that performs an action on the specified object
        /// upon receiving a request message.</param>
        /// <param name="filter">Filter predicate that allows checking whether request message should 
        /// be processed or ignored.</param>
        public void Register(Action<IRequestContext> handler, IPredicate<IMessage> filter)
        {
            Register(handler, new RequestFilter(filter));
        }

        #endregion ISubscriptionService<T> Members

        #region Implementation Members

        /// <summary>
        /// Disposes of the service. Implements the Basic Dispose Pattern.
        /// </summary>
        /// <param name="disposing">
        /// <c>false</c> indicates that the method was invoked from the finalizer,
        /// in this case reference objects should not be accessed.
        /// </param>
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            if (disposing)
            {
                this.receiver = null;
            }
        }

        /// <summary>
        /// Receives request messages.
        /// </summary>
        /// <returns>Returns request context of received message.</returns>
        protected override IRequestContext Receive()
        {
            return Receiver.ReceiveRequest();
        }

        /// <summary>
        /// Gets generic receiver. Generic receiver is able to receive both: event and request messages.
        /// </summary>
        protected override IReceiver GenericReceiver
        {
            get { return Receiver; }
        }

        #endregion Implementation Members
    }
}

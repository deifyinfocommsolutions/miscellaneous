//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

//===============================================================================

#define ProtectUserPasswordFeatureDisabled
using System;
using System.Collections.Generic;
using System.Text;
using Genesyslab.Platform.Commons.Protocols.Auth;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
using Genesyslab.Platform.Configuration.Protocols.Internal.Codecs;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Protocols
{
    ///<summary>
    /// Protocol Manager Application Block is deprecated.
    /// <seealso cref="Genesyslab.Platform.Configuration.Protocols.IConfServerProtocolHandshakeOptions"/>   
    /// <seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.IClientConnectionOptions"/>
    /// <seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.PropertyConfiguration"/>
    /// <seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.KeyValueConfiguration"/>
    /// <seealso cref="Genesyslab.Platform.Commons.Protocols.Endpoint"/>
    /// <seealso cref="Genesyslab.Platform.ApplicationBlocks.WarmStandby.WarmStandbyConfiguration"/>
    /// </summary>
    [Obsolete("Use Endpoint to manage protocol's configuration.")]
    public class ConfServerConfiguration : ProtocolConfiguration
    {
        #region Fields

        private string clientName;
        //private ConfServerClientType? clientType;
        CfgAppType clientType;
        private string userName;
        private string userPassword;
        private IKerberosTicketAcquirer _kerberosTicketAcquirer;

        #endregion Fields

        public ConfServerConfiguration(string name)
            : base(name, typeof(ConfServerProtocol))
        {
        }

        #region Properties
        /// <summary>
        /// Kerberos ticket acquirer. Used to obtain Kerberos ticket from Active Directory for Kerberos authentication.
        /// In case of <see cref="Genesyslab.Platform.Commons.Protocols.Endpoint">Endpoint</see>.ServicePrincipalName has been set and 
        /// KerberosTicketAcquirer has not been set will be used <see cref="DefaultKerberosTicketAcquirer"/> instance.
        /// Default value: null
        /// </summary>
        public IKerberosTicketAcquirer KerberosTicketAccuirer
        {
          get { return this._kerberosTicketAcquirer; }
          set { this._kerberosTicketAcquirer = value; }
        }

        public string ClientName
        {
            get { return this.clientName; }
            set { this.clientName = value; }
        }

/*        [Obsolete("This property has been deprecated. Please use ClientApplicationType instead.", false)]
        public ConfServerClientType? ClientType
        {
            get { return (ConfServerClientType)this.clientType;  }
            set { this.clientType = (CfgAppType)value; }
        }
*/
        public CfgAppType ClientApplicationType
        {
            get { return this.clientType; }
            set { this.clientType = value; }
        }

        public string UserName
        {
            get { return this.userName; }
            set { this.userName = value; }
        }
#if (!ProtectUserPasswordFeatureDisabled)
        [Obsolete("Use SecuredUserPassword property instead")]
#endif
        public string UserPassword
        {
          get { return userPassword; }
          set
          {
            this.userPassword = value;
          }
        }
#if (!ProtectUserPasswordFeatureDisabled)
        /// <summary>
        /// Secured password used instead of UserPassword property
        /// </summary>
        public IEnumerable<char> SecuredUserPassword { internal get; set; }
        /// <summary>
        /// Callback to request a password value from clients's code
        /// </summary>
        public RequestPasswordCallback RequestPasswordCallback { internal get; set; }
        /// <summary>
        /// Callback to request a new password value from clients's code
        /// </summary>
        public RequestPasswordCallback RequestNewPasswordCallback { internal get; set; }
#endif
        #endregion Properties

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(base.ToString());

            sb.AppendFormat("ClientName: {0}\n", this.clientName);
            sb.AppendFormat("ClientType: {0}\n", this.clientType.ToString());
            if (_kerberosTicketAcquirer != null)
            {
                sb.AppendFormat("KerberosTicket:{0} \n",_kerberosTicketAcquirer);
            }
            else
            {
              sb.AppendFormat("UserName: {0}\n", this.userName);
              sb.Append("UserPassword: *******\n");
            }

          return sb.ToString();
        }
    }
}

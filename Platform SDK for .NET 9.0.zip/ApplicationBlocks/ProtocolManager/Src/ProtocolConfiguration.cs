//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Text;

using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Protocols
{
    ///<summary>
    /// Protocol Manager Application Block is deprecated. 
    /// <seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.IClientConnectionOptions"/>
    /// <seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.PropertyConfiguration"/>
    /// <seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.KeyValueConfiguration"/>
    /// <seealso cref="Genesyslab.Platform.Commons.Protocols.Endpoint"/>
    /// <seealso cref="Genesyslab.Platform.ApplicationBlocks.WarmStandby.WarmStandbyConfiguration"/>
    /// </summary>    
    [Obsolete("Use Endpoint to manage protocol's configuration.")]
    public abstract class ProtocolConfiguration
    {
        #region Fields

        private readonly Type protocolType;
        private string name;
        private Uri uri;
        private Uri warmStandbyUri;
        private short? warmStandbyAttempts;
        private short? warmStandbySwitchovers;
        private int? warmStandbyTimeout;
        private int? addpClientTimeout;
        private int? addpServerTimeout;
        private bool? useAddp;
        private FaultToleranceMode? faultTolerance;
        private string addpTrace;
        bool? useTls;
        string localBindingHost;
        int? localBindingPort;
        bool? blockingMode;
        string encoding;

        #endregion Fields

        #region Constructors

        protected ProtocolConfiguration(string name, string host, string port, Type protocolType)
            : this(name, protocolType)
        {
            this.uri = new Uri("tcp://" + host + ":" + port);
        }

        protected ProtocolConfiguration(string name, Uri uri, Uri warmStandbyUri, Type protocolType)
            : this(name, protocolType)
        {
            this.uri = uri;
            this.warmStandbyUri = warmStandbyUri;
        }

        protected ProtocolConfiguration(string name, Type protocolType)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name", "Name is null or empty.");
            }

            if (protocolType == null)
            {
                throw new ArgumentNullException("protocolType", "ProtocolType is null.");
            }

            this.name = name;
            this.protocolType = protocolType;
        }

        #endregion Constructors

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.GetType().ToString());
            sb.Append(":\n");
            sb.AppendFormat("Protocol: {0}\n", this.protocolType.ToString());
            sb.AppendFormat("Name: {0}\n", this.name);

            sb.AppendFormat("FaultToleranceMode: {0}\n", this.faultTolerance != null ? this.faultTolerance.ToString() : "null");
            sb.AppendFormat("Uri: {0}\n", this.uri != null ? this.Uri.ToString() : "null");
            sb.AppendFormat("WarmStandbyUri: {0}\n", this.warmStandbyUri != null ? this.warmStandbyUri.ToString() : "null");
            sb.AppendFormat("WarmStandbyTimeout: {0}\n", this.warmStandbyTimeout.ToString());
            sb.AppendFormat("WarmStandbyAttempts: {0}\n", this.warmStandbyAttempts.ToString());
            sb.AppendFormat("WarmStandbySwitchovers: {0}\n", this.warmStandbySwitchovers.ToString());
            sb.AppendFormat("AddpClientTimeout: {0}\n", this.addpClientTimeout.ToString());
            sb.AppendFormat("AddpServerTimeout: {0}\n", this.addpServerTimeout.ToString());
            sb.AppendFormat("UseTls: {0}\n", this.useTls != null ? this.useTls.ToString() : "null");            
            sb.AppendFormat("LocalBindingHost: {0}\n", this.localBindingHost != null ? this.localBindingHost : "null");
            sb.AppendFormat("LocalBindingPort: {0}\n", this.localBindingPort != null ? this.localBindingPort.ToString() : "null");
            sb.AppendFormat("BlockingMode: {0}\n", this.blockingMode != null ? this.blockingMode.ToString() : "null");
            sb.AppendFormat("Encoding: {0}\n", this.encoding != null ? this.encoding : "null");

            return sb.ToString();
        }

        #region Properties

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("value", "Value is null or empty.");
                }

                this.name = value;
            }
        }

        public Uri Uri
        {
            get { return this.uri; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value", "Value is null.");
                }

                this.uri = value;
            }
        }

        /// <summary>
        /// Gets/Sets the standby URI for Warm Standby.
        /// </summary>
        public Uri WarmStandbyUri
        {
            get { return warmStandbyUri; }
            set
            {
                this.warmStandbyUri = value;
            }
        }

        /// <summary>
        /// Gets/Sets the number of reconnection attempts for Warm Standby.
        /// </summary>
        public short? WarmStandbyAttempts
        {
            get { return this.warmStandbyAttempts; }
            set { this.warmStandbyAttempts = value; }
        }

        /// <summary>
        /// Gets/Sets the number of primary/backup switchovers allowed for Warm Standby. 
        /// If this parameter is not set, or if it is set to null, then an unlimited 
        /// number of switchovers are allowed. If this parameter is set to 0 then 
        /// switchover will not happen.
        /// </summary>
        public short? WarmStandbySwitchovers
        {
            get { return this.warmStandbySwitchovers; }
            set { this.warmStandbySwitchovers = value; }
        }

        /// <summary>
        /// Gets/Sets the timeout (in milliseconds) between the reconnection attempts for Warm Standby.
        /// </summary>
        public int? WarmStandbyTimeout
        {
            get { return this.warmStandbyTimeout; }
            set { this.warmStandbyTimeout = value; }
        }

        public int? AddpClientTimeout
        {
            get { return this.addpClientTimeout; }
            set { this.addpClientTimeout = value; }
        }

        public int? AddpServerTimeout
        {
            get { return this.addpServerTimeout; }
            set { this.addpServerTimeout = value; }
        }

        public bool? UseAddp
        {
            get { return this.useAddp; }
            set { this.useAddp = value; }
        }

        public string AddpTrace
        {
            get { return this.addpTrace; }
            set { this.addpTrace = value; }
        }

        public FaultToleranceMode? FaultTolerance
        {
            get
            {
                return this.faultTolerance;
            }
            set
            {
                this.faultTolerance = value;
            }
        }

        public bool? UseTls
        {
            get { return useTls; }
            set { useTls = value; }
        }

        public string LocalBindingHost
        {
            get { return localBindingHost; }
            set { localBindingHost = value; }
        }

        public int? LocalBindingPort
        {
            get { return localBindingPort; }
            set { localBindingPort = value; }
        }

        public bool? BlockingMode
        {
            get { return blockingMode; }
            set { blockingMode = value; }
        }

        public string Encoding
        {
            get { return encoding; }
            set { encoding = value; }
        }

        #endregion Properties

        #region Implementation Members

        internal Type ProtocolType
        {
            get
            {
                return this.protocolType;
            }
        }

        #endregion Implementation Members

    }
}

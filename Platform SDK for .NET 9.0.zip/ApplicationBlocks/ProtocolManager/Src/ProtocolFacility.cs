//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Globalization;
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.ApplicationBlocks.WarmStandby;
using Warmstandby = Genesyslab.Platform.ApplicationBlocks.WarmStandby;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Connection;

namespace Genesyslab.Platform.ApplicationBlocks.Commons.Protocols
{
    internal abstract class ProtocolFacility : AbstractLogEnabled
    {
        public void Initialize(ProtocolInstance entry, IMessageReceiverSupport receiver)
        {
            entry.Protocol.SetReceiver(receiver);
        }

        public void Uninitialize(ProtocolInstance entry)
        {
            this.BeginCloseProtocol(entry);

            while (entry.Protocol.State != ChannelState.Closed)
            {
                entry.ChannelEvent.WaitOne();
            }

            entry.Dispose();
        }

        public virtual void ApplyConfiguration(ProtocolInstance entry, ProtocolConfiguration conf, ILogger logger)
        {
            this.EnableLogging(entry, logger);
            this.ApplyChannelConfiguration(entry, conf);
            this.ApplyWarmStandbyConfiguration(entry, conf, logger);
        }

        public void BeginOpenProtocol(ProtocolInstance entry)
        {
            if (entry.WarmStandby != null && entry.WarmStandby.State != WarmStandbyState.Off)
            {
                entry.WarmStandby.Stop();
            }

            if (entry.Protocol.State == ChannelState.Opening || entry.Protocol.State == ChannelState.Closing)
            {
                entry.ChannelEvent.WaitOne();
            }

            if (entry.WarmStandby != null && entry.WarmStandby.State == WarmStandbyState.Off)
            {
                entry.WarmStandby.Start();
            }

            if (entry.Protocol.State == ChannelState.Closed)
            {
                try
                {
                    entry.Protocol.BeginOpen();
                }
                catch (ProtocolException e)
                {
                    if (this.Logger.IsWarnEnabled) this.Logger.WarnFormat("Exception on Channel opening: {0}", e.ToString());
                    if (entry.WarmStandby == null) throw e;
                }
            }
        }

        public void BeginCloseProtocol(ProtocolInstance entry)
        {
            if (entry.WarmStandby != null && entry.WarmStandby.State != WarmStandbyState.Off)
            {
                try
                {
                    entry.WarmStandby.Stop();
                }
                catch (InvalidOperationException e)
                {
                    Logger.Warn("It seems that warmstandby service is already stopped..", e);
                }
            }

            if (entry.Protocol.State == ChannelState.Opening || entry.Protocol.State == ChannelState.Closing)
            {
                entry.ChannelEvent.WaitOne();
            }

            if (entry.Protocol.State == ChannelState.Opened)
            {
                entry.Protocol.BeginClose();
            }
        }

        public void EnableLogging(ProtocolInstance entry, ILogger logger)
        {
            this.EnableLogging(logger.CreateChildLogger("ProtocolFacility"));
            entry.EnableLogging(logger.CreateChildLogger("ProtocolInstance"));
        }
        internal void EnableLogging(ProtocolInstance entry, ILogger logger, bool skipLogAssemblyReferences)
        {
          this.EnableLogging(logger.CreateChildLogger("ProtocolFacility"));
          entry.EnableLogging(logger.CreateChildLogger("ProtocolInstance"), skipLogAssemblyReferences);
        }

        public abstract ClientChannel CreateProtocol(string name, Uri uri);

        #region Implementation Members

        private void ApplyWarmStandbyConfiguration(ProtocolInstance entry, ProtocolConfiguration conf, ILogger logger)
        {
            if (conf.FaultTolerance == null)
                return;

            if (conf.FaultTolerance == FaultToleranceMode.WarmStandby) // warm standby is ON
            {
                if (entry.WarmStandby == null)
                {
                    entry.WarmStandby = new WarmStandbyService(entry.Protocol);
                    entry.WarmStandby.EnableLogging(logger.CreateChildLogger("WarmStandbyService"));
                }

                Uri uri = conf.Uri ?? entry.Protocol.Endpoint.Uri;
                //this type of exception is chosen to keep the exception-specification compatibility with earlier versions.
                if (uri == null)
                    throw new ArgumentNullException("activeUri", "WarmStandbyConfiguration:activeUri is null.");
                if (conf.WarmStandbyUri == null)
                    throw new ArgumentNullException("standbyUri", "WarmStandbyConfiguration:standbyUri is null.");

                Endpoint backup = new Endpoint(conf.Name, conf.WarmStandbyUri);

                //IConnectionConfiguration connConf = entry.Protocol.Endpoint.GetConfiguration();

                backup.SetConfiguration(CreateBacupConfiguration(entry, conf, backup));

                WarmStandbyConfiguration wsConf = new WarmStandbyConfiguration(
                                                        entry.Protocol.Endpoint, backup)
                {
                    Attempts = conf.WarmStandbyAttempts,
                    Switchovers = conf.WarmStandbySwitchovers,
                    Timeout = conf.WarmStandbyTimeout
                };

                entry.WarmStandby.ApplyConfiguration(wsConf);

                if (entry.WarmStandby.State == WarmStandbyState.Off)
                {
                    entry.WarmStandby.Start();
                }
            }
            else if (entry.WarmStandby != null) // warm standby is OFF
            {
                entry.WarmStandby.Dispose();
                entry.WarmStandby = null;
            }
        }
        #region Create (& merge) configuration (primary & backup)
        protected IConnectionConfiguration CreateBacupConfiguration(ProtocolInstance entry, ProtocolConfiguration conf, Endpoint backup)
        {
          IConnectionConfiguration connConf = backup.GetConfiguration();
          FillChannelConfiguration(entry,conf,connConf);
          return connConf;
          
          //IConnectionConfiguration prim = entry.Protocol.Endpoint.GetConfiguration() as IConnectionConfiguration;
          //if (prim != null)
          //{
          //  bool updateTimeouts = true;
          //  if (prim.GetOption(ConnectionBase.ProtocolNameKey) != null)
          //  {
          //    if (prim.GetOption(ConnectionBase.ProtocolNameKey, "").Equals(AddpInterceptor.Name))
          //    {
          //      connConf.SetOption(ConnectionBase.ProtocolNameKey, AddpInterceptor.Name);
          //    }
          //    else
          //    {
          //      connConf.SetOption(AddpInterceptor.RemoteTimeoutKey, "-1");
          //      connConf.SetOption(AddpInterceptor.TimeoutKey, "-1");
          //      updateTimeouts = false;
          //    }
          //  }
          //  if (prim.GetOption(AddpInterceptor.RemoteTimeoutKey) != null && updateTimeouts)
          //  {
          //    connConf.SetOption(AddpInterceptor.RemoteTimeoutKey, prim.GetOption(AddpInterceptor.RemoteTimeoutKey));
          //  }

          //  if (prim.GetOption(AddpInterceptor.TimeoutKey) != null && updateTimeouts)
          //  {
          //    connConf.SetOption(AddpInterceptor.TimeoutKey, prim.GetOption(AddpInterceptor.TimeoutKey));
          //  }
          //  if (prim.GetOption(AddpInterceptor.TraceKey) != null)
          //    connConf.SetOption(AddpInterceptor.TraceKey, prim.GetOption(AddpInterceptor.TraceKey));

          //  if (prim.GetOption(CommonConnection.TlsKey) != null)
          //  {
          //    connConf.SetBoolean(CommonConnection.TlsKey, prim.GetBoolean(CommonConnection.TlsKey));
          //  }

          //  if (prim.GetOption(CommonConnection.BindHostKey)!=null)
          //  {
          //    connConf.SetOption(CommonConnection.BindHostKey, prim.GetOption(CommonConnection.BindHostKey));
          //  }

          //  if (prim.GetOption(CommonConnection.BindPortKey) != null && prim.GetInteger(CommonConnection.BindPortKey) > 0)
          //  {
          //    connConf.SetInteger(CommonConnection.BindPortKey, prim.GetInteger(CommonConnection.BindPortKey));
          //  }
          //  if (prim.GetOption(CommonConnection.BlockingModeKey) != null)
          //  {
          //    connConf.SetBoolean(CommonConnection.BlockingModeKey, prim.GetBoolean(CommonConnection.BlockingModeKey));
          //  }
          //  if (prim.GetOption(ConnectionBase.StringAttributeEncodingKey) != null)
          //  {
          //    connConf.SetOption(ConnectionBase.StringAttributeEncodingKey, prim.GetOption(ConnectionBase.StringAttributeEncodingKey));
          //  }

          //}
          //return connConf;
        }

      #endregion 

        private void ApplyChannelConfiguration(ProtocolInstance entry, ProtocolConfiguration conf)
        {
            if (conf.Uri != null)
            {
                entry.Protocol.Endpoint = new Endpoint(conf.Name, conf.Uri);
            }

            // Connection configuration
            //if (conf.UseAddp != null || conf.AddpServerTimeout != null || conf.AddpClientTimeout != null ||
            //    conf.AddpTrace != null || conf.UseTls != null || conf.LocalBindingHost != null ||
            //    conf.LocalBindingPort != null || conf.BlockingMode != null || conf.Encoding != null)
            //{

              IConnectionConfiguration connectionConf = null;
              if ((entry != null) && (entry.Protocol != null) && entry.Protocol.Endpoint != null)
                connectionConf = entry.Protocol.Endpoint.GetConfiguration();
              if (connectionConf == null) connectionConf = new PropertyConfiguration();
              FillChannelConfiguration(entry, conf, connectionConf);
              if ((entry != null) && (entry.Protocol != null))
                entry.Protocol.Configure(connectionConf);
            //}
        }
        private void FillChannelConfiguration(ProtocolInstance entry, ProtocolConfiguration conf, IConnectionConfiguration connectionConf)
        {

          bool updateTimeouts = true;

          if (conf.UseAddp != null)
          {
            if (conf.UseAddp.Value)
            {
              connectionConf.SetOption("protocol", "addp");
            }
            else
            {
              connectionConf.SetOption(AddpInterceptor.RemoteTimeoutKey, "-1");
              connectionConf.SetOption(AddpInterceptor.TimeoutKey, "-1");
              updateTimeouts = false;
            }
          }

          if (conf.AddpServerTimeout != null && updateTimeouts)
          {
            connectionConf.SetOption(AddpInterceptor.RemoteTimeoutKey, conf.AddpServerTimeout.Value.ToString(CultureInfo.InvariantCulture));
          }

          if (conf.AddpClientTimeout != null && updateTimeouts)
          {
            connectionConf.SetOption(AddpInterceptor.TimeoutKey, conf.AddpClientTimeout.Value.ToString(CultureInfo.InvariantCulture));
          }

          if (!string.IsNullOrEmpty(conf.AddpTrace))
          {
            connectionConf.SetOption(AddpInterceptor.TraceKey, conf.AddpTrace);
          }

          if (conf.UseTls != null)
          {
            connectionConf.SetBoolean(CommonConnection.TlsKey, conf.UseTls.Value);
          }

          if (!string.IsNullOrEmpty(conf.LocalBindingHost))
          {
            connectionConf.SetOption(CommonConnection.BindHostKey, conf.LocalBindingHost);
          }

          if (conf.LocalBindingPort != null && conf.LocalBindingPort > 0)
          {
            connectionConf.SetInteger(CommonConnection.BindPortKey, conf.LocalBindingPort.Value);
          }
          if (conf.BlockingMode != null)
          {
            connectionConf.SetBoolean(CommonConnection.BlockingModeKey, conf.BlockingMode.Value);
          }
          if (conf.Encoding != null)
          {
            connectionConf.SetOption(ConnectionBase.StringAttributeEncodingKey, conf.Encoding);
          }
        }

      #endregion Implementation Members
    }
}

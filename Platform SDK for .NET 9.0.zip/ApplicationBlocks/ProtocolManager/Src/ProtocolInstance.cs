//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Threading;
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.ApplicationBlocks.WarmStandby;


namespace Genesyslab.Platform.ApplicationBlocks.Commons.Protocols
{
    internal sealed class ProtocolInstance : AbstractLogEnabled, IDisposable 
    {
        #region Fields

        private readonly ClientChannel protocol;
        private readonly object protocolLock;
        private WarmStandbyService warmStandby;
        private readonly AutoResetEvent channelEvent;
        private bool isDisposed;
        private readonly object lifecycleLock;

        #endregion Fields

        #region Constructors

        public ProtocolInstance(ClientChannel protocol)
            : this(protocol, null)
        {
        }

        public ProtocolInstance(ClientChannel protocol, WarmStandbyService warmStandby)
        {
            this.protocol = protocol;
            this.warmStandby = warmStandby;
            this.protocolLock = new object();
            this.lifecycleLock = new object();
            this.channelEvent = new AutoResetEvent(false);
            this.protocol.Opened += this.OnChannelOpened;
            this.protocol.Closed += this.OnChannelClosed;
        }

        #endregion Constructors

        #region Properties

        public ClientChannel Protocol
        {
            get { return this.protocol; }
        }

        public object ProtocolLock
        {
            get { return this.protocolLock; }
        }

        public AutoResetEvent ChannelEvent
        {
            get { return this.channelEvent; }
        }

        public WarmStandbyService WarmStandby
        {
            get { return this.warmStandby; }
            set { this.warmStandby = value; }
        }

        #endregion Properties
         
        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion IDisposable Members

        #region AbstractLogEnabled Members

        internal void EnableLogging(ILogger logger, bool skipLogAssemblyReferences)
        {
          IConnectionConfiguration cfg = null;
          string option = null;
          if (skipLogAssemblyReferences)
          {
            cfg = protocol.Endpoint.GetConfiguration();
            if (cfg != null)
            {
              option = cfg.GetOption(DuplexChannel.SkipLogAssemblyReferencesKey);
              if (option != null)
                cfg.SetBoolean(DuplexChannel.SkipLogAssemblyReferencesKey, true);
            }
          }
          EnableLogging(logger);
          if (skipLogAssemblyReferences)
          {
            if ((cfg != null) && (option == null))
              cfg.SetOption(DuplexChannel.SkipLogAssemblyReferencesKey, null);
          }
        }
        
        protected override void OnEnableLogging(ILogger logger)
        {
            base.OnEnableLogging(logger);
            this.protocol.EnableLogging(logger.CreateChildLogger("Channel"));
            if( this.warmStandby != null )
            {
                this.warmStandby.EnableLogging(logger.CreateChildLogger("WarmStandbyService"));
            }
        }

        #endregion AbstractLogEnabled Members

        #region Implementation Members

        private void Dispose(bool disposing)
        {
          if (this.isDisposed) return;
          lock (this.lifecycleLock)
            {
                if (this.isDisposed) return;
                this.isDisposed = true;
                var protocolInstanceStr = protocol.Endpoint.ToString();
                if ((Logger!=null) && (Logger.IsDebugEnabled))
                {
                  Logger.Debug("Disposing protocol instance: " + protocolInstanceStr);
                }
                this.protocol.Opened -= this.OnChannelOpened;
                this.protocol.Closed -= this.OnChannelClosed;
                this.channelEvent.Close();
                this.protocol.ResetReceiver();
                if( this.warmStandby != null )
                {
                    this.warmStandby.Dispose();
                    this.warmStandby = null;
                }
                this.protocol.Dispose();
                if ((Logger != null) && (Logger.IsDebugEnabled))
                {
                  Logger.Debug("Protocol instance: " + protocolInstanceStr + " is disposed.");
                }
            }
        }

        private void OnChannelClosed(object sender, EventArgs eventArgs)
        {
          if (this.isDisposed) return;
          if (Monitor.TryEnter(this.lifecycleLock))
          {
            // this should prevent starting Dispose() till channelEvent will be setted
            try
            {
              if (this.isDisposed) return;
              if ((Logger != null) && (Logger.IsDebugEnabled))
              {
                Logger.Debug("Set channel event for protocol: " + protocol.Endpoint);
              }
              try
              {
                this.channelEvent.Set();
              }
              catch (Exception ex)
              {
                if ((Logger != null) && (Logger.IsWarnEnabled)) 
                  Logger.WarnFormat("Exception in OnChannelClosed(): {0}", ex);
                else Console.WriteLine("Exception in OnChannelClosed():" + ex);
              }
            }
            finally
            {
              Monitor.Exit(this.lifecycleLock);
            }
          }
          else
          {
            if ((Logger != null) && (Logger.IsDebugEnabled))
            {
              Logger.Debug("ProtocolInstance.OnChannelClosed [" + protocol.Endpoint + "]: Cannot take exclusive lock. Object is disposing...");
            }
          }
        }

        private void OnChannelOpened(object sender, EventArgs eventArgs)
        {
            this.channelEvent.Set();
        }

        #endregion Implementation Members
    }
}

//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2007 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

using Genesyslab.Platform.ApplicationBlocks.WarmStandby;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;

using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Management.Protocols;
using Genesyslab.Platform.OpenMedia.Protocols;
using Genesyslab.Platform.Outbound.Protocols;
using Genesyslab.Platform.Reporting.Protocols;
using Genesyslab.Platform.Routing.Protocols;
using Genesyslab.Platform.Voice.Protocols;
using Genesyslab.Platform.Contacts.Protocols;
using Genesyslab.Platform.Reporting.Protocols.StatServer;
using Genesyslab.Platform.WebMedia.Protocols;
using Genesyslab.Platform.WebMedia.Protocols.EspEmail;


namespace Genesyslab.Platform.ApplicationBlocks.Commons.Protocols
{
    ///<summary>
    ///Protocol Manager Application Block is deprecated.
    ///A number of specific configuration options were added to <see cref="Genesyslab.Platform.Commons.Connection.Configuration.IClientConnectionOptions"/> interfaces.
    ///The <see cref="Genesyslab.Platform.Commons.Protocols.Endpoint"/> class has been extended with constructor to accept IConnectionConfiguration parameter.
    ///The <see cref="Genesyslab.Platform.Commons.Protocols.Endpoint"/> class can be used to setup  protocol's configuration.
    ///So, user should create WarmStanbyService and manage its' state directly if it is required.
    ///</summary>
    ///<seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.IClientConnectionOptions"/>
    ///<seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.PropertyConfiguration"/>
    ///<seealso cref="Genesyslab.Platform.Commons.Connection.Configuration.KeyValueConfiguration"/>
    ///<seealso cref="Genesyslab.Platform.Commons.Protocols.Endpoint"/>
    ///<seealso cref="Genesyslab.Platform.ApplicationBlocks.WarmStandby.WarmStandbyConfiguration"/>
    [Obsolete("Use Endpoint to manage protocol's configuration. Use protocol object directly to open and close connection. Use WarmStandby service directly.")]
    public class ProtocolManagementService : AbstractLogEnabled, IProtocolManagementService, IDisposable
    {
        #region Types


        #endregion Types

        #region Fields

        private readonly IMessageReceiverSupport receiver;
        private readonly Dictionary<string, ProtocolInstance> protocols;
        private readonly Dictionary<Type, ProtocolFacility> facilities;
        private readonly object protocolsLock;
        private bool isDisposed;
        private readonly object lifecycleLock;

        #endregion Fields

        #region Constructors

        public ProtocolManagementService() :
 	 	    this(new QueueMessageReceiver(1024))
        {
 	 	}
 	 	
        public ProtocolManagementService(IMessageReceiverSupport messageReceiver)
        {
            if (messageReceiver == null)
            {
                throw new ArgumentNullException("messageReceiver");
            }

            this.receiver = messageReceiver;

            this.protocols = new Dictionary<string, ProtocolInstance>(64);
            this.facilities = new Dictionary<Type, ProtocolFacility>(16);
            this.protocolsLock = new object();
            this.lifecycleLock = new object();

            Initialize();
        }

        #endregion Constructors

        #region IProtocolManagementService Members

        [IndexerName("Protocol")]
        public IProtocol this[string name]
        {
            get
            {
                if (string.IsNullOrEmpty(name))
                {
                    throw new ArgumentNullException("name", "Name is null.");
                }

                ProtocolInstance entry;

                lock (this.protocolsLock)
                {
                    if (this.protocols.TryGetValue(name, out entry) == false)
                    {
                        throw new ArgumentException("Protocol is not registered.", "name");
                    }
                }

                return entry.Protocol;
            }
        }

        public IProtocol Register(ProtocolConfiguration protocolConfiguration)
        {
            if (protocolConfiguration == null)
            {
                throw new ArgumentNullException("protocolConfiguration", "ProtocolConfiguration is null.");
            }

            this.Logger.DebugFormat("Registering protocol configuration: \n{0}\n", protocolConfiguration.ToString());

            IProtocol protocol = RegisterInternal(protocolConfiguration.Name, protocolConfiguration);

            return protocol;
        }

        public void Unregister(string name)
        {
            if( string.IsNullOrEmpty(name) )
            {
                throw new ArgumentNullException("name", "Name is null.");
            }

            ProtocolInstance entry;

            lock(this.protocolsLock)
            {
                if (this.protocols.TryGetValue(name, out entry) == false)
                {
                    throw new ArgumentException("Protocol is not registered.", "name");
                }

                protocols.Remove(name);
            }

            UnregisterInternal(entry);
        }

        public void ApplyConfiguration(ProtocolConfiguration protocolConfiguration)
        {
            if( protocolConfiguration == null )
            {
                throw new ArgumentNullException("protocolConfiguration", "ProtocolConfiguration is null.");
            }

            if( string.IsNullOrEmpty(protocolConfiguration.Name) )
            {
                throw new ArgumentNullException("protocolConfiguration", "Protocol name is null.");
            }

            ProtocolInstance entry;

            lock(this.protocolsLock)
            {
                if( this.protocols.TryGetValue(protocolConfiguration.Name, out entry) == false )
                {
                    throw new ArgumentException("Protocol is not registered.", "protocolConfiguration");
                }

            }

            this.ApplyConfiguration(entry, protocolConfiguration);
        }

        public event EventHandler<ProtocolEventArgs> ProtocolOpened;
        public event EventHandler<ProtocolEventArgs> ProtocolClosed;
        //public event EventHandler<ProtocolEventArgs> ProtocolChanged;

        #endregion IProtocolManagementService Members

        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        #region Properties

        public IMessageReceiver Receiver
        {
            get { return receiver; }
        }

        #endregion Properties

        #region Public Members

        public void BeginOpen()
        {
            lock (this.protocolsLock)
            {
                foreach (ProtocolInstance entry in this.protocols.Values)
                {
                    BeginOpenProtocol(entry);
                }
            }
        }

        public void BeginClose()
        {
            lock (this.protocolsLock)
            {
                foreach (ProtocolInstance entry in this.protocols.Values)
                {
                    BeginCloseProtocol(entry);
                }
            }
        }

        public void BeginOpenProtocol(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name", "Name is null.");
            }

            ProtocolInstance entry;

            lock( this.protocolsLock )
            {
                if( this.protocols.TryGetValue(name, out entry) == false )
                {
                    throw new ArgumentException("Protocol is not registered.", "name");
                }        
            }

            BeginOpenProtocol(entry);
        }

        public void BeginCloseProtocol(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name", "Name is null.");
            }

            ProtocolInstance entry;

            lock(this.protocolsLock)
            {
                if (this.protocols.TryGetValue(name, out entry) == false)
                {
                    throw new ArgumentException("Protocol is not registered.", "name");
                }
            }

            BeginCloseProtocol(entry);
        }

        public WarmStandbyService GetWarmStandbyService(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name", "Name is null.");
            }

            ProtocolInstance entry;

            lock (this.protocolsLock)
            {
                if (this.protocols.TryGetValue(name, out entry) == false)
                {
                    throw new ArgumentException("Protocol is not registered.", "name");
                }
            }
            return entry.WarmStandby;
        }

        #endregion Public Members

        #region Implementation Members

        private ClientChannel RegisterInternal(string name, ProtocolConfiguration protocolConfiguration)
        {
            Debug.Assert( protocolConfiguration != null);

            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("protocolConfiguration", "Protocol name can't be null or empty.");
            }

            ProtocolInstance entry;

            lock (this.protocolsLock)
            {
                if( this.protocols.ContainsKey(name) )
                {
                    throw new ArgumentException("protocolConfiguration","Protocol is already registered.");
                }

                ProtocolFacility facility = GetFacility(protocolConfiguration.ProtocolType);

                ClientChannel protocol = facility.CreateProtocol(protocolConfiguration.Name, protocolConfiguration.Uri);
                entry = new ProtocolInstance(protocol);

                WireEvents(entry);

                facility.ApplyConfiguration(entry, protocolConfiguration, Logger);
                
                facility.Initialize(entry, this.receiver);

                this.protocols.Add(name, entry);
            }

            return entry.Protocol;
        }

        private void UnregisterInternal(ProtocolInstance entry)
        {
            lock (entry.ProtocolLock)
            {
                ProtocolFacility facility = GetFacility(entry.Protocol.GetType());
                facility.Uninitialize(entry);
            }
        }

        private void WireEvents(ProtocolInstance entry)
        {
            entry.Protocol.Opened += new EventHandler(OnProtocolOpened);
            entry.Protocol.Closed += new EventHandler(OnProtocolClosed);

            if (entry.WarmStandby != null)
            {
                entry.WarmStandby.StateChanged += new EventHandler(OnWarmStandbyChanged);
            }
        }

        private void ApplyConfiguration(ProtocolInstance entry, ProtocolConfiguration conf)
        {
            ProtocolFacility facility = GetFacility(conf.ProtocolType);

            lock (entry.ProtocolLock)
            {
                facility.ApplyConfiguration(entry, conf, Logger);
            }
        }

        private void BeginOpenProtocol(ProtocolInstance entry)
        {
            ProtocolFacility facility = GetFacility(entry.Protocol.GetType());

            lock (entry.ProtocolLock)
            {
                facility.BeginOpenProtocol(entry);
            }
        }

        private void BeginCloseProtocol(ProtocolInstance entry)
        {
            ProtocolFacility facility = GetFacility(entry.Protocol.GetType());

            lock (entry.ProtocolLock)
            {
                facility.BeginCloseProtocol(entry);
            }
        }

        void OnProtocolOpened(object sender, EventArgs e)
        {
            if (this.ProtocolOpened!=null)
            {
                this.ProtocolOpened(this, new ProtocolEventArgs((IProtocol)sender));
            }
        }

        void OnProtocolClosed(object sender, EventArgs e)
        {
            if (this.ProtocolClosed != null)
            {
                this.ProtocolClosed(this, new ProtocolEventArgs((IProtocol)sender));
            }
        }

        void OnWarmStandbyChanged(object sender, EventArgs e)
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        private ProtocolFacility GetFacility(Type type)
        {
            Debug.Assert(this.facilities.ContainsKey(type));

            ProtocolFacility facility = this.facilities[type];

            return facility;
        }

        protected override void OnEnableLogging(ILogger logger)
        {
            base.OnEnableLogging(logger);
            bool isNotFirst = false;
            lock (this.protocolsLock)
            {
                foreach (ProtocolInstance entry in this.protocols.Values)
                {
                    ProtocolFacility facility = GetFacility(entry.Protocol.GetType());

                    lock (entry.ProtocolLock)
                    {
                      facility.EnableLogging(entry, logger, isNotFirst);
                      isNotFirst = true;
                    }
                }
            }
        }

        private void Initialize()
        {
            this.facilities.Add(typeof(ConfServerProtocol), new ConfServerFacility());
            this.facilities.Add(typeof(TServerProtocol), new TServerFacility());
            this.facilities.Add(typeof(BasicChatProtocol), new BasicChatFacility());
            this.facilities.Add(typeof(CallbackProtocol), new CallbackFacility());
            this.facilities.Add(typeof(EmailProtocol), new EmailFacility());
            this.facilities.Add(typeof(FlexChatProtocol), new FlexChatFacility());
            this.facilities.Add(typeof(EspEmailProtocol), new EspEmailFacility());
            this.facilities.Add(typeof(InteractionServerProtocol), new InteractionServerFacility());
            this.facilities.Add(typeof(StatServerProtocol), new StatServerFacility());
            this.facilities.Add(typeof(OutboundServerProtocol), new OutboundServerFacility());
            this.facilities.Add(typeof(LocalControlAgentProtocol), new LcaFacility());
            this.facilities.Add(typeof(SolutionControlServerProtocol), new ScsFacility());
            this.facilities.Add(typeof(MessageServerProtocol), new MessageServerFacility());
            this.facilities.Add(typeof(UniversalContactServerProtocol), new UcsFacility());
            this.facilities.Add(typeof(UrsCustomProtocol), new UrsCustomFacility());
        }

        private void Dispose(bool disposing)
        {
            lock (this.lifecycleLock)
            {
                if (this.isDisposed)
                    return;

                UnregisterAll();

                this.isDisposed = true;
            }
        }

        private void UnregisterAll()
        {
            lock (this.protocolsLock)
            {
                ProtocolInstance[] entries = new ProtocolInstance[this.protocols.Count];
                protocols.Values.CopyTo(entries, 0);

                foreach (ProtocolInstance entry in entries)
                {
                    protocols.Remove(entry.Protocol.Endpoint.Name);

                    UnregisterInternal(entry);
                }
            }
        }

    #endregion Implementation Members
    }
}

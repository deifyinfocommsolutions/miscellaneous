//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

//===============================================================================



using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;

using Genesyslab.Platform.ApplicationBlocks.WarmStandby;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;
//using Genesyslab.Platform.OpenMedia.Protocols;
//using Genesyslab.Platform.OpenMedia.Protocols.InteractionServer;
//using Genesyslab.Platform.Reporting.Protocols;

namespace WarmStandbyQuickStart
{
    /// <summary>
    /// <exclude/>
    /// The class implements the main form of the Warm Standby Quick Start Sample Application
    /// </summary>
    public class MainForm : System.Windows.Forms.Form
    {
        #region Fields

        private ClientChannel channel;
        private WarmStandbyService warmStandby;
        private readonly ProtocolFactory factory = new ProtocolFactory();
        private WarmStandbyQuickStartConfiguration appConfiguration;
        private ILogger logger = new TraceLogger();

        #endregion Fields

        #region Forms

        private System.Windows.Forms.Label lblProtocolType;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox grpWarmStandby;
        private System.Windows.Forms.GroupBox grpChannel;
        private System.Windows.Forms.Label lblAttempts;
        private System.Windows.Forms.Label lblTimeout;
        private TextBox txtProtocolType;
        private TextBox txtClientName;
        private System.Windows.Forms.Button btnReconfigure;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblClientName;
        private System.Windows.Forms.StatusBarPanel statusBarPanelChannelState;
        private System.Windows.Forms.StatusBarPanel statusBarPanelChannelEndpoint;
        private System.Windows.Forms.StatusBarPanel statusBarPanelWarmStandbyState;
        private System.Windows.Forms.StatusBar statusBar;
        private System.Windows.Forms.GroupBox grpApplication;

        #endregion Forms
        private System.Windows.Forms.StatusBarPanel statusBarPanelAttempt;
        private System.Windows.Forms.Label lblActiveChannel;
        private System.Windows.Forms.TextBox txtActiveUrl;
        private System.Windows.Forms.Label lblStandbyChannel;
        private System.Windows.Forms.TextBox txtStandbyUrl;
        private System.Windows.Forms.NumericUpDown numericTimeout;
        private System.Windows.Forms.NumericUpDown numericAttemts;
        private System.Windows.Forms.NumericUpDown numericSwitchovers;
        private System.Windows.Forms.Label lblSwitchovers;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        /// <summary>
        /// Constructor of the MainForm class
        /// </summary>
        public MainForm()
        {
            //mainform
            // Required for Windows Form Designer support
            //
            InitializeComponent();

        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.grpApplication = new System.Windows.Forms.GroupBox();
            this.txtClientName = new System.Windows.Forms.TextBox();
            this.lblClientName = new System.Windows.Forms.Label();
            this.txtProtocolType = new System.Windows.Forms.TextBox();
            this.lblProtocolType = new System.Windows.Forms.Label();
            this.grpChannel = new System.Windows.Forms.GroupBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.grpWarmStandby = new System.Windows.Forms.GroupBox();
            this.lblTimeout = new System.Windows.Forms.Label();
            this.lblAttempts = new System.Windows.Forms.Label();
            this.numericTimeout = new System.Windows.Forms.NumericUpDown();
            this.numericAttemts = new System.Windows.Forms.NumericUpDown();
            this.btnReconfigure = new System.Windows.Forms.Button();
            this.lblStandbyChannel = new System.Windows.Forms.Label();
            this.lblActiveChannel = new System.Windows.Forms.Label();
            this.txtActiveUrl = new System.Windows.Forms.TextBox();
            this.txtStandbyUrl = new System.Windows.Forms.TextBox();
            this.statusBar = new System.Windows.Forms.StatusBar();
            this.statusBarPanelChannelEndpoint = new System.Windows.Forms.StatusBarPanel();
            this.statusBarPanelChannelState = new System.Windows.Forms.StatusBarPanel();
            this.statusBarPanelWarmStandbyState = new System.Windows.Forms.StatusBarPanel();
            this.statusBarPanelAttempt = new System.Windows.Forms.StatusBarPanel();
            this.numericSwitchovers = new System.Windows.Forms.NumericUpDown();
            this.lblSwitchovers = new System.Windows.Forms.Label();
            this.grpApplication.SuspendLayout();
            this.grpChannel.SuspendLayout();
            this.grpWarmStandby.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericTimeout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericAttemts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelChannelEndpoint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelChannelState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelWarmStandbyState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelAttempt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericSwitchovers)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(208, 112);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(96, 23);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(208, 160);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(96, 23);
            this.btnStop.TabIndex = 2;
            this.btnStop.Text = "Stop";
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // grpApplication
            // 
            this.grpApplication.Controls.Add(this.txtClientName);
            this.grpApplication.Controls.Add(this.lblClientName);
            this.grpApplication.Controls.Add(this.txtProtocolType);
            this.grpApplication.Controls.Add(this.lblProtocolType);
            this.grpApplication.Controls.Add(this.grpChannel);
            this.grpApplication.Location = new System.Drawing.Point(32, 24);
            this.grpApplication.Name = "grpApplication";
            this.grpApplication.Size = new System.Drawing.Size(272, 264);
            this.grpApplication.TabIndex = 5;
            this.grpApplication.TabStop = false;
            this.grpApplication.Text = "Application";
            // 
            // txtClientName
            // 
            this.txtClientName.Location = new System.Drawing.Point(96, 32);
            this.txtClientName.Name = "txtClientName";
            this.txtClientName.ReadOnly = true;
            this.txtClientName.Size = new System.Drawing.Size(144, 20);
            this.txtClientName.TabIndex = 6;
            this.txtClientName.Text = "";
            // 
            // lblClientName
            // 
            this.lblClientName.Enabled = false;
            this.lblClientName.Location = new System.Drawing.Point(16, 32);
            this.lblClientName.Name = "lblClientName";
            this.lblClientName.Size = new System.Drawing.Size(56, 23);
            this.lblClientName.TabIndex = 5;
            this.lblClientName.Text = "Name";
            // 
            // txtProtocolType
            // 
            this.txtProtocolType.Location = new System.Drawing.Point(96, 64);
            this.txtProtocolType.Name = "txtProtocolType";
            this.txtProtocolType.ReadOnly = true;
            this.txtProtocolType.Size = new System.Drawing.Size(144, 20);
            this.txtProtocolType.TabIndex = 4;
            this.txtProtocolType.Text = "";
            // 
            // lblProtocolType
            // 
            this.lblProtocolType.Enabled = false;
            this.lblProtocolType.Location = new System.Drawing.Point(16, 64);
            this.lblProtocolType.Name = "lblProtocolType";
            this.lblProtocolType.Size = new System.Drawing.Size(56, 23);
            this.lblProtocolType.TabIndex = 1;
            this.lblProtocolType.Text = "Protocol";
            // 
            // grpChannel
            // 
            this.grpChannel.Controls.Add(this.btnOpen);
            this.grpChannel.Controls.Add(this.btnClose);
            this.grpChannel.Location = new System.Drawing.Point(16, 104);
            this.grpChannel.Name = "grpChannel";
            this.grpChannel.Size = new System.Drawing.Size(240, 144);
            this.grpChannel.TabIndex = 8;
            this.grpChannel.TabStop = false;
            this.grpChannel.Text = "Connection";
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(56, 32);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(96, 23);
            this.btnOpen.TabIndex = 2;
            this.btnOpen.Text = "Open";
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(56, 88);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(96, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // grpWarmStandby
            // 
            this.grpWarmStandby.Controls.Add(this.lblSwitchovers);
            this.grpWarmStandby.Controls.Add(this.numericSwitchovers);
            this.grpWarmStandby.Controls.Add(this.lblTimeout);
            this.grpWarmStandby.Controls.Add(this.lblAttempts);
            this.grpWarmStandby.Controls.Add(this.numericTimeout);
            this.grpWarmStandby.Controls.Add(this.numericAttemts);
            this.grpWarmStandby.Controls.Add(this.btnStart);
            this.grpWarmStandby.Controls.Add(this.btnStop);
            this.grpWarmStandby.Controls.Add(this.btnReconfigure);
            this.grpWarmStandby.Controls.Add(this.lblStandbyChannel);
            this.grpWarmStandby.Controls.Add(this.lblActiveChannel);
            this.grpWarmStandby.Controls.Add(this.txtActiveUrl);
            this.grpWarmStandby.Controls.Add(this.txtStandbyUrl);
            this.grpWarmStandby.Enabled = false;
            this.grpWarmStandby.Location = new System.Drawing.Point(312, 24);
            this.grpWarmStandby.Name = "grpWarmStandby";
            this.grpWarmStandby.Size = new System.Drawing.Size(328, 264);
            this.grpWarmStandby.TabIndex = 7;
            this.grpWarmStandby.TabStop = false;
            this.grpWarmStandby.Text = "Warm Standby";
            // 
            // lblTimeout
            // 
            this.lblTimeout.Location = new System.Drawing.Point(8, 168);
            this.lblTimeout.Name = "lblTimeout";
            this.lblTimeout.Size = new System.Drawing.Size(74, 23);
            this.lblTimeout.TabIndex = 5;
            this.lblTimeout.Text = "Timeout (sec)";
            // 
            // lblAttempts
            // 
            this.lblAttempts.Location = new System.Drawing.Point(16, 120);
            this.lblAttempts.Name = "lblAttempts";
            this.lblAttempts.Size = new System.Drawing.Size(64, 23);
            this.lblAttempts.TabIndex = 4;
            this.lblAttempts.Text = "Attempts";
            // 
            // numericTimeout
            // 
            this.numericTimeout.Location = new System.Drawing.Point(96, 168);
            this.numericTimeout.Maximum = new System.Decimal(new int[] {
																		   120,
																		   0,
																		   0,
																		   0});
            this.numericTimeout.Name = "numericTimeout";
            this.numericTimeout.Size = new System.Drawing.Size(69, 20);
            this.numericTimeout.TabIndex = 2;
            this.numericTimeout.Value = new System.Decimal(new int[] {
																		 5,
																		 0,
																		 0,
																		 0});
            // 
            // numericAttemts
            // 
            this.numericAttemts.Location = new System.Drawing.Point(96, 120);
            this.numericAttemts.Name = "numericAttemts";
            this.numericAttemts.Size = new System.Drawing.Size(69, 20);
            this.numericAttemts.TabIndex = 1;
            this.numericAttemts.Value = new System.Decimal(new int[] {
																		 3,
																		 0,
																		 0,
																		 0});
            // 
            // btnReconfigure
            // 
            this.btnReconfigure.Location = new System.Drawing.Point(208, 208);
            this.btnReconfigure.Name = "btnReconfigure";
            this.btnReconfigure.Size = new System.Drawing.Size(96, 23);
            this.btnReconfigure.TabIndex = 10;
            this.btnReconfigure.Text = "Reconfigure";
            this.btnReconfigure.Click += new System.EventHandler(this.btnReconfigure_Click);
            // 
            // lblStandbyChannel
            // 
            this.lblStandbyChannel.Location = new System.Drawing.Point(16, 64);
            this.lblStandbyChannel.Name = "lblStandbyChannel";
            this.lblStandbyChannel.Size = new System.Drawing.Size(80, 23);
            this.lblStandbyChannel.TabIndex = 4;
            this.lblStandbyChannel.Text = "Backup Server";
            // 
            // lblActiveChannel
            // 
            this.lblActiveChannel.Location = new System.Drawing.Point(16, 32);
            this.lblActiveChannel.Name = "lblActiveChannel";
            this.lblActiveChannel.Size = new System.Drawing.Size(96, 23);
            this.lblActiveChannel.TabIndex = 3;
            this.lblActiveChannel.Text = "Primary Server";
            // 
            // txtActiveUrl
            // 
            this.txtActiveUrl.AcceptsReturn = true;
            this.txtActiveUrl.AllowDrop = true;
            this.txtActiveUrl.Location = new System.Drawing.Point(120, 32);
            this.txtActiveUrl.MaxLength = 80;
            this.txtActiveUrl.Name = "txtActiveUrl";
            this.txtActiveUrl.Size = new System.Drawing.Size(168, 20);
            this.txtActiveUrl.TabIndex = 3;
            this.txtActiveUrl.Text = "";
            // 
            // txtStandbyUrl
            // 
            this.txtStandbyUrl.Location = new System.Drawing.Point(120, 64);
            this.txtStandbyUrl.Name = "txtStandbyUrl";
            this.txtStandbyUrl.Size = new System.Drawing.Size(168, 20);
            this.txtStandbyUrl.TabIndex = 0;
            this.txtStandbyUrl.Text = "";
            // 
            // statusBar
            // 
            this.statusBar.Location = new System.Drawing.Point(0, 305);
            this.statusBar.Name = "statusBar";
            this.statusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						 this.statusBarPanelChannelEndpoint,
																						 this.statusBarPanelChannelState,
																						 this.statusBarPanelWarmStandbyState,
																						 this.statusBarPanelAttempt});
            this.statusBar.ShowPanels = true;
            this.statusBar.Size = new System.Drawing.Size(656, 24);
            this.statusBar.TabIndex = 10;
            // 
            // statusBarPanelChannelEndpoint
            // 
            this.statusBarPanelChannelEndpoint.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
            this.statusBarPanelChannelEndpoint.Width = 260;
            // 
            // statusBarPanelChannelState
            // 
            this.statusBarPanelChannelState.Width = 140;
            // 
            // statusBarPanelWarmStandbyState
            // 
            this.statusBarPanelWarmStandbyState.Width = 160;
            // 
            // statusBarPanelAttempt
            // 
            this.statusBarPanelAttempt.Width = 80;
            // 
            // numericSwitchovers
            // 
            this.numericSwitchovers.Location = new System.Drawing.Point(96, 208);
            this.numericSwitchovers.Maximum = new System.Decimal(new int[] {
																			   120,
																			   0,
																			   0,
																			   0});
            this.numericSwitchovers.Name = "numericSwitchovers";
            this.numericSwitchovers.Size = new System.Drawing.Size(69, 20);
            this.numericSwitchovers.TabIndex = 11;
            this.numericSwitchovers.Value = new System.Decimal(new int[] {
																			 3,
																			 0,
																			 0,
																			 0});
            // 
            // lblSwitchovers
            // 
            this.lblSwitchovers.Location = new System.Drawing.Point(8, 208);
            this.lblSwitchovers.Name = "lblSwitchovers";
            this.lblSwitchovers.Size = new System.Drawing.Size(74, 23);
            this.lblSwitchovers.TabIndex = 12;
            this.lblSwitchovers.Text = "Switchovers ";
            // 
            // MainForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(656, 329);
            this.Controls.Add(this.statusBar);
            this.Controls.Add(this.grpWarmStandby);
            this.Controls.Add(this.grpApplication);
            this.Name = "MainForm";
            this.Text = "Genesys Warm Standby";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Closed += new System.EventHandler(this.MainForm_Unload);
            this.grpApplication.ResumeLayout(false);
            this.grpChannel.ResumeLayout(false);
            this.grpWarmStandby.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericTimeout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericAttemts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelChannelEndpoint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelChannelState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelWarmStandbyState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanelAttempt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericSwitchovers)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new MainForm());
        }

        /// <summary>
        /// Loads the MainForm
        /// </summary>
        private void MainForm_Load(object sender, System.EventArgs e)
        {
            // set the visual control properties
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            try
            {
                this.LoadConfiguration();
            }
            catch (Exception ex)
            {
                this.Close();
                System.Diagnostics.Debug.WriteLine("Application Configuration Error:\n " + ex.ToString());
                return;

            }
            try
            {
                this.InitializeChannel();
            }
            catch (UriFormatException)
            {
                this.Close();
                return;
            }

            try
            {
                this.InitializeWarmstandby();
            }
            catch (UriFormatException)
            {
                this.Close();
                return;
            }

            this.btnClose.Enabled = false;
            this.btnStop.Enabled = false;
            grpWarmStandby.Enabled = true;

            statusBar.Panels[0].Text = "Server: " + this.channel.Endpoint.ToString();
            statusBar.Panels[1].Text = "Connection: " + this.channel.State.ToString();
            statusBar.Panels[2].Text = "WarmStandby: " + this.warmStandby.State.ToString();
            statusBar.Panels[3].Text = "Attempt: ";
        }

        /// <summary>
        /// Unloads the MainForm upon the form's event 'Closing'
        /// </summary>
        private void MainForm_Unload(object sender, System.EventArgs e)
        {
            if (this.channel != null && this.channel.State == ChannelState.Opened)
            {
                channel.Close();
            }
            warmStandby.Dispose();
        }


        #region Initializing

        /// <summary>
        /// Loads Warm Standby Quick Start Sample Application's Configuration
        /// </summary>
        private void LoadConfiguration()
        {
            try
            {
                this.appConfiguration = (WarmStandbyQuickStartConfiguration)ConfigurationManager.GetSection(WarmStandbyQuickStartConfiguration.SectionName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Warm Standby Quick Start Application Configuration Error", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }
        }

        /// <summary>
        /// Initializes the Protocol Channel
        /// </summary>
        private void InitializeChannel()
        {
            this.txtProtocolType.Text = this.appConfiguration.Protocol.ToString();
            this.txtClientName.Text = this.appConfiguration.ClientName;

            this.txtActiveUrl.Text = this.appConfiguration.PrimaryServer;

            Endpoint activeEndpoint = null;
            try
            {
                activeEndpoint = new Endpoint(new Uri(this.appConfiguration.PrimaryServer));
            }
            catch (UriFormatException ex)
            {
                MessageBox.Show(this, ex.Message, "Configuration Problem: PrimaryServer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }

            this.channel = factory.CreateProtocol(this.appConfiguration.Protocol, activeEndpoint);

            if (this.appConfiguration.Protocol == ProtocolType.ConfigurationServer)
            {
                ConfServerProtocol confChannel = this.channel as ConfServerProtocol;
                confChannel.ClientName = this.appConfiguration.ClientName;
                confChannel.UserName = this.appConfiguration.UserName;
                confChannel.UserPassword = this.appConfiguration.UserPassword;
                confChannel.ClientApplicationType = this.appConfiguration.ClientType;
                confChannel.EnableLogging(this.logger);
            }
            /*else if( this.appConfiguration.Protocol == ProtocolType.InteractionServer )
            {
                InteractionServerProtocol interactionChannel = this.channel as InteractionServerProtocol;
                interactionChannel.ClientType = (InteractionClient)this.appConfiguration.ClientType;
                interactionChannel.ClientName = this.appConfiguration.ClientName;
            }
            else if( this.appConfiguration.Protocol == ProtocolType.StatServer )
            {
                StatServerProtocol statChannel = this.channel as StatServerProtocol;
                statChannel.ClientName = this.appConfiguration.ClientName;
            }*/

            this.channel.Timeout = new TimeSpan(0, 0, 30);

            this.channel.Opened += new EventHandler(OnChannelOpened);
            this.channel.Closed += new EventHandler(OnChannelClosed);
        }

        /// <summary>
        /// Initializes the Warm Standby
        /// </summary>
        private void InitializeWarmstandby()
        {
            this.txtStandbyUrl.Text = this.appConfiguration.BackupServer;
            this.numericAttemts.Value = this.appConfiguration.Attempts;
            this.numericTimeout.Value = this.appConfiguration.Timeout;
            this.numericSwitchovers.Value = this.appConfiguration.Switchovers;

            Uri standbyUri;
            try
            {
                standbyUri = new Uri(this.appConfiguration.BackupServer);
            }
            catch (UriFormatException ex)
            {
                MessageBox.Show(this, ex.Message, "Configuration Problem: BackupServer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }
            WarmStandbyConfiguration config = new WarmStandbyConfiguration(
                this.channel.Endpoint,
                new Endpoint("backup", standbyUri),
                this.appConfiguration.Timeout * 1000, this.appConfiguration.Attempts);
            config.Switchovers = this.appConfiguration.Switchovers;
            this.warmStandby = new WarmStandbyService(this.channel);
            this.warmStandby.ApplyConfiguration(config);

            this.warmStandby.StateChanged += new EventHandler(this.OnWarmStandbyStateChanged);
            this.warmStandby.SwitchedOver += new EventHandler(this.OnWarmStandbySwitchedOver);
            statusBar.Panels[2].Text = "WarmStandby: " + this.warmStandby.State.ToString();
            statusBar.Panels[3].Text = "Attempt: ";
            this.warmStandby.EnableLogging(this.logger);
        }


        #endregion Initializing

        #region EventHandlers

        private delegate void UIEventHandler(object sender, EventArgs eventArgs);

        /// <summary>
        /// Event Handler for the event triggered by the Warm Standby when it switches over its configuration
        /// </summary>
        private void OnWarmStandbySwitchedOver(object sender, System.EventArgs eventArgs)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new UIEventHandler(this.OnWarmStandbySwitchedOver), new object[] { sender, eventArgs });
                return;
            }

            WarmStandbyService warmStandby = sender as WarmStandbyService;
            statusBar.Panels[0].Text = "Server: " + this.channel.Endpoint.ToString();
            if (this.warmStandby.State != WarmStandbyState.Off && this.warmStandby.State != WarmStandbyState.Idle)
            {
                statusBar.Panels[3].Text = "Attempt: " + this.warmStandby.Attempt;
            }
            txtActiveUrl.Text = this.warmStandby.Configuration.ActiveUri.ToString();
            txtStandbyUrl.Text = this.warmStandby.Configuration.StandbyUri.ToString();
        }

        /// <summary>
        /// Event Handler for the event triggered by the Warm Standby upon its stat change
        /// </summary>
        private void OnWarmStandbyStateChanged(object sender, System.EventArgs eventArgs)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new UIEventHandler(this.OnWarmStandbyStateChanged), new object[] { sender, eventArgs });
                return;
            }

            WarmStandbyService warmStandby = sender as WarmStandbyService;
            btnStart.Enabled = warmStandby.State == WarmStandbyState.Off;
            btnStop.Enabled = warmStandby.State != WarmStandbyState.Off;
            statusBar.Panels[2].Text = "WarmStandby: " + this.warmStandby.State.ToString();
            if (this.warmStandby.State == WarmStandbyState.Waiting)
            {
                statusBar.Panels[3].Text = "Attempt: " + this.warmStandby.Attempt;
            }
            else if (this.warmStandby.State == WarmStandbyState.Reconnecting)
            {
                statusBar.Panels[1].Text = "Connection: " + this.channel.State.ToString();
            }
            else if (this.warmStandby.State == WarmStandbyState.Off)
            {
                statusBar.Panels[3].Text = "Attempt: ";
                btnOpen.Enabled = true;
            }
            else if (this.warmStandby.State == WarmStandbyState.Idle)
            {
                statusBar.Panels[3].Text = "Attempt: ";
            }
        }

        /// <summary>
        /// Event Handler for the event triggered by the Client Channel when it gets into the Opened state
        /// </summary>
        private void OnChannelOpened(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new UIEventHandler(this.OnChannelOpened), new object[] { sender, e });
                return;
            }

            btnOpen.Enabled = false;
            btnClose.Enabled = true;
            statusBar.Panels[1].Text = "Connection: " + this.channel.State.ToString();
        }

        /// <summary>
        /// Event Handler for event triggered when the Client Channel gets into the Closed state
        /// </summary>
        private void OnChannelClosed(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new UIEventHandler(this.OnChannelClosed), new object[] { sender, e });
                return;
            }

            if (this.warmStandby.State == WarmStandbyState.Off)
            {
                btnClose.Enabled = false;
                btnOpen.Enabled = true;
            }
            else
            {
                btnClose.Enabled = false;
                btnOpen.Enabled = false;
            }

            statusBar.Panels[0].Text = "Server: " + this.channel.Endpoint.ToString();
            statusBar.Panels[1].Text = "Connection: " + this.channel.State.ToString();
        }


        #endregion EventHandlers

        private void btnOpen_Click(object sender, System.EventArgs e)
        {
            txtActiveUrl.Text = this.warmStandby.Configuration.ActiveUri.ToString();
            txtStandbyUrl.Text = this.warmStandby.Configuration.StandbyUri.ToString();

            btnOpen.Enabled = false;

            if (this.warmStandby.State == WarmStandbyState.Off)
            {
                btnClose.Enabled = true;
            }
            else
            {
                btnClose.Enabled = false;
            }

            statusBar.Panels[0].Text = "Server: " + this.channel.Endpoint.ToString();
            statusBar.Panels[1].Text = "Connection: " + ChannelState.Opening.ToString();
            statusBar.Panels[2].Text = "WarmStandby: " + this.warmStandby.State.ToString();

            try
            {
                this.channel.BeginOpen();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Open failed. " + ex.ToString() + System.Threading.Thread.CurrentThread.Name);
            }
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            btnClose.Enabled = false;
            btnOpen.Enabled = true;

            this.channel.Close();
            statusBar.Panels[1].Text = "Connection: " + ChannelState.Closed.ToString();
        }

        private void btnStart_Click(object sender, System.EventArgs e)
        {
            txtActiveUrl.Text = this.warmStandby.Configuration.ActiveUri.ToString();
            txtStandbyUrl.Text = this.warmStandby.Configuration.StandbyUri.ToString();

            if (this.channel.State == ChannelState.Closed)
            {
                btnOpen.Enabled = true;
            }
            else
            {
                btnClose.Enabled = true;
            }

            this.warmStandby.Start();
        }

        private void btnStop_Click(object sender, System.EventArgs e)
        {
            if (this.channel.State == ChannelState.Closed)
            {
                btnOpen.Enabled = true;
            }
            else
            {
                btnClose.Enabled = true;
            }
            this.warmStandby.Stop();
            //statusBar.Panels[1].Text = "Connection: " + ChannelState.Closed.ToString();
        }

        private void btnReconfigure_Click(object sender, System.EventArgs e)
        {
            Uri activeUri = null;
            Uri standbyUri = null;
            try
            {
                activeUri = new Uri(txtActiveUrl.Text);
            }
            catch (UriFormatException ex)
            {
                MessageBox.Show(this, ex.Message, "Invalid URI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            try
            {
                standbyUri = new Uri(txtStandbyUrl.Text);
            }
            catch (System.UriFormatException ex)
            {
                MessageBox.Show(this, ex.Message, "Invalid URI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (activeUri == null || standbyUri == null)
            {
                return;
            }

            WarmStandbyConfiguration config = new WarmStandbyConfiguration(
                new Endpoint("primary", activeUri),
                new Endpoint("backup", standbyUri),
                (int)numericTimeout.Value * 1000, (short)numericAttemts.Value);
            config.Switchovers = (short)numericSwitchovers.Value;
            this.warmStandby.ApplyConfiguration(config, true);

            txtActiveUrl.Text = this.warmStandby.Configuration.ActiveUri.ToString();
            txtStandbyUrl.Text = this.warmStandby.Configuration.StandbyUri.ToString();


            statusBar.Panels[3].Text = "Attempt: ";
        }
    }
}

//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

//===============================================================================

using System;
using System.Configuration;
using System.Xml;
using System.Xml.XPath;
using System.Windows.Forms;

using Genesyslab.Platform.ApplicationBlocks.WarmStandby;
using Genesyslab.Platform.Configuration.Protocols.ConfServer;

namespace WarmStandbyQuickStart
{
    /// <summary>
    /// <c>WarmStandbyQuickStartConfiguration</c> class is an implementation of <c>IConfigurationSectionHandler</c>
    /// interface for Warm Standby Quick Start sample application.
    /// </summary>
    public class WarmStandbyQuickStartConfiguration : IConfigurationSectionHandler
    {
        /// <summary>
        /// <c>SectionName</c> defines the name of the configuration section for 
        /// Warm Standby Quick Start sample application
        /// </summary>
        public const string SectionName = "WarmStandbyQuickStart";

        #region Fields

        private ProtocolType protocol;
        private string clientName;

        private string primaryServer;
        private string backupServer;
        private short attempts;
        private int timeout;
        private short switchovers = -1;

        private string userName;
        private string userPassword;
        private int clientType;

        #endregion Fields

        /// <summary>
        /// Constructor of the WarmStandbyQuickStartConfiguration class
        /// </summary>
        public WarmStandbyQuickStartConfiguration()
        {
        }

        #region Properties

        /// <summary>
        /// Gets the protocol type
        /// </summary>
        public ProtocolType Protocol
        {
            get { return this.protocol; }
        }
        /// <summary>
        /// Gets the client name
        /// </summary>
        public string ClientName
        {
            get { return this.clientName; }
        }
        /// <summary>
        /// Gets the Primary/Active server's Uri in string format
        /// </summary>
        public string PrimaryServer
        {
            get { return this.primaryServer; }
        }
        /// <summary>
        /// Gets the Backup/Standby server's Uri in string format
        /// </summary>
        public string BackupServer
        {
            get { return this.backupServer; }
        }
        /// <summary>
        /// Gets the number of reconnection (connection reopening) attempts
        /// </summary>
        public short Attempts
        {
            get { return this.attempts; }
        }
        /// <summary>
        /// Gets the value of timeout (in sec) between reconnection (connection reopening) attempts
        /// </summary>
        public int Timeout
        {
            get { return this.timeout; }
        }
        /// <summary>
        /// Gets user name (Configuration Protocol specific property)
        /// </summary>
        public string UserName
        {
            get { return this.userName; }
        }
        /// <summary>
        /// Gets user password (Configuration Protocol specific property)
        /// </summary>
        public string UserPassword
        {
            get { return this.userPassword; }
        }
        /// <summary>
        /// Gets client (application) type (Configuration Protocol specific property)
        /// </summary>
        public int ClientType
        {
            get { return this.clientType; }
        }

        /// <summary>
        /// Gets/Sets the number of primary/backup switchovers
        /// </summary>
        public short Switchovers
        {
            get { return this.switchovers; }
            set { this.switchovers = value; }
        }

        #endregion Properties

        #region IConfigurationSectionHandler Members

        /// <summary>
        /// Creates the set of configuration properties using the application configuration file 
        /// as the source
        /// </summary>
        public object Create(object parent, object configContext, XmlNode section)
        {
            string protocolName = section.SelectSingleNode("Channel/@ProtocolName").Value;
            this.clientName = section.SelectSingleNode("Channel/@ClientName").Value;
            this.clientType = int.Parse(section.SelectSingleNode("Channel/@ClientType").Value);
            this.primaryServer = section.SelectSingleNode("WarmStandby/@PrimaryServer").Value;
            this.backupServer = section.SelectSingleNode("WarmStandby/@BackupServer").Value;
            this.attempts = short.Parse(section.SelectSingleNode("WarmStandby/@Attempts").Value);
            this.timeout = int.Parse(section.SelectSingleNode("WarmStandby/@Timeout").Value);
            this.switchovers = short.Parse(section.SelectSingleNode("WarmStandby/@Switchovers").Value);

            this.protocol = ProtocolType.StatServer;
            if (ProtocolType.TServer.ToString() == protocolName) this.protocol = ProtocolType.TServer;
            else if (ProtocolType.StatServer.ToString() == protocolName) this.protocol = ProtocolType.StatServer;
            else if (ProtocolType.OutboundServer.ToString() == protocolName) this.protocol = ProtocolType.OutboundServer;
            else if (ProtocolType.InteractionServer.ToString() == protocolName) this.protocol = ProtocolType.InteractionServer;
            else if (ProtocolType.ConfigurationServer.ToString() == protocolName) this.protocol = ProtocolType.ConfigurationServer;

            if (this.protocol == ProtocolType.ConfigurationServer)
            {
                this.userName = section.SelectSingleNode("ConfServer/@UserName").Value;
                this.userPassword = section.SelectSingleNode("ConfServer/@UserPassword").Value;
            }

            return this;
        }

        #endregion IConfigurationSectionHandler Members
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Security;
using Genesyslab.Utils;

namespace Genesyslab.Platform.Standby
{
  internal static class ArrayExt
  {
    public static int[] CopyOf(this int[] source)
    {
      if (source == null) return null;
      var dest = new int[source.Length];
      Array.Copy(source,dest, source.Length);
      return dest;
    }
    public static bool EqualsTo(this int[] source, int[] dest)
    {
      if (source == null) return dest == null;
      if (dest == null) return false;
      if (source.Length!=dest.Length) return false;
      return !source.Where((t, i) => t != dest[i]).Any();
    }
    public static int CalcHashCode(this int[] source)
    {
      int h = typeof (int[]).GetHashCode();
      if (source != null)
      {
        for (int i = source.Length - 1; i >= 0; i--)
        {
          h = (h * 31) ^ source[i];
        }
      }
      return h;
    }
    public static string ConvertToString(this int[] source)
    {
      if (source == null) return String.Empty;
      if (source.Length == 0) return "[]";
      var sb = new StringBuffer().Append("[");
      foreach (int t in source)
        sb.Append(t).Append(",");
      return sb.RemoveLast(1,c => c==',').Append("]").ToString();
    }
  }

  /// <exclude/>
  public enum WSDelayType
  {
    /// <exclude/>
    Unknown = -1,
    /// <exclude/>
    ReconnectionDelay = 1,
    /// <exclude/>
    BackupDelay = 2,
    /// <exclude/>
    RetryDelay = 3,
    /// <exclude/>
    Endpoints = 4,
    /// <exclude/>
    Name = 5,
    /// <exclude/>
    Timeout = 6
  }

  /// <exclude/>
  public class WSConfigOption:EventArgs
  {
    private readonly int _optionCode;
    private WSConfigOption(WSDelayType code)
    {
      _optionCode = (int)code;
    }
    public override string ToString()
    {
      switch (_optionCode)
      {
        case 1:
          return "ReconnectionDelay";
        case 2:
          return "BackupDelay";
        case 3:
          return "RetryDelay";
        case 4:
          return "Endpoints";
        case 5:
          return "Name";
        case 6:
          return "Timeout";
        default:
          return base.ToString();
      }
    }

    /// <exclude/>
    public static readonly WSConfigOption ReconnectionDelay = new WSConfigOption(WSDelayType.ReconnectionDelay);
    /// <exclude/>
    public static readonly WSConfigOption BackupDelay = new WSConfigOption(WSDelayType.BackupDelay);
    /// <exclude/>
    public static readonly WSConfigOption RetryDelay = new WSConfigOption(WSDelayType.RetryDelay);
    /// <exclude/>
    public static readonly WSConfigOption Endpoints = new WSConfigOption(WSDelayType.Endpoints);
    /// <exclude/>
    public static readonly WSConfigOption Name = new WSConfigOption(WSDelayType.Name);
    /// <exclude/>
    public static readonly WSConfigOption Timeout = new WSConfigOption(WSDelayType.Timeout);

    /// <exclude/>
    public static implicit operator int(WSConfigOption option)
    {
      return option._optionCode;
    }
    /// <exclude/>
    public static implicit operator WSDelayType(WSConfigOption option)
    {
      switch (option._optionCode)
      {
        case (int)WSDelayType.BackupDelay: return WSDelayType.BackupDelay;
        case (int)WSDelayType.ReconnectionDelay: return WSDelayType.ReconnectionDelay;
        case (int)WSDelayType.RetryDelay: return WSDelayType.RetryDelay;
        case (int)WSDelayType.Endpoints: return WSDelayType.Endpoints;
        case (int)WSDelayType.Name: return WSDelayType.Name;
        case (int)WSDelayType.Timeout: return WSDelayType.Timeout;
        default: return WSDelayType.Unknown;
      } 
    }
  } 

  /// <summary>
  /// The configuration helps to:
  /// <list type="bullet">
  /// <item>define endpoint pool using <see cref="Endpoints"/> or <see cref="SetEndpoints(Endpoint[])"/>;</item>
  /// <item>configure standard warm standby behavior.</item>
  /// </list>
  /// </summary>
  public sealed class WSConfig: ICloneable
  {
    private class CopyOnWriteList<T> : List<T>, IList<T>, ICloneable where T : class
    {
      public CopyOnWriteList(){ }
      public CopyOnWriteList(IEnumerable<T> valuesList) : base(valuesList) { }
      IEnumerator<T> IEnumerable<T>.GetEnumerator()
      {
        return new List<T>(this).GetEnumerator();
      }

      public object Clone()
      {
        return new CopyOnWriteList<T>(this);
      }

      public override string ToString()
      {
        if (Count == 0) return "[]";
        var sb = new StringBuffer().Append("[");
        foreach (T value in this)
        {
          sb.Append(value.ToString()).Append(",");
        }
        return sb.RemoveLast(1,c => c==',').Append("]").ToString();
      }

      public override int GetHashCode()
      {
        int hash = GetType().GetHashCode();
        return this.Aggregate(hash, (current, value) => (current*27) ^ value.GetHashCode());
      }

      public override bool Equals(object obj)
      {
        var tObj = obj as CopyOnWriteList<T>;
        if ((tObj == null)|| (Count != tObj.Count)) return false;
        for (int i = 0; i < Count; i++)
        {
          try
          {
            if (!this[i].Equals(tObj[i])) return false;
          }
          catch (Exception)
          {
            return false;
          }
        }
        return true;
      }

      void ICollection<T>.Add(T item)
      {
        if (item == null)
          throw new ArgumentNullException("item","value can not be null");
        base.Add(item);
        Notify();
      }
      bool ICollection<T>.Remove(T item)
      {
        if (item == null)
          throw new ArgumentNullException("item", "value can not be null");
        var result = base.Remove(item);
        if (result) Notify();
        return result;
      }
      void IList<T>.RemoveAt(int index)
      {
        base.RemoveAt(index);
        Notify();
      }
      T IList<T>.this[int index]
      {
        get
        {
          return base[index];
        }
        set
        {
          if (value==null)
            throw new ArgumentNullException("value","value can not be null");
          base[index] = value;
          Notify();
        }
      }
      void IList<T>.Insert(int index, T item)
      {
        if (item==null)
          throw new ArgumentNullException("item", "value can not be null");
        base.Insert(index, item);
        Notify();
      }

      private void Notify()
      {
        var handler = OnChange;
        if (handler != null)
        {
          try
          {
            handler.Invoke(this, EventArgs.Empty);
          }catch(Exception e){}
        }
      }

      internal event EventHandler OnChange;
    }

    private static readonly SecureRandom RandomGenerator = new SecureRandom();
    private volatile CopyOnWriteList<Endpoint> _endpoints = new CopyOnWriteList<Endpoint>();
    private volatile int _reconnectionRandomDelayRange;// 
    private volatile int _backupDelay;
    private volatile int[] _retryDelay = { 1000 };
    private int? _timeout;
    private volatile string _name ;

    private readonly object _syncRoot = new object();
    internal object SyncRoot { get { return _syncRoot; }}

    internal int RandomDelay
    {
      get
      {
        var range = _reconnectionRandomDelayRange;
        return range == 0 ? 0 : RandomGenerator.Next(range);
      }
    }

    /// <summary>
    /// Constructor of WSConfig. Creates instance of WSConfog with default values.
    /// </summary>
    public WSConfig():this(null){}
    /// <summary>
    /// Constructor of WSConfig. Creates instance of WSConfog with default values.
    /// </summary>
    /// <param name="name">Name of configuration</param>
    public WSConfig(string name)
    {
      _name = name;
      _endpoints.OnChange += (sender, args) => OnChanged(WSConfigOption.Endpoints);
    }
    #region properties

    /// <summary>
    /// Sets endpoints list.
    /// <para>
    /// <b>Note:</b> if endpoints with same app,host and port will be passed
    /// multiple times then only first one will be used while opening.
    /// </para>
    /// <para>
    /// The iteration through endpoints always starts from the begin of the ednpoint's pool. <br/>
    /// Endpoint from which channel has been disconnected and endpoints which
    /// have been already checked unsuccessfully after disconnection, are skipped
    /// from the iteration. <br/>
    /// If some other order of iteration is desired than in the appropriate event 
    /// handler the endpoints order in the pool can be changed appropriately.
    /// </para>
    /// </summary>
    public IList<Endpoint> Endpoints
    {
      get { return _endpoints; }
      set
      {
        if (value == null)
        {
          _endpoints.Clear();
        }
        else
        {
          if (value.Any(e => e == null))
            throw new ArgumentException("null endpoint in list", "value");
          var newEndpoints = new CopyOnWriteList<Endpoint>(value);
          newEndpoints.OnChange += (sender, args) => OnChanged(WSConfigOption.Endpoints);
          lock (SyncRoot)
          {
            _endpoints = newEndpoints;
            OnChanged(WSConfigOption.Endpoints);
          }
        }
      }
    }
    /// <summary>
    /// Sets open array of endpoints.
    /// </summary>
    /// <param name="value">Open array of endpoints</param>
    /// <returns>this instance</returns>
    public WSConfig SetEndpoints(params Endpoint[] value) {
      Endpoints = value==null?null:value.ToList();
      return this;
    }

    /// <summary>
    /// Gets/sets the random delay range before reconnection to the last opened
    /// endpoint in case of disconnection.
    /// </summary>
    public int ReconnectionRandomDelayRange
    {
      get { return _reconnectionRandomDelayRange; }
      set
      {
        if (value < 0)
        {
          throw new ArgumentException("negative reconnectionRandomDelayRange", "value");
        }
        if (_reconnectionRandomDelayRange != value)
        {
          lock (SyncRoot)
          {
            _reconnectionRandomDelayRange = value;
            OnChanged(WSConfigOption.ReconnectionDelay);
          }
        }
      }
    }
    /// <summary>
    /// Gets/sets the backup delay that is applied after failure of the first
    /// reconnection attempt and before switching to backup endpoint. It
    /// represents time which is enough for backup server to switchover to
    /// primary mode.
    /// </summary>
    public int BackupDelay
    {
      get { return _backupDelay; }
      set
      {
        if (value < 0)
          throw new ArgumentException("negative backupDelay", "value");
        if (_backupDelay != value)
        {
          lock (SyncRoot)
          {
            _backupDelay = value;
            OnChanged(WSConfigOption.BackupDelay);
          }
        }
      }
    }
    /// <summary>
    /// Gets/sets the open timeout that is used for connection to endpoints.
    /// Default value is null, it means using channel's timeout.
    /// </summary>
    public int? Timeout
    {
      get { return _timeout; }
      set
      {
        if ((value!=null) && (value < -1))
          throw new ArgumentException("illegal negative timeout", "value");
        lock (SyncRoot)
        {
          _timeout = value;
          OnChanged(WSConfigOption.Timeout);
        }
      }
    }
    /// <summary>
    /// Gets/sets name of configuration.
    /// Default value is null.
    /// </summary>
    public string Name
    {
      get { return _name; }
    }
    /// <summary>
    /// Gets/sets retry delays that is applied after all endpoints has been checked
    /// unsuccessfully and before next iteration will be started.
    /// <para>The default value is 1000 ms.</para>
    /// </summary>
    public int[] RetryDelay
    {
      get { return _retryDelay; }
      set
      {
        var tmp = value.CopyOf();
        if ((tmp!=null) && (tmp.Any(t => t < 0)))
          throw new ArgumentException("negative retryDelay", "value");
        if (!_retryDelay.EqualsTo(tmp))
        {
          lock (SyncRoot)
          {
            _retryDelay = tmp;
            OnChanged(WSConfigOption.RetryDelay);
          }
        }
      }
    }

    /// <summary>
    /// Sets retry delays that is applied after all endpoints has been checked
    /// unsuccessfully and before next iteration will be started.
    /// </summary>
    public WSConfig SetRetryDelay(params int[] values)
    {
      RetryDelay = values;
      return this;
    }

    /// <summary>
    /// Gets retry delay that is applied after all endpoints has been checked
    /// unsuccessfully and before next iteration will be started.
    /// </summary>
    /// <returns>retry delay in milliseconds</returns>
    public int GetRetryDelay(int retryNumber)
    {
      if (retryNumber < 0)
        throw new ArgumentException("null retryNumber", "retryNumber");
      int[] retryDelays = _retryDelay;
      return (retryDelays != null && retryDelays.Length > 0)
        ? retryDelays[Math.Min(retryDelays.Length - 1, retryNumber)]
        : 0;
    }

    #endregion properties

    #region service
    internal event EventHandler Changed;
    private void OnChanged(WSConfigOption option)
    {
      EventHandler handler = Changed;
      if (handler != null)
        handler(this, option);
    }
    internal void Apply(WSConfig configuration)
    {
      if (configuration == null)
        throw new ArgumentNullException("configuration", "null configuration");
      ReconnectionRandomDelayRange = configuration.ReconnectionRandomDelayRange;
      BackupDelay = configuration.BackupDelay;
      Timeout = configuration.Timeout;
      RetryDelay = configuration.RetryDelay;
      Endpoints = configuration.Endpoints;
    }
    public object Clone()
    {
      var obj = (WSConfig) MemberwiseClone();
      obj._endpoints = (CopyOnWriteList<Endpoint>)_endpoints.Clone();
      obj._endpoints.OnChange += (sender, args) => OnChanged(WSConfigOption.Endpoints);
      int[] tmp = _retryDelay;
      if (tmp != null)
      {
        obj._retryDelay = new int[tmp.Length];
        Array.Copy(tmp,obj._retryDelay,tmp.Length);
      }
      return obj;
    }

    public override int GetHashCode()
    {
      int h = typeof (WSConfig).GetHashCode();
      h = (h*31) ^ _reconnectionRandomDelayRange;
      h = (h*37) ^ _backupDelay;
      h = (h*41) ^ _retryDelay.CalcHashCode();
      h = (h*47) ^ _endpoints.GetHashCode();
      if (_name != null)
        h ^= _name.GetHashCode();
      return (_timeout == null) ? h : (h*47) ^ _timeout.Value;
    }

    public override bool Equals(object obj)
    {
      var tObj = obj as WSConfig;
      return 
           (tObj != null) 
        && String.Equals(_name, tObj._name)
        && (_timeout.Equals(tObj._timeout)) 
        && (_reconnectionRandomDelayRange == tObj._reconnectionRandomDelayRange)
        && (_backupDelay == tObj._backupDelay) 
        && (_retryDelay.EqualsTo(tObj._retryDelay)) 
        && (_endpoints.Equals(tObj._endpoints));
    }

    /// <summary>
    /// Compars configurations ignoring their names 
    /// </summary>
    /// <param name="config">Configuration to be compared</param>
    /// <returns>comparison result</returns>
    public bool EqualsIgnoreName(WSConfig config)
    {
      return EqualsIgnoreName(this, config);
    }
    /// <summary>
    /// Helper method, to compare configurations ignoring their names 
    /// </summary>
    /// <param name="firstCfg">First config</param>
    /// <param name="secondCfg">Second config</param>
    /// <returns>comparison result</returns>
    public static bool EqualsIgnoreName(WSConfig firstCfg, WSConfig secondCfg)
    {
      if (ReferenceEquals(firstCfg,secondCfg)) return true;
      if ((firstCfg==null) || (secondCfg==null)) return false;
      return
        (firstCfg._timeout.Equals(secondCfg._timeout))
        && (firstCfg._reconnectionRandomDelayRange == secondCfg._reconnectionRandomDelayRange)
        && (firstCfg._backupDelay == secondCfg._backupDelay)
        && (firstCfg._retryDelay.EqualsTo(secondCfg._retryDelay))
        && (firstCfg._endpoints.Equals(secondCfg._endpoints));
    }

    public override string ToString()
    {
      var sb = new StringBuffer();
      sb.Append("{");
      if (_name != null)
        sb.Append("\"Name\":\"").Append(Name.Replace("\"","\\\"")).Append("\",");
      if (_reconnectionRandomDelayRange != 0)
        sb.Append("\"ReconnectionRandomDelayRange\":").Append(_reconnectionRandomDelayRange).Append(",");
      if (_backupDelay != 0)
        sb.Append("\"BackupDelay\":").Append(_backupDelay).Append(",");
      if (_retryDelay!=null) 
        sb.Append("\"RetryDelay\":").Append(_retryDelay.ConvertToString()).Append(",");
      if (_timeout != null)
        sb.Append("\"Timeout\":").Append(_timeout.Value).Append(","); 
      if (_endpoints.Count>0)
        sb.Append("\"Enpoints\":").Append(_endpoints.ToString()).Append(",");
      return sb.RemoveLast(1,c => c==',').Append("}").ToString();
    }

    #endregion service
  }
}

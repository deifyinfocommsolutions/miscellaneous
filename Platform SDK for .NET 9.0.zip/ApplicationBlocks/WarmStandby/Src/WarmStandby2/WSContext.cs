﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;

namespace Genesyslab.Platform.Standby
{

  internal class ManualResetEventEx : EventWaitHandle
  {
    private readonly AtomicReference<Thread> _invokerThreadRef;
    private ILogger _logger;
    internal ManualResetEventEx(AtomicReference<Thread> reference)
      : base(false, EventResetMode.ManualReset)
    {
      _invokerThreadRef = reference;
    }

    internal void SetLogger(ILogger logger)
    {
      _logger = ((logger == null) || (!logger.IsWarnEnabled)) ? null : logger;
    }

    private void CheckThread()
    {
      if (_invokerThreadRef == null) return;
      if (_invokerThreadRef.Get() == Thread.CurrentThread)
      {
        if (_logger != null)
          _logger.Warn("[WaitHandle.WaitOne] Invalid operation: this method can not be called inside WarmStandbyInvoker. ");
        throw new InvalidOperationException("Synchronous operations are disabled inside handlers");
      }
    }
    public override bool WaitOne(TimeSpan timeout, bool exitContext)
    {
      CheckThread();
      return base.WaitOne(timeout, exitContext);
    }
    public override bool WaitOne(int millisecondsTimeout, bool exitContext)
    {
      CheckThread();
      return base.WaitOne(millisecondsTimeout, exitContext);
    }
  }
  internal class EnvelopedManualResetEvent
  {
    private volatile ManualResetEvent _event;
    internal EnvelopedManualResetEvent(bool synchronous)
    {
      if (synchronous)
        _event = new ManualResetEvent(false);
    }

    internal void Close()
    {
      var evt = _event;
      _event = null;
      if (evt != null)
        evt.Close();
    }

    public void Set()
    {
      var evt = _event;
      if (evt != null) evt.Set();
    }
    public bool WaitOne(TimeSpan timeout)
    {
      var evt = _event;
      return (evt == null) || evt.WaitOne(timeout);
    }
  }

  internal class ControlledManualResetEvent : EventWaitHandle
  {
    private readonly bool _synchronous;
    internal ControlledManualResetEvent(bool synchronous)
      : base(false, EventResetMode.ManualReset)
    {
      _synchronous = synchronous;
    }

    public new void Set()
    {
      if (_synchronous) base.Set();
    }
    public override bool WaitOne(TimeSpan timeout, bool exitContext)
    {
      return !_synchronous || base.WaitOne(timeout, exitContext);
    }
  }
  internal class AtomicReference<T> where T : class
  {
    private T _reference;

    internal AtomicReference()
    {
      _reference = default(T);
    }
    internal T Get()
    {
      return Interlocked.CompareExchange(ref _reference, null, null);
    }
    internal void Set(T value)
    {
      Interlocked.Exchange(ref _reference, value);
    }
    internal void Set(T value, T compare)
    {
      Interlocked.CompareExchange(ref _reference, value, compare);
    }

  }

  /// <exclude/>
  internal abstract class WSContext : AbstractLogEnabledEx
  {
    #region private

    private static int _uniqueIdCounter;
    private readonly int _uniqueId = Interlocked.Increment(ref _uniqueIdCounter);

    internal readonly WarmStandbyImpl ImplWarmStandby;
    public Exception Cause { get; private set; }
    private readonly Queue<IAsyncResultNotifySupport> _asyncResults = new Queue<IAsyncResultNotifySupport>();
    #endregion private

    #region properties
    public bool IsCompleted { get; private set; }
    public ManualResetEventEx AsyncWaitHandle { get; private set; }
    internal readonly ControlledManualResetEvent CompletionHandle;
    internal readonly EventWaitHandle FinalizeHandle;
    internal WSConfig Configuration
    {
      get { return ImplWarmStandby.Configuration; }
    }

    internal IAsyncInvoker AsyncInvoker
    {
      get { return ImplWarmStandby.AsyncInvoker; }
    }
    #endregion properties

    #region constructor
    /// <exclude/>
    internal WSContext(WarmStandbyImpl warmStandby)
    {
      ImplWarmStandby = warmStandby;
      AsyncWaitHandle = new ManualResetEventEx(GetThreadReference);
      AsyncWaitHandle.SetLogger(Logger);
      CompletionHandle = new ControlledManualResetEvent(ImplWarmStandby.WaitForCompleteNotifications);
      FinalizeHandle = new ManualResetEvent(false);
    }
    #endregion constructor
    protected override void OnEnableLogging(ILogger logger)
    {
      base.OnEnableLogging(logger);
      AsyncWaitHandle.SetLogger(logger);
    }
    #region Invokers
    protected virtual AtomicReference<Thread> GetThreadReference
    {
      get { return (ImplWarmStandby == null) ? null : ImplWarmStandby.InvokerReference; }
    }

    internal void FireSuccess(EventArgs args)
    {
      FireSuccess(args,true);
    }
    internal void FireSuccess(EventArgs args,bool finalize)
    {
      Complete(args, null, finalize);
      this.DebugFormatLog("{0}.FireSuccess", LogWarmStandbyName);
    }

    internal virtual void FireFailed(EventArgs args, Exception cause)
    {
      if (Complete(args, cause))
        this.DebugFormatLog(LogWarmStandbyName + ".FireFailed with exception: {0} message: '{1}'",
            cause != null ? cause.GetType().Name : "", cause != null ? cause.Message : "");
    }

    private bool Complete(EventArgs args,Exception cause)
    {
      return Complete(args, cause, true);
    }
    protected virtual void OnComplete(){}
    private bool Complete(EventArgs args, Exception cause, bool finalize)
    {
      if (!IsCompleted) 
      lock (ImplWarmStandby.SyncRoot)
      {
        if (!IsCompleted)
        {
          this.DebugFormatLog("{0} Completing... finalize={1}  cause:{2}", this, finalize,
            (cause == null) ? "<null>" : cause.ToString());
          OnComplete();
          Cause = cause;
          IsCompleted = true;
          AsyncWaitHandle.Set();
          while (_asyncResults.Count > 0)
          {
            var iar = _asyncResults.Dequeue();
            if (iar != null)
            {
              iar.Arguments = args;
              AsyncInvoker.Invoke(ImplWarmStandby.RunCallback, iar);
            }
          }
          if (finalize)
            AsyncInvoker.Invoke(state => OnFinalize(), this);
          this.DebugFormatLog("{0}.Complete()", LogWarmStandbyName);
          return true;
        }
      }
      return false;
    }
    internal void RunCallback(object iarObj)
    {
      var iar = iarObj as IAsyncResultNotifySupport;
      if (iar != null)
      {
        try
        {
          iar.ExecCallback();
        }
        catch (Exception e)
        {
          this.DebugFormatLog("WSContext: [{0}] has thrown an exception: {1}", iar.ToString(), e);
        }
      }
    }
    #endregion

    public abstract IAsyncResultNotifySupport CreateAsyncResult(AsyncCallback callback, object state);
    private string _logInstanceName ;
    internal String LogWarmStandbyName
    {
      get
      {
        return _logInstanceName ?? (_logInstanceName = ImplWarmStandby.LogInstanceName
          + GetType().Name + "[" + _uniqueId + "]");
      }
    }
    internal IAsyncResultNotifySupport RegisterAsyncResult(IAsyncResultNotifySupport iar)
    {
      lock (ImplWarmStandby.SyncRoot)
      {
        if (!IsCompleted)
        {
          this.DebugFormatLog("{0}.RegisterAsyncResult adding {1} to queue", LogWarmStandbyName, iar.GetType().Name);
          _asyncResults.Enqueue(iar);
        }
        else
        {
          this.DebugFormatLog("{0}.RegisterAsyncResult invoking {1}", LogWarmStandbyName, iar.GetType().Name);
          AsyncInvoker.Invoke(ImplWarmStandby.RunCallback, iar);
        }
      }
      return iar;
    }

    internal event EventHandler Finalize;

    internal virtual void OnFinalize()
    {
      EventHandler handler = Finalize;
      Finalize = null;
      if (handler != null) 
        handler(this, EventArgs.Empty);
    }
  }

  internal class WSOpenContext : WSContext, ITimerAction
  {
    private readonly List<Endpoint> _processedEnpoints = new List<Endpoint>();
    private ITimerActionTicket _timerActionTicket;
    private readonly int _retryNumber;
    private volatile bool _restore;
    private volatile ClosedEventArgs _previousClosedEventArgs;

    internal delegate void OnRestartHandler(int delay, Exception exception, ClosedEventArgs args);

    internal OnRestartHandler OnRestart;
    internal int RetryNumber { get { return _retryNumber; } }

    internal WSOpenContext(WarmStandbyImpl warmStandby, bool restore, int retryNumber, ClosedEventArgs args )
      : base(warmStandby)
    {
      _restore = restore;
      _retryNumber = retryNumber;
      _previousClosedEventArgs = args;
      if (_previousClosedEventArgs != null)
      {
        if ((_previousClosedEventArgs.SessionCountReceivedMessages == 0)
            && ((_previousClosedEventArgs.SessionCountSentMessages > 0)
                || (_previousClosedEventArgs.AddpInitializationIsNotConfirmed)))
        {
          var ep = _previousClosedEventArgs.Endpoint;
          if ((ep != null) && (!_processedEnpoints.Contains(ep)))
            _processedEnpoints.Add(ep);
        }
      }
    }

    private int DelayRange
    {
      get { return ImplWarmStandby.Configuration.RandomDelay; }
    }

    protected override void OnComplete()
    {
      CancelTimerAction();
    }
    private bool SetChannelEndpoint(Endpoint endpoint)
    {
      this.DebugFormatLog("{0} Using endpoint: {1}", LogWarmStandbyName, endpoint);
      try
      {
        ImplWarmStandby.ConnectionOperations.Endpoint = endpoint;
        ImplWarmStandby.Channel.TlsProperties.Enabled = false;
      }
      catch (Exception e)
      {
        this.DebugFormatLog("{0} Exception during set endpoint: {1}", LogWarmStandbyName, e);

        var args = new ClosedEventArgs(ChannelState.Closed, e, endpoint);
        var result = ImplWarmStandby.OnEndpointTriedUnsuccessfully(args);
        _timerActionTicket = WarmStandbyImpl.TimerFactory.Schedule(1, new ProcessOnEndpointTriedUnsuccessfully(this, args, result));
        return false;
      }
      this.DebugFormatLog("{0} Used endpoint: {1}", LogWarmStandbyName, endpoint);
      return true;
    }
    private void ClearChannelEndpoint()
    {
      try
      {
        ImplWarmStandby.ConnectionOperations.Endpoint = null;
        ImplWarmStandby.Channel.TlsProperties.Enabled = false;
      }
      catch (Exception e)
      {
        this.DebugFormatLog("{0} Exception during clear endpoint: {1}", LogWarmStandbyName, e);
      }
    }
    private class ProcessOnEndpointTriedUnsuccessfully : ITimerAction
    {
      private readonly WSOpenContext _context;
      private readonly ClosedEventArgs _args;
      private readonly WarmStandbyImpl.EndpointTriedUnsuccessfullyResult _result;
      internal ProcessOnEndpointTriedUnsuccessfully(WSOpenContext context,
        ClosedEventArgs args,
        WarmStandbyImpl.EndpointTriedUnsuccessfullyResult result)
      {
        _context = context;
        _args = args;
        _result = result;
      }
      public void OnTimer()
      {
        if (!_context.IsCompleted)
        {
          _context.ProcessEndpointTriedUnsuccessfully(_args, _result);
        }
      }
    }
    internal void BeginOpen(bool restore, int timeout, ClosedEventArgs args)
    {
      if (!restore)
      {
        var endPoint = GetEndpoint();
        if (endPoint == null)
        {
          Exception cause;
          if (Configuration.Endpoints.Any(endpoint => ((endpoint != null) && (!endpoint.IsUndefined))))
          {
            cause = new WSNoAvailableServersException("There is no available servers", null);
          }
          else
          {
            cause = new WSEmptyEndpointPoolException("Endpoint's pool is empty", null);
            ClearChannelEndpoint();
          }
          ImplWarmStandby.OnAllEndpointsTriedUnsuccessfully(_retryNumber + 1);
          if (IsCompleted) return;
          _processedEnpoints.Clear();

          if (ImplWarmStandby.AutoRestoreFlag)
          {
            if (OnRestart != null)
              OnRestart(Configuration.GetRetryDelay(_retryNumber) + DelayRange, cause, args);
          }
          else
          {
            FireFailed(null,cause);
            ImplWarmStandby.BeginClose(null, null);
          }
          return;
        }
        if (!SetChannelEndpoint(endPoint)) return;
      }
      else 
      {
        lock (ImplWarmStandby.SyncRoot)
        {
          Endpoint endPoint = ImplWarmStandby.ConnectionOperations.Endpoint;
          if (endPoint != null)
          {
            if (Configuration.Endpoints.Contains(endPoint) && (!_processedEnpoints.Contains(endPoint)))
            {
              timeout += DelayRange;
              _processedEnpoints.Add(endPoint);
            }
            else
            {
              endPoint = GetEndpoint();
              if (endPoint == null)
              {
                var cause = new WSEmptyEndpointPoolException("Endpoint's pool is empty.", null);
                ImplWarmStandby.OnAllEndpointsTriedUnsuccessfully(_retryNumber + 1);
                if ((ImplWarmStandby.AutoRestoreFlag) && (OnRestart != null))
                {
                  OnRestart(Configuration.GetRetryDelay(_retryNumber) + DelayRange, cause, args);
                } else
                {
                  FireFailed(null, cause);
                  Monitor.Exit(ImplWarmStandby.SyncRoot);
                  ImplWarmStandby.OnAllEndpointsTriedUnsuccessfully(_retryNumber + 1);
                  Monitor.Enter(ImplWarmStandby.SyncRoot);
                }
                return;

              }
              if (!SetChannelEndpoint(endPoint)) return;
            }
          }
        }
      }
      if (timeout == 0)
      {
        OnTimer();
      }
      else
      {
        var logEnabled = WarmStandbyImpl.TimerFactory as AbstractLogEnabled;
        if (logEnabled != null) logEnabled.EnableLogging(Logger);
        this.DebugFormatLog("{0}.BeginOpen schedules open action with timeout {1} ms.", LogWarmStandbyName, Math.Max(1, timeout));
        _timerActionTicket = WarmStandbyImpl.TimerFactory.Schedule(Math.Max(1, timeout), this);
      }
    }

    internal void CancelTimerAction()
    {
      if (!IsCompleted)
      {
        var action = _timerActionTicket;
        _timerActionTicket = null;
        if (action != null)
        {
          action.Cancel();
          this.DebugFormatLog("{0}.CancelTimerAction.", LogWarmStandbyName);
        }
      }
    }
    private class OpenedArgs : OpenedEventArgs
    {
      public OpenedArgs(WarmStandbyImpl ws)
        : base(null)
      {
        Endpoint = ws.Channel.Endpoint == null ? null : ws.Channel.Endpoint.Clone() as Endpoint;
      }
    }
    internal void CompleteSuccess(OpenedEventArgs args, bool notify)
    {
      if (args == null) args = new OpenedArgs(ImplWarmStandby);
      FireSuccess(args, !ImplWarmStandby.WaitForCompleteNotifications);
      if (notify)
      {
        ImplWarmStandby.OnChannelOpened(args);
        this.DebugFormatLog(LogWarmStandbyName + ".ChannelOpened success: {0}", args.ToString());
      }
      if (ImplWarmStandby.WaitForCompleteNotifications)
        OnFinalize();

    }

    internal override void FireFailed(EventArgs args, Exception cause)
    {
      ImplWarmStandby.ConnectionOperations.Close();
      args = args as OpenedEventArgs ?? new OpenedEventArgs(cause);
      base.FireFailed(args, cause);
    }
    private void ChannelBeginOpenCallback(object state)
    {
      var openIar = state as DuplexChannel.IAsyncChannelOperation;
      try
      {
        this.DebugLog("{0} callback with cause: {1}",LogWarmStandbyName, openIar==null?"<null>":(openIar.Cause==null)?"<OK>":openIar.Cause.ToString());
        ImplWarmStandby.ConnectionOperations.EndOpen(openIar);
        if (Cause is WSCanceledException)
        {
          throw Cause;
        }
        ImplWarmStandby.SetChannelCloseEvent();
        var args = openIar == null ? null : openIar.Arguments as OpenedEventArgs;
        CompleteSuccess(args, true);
      }
      catch (Exception)
      {
        var args = openIar == null ? null : openIar.Arguments as ClosedEventArgs;
        if (args == null)
        {
          var err = openIar == null ? null : openIar.Arguments as ErrorArgs;
          args = new ClosedEventArgs(ChannelState.Opening, (err != null)?err.Cause:null, ImplWarmStandby.Channel.Endpoint);
        }
        this.DebugFormatLog(LogWarmStandbyName + ".ChannelOpened failed : {0}", args.ToString());
        var result = ImplWarmStandby.OnEndpointTriedUnsuccessfully(args);
        ProcessEndpointTriedUnsuccessfully(args, result);
      }
    }

    private void ProcessEndpointTriedUnsuccessfully(ClosedEventArgs args, 
                                                    WarmStandbyImpl.EndpointTriedUnsuccessfullyResult result)
    {
      if ((!ImplWarmStandby.IsActive) || (IsCompleted))
      {
        this.DebugFormatLog(LogWarmStandbyName + ".ChannelOpenedCallback: stop continue cause active:{0} completed:{1}", ImplWarmStandby.IsActive, IsCompleted);
        return;
      }
      switch (result)
      {
        case WarmStandbyImpl.EndpointTriedUnsuccessfullyResult.Fail:
          {
            FireFailed(args, args != null ? args.Cause : null);
            ImplWarmStandby.BeginClose(null, null);
            return;
          }
        case WarmStandbyImpl.EndpointTriedUnsuccessfullyResult.Restart:
          {
            if ((args != null) && (args.Endpoint != null))
            {
              if ((Configuration.Endpoints.Contains(args.Endpoint)) && (_processedEnpoints.Contains(args.Endpoint)))
                _processedEnpoints.Remove(args.Endpoint);
            }
            BeginOpen(true, 0, args);
            return;
          }
        case WarmStandbyImpl.EndpointTriedUnsuccessfullyResult.Continue:
          {
            int timeout = 0;
            if (_restore)
            {
              _restore = false;
              timeout = Configuration.BackupDelay;
            }
            BeginOpen(false, timeout, args);
            return;
          }
      }
      
    }
    public void OnTimer()
    {
      CancelTimerAction();
      if (!IsCompleted)
      {
        this.DebugFormatLog("{0}.OnTimer executing Channel.BeginOpen method.", LogWarmStandbyName);
        AsyncCallback callback = ar => ThreadPool.QueueUserWorkItem(ChannelBeginOpenCallback, ar);

        if (Configuration.Timeout != null)
          ImplWarmStandby.ConnectionOperations.BeginOpen(TimeSpan.FromMilliseconds(Configuration.Timeout.Value),
            callback, this);
        else
          ImplWarmStandby.ConnectionOperations.BeginOpen(callback, this);
      }
      else
      {
        this.DebugFormatLog("{0}.OnTimer skipping executing Channel.BeginOpen method cause it is completed.", LogWarmStandbyName);
      }
    }

    public override IAsyncResultNotifySupport CreateAsyncResult(AsyncCallback callback, object state)
    {
      return RegisterAsyncResult(new WSOpenAsyncResult(this, callback, state));
    }

    private Endpoint GetEndpoint()
    {
      lock (ImplWarmStandby.SyncRoot)
      {
        var enpoint =
          Configuration.Endpoints.FirstOrDefault(
            endpoint => ((endpoint != null) && (!endpoint.IsUndefined) && (!_processedEnpoints.Contains(endpoint))));
        if (enpoint != null)
          _processedEnpoints.Add(enpoint);
        return enpoint;
      }
    }
  }
  internal class WSCloseContext : WSContext
  {
    internal WSCloseContext(WarmStandbyImpl warmStandby)
      : base(warmStandby)
    {
      warmStandby.Resume();
    }
    public override IAsyncResultNotifySupport CreateAsyncResult(AsyncCallback callback, object state)
    {
      return RegisterAsyncResult(new WSCloseAsyncResult(this, callback, state));
    }

    protected override AtomicReference<Thread> GetThreadReference
    {
      get { return null; }
    }

    internal void BeginClose()
    {
      EventArgs args = null;
      ImplWarmStandby.ConnectionOperations.BeginClose(TimeoutConstants.InfiniteTimeout, ar =>
      {
        var oper = ar as DuplexChannel.IAsyncChannelOperation;
        if (oper != null) args = oper.Arguments;
        try
        {
          ImplWarmStandby.ConnectionOperations.EndClose(ar);
        }
        catch (Exception e)
        {
          this.DebugLog(LogWarmStandbyName + "Channel.EndClose raised exception: ", e);
        }
        FireSuccess(args);
      }, this);
    }
  }


  internal interface IAsyncResultNotifySupport : IAsyncResult
  {
    void ExecCallback();
    EventArgs Arguments { get; set; }
  }
  /// <exclude/>
  public abstract class WSAsyncResult : AbstractLogEnabled, IAsyncResultNotifySupport
  {
    #region private
    private readonly WSContext _wsContext;
    private readonly AsyncCallback _callback;
    private String _toStrigValue;
    #endregion private

    #region properties
    public bool IsCompleted { get { return _wsContext.IsCompleted; } }
    public WaitHandle AsyncWaitHandle { get { return _wsContext.AsyncWaitHandle; } }
    internal WaitHandle CompletionHandle { get { return _wsContext.CompletionHandle; } }
    /// <exclude/>
    public Exception Cause { get { return _wsContext.Cause; } }
    public object AsyncState { get; private set; }
    public bool CompletedSynchronously { get; internal set; }
    public EventArgs Arguments { get;  set; }
    internal WSContext Context
    {
      get { return _wsContext; }
    }

    #endregion properties

    internal WSAsyncResult(WSContext wsWSContext, AsyncCallback callback, object asyncState)
    {
      _wsContext = wsWSContext;
      _callback = callback;
      AsyncState = asyncState;
    }

    void IAsyncResultNotifySupport.ExecCallback()
    {
      if (_callback != null)
      {
        Context.DebugFormatLog(_wsContext.LogWarmStandbyName + ": Start executing [{0}]", this);
        _callback(this);
      }
    }

    public override string ToString()
    {
      return _toStrigValue ?? (_toStrigValue = string.Format(
        "\"{2}\":\"{0}.{1}\"", (((_callback == null) || (_callback.Method == null) || (_callback.Method.ReflectedType == null))
          ? ""
          : _callback.Method.ReflectedType.FullName), (((_callback == null) || (_callback.Method == null)) ? "" : _callback.Method.Name), GetType().Name));
    }
  }
  /// <exclude/>
  public class WSOpenAsyncResult : WSAsyncResult
  {
    internal WSOpenAsyncResult(WSContext wsWSContext, AsyncCallback callback, object asyncState)
      : base(wsWSContext, callback, asyncState)
    { }
  }
  /// <exclude/>
  public class WSCloseAsyncResult : WSAsyncResult
  {
    internal WSCloseAsyncResult(WSContext wsWSContext, AsyncCallback callback, object asyncState)
      : base(wsWSContext, callback, asyncState)
    { }
  }
}

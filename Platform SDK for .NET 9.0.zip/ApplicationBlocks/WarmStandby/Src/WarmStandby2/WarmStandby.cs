//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

//===============================================================================

using System;
using System.Collections.Generic;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.Standby
{
  /// <summary>
  /// WarmStandby facade. Declares basic functionality of WarmStandby.
  /// Active WarmStandby controls channel, so it may considered as resource.
  /// Always close or dispose it before leaving an application, 
  /// because an opened WarmStandby will lead the to non-stopped threads. 
  /// </summary>
  public class WarmStandby : AbstractLogEnabled, IDisposable
  {
    private readonly WarmStandbyImpl _implementation;
    private volatile bool _isDisposed;

    /// <summary>
    /// Creates a new warm standby instance.
    /// <para>Disables direct connection operations of the channel.<br/>
    /// The warm standby gets exclusive control under the connection operations.
    /// </para>
    /// </summary>
    /// <param name="channel">Client channel</param>
    /// <param name="endpoints">List of endpoints</param>
    /// <exception cref="DisabledMethodException">If channel is externally controlled, for example by another WarmStandby</exception>
    /// <exception cref="ArgumentNullException">If channel is null</exception>
    /// <exception cref="ArgumentException">If list of endpoints contains null value</exception>
    public WarmStandby(ClientChannel channel, List<Endpoint> endpoints):this(null,channel, endpoints){}
    /// <summary>
    /// Creates a new warm standby instance.
    /// <para>Disables direct connection operations of the channel.<br/>
    /// The warm standby gets exclusive control under the connection operations.
    /// </para>
    /// </summary>
    /// <param name="name">Name of instance</param>
    /// <param name="channel">Client channel</param>
    /// <param name="endpoints">List of endpoints</param>
    /// <exception cref="DisabledMethodException">If channel is externally controlled, for example by another WarmStandby</exception>
    /// <exception cref="ArgumentNullException">If channel is null</exception>
    /// <exception cref="ArgumentException">If list of endpoints contains null value</exception>
    public WarmStandby(String name, ClientChannel channel, List<Endpoint> endpoints)
    {
      _implementation = new WarmStandbyImpl(name, this, channel);
      _implementation.Configuration.Endpoints = endpoints;
      _implementation.InstanceName = name;
    }
    /// <summary>
    /// Creates a new warm standby instance.
    /// <para>Disables direct connection operations of the channel.<br/>
    /// The warm standby gets exclusive control under the connection operations.
    /// </para>
    /// </summary>
    /// <param name="channel">Client channel</param>
    /// <param name="endpoints">Array of endpoints</param>
    /// <exception cref="DisabledMethodException">If channel is externally controlled, for example by another WarmStandby</exception>
    /// <exception cref="ArgumentNullException">If channel is null</exception>
    /// <exception cref="ArgumentException">If list of endpoints contains null value</exception>
    public WarmStandby(ClientChannel channel, params Endpoint[] endpoints):this(null, channel, endpoints){}
    /// <summary>
    /// Creates a new warm standby instance.
    /// <para>Disables direct connection operations of the channel.<br/>
    /// The warm standby gets exclusive control under the connection operations.
    /// </para>
    /// </summary>
    /// <param name="name">Name of instance</param>
    /// <param name="channel">Client channel</param>
    /// <param name="endpoints">Array of endpoints</param>
    /// <exception cref="DisabledMethodException">If channel is externally controlled, for example by another WarmStandby</exception>
    /// <exception cref="ArgumentNullException">If channel is null</exception>
    /// <exception cref="ArgumentException">If list of endpoints contains null value</exception>
    public WarmStandby(String name, ClientChannel channel, params Endpoint[] endpoints)
    {
      _implementation = new WarmStandbyImpl(name, this, channel);
      _implementation.Configuration.SetEndpoints(endpoints);
      if (name!=null)
        _implementation.InstanceName = name;
    }
    /// <summary>
    /// Opens synchronously the channel to any available server specified in the configuration.
    /// <para>
    /// This method blocks until the channel is opened, also in the case that channel opening is already in progress.
    /// </para>
    /// <para>
    /// Do not use directly channel's open/close operations. Use the WarmStandby's ones.
    /// </para>
    /// <para>
    /// <b>Caution: Do not use this method inside WarmStandby handler.</b>
    /// </para>
    /// </summary>
    /// <exception cref="InvalidOperationException">If this method is called inside WarmStandby handler</exception>
    public void Open()
    {
      CheckDisposed(); 
      _implementation.Open();
    }
    /// <summary>
    /// Opens asynchronously the channel to any available server specified in the configuration.
    /// <para>
    /// Do not use directly channel's open/close operations. Use the WarmStandby's ones.
    /// </para>
    /// </summary>
    /// <param name="callback">Callback</param>
    /// <param name="state">custon object</param>
    /// <returns>IAsyncResult instance</returns>
    public IAsyncResult BeginOpen(AsyncCallback callback, object state)
    {
      CheckDisposed(); 
      return _implementation.BeginOpen(callback, state);
    }
    /// <summary>
    /// Finishes BeginOpen operation synchronously.
    /// <para>
    /// <b>Caution: Do not use this method inside WarmStandby handler.</b>
    /// </para>
    /// </summary>
    /// <param name="iar">IAsyncResult instance</param>
    /// <exception cref="InvalidOperationException">If this method is called inside WarmStandby handler</exception>
    public void EndOpen(IAsyncResult iar)
    {
      CheckDisposed(); 
      _implementation.EndOpen(iar);
    }

    /// <summary>
    /// Synchronously closes the channel and stops all WarmStandby's activity.
    /// Clears flag auto restore.
    /// <para>
    /// It disables auto restore, cancels channel opening and closes the channel synchronously.
    /// </para>
    /// <para>
    /// Do not use directly channel's open/close operations. Use the WarmStandby's ones.
    /// </para>
    /// </summary>
    public void Close()
    {
      CheckDisposed(); 
      _implementation.Close();
    }
    /// <summary>
    /// Asynchronously closes the channel and stops all WarmStandby's activity.
    /// Clears flag auto restore.
    /// <para>
    /// It disables auto restore, cancels channel opening and closes the channel asynchronously.
    /// </para>
    /// <para>
    /// Do not use directly channel's open/close operations. Use the WarmStandby's ones.
    /// </para>
    /// </summary>
    /// <param name="callback">Callback</param>
    /// <param name="state">custon object</param>
    /// <returns>IAsyncResult instance</returns>
    public IAsyncResult BeginClose(AsyncCallback callback, object state)
    {
      CheckDisposed(); 
      return _implementation.BeginClose(callback, state);
    }
    /// <summary>
    /// Finishes BeginClose operation
    /// </summary>
    /// <param name="iar">IAsyncResult instance</param>
    public void EndClose(IAsyncResult iar)
    {
      CheckDisposed(); 
      _implementation.EndClose(iar);
    }
    #region properties
    ///// <summary>
    ///// Returns true if WarmStandby is activated.
    ///// </summary>
    //public bool IsActive { get { return _implementation.IsActive; } }
    /// <summary>
    /// Returns true if Channel is opened.
    /// </summary>
    public bool IsOpened
    {
      get
      {
        CheckDisposed(); 
        return _implementation.IsOpened;
      }
    }

    /// <summary>
    /// Returns client channel
    /// </summary>
    public ClientChannel Channel
    {
      get
      {
        CheckDisposed(); 
        return _implementation.Channel;
      }
    }

    /// <summary>
    /// Gets configuration's reference, and apply properties of external configuration
    /// </summary>
    public WSConfig Configuration
    {
      get
      {
        CheckDisposed(); 
        return _implementation.Configuration;
      }
      set
      {
        CheckDisposed(); 
        _implementation.Configuration = value;
      }
    }
    /// <summary>
    /// Gets the instance name
    /// </summary>
    public string Name
    {
      get
      {
        CheckDisposed(); 
        return _implementation.InstanceName;
      }
    }
    /// <summary>
    /// Gets the instance unique ID
    /// </summary>
    public int ID
    {
      get
      {
        CheckDisposed();
        return _implementation.Uid;
      }
    }
    /// <summary>
    /// Enables/disables auto restore and opens asynchronously the channel if required.
    /// Set it to true only when configuration is initialized.
    /// <para>
    /// This method equals to AutoRestore(true);
    /// </para>
    /// </summary>
    /// <exception cref="WSEmptyEndpointPoolException">if pool of Endpoint is empty</exception>
    public void AutoRestore(){AutoRestore(true);}
    /// <summary>
    /// Enables auto restore and opens asynchronously the channel if required.
    /// Set it to true only when configuration is initialized.
    /// Use method Close, to disable auto restore.
    /// </summary>
    /// <param name="open">Flag to start opening channel</param>
    /// <exception cref="WSEmptyEndpointPoolException">if pool of Endpoint is empty</exception>
    public void AutoRestore(bool open)
    {
      CheckDisposed(); 
      _implementation.AutoRestore(open);
    }
    #endregion properties
    #region events
    /// <summary>
    /// It is called when the channel has been opened.
    /// </summary>
    public event EventHandler ChannelOpened
    {
      add{ CheckDisposed(); _implementation.ChannelOpened += value; }
      remove{ CheckDisposed(); _implementation.ChannelOpened -= value; }
    }
    /// <summary>
    /// It is called when the channel disconnection occurs.
    /// </summary>
    public event EventHandler ChannelDisconnected
    {
      add{ CheckDisposed(); _implementation.ChannelDisconnected += value; }
      remove{ CheckDisposed(); _implementation.ChannelDisconnected -= value; }
    }
    /// <summary>
    /// It is called when the channel hasn't been opened due to some error.
    /// </summary>
    public event EventHandler EndpointTriedUnsuccessfully
    {
      add{ CheckDisposed(); _implementation.EndpointTriedUnsuccessfully += value; }
      remove{ CheckDisposed(); _implementation.EndpointTriedUnsuccessfully -= value; }
    }
    /// <summary>
    /// It is called when all endpoints have been checked unsuccessfully (all
    /// servers have been unavaliable) or the endpoint pool is empty.
    /// </summary>
    public event EventHandler AllEndpointsTriedUnsuccessfully
    {
      add { CheckDisposed(); _implementation.AllEndpointsTriedUnsuccessfully += value; }
      remove { CheckDisposed(); _implementation.AllEndpointsTriedUnsuccessfully -= value; }
    }
    #endregion events
    #region override
    public override string ToString()
    {
      CheckDisposed();
      return _implementation.ToString();
    }


    public void Dispose()
    {
      lock (this)
      {
        if (_isDisposed) return;
        _isDisposed = true;
        _implementation.Dispose();
        GC.SuppressFinalize(this);
      }
    }

    /// <exclude/>
    protected override void OnEnableLogging(ILogger logger)
    {
      CheckDisposed();
      base.OnEnableLogging(logger);
      _implementation.EnableLogging(logger);
    }

    private void CheckDisposed()
    {
      if (_isDisposed)
        throw new ObjectDisposedException("Object is disposed");
    }
    #endregion override
  }
}

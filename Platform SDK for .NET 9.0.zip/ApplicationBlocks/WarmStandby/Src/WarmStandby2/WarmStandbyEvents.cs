﻿using System;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.Standby
{
  /// <summary>
  /// Base WarmStaneby eventArgsArgs
  /// </summary>
  public abstract class WSEvent : EventArgs
  {
    private readonly WarmStandby _source;

    /// <summary>
    /// Constructor of base WarmStandby eventArgs
    /// </summary>
    /// <param name="warmStandby">WarmStandby instance</param>
    internal WSEvent(WarmStandby warmStandby)
    {
      _source = warmStandby;
    }

    /// <summary>
    /// Returns source WarmStandby instance
    /// </summary>
    public WarmStandby WarmStandby
    {
      get { return _source; }
    }
  }

  /// <summary>
  /// Event to notify that all endpoints in pool was unsuccessfuly processed.
  /// </summary>
  public sealed class WSAllTriedUnsuccessfullyEvent : WSEvent
  {
    private readonly int _retryNumber;

    internal WSAllTriedUnsuccessfullyEvent(WarmStandby warmStandby, int retryNumber)
      : base(warmStandby)
    {
      _retryNumber = retryNumber;
    }

    /// <summary>
    /// Returns how many times all endpoints have been tried unsuccessfully.
    /// Every time when the channel is opened retry number is reset to zero.
    /// </summary>
    /// <returns>retry number</returns>
    public int RetryNumber
    {
      get { return _retryNumber; }
    }

  }
  /// <summary>
  /// Base event to present information about single endpoint.
  /// </summary>
  public abstract class WSClosedEvent : WSEvent
  {
    private readonly ClosedEventArgs _eventArgs;

    /// <exclude/>
    internal WSClosedEvent(WarmStandby warmStandby, ClosedEventArgs eventArgsArgs)
      : base(warmStandby)
    {
      if (eventArgsArgs == null)
      {
        throw new ArgumentNullException("eventArgsArgs", "null eventArgsArgs");
      }
      _eventArgs = eventArgsArgs;
    }

    /// <summary>
    /// Arguments of channel closed event
    /// </summary>
    public ClosedEventArgs ClosedEvent
    {
      get { return _eventArgs; }
    }

    /// <summary>
    /// Cause of disconnection or channel's opening error
    /// </summary>
    public Exception Cause
    {
      get { return (_eventArgs==null)?null:_eventArgs.Cause; }
    }

    /// <summary>
    /// Active endpoint 
    /// </summary>
    public Endpoint Endpoint
    {
      get { return (_eventArgs==null)?null:_eventArgs.Endpoint; }
    }
  }

  /// <summary>
  /// Event represents that opened channel was closed.
  /// </summary>
  public class WSDisconnectedEvent : WSClosedEvent
  {
    /// <exclude/>
    internal WSDisconnectedEvent(WarmStandby warmStandby, ClosedEventArgs eventArgs)
      : base(warmStandby, eventArgs)
    {
    }
  }

  /// <summary>
  /// Event represents that channel was opened successfuly
  /// </summary>
  public class WSOpenedEvent : WSEvent
  {

    private readonly OpenedEventArgs _eventArgs;

    /// <exclude/>
    internal WSOpenedEvent(WarmStandby warmStandby, OpenedEventArgs eventArgs) : base(warmStandby)
    {
      if (eventArgs == null)
      {
        throw new ArgumentNullException("eventArgs", "null event");
      }
      _eventArgs = eventArgs;
    }

    /// <exclude/>
    public OpenedEventArgs OpenedEvent
    {
      get { return _eventArgs; }
    }

    /// <exclude/>
    public Endpoint Endpoint
    {
      get { return (_eventArgs!=null)?_eventArgs.Endpoint:null; }
    }
  }

  /// <summary>
  /// Event represents that channel had the unsuccessful try to open.
  /// </summary>
  public class WSTriedUnsuccessfullyEvent : WSClosedEvent
  {

    private bool _resume;

    /// <exclude/>
    public WSTriedUnsuccessfullyEvent(WarmStandby warmStandby, ClosedEventArgs eventArgs)
      : base(warmStandby, eventArgs)
    {
    }

    /// <summary>
    /// Checks if channel connection restoring will be stopped.
    /// </summary>
    /// <returns>true if channel connection restoring will be stopped.</returns>
    public bool RestoringStopped
    {
      get
      {
        Exception cause = ClosedEvent.Cause;
        return ((!_resume) && (cause is RegistrationException));
      }
    }

    /// <summary>
    /// Specify that the same endpoint should be retried again (ASAP) 
    /// if warm standby open operation won't be canceled.
    /// </summary>
    public void Resume()
    {
      _resume = true;
    }

  }

}

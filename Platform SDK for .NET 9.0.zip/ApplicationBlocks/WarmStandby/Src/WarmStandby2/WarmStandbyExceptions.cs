﻿using System;
using Genesyslab.Platform.Commons;

namespace Genesyslab.Platform.Standby
{
  /// <summary>
  /// Base class for all warm standby exceptions.
  /// </summary>
  public abstract class WSException:PlatformException
  {
    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="message">Details of the exception.</param>
    /// <param name="cause">Source of the exception.</param>
    protected WSException(String message, Exception cause) : base(message, cause) { }
  }

  /// <summary>
  /// This exception can be thrown when opening operation has been canceled. See the reason in cause.
  /// </summary>
  public class WSCanceledException : WSException
  {
    /// <exclude/>
    public WSCanceledException(String message, Exception cause) : base(message, cause)
    {
    }
  }
  /// <summary>
  /// This exception can be thrown when all endpoints have been tried unsuccessfully.
  /// </summary>
  public class WSNoAvailableServersException:WSException
  {
    /// <exclude/>
    public WSNoAvailableServersException(String message, Exception cause)
      : base(message, cause)
    {
    }
  }

  /// <summary>
  /// This exception can be thrown when when endpoint pool is empty.
  /// </summary>
  public class WSEmptyEndpointPoolException : WSNoAvailableServersException
  {
    /// <exclude/>
    public WSEmptyEndpointPoolException(String message, Exception cause)
      : base(message, cause)
    {
    }
  }


}

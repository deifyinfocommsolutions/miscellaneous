﻿using Genesyslab.Configuration;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;
using System;
using System.Text;
using System.Threading;

namespace Genesyslab.Platform.Standby
{
  internal class AbstractLogEnabledEx : AbstractLogEnabled
  {
    internal new ILogger Logger { get { return base.Logger; } }
  }

  internal static class AbstractLogEnabledExt
  {
    internal static void DebugLog(this AbstractLogEnabledEx obj, object message)
    {
      var logger = obj.Logger;
      if ((logger != null) && (logger.IsDebugEnabled))
        logger.Debug(message);
    }
    internal static void WarnLog(this AbstractLogEnabledEx obj, object message)
    {
      var logger = obj.Logger;
      if ((logger != null) && (logger.IsWarnEnabled))
        logger.Warn(message);
    }
    internal static void DebugLog(this AbstractLogEnabledEx obj, object message, Exception exception)
    {
      var logger = obj.Logger;
      if ((logger != null) && (logger.IsDebugEnabled))
        logger.Debug(message, exception);
    }
    internal static void DebugFormatLog(this AbstractLogEnabledEx obj, string format, params object[] args)
    {
      var logger = obj.Logger;
      if ((logger != null) && (logger.IsDebugEnabled))
        logger.DebugFormat(format, args);
    }
  }
  internal class WarmStandbyImpl : AbstractLogEnabledEx, IDisposable
  {
    internal static readonly IScheduler TimerFactory = Commons.Connection.Timer.TimerFactory.Scheduler;
    private static int Guid;

    private const string WaitForCompleteNotificationsKey = "WarmStandby.WaitForCompleteNotifications";
    private const bool SynchronousNotifications = true;
    internal readonly bool WaitForCompleteNotifications = PsdkCustomization.CustomOption(WaitForCompleteNotificationsKey, false);
    private const String DefaultInvokerName = "WarmStandby";
    private readonly object _syncRoot = new object();
    internal object SyncRoot { get { return _syncRoot; } }
    private readonly WSConfig _configuration;
    private readonly WarmStandby _warmStandby;
    internal readonly int Uid;
    internal readonly DuplexChannel.IConnectionOperations ConnectionOperations;
    private readonly ClientChannel _clientChannel;
    private readonly AtomicReference<WSOpenContext> _openContext = new AtomicReference<WSOpenContext>();
    private readonly AtomicReference<WSCloseContext> _closeContext = new AtomicReference<WSCloseContext>();
    private readonly AtomicReference<Thread> _invokerThreadRef = new AtomicReference<Thread>();
    private volatile Endpoint _ignoreInitialEndpoint;

    internal IAsyncInvoker AsyncInvoker;
    internal AtomicReference<Thread> InvokerReference { get { return _invokerThreadRef; } }

    internal WarmStandbyImpl(string name, WarmStandby warmStandby, ClientChannel channel)
    {
      if (channel == null)
        throw new ArgumentNullException("channel");
      _clientChannel = channel;
      ConnectionOperations = _clientChannel.DisableExternalConnectionOperations;
      _configuration = new WSConfig(name);
      _configuration.Changed += OnChangeConfiguration;
      _warmStandby = warmStandby;
      AsyncInvoker = InvokerFactory.NamedInvoker(DefaultInvokerName);
      Uid = Interlocked.Increment(ref Guid);
      _ignoreInitialEndpoint = ((Channel.Endpoint != null) && (!Channel.Endpoint.IsUndefined))?Channel.Endpoint:null;
    }

    ~WarmStandbyImpl()
    {
      lock (_syncRoot)
      {
        ReleaseResources();
      }
    }

    private bool _isDisposed;
    public void Dispose()
    {
      if (!_isDisposed)
      {
        lock (_syncRoot)
        {
          if (!_isDisposed)
          {
            _isDisposed = true;
            this.DebugFormatLog("{0}.Dispose is called", LogInstanceName);
            if (IsActive)
              CloseSync();
            ReleaseResources();
            GC.SuppressFinalize(this);
          }
        }
      }
    }

    private void ReleaseResources()
    {
      if (AsyncInvoker != null)
      {
        AsyncInvoker = null;
        InvokerFactory.ReleaseInvoker(DefaultInvokerName);
      }
    }
    #region API

    internal string LogInstanceName
    {
      get
      {
        if (String.IsNullOrEmpty(InstanceName)) return "WarmStandby["+Uid+"]";
        return "WarmStandby[" + Uid + "][" + InstanceName + "]";
      }
    }
    internal void Open()
    {
      if (_invokerThreadRef.Get() == Thread.CurrentThread)
      {
        this.WarnLog("[" + LogInstanceName + ".Open] method is called inside WarmStandbyInvoker. Redirecting to WarmStandby.BeginOpen");
        throw new InvalidOperationException("Synchronous operations are disabled inside handlers");
      }
      EndOpen(BeginOpen(null, null));
    }
    internal IAsyncResult BeginOpen(AsyncCallback callback, object state)
    {
      this.DebugLog(LogInstanceName + ".BeginOpen method is called");
      return InitiateOpening(callback, state);
    }
    internal void EndOpen(IAsyncResult iar)
    {
      this.DebugLog(LogInstanceName + ".EndOpen method is started");
      if (_invokerThreadRef.Get() == Thread.CurrentThread)
      {
        this.WarnLog("[" + LogInstanceName + ".EndOpen] method is called inside WarmStandbyInvoker. Execution skipped.");
        throw new InvalidOperationException("Synchronous operations are disabled inside handlers");
      }
      var ar = iar as WSOpenAsyncResult;
      if (ar == null)
        throw new ArgumentException("Wrong type of IAsyncResult instance. Expected: WSOpenAsyncResult.", "iar");
      if (!ar.IsCompleted)
      {
        this.DebugFormatLog("{0}.EndOpen is waiting for complete", ar.Context.LogWarmStandbyName);
        ar.AsyncWaitHandle.WaitOne();
        ar.CompletedSynchronously = true;
      }
      ar.CompletionHandle.WaitOne(DuplexChannel.DefaultTimeout);
      this.DebugFormatLog("{0}.EndOpen method is completed", ar.Context.LogWarmStandbyName);
      if (ar.Cause != null)
        throw ar.Cause;
    }

    internal void Close()
    {
      if (_invokerThreadRef.Get() == Thread.CurrentThread)
      {
        this.WarnLog("[" + LogInstanceName + ".Close] method is called inside WarmStandbyInvoker.");
        CloseSync();
      }
      else
      {
        EndClose(BeginClose(null, null));
      }
    }

    internal IAsyncResult BeginClose(AsyncCallback callback, object state)
    {
      this.DebugLog(LogInstanceName + ".BeginClose method is called");
      return InitiateClosing(callback, state);
    }

    internal void EndClose(IAsyncResult iar)
    {
      var ar = iar as WSCloseAsyncResult;
      if (ar == null)
        throw new ArgumentException("Wrong type of IAsyncResult instance. Expected: WSCloseAsyncResult.", "iar");
      if (!ar.IsCompleted)
      {
        ar.AsyncWaitHandle.WaitOne();
        ar.CompletedSynchronously = true;
      }
      ar.CompletionHandle.WaitOne(DuplexChannel.DefaultTimeout);
      if (ar.Cause != null) throw ar.Cause;
    }

    private void CloseSync()
    {
      lock (_syncRoot)
      {
        var openContext = _openContext.Get();
        if ((openContext != null) && (!IsOpened))
        {
          openContext.FireFailed(null,new WSCanceledException("WarmStanby was closed", null));
          OnFinalizeOpenContext(openContext, null);
        }
        AutoRestoreFlag = false;
        this.DebugFormatLog(LogInstanceName + ".CloseSync: set AutoRestore to false");
        ConnectionOperations.Close();
        var closeContext = _closeContext.Get();
        if (closeContext != null)
        {
          closeContext.FireSuccess(null);
          OnFinalizeCloseContext(closeContext, null);
        }
        if (Interlocked.CompareExchange(ref _isActive, 0, 1)==1)
          this.DebugFormatLog(LogInstanceName + ".CloseSync: set active to false");
      }
    }
    #endregion API


    #region events
    internal event EventHandler ChannelOpened;
    internal event EventHandler ChannelDisconnected;
    internal event EventHandler EndpointTriedUnsuccessfully;
    internal event EventHandler AllEndpointsTriedUnsuccessfully;

    internal void OnAllEndpointsTriedUnsuccessfully(int retryNumber)
    {
      var handler = AllEndpointsTriedUnsuccessfully;
      var invoker = AsyncInvoker;
      if ((handler != null) && (invoker != null))
      {
        var evt = new EnvelopedManualResetEvent(SynchronousNotifications);
        invoker.Invoke(state =>
        {
          lock (Configuration.SyncRoot)
          {
            this.DebugLog(LogInstanceName + " check if paused.");
            if (AutoRestoreFlag && (Configuration.Endpoints.Count == 0))
            {
              Pause();
            }
          }
          this.DebugFormatLog(LogInstanceName + ".OnAllEndpointsTriedUnsuccessfully is invoking. Retry number = {0} ",
            retryNumber);
          try
          {
            _invokerThreadRef.Set(Thread.CurrentThread);
            handler(_warmStandby, new WSAllTriedUnsuccessfullyEvent(_warmStandby, retryNumber));
          }
          catch (Exception e)
          {
            this.DebugFormatLog(LogInstanceName + ".OnAllEndpointsTriedUnsuccessfully handler raised an exception: {0}", e);
          }
          this.DebugLog(LogInstanceName + ".OnAllEndpointsTriedUnsuccessfully is completed.");
          _invokerThreadRef.Set(null);
          evt.Set();
        }, this);
        evt.WaitOne(DuplexChannel.DefaultTimeout);
      }
    }

    internal enum EndpointTriedUnsuccessfullyResult
    {
      Fail,
      Continue,
      Restart
    }
    internal EndpointTriedUnsuccessfullyResult OnEndpointTriedUnsuccessfully(ClosedEventArgs arg)
    {
      var handler = EndpointTriedUnsuccessfully;
      var @event = new WSTriedUnsuccessfullyEvent(_warmStandby, arg);
      var evt = new EnvelopedManualResetEvent(true);
      var invoker = AsyncInvoker;
      if ((handler != null) && (invoker != null))
      {
        invoker.Invoke(state =>
        {
          this.DebugFormatLog(LogInstanceName + ".OnEndpointTriedUnsuccessfully is invoking. Endpoint = {0} ",
            (((arg == null) || (arg.Endpoint == null)) ? "<null>" : arg.Endpoint.ToString()));
          try
          {
            _invokerThreadRef.Set(Thread.CurrentThread);
            handler(_warmStandby, @event);
          }
          catch (Exception e)
          {
            this.DebugFormatLog(LogInstanceName + ".OnEndpointTriedUnsuccessfully handler raised an exception: {0}", e);
          }
          this.DebugFormatLog(LogInstanceName + ".OnEndpointTriedUnsuccessfully is completed. RestoringStopped = {0} ",
            @event.RestoringStopped);
          _invokerThreadRef.Set(null);
          evt.Set();
        }, this);
        evt.WaitOne(DuplexChannel.DefaultTimeout);
      }
      if (arg == null) return EndpointTriedUnsuccessfullyResult.Fail;
      if (arg.Cause is RegistrationException)
        return @event.RestoringStopped
          ? ((_configuration.Endpoints.Contains(arg.Endpoint))
            ? EndpointTriedUnsuccessfullyResult.Fail
            : EndpointTriedUnsuccessfullyResult.Continue)
          : EndpointTriedUnsuccessfullyResult.Restart;
      return EndpointTriedUnsuccessfullyResult.Continue;
    }
    internal void OnChannelOpened(OpenedEventArgs arg)
    {
      var handler = ChannelOpened;
      var invoker = AsyncInvoker;
      if ((handler != null) && (invoker != null))
      {
        var evt = new EnvelopedManualResetEvent(SynchronousNotifications);
        invoker.Invoke(state =>
        {
          this.DebugFormatLog(LogInstanceName + ".OnChannelOpened is invoking. Endpoint = {0} ",
            ((arg == null) ? "<null>" : arg.Endpoint.ToString()));
          try
          {
            _invokerThreadRef.Set(Thread.CurrentThread);
            handler(_warmStandby, new WSOpenedEvent(_warmStandby, arg));
            this.DebugLog(LogInstanceName + ".OnChannelOpened is complete.");
          }
          catch (Exception e)
          {
            this.DebugFormatLog(LogInstanceName + ".OnChannelOpened handler raised an exception: {0}", e);
          }
          _invokerThreadRef.Set(null);
          evt.Set();
        }, this);
        evt.WaitOne(DuplexChannel.DefaultTimeout);
      }
    }

    private void OnChannelDisconnected(ClosedEventArgs arg)
    {
      var handler = ChannelDisconnected;
      var invoker = AsyncInvoker;
      if ((handler != null) && (invoker!=null))
      {
        var evt = new EnvelopedManualResetEvent(SynchronousNotifications);
        invoker.Invoke(state =>
        {
          this.DebugFormatLog(LogInstanceName + ".OnChannelDisconnected is invoking. Endpoint = {0} Cause={1}",
            (((arg != null) && (arg.Endpoint != null)) ? arg.Endpoint.ToString() : "<null>"),
            (((arg != null) && (arg.Cause != null)) ? arg.Cause.ToString() : "null"));
          _invokerThreadRef.Set(Thread.CurrentThread);
          try
          {
            handler(_warmStandby, new WSDisconnectedEvent(_warmStandby, arg));
            this.DebugLog(LogInstanceName + ".OnChannelDisconnected is completed.");
          }
          catch (Exception e)
          {
            this.DebugFormatLog(LogInstanceName + ".OnChannelDisconnected handler raised an exception: {0}", e);
          }
          _invokerThreadRef.Set(null);
          evt.Set();
        }, this);
        evt.WaitOne(DuplexChannel.DefaultTimeout);
      }
    }

    #endregion events
    #region properties

    private bool _nameAssigned;
    internal string InstanceName{ get; set; }

    internal WSConfig Configuration
    {
      get { return _configuration; }
      set { _configuration.Apply(value); }
    }
    internal ClientChannel Channel { get { return _clientChannel; } }
    internal bool IsOpened { get { return Channel.State == ChannelState.Opened; } }
    private int _isActive;
    public bool IsActive { get { return Interlocked.CompareExchange(ref _isActive, 0, 0) > 0; } }
    private int _isPaused;
    public bool IsPaused { get { return Interlocked.CompareExchange(ref _isPaused, 0, 0) > 0; } }

    internal void Pause()
    {
      Interlocked.CompareExchange(ref _isPaused, 1, 0);
      this.DebugLog(LogInstanceName + ".Suspended.");
    }

    internal void Resume()
    {
      if (Interlocked.CompareExchange(ref _isPaused, 0, 1)==0);
        this.DebugLog(LogInstanceName + ".Resumed.");
    }
    internal volatile bool AutoRestoreFlag;
    internal void AutoRestore(bool open)
    {
      this.DebugFormatLog(LogInstanceName + ".SetAutoRestore. OpenFlag =  {0}", open);
      AutoRestoreFlag = true;
      if (open)
        BeginOpen(null, null);
    }

    #endregion properties
    #region AsyncResult

    internal void RunCallback(object iarObj)
    {
      var ar = iarObj as WSAsyncResult;
      if (ar != null)
        ar.Context.RunCallback(iarObj);
    }

    #endregion AsyncResult
    #region override
    public override string ToString()
    {
      return new StringBuilder()
        .Append("{")
        //.Append("\"ClassName\":\"Genesyslab.Platform.WarmStandby.WarmStandby\",")
        .Append("\"ID\":").Append(Uid).Append(",")
        .Append(InstanceName == null ? "" : "\"Name\":\"" + InstanceName.Replace("\"", "\\\"") + "\",")
        .Append("\"Channel\":\"")
        .Append(_clientChannel.GetType().Name)
        .Append("\",\"ProtocolId\":\"")
        .Append(_clientChannel.ProtocolId.ToString("X8"))
        .Append("\",\"Configuration\":")
        .Append(_configuration)
        .Append("}")
        .ToString();
    }
    #endregion override
    #region private

    private IAsyncResult InitiateOpening(AsyncCallback callback, object state)
    {
      lock (_syncRoot)
      {
        var closeContext = _closeContext.Get();
        if (closeContext != null)
        {
          this.DebugFormatLog(LogInstanceName + ".InitiateOpening: wait for close");
          Monitor.Exit(_syncRoot);
          closeContext.FinalizeHandle.WaitOne(DuplexChannel.DefaultTimeout);
          Monitor.Enter(_syncRoot);
          _closeContext.Set(null);
          this.DebugFormatLog(LogInstanceName + ".InitiateOpening: waiting for close is completed");
        }
        if (Interlocked.CompareExchange(ref _isActive, 1, 0)==0)
          this.DebugFormatLog(LogInstanceName + ".InitiateOpening: set active to true");
        var openContext = _openContext.Get();
        if (openContext != null)
          return openContext.CreateAsyncResult(callback, state);
        this.DebugLog(LogInstanceName + ".InitiateOpen");
        return CreateOpenContext(false, callback, state, 0, 0, null);
      }
    }
    private class BeginOpenAction : ITimerAction
    {
      private readonly WSOpenContext _context;
      private readonly bool _restore;
      private readonly ClosedEventArgs _closedEventArgs;
      internal BeginOpenAction(WSOpenContext context, bool restore, ClosedEventArgs args)
      {
        _context = context;
        _restore = restore;
        _closedEventArgs = args;
      }
      public void OnTimer()
      {
        _context.DebugFormatLog("{0} OnTimer Action. Completed = {1}", _context.LogWarmStandbyName, _context.IsCompleted);
        if (_context.IsCompleted) return;
        _context.BeginOpen(_restore, 0, _closedEventArgs);
      }
    }

    private IAsyncResult CreateOpenContext(bool restore, AsyncCallback callback, object state, int delay, int retryNumber, ClosedEventArgs args)
    {
      var openContext = new WSOpenContext(this, restore, retryNumber, args);

      _openContext.Set(openContext);
      this.DebugFormatLog("{0} is created. Restore = {1}, delay={2}ms, RetryNumber={3}", 
        openContext.LogWarmStandbyName, restore, delay, retryNumber);
      openContext.EnableLogging(Logger.CreateChildLogger("OpenContext"));
      IAsyncResult iar = openContext.CreateAsyncResult(callback, state);
      if (_ignoreInitialEndpoint!=null)
      {
        this.DebugFormatLog(
          "[" + LogInstanceName + ".CreateOpenContext] Channel has an assigned endpoint [{0}]. It will be ignored.",
          _ignoreInitialEndpoint);
        _ignoreInitialEndpoint = null;
      }
      openContext.Finalize += OnFinalizeOpenContext;
      openContext.OnRestart = OnRestart;
      if (Channel.State == ChannelState.Opened)
      {
        this.DebugFormatLog("[" + LogInstanceName + ".CreateOpenContext] Channel [{0}] is already opened.", Channel.Endpoint);
        openContext.CompleteSuccess(null, false);
        return iar;
      }
      this.DebugFormatLog("{0}.CreateOpenContext schedules open action" + ((delay > 0) ? " with timeout " + delay + " ms." : "."), LogInstanceName);
      var logEnabled = TimerFactory as AbstractLogEnabled;
      if (logEnabled!=null) logEnabled.EnableLogging(Logger);
      TimerFactory.Schedule(Math.Max(1, delay), new BeginOpenAction(openContext, restore, args));
      return iar;
    }

    private void OnFinalizeOpenContext(object sender, EventArgs args)
    {
      lock (_syncRoot)
      {
        var openContext = sender as WSOpenContext;
        if (openContext != null)
        {
          openContext.Finalize -= OnFinalizeOpenContext;
          openContext.OnRestart = null;
          openContext.CompletionHandle.Set();
          openContext.FinalizeHandle.Set();
        }
        _openContext.Set(null, openContext);
        this.DebugFormatLog("{0}.OnFinalizeOpenContext()", (openContext != null) ? openContext.LogWarmStandbyName : LogInstanceName);
      }
    }



    private void OnRestart(int delay, Exception exception, ClosedEventArgs args)
    {
      this.DebugFormatLog(LogInstanceName + ".Restarting. Delay={0}ms, cause = {1}",delay, exception);
      lock (_syncRoot)
      {
        int number = 0;
        var openContext = _openContext.Get();
        if (openContext != null)
        {
          number = openContext.RetryNumber + 1;
          if (exception!=null)
            openContext.FireFailed(null, exception);
        }
        //ConnectionOperations.Endpoint = null;
        CreateOpenContext(false, null, null, delay, number, null);
      }
    }

    private IAsyncResult InitiateClosing(AsyncCallback callback, object state)
    {
      IAsyncResult result;
      WSCloseContext closeContext;
      lock (_syncRoot)
      {
        closeContext = _closeContext.Get();
        if (closeContext != null)
          return closeContext.CreateAsyncResult(callback, state);
        AutoRestoreFlag = false;
        this.DebugFormatLog(LogInstanceName + ".InitiateClosing: set AutoRestore to false");
        var openContext = _openContext.Get();
        if (openContext != null)
          openContext.FireFailed(null, new WSCanceledException("WarmStandby was closed.", null));
        this.DebugLog(LogInstanceName + ".InitiateClose");
        closeContext = new WSCloseContext(this);
        closeContext.EnableLogging(Logger.CreateChildLogger("CloseContext"));
        closeContext.Finalize += OnFinalizeCloseContext;
        _closeContext.Set(closeContext);
        result = closeContext.CreateAsyncResult(callback, state);
      }
      closeContext.BeginClose();
      return result;
    }

    private void OnFinalizeCloseContext(object sender, EventArgs args)
    {
      lock (_syncRoot)
      {
        var closeContext = sender as WSCloseContext;
        _closeContext.Set(null, closeContext);
        //ConnectionOperations.Endpoint = null;
        if (Interlocked.CompareExchange(ref _isActive, 0, 1)==1)
          this.DebugFormatLog(LogInstanceName + ".OnFinalizeCloseContext: set active to false");
        this.DebugFormatLog("{0}.OnFinalizeCloseContext()", (closeContext != null) ? closeContext.LogWarmStandbyName : LogInstanceName);
        if (closeContext != null)
        {
          closeContext.CompletionHandle.Set();
          closeContext.FinalizeHandle.Set();
        }
      }
    }

    #endregion private
    #region handlers
    private void OnChangeConfiguration(object sender, EventArgs args)
    {
      this.DebugFormatLog("{0} Configuration option '{1}' was changed. Configuration: {2}", LogInstanceName, args,
        Configuration.ToString());
      if (args == WSConfigOption.Endpoints)
      {
        this.DebugFormatLog("Processing changed endpoint's list. Configuration: {2}", LogInstanceName, args,
          Configuration.ToString());
        if (AutoRestoreFlag && IsPaused)
        {
          if (Configuration.Endpoints.Count > 0)
          {
            Resume();
            BeginOpen(null, null);
          }
        }
      }
    }

    private int _countEventsAssigned;
    internal void SetChannelCloseEvent()
    {
      lock (_syncRoot)
      {
        Channel.Closed += OnChannelClosed;
        _countEventsAssigned++;
        this.DebugFormatLog("{0} Assign channel close event", LogInstanceName);
      }
    }

    private bool ResetChannelCloseEvent()
    {
      lock (_syncRoot)
      {
        bool result = _countEventsAssigned != 0;
        Channel.Closed -= OnChannelClosed;
        if (_countEventsAssigned > 0) _countEventsAssigned--;
        this.DebugFormatLog("{0} Reset channel close event", LogInstanceName);
        return result;
      }
    }
    private void OnChannelClosed(object sender, EventArgs args)
    {
      this.DebugFormatLog("{0}.OnChannelClosed is started", LogInstanceName);
      ResetChannelCloseEvent();
      OnChannelDisconnected(args as ClosedEventArgs);
      if (!IsActive) return;
      lock (_syncRoot)
      {
        if (_openContext.Get() != null) return;
        if (!AutoRestoreFlag)
        {
          this.DebugFormatLog("{0}.OnChannelClosed WarmStandby is finished", LogInstanceName);
          if (Interlocked.CompareExchange(ref _isActive, 0, 1)==1)
            this.DebugFormatLog(LogInstanceName + ".OnChannelClosed: set active to false");
          return;
        }
        this.DebugFormatLog("{0}.OnChannelClosed restarting...", LogInstanceName);
        CreateOpenContext(true, null, null, _configuration.RandomDelay, 0,  args as ClosedEventArgs);
      }
    }
    #endregion handlers

  }
}

//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

//===============================================================================using System;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genesyslab.Configuration;
using Genesyslab.Platform.Commons.Connection.Timer;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Protocols.Internal;
using Genesyslab.Platform.Commons.Threading;
using Genesyslab.Security;

namespace Genesyslab.Platform.ApplicationBlocks.WarmStandby
{
  internal static class ArrayExt
  {
    internal static T[] CloneArray<T>(this T[] source)
    {
      if (source == null) return null;
      var result = new T[source.Length];
      Array.Copy(source, result, source.Length);
      return result;
    }
    internal static T[] DeepCloneArray<T>(this T[] source)
    {
      if (source == null) return null;
      return (from data in source select (data is ICloneable) ? (T)(data as ICloneable).Clone() : data).ToArray();
    }

    internal static T GetValue<T>(this T[] source, int index, T[] alternate, T defaultValue)
    {
      if ((source==null)||(source.Length == 0))
      {
        if ((alternate == null) || (alternate.Length == 0)) return defaultValue;
        if (index >= alternate.Length) index = alternate.Length - 1;
        return alternate[index];
      }
      if (index >= source.Length) index = source.Length - 1;
      return source[index];
    }
  }

  /// <summary>
  /// <c>WarmStandbyChannel</c> class realizes a redundancy configuration consisting of list of servers, 
  /// where the one server operates in active mode (Primary) and the others servers in standby mode. 
  /// Only the Primary server accepts connections and message exchanges with the clients. 
  /// In case of the Primary server failure, the next server switches to active mode assuming the role 
  /// and behavior of the Primary server.
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public interface IWarmStandbyChannel<T> where T:ClientChannel, new()
  {
    /// <summary>
    /// Starts the service
    /// </summary>
    void Start();
    /// <summary>
    /// Stops the service
    /// </summary>
    void Stop();
    /// <summary>
    /// Returns client channel 
    /// </summary>
    T Channel { get; }
    /// <summary>
    /// Indicates that service is already started
    /// </summary>
    bool IsStarted { get; }
    // TODO: Investigate necessity of messages exchange

  }

  #region Enums
  /// <summary>
  /// Codes of events which are raised by WarmStandbyChannel
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public enum WarmStandbyChannelEventCode
  {
    /// <summary>
    /// WarmStandbyChannel was stopped
    /// </summary>
    WarmStandbyStopped,
    /// <summary>
    /// WarmStandbyChannel was started
    /// </summary>
    WarmStandbyStarted,
    /// <summary>
    /// Channel starts opening (reconnecting)
    /// </summary>
    ChannelOpening,
    /// <summary>
    /// Channel was opened 
    /// </summary>
    ChannelOpened,
    /// <summary>
    /// Channel was closed 
    /// </summary>
    ChannelClosed,
    /// <summary>
    /// Sceduled new try to open a channel
    /// </summary>
    ConnectionScheduled,
    /// <summary>
    /// A new try to open a channel was not scheduled
    /// </summary>
    ConnectionNotScheduled
  }
  /// <summary>
  /// Describes codes of actions which service can make.
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public enum WarmsStandbyChannelActionCode
  {
    Reconnect,
    Connect,
    AddAndConnect,
    Skip,
    SkipAll,
    Remove,
    Add,
    Reconfigure,
    Restart,
    Stop,
    DoNothing
  }
  /// <summary>
  /// few predefined iteration orders
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public enum WarmStandbyChannelIterationOrder
  {
    ///<summary>
    /// Continue iteration according to last used endpoint.
    /// Use element which is next for last used one. If last used one is the last in the pool then the first one in the pool will be used.
    /// Note: Iterations will be processed until unchecked endpoint will be found.
    /// If all enpoints in the pool is checked then next iteration will be statred (all endpoints will be marked as unchecked). 
    /// It's default order.
    ///</summary>
    Consecutive,

    ///<summary>
    /// Begin each iteration from start of the pool.
    /// The enpoints have strong priority (according to theirs order in the pool) in which they must be used for connection attempts.   
    /// Note: Iterations will be processed until unchecked endpoint will be found.
    ///       If all enpoints in the pool is checked then next iteration will be statred (all endpoints will be marked as unchecked). 
    ///</summary>
    Priority,


    ///<summary>
    /// Itterate endpoints in some random order.
    /// It may help to load balance partially.
    /// Note: Iterations will be processed until unchecked endpoint will be found.
    ///       If all enpoints in the pool is checked then next iteration will be statred (all endpoints will be marked as unchecked).
    ///</summary>
    Random
  }
  #endregion Enums
  #region Utility classes
  /// <summary>
  /// Used to describe what service should do next step.
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public sealed class WarmStandbyChannelAction:EventArgs
  {
    public WarmsStandbyChannelActionCode Code { get; private set; }
    public Endpoint Endpoint { get; private set; }
    public TimeSpan? Timeout { get; private set; }
    public TimeSpan? Delay { get; private set; }
    internal WarmStandbyChannelEndpointConfiguration EndpointConfiguration { get; set; }

    internal WarmStandbyChannelAction(WarmsStandbyChannelActionCode code, Endpoint endpoint, TimeSpan? timeout, TimeSpan? delay)
    {
      Code = code;
      Endpoint = endpoint;
      Timeout = timeout;
      Delay = delay;
    }

    public override string ToString()
    {
      return new StringBuilder()
        .Append("Action Code= ").Append(Code.ToString("F"))
        .Append(" Endpoint: ").Append(Endpoint == null ? "null" : Endpoint.ToString())
        .Append(" Timeout: ").Append(Timeout == null ? "null" : ((long) Timeout.Value.TotalMilliseconds).ToString("D")).Append(" ms")
        .Append(" Delay: ").Append(Delay == null ? "null" : ((long) Delay.Value.TotalMilliseconds).ToString("D")).Append(" ms").ToString();
    }
  }

  /// <summary>
  /// Builder of WarmStandbyChannelEndpointConfiguration
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public class WarmStandbyChannelEndpointConfiguration : ICloneable
  {
    /// <summary>
    /// Constructor of class
    /// </summary>
    /// <param name="endpoint">endpoint value</param>
    public WarmStandbyChannelEndpointConfiguration(Endpoint endpoint)
    {
      if (endpoint==null)
        throw new ArgumentNullException("endpoint", "Null endpoint value is not supported");
      Endpoint = endpoint;
    }
    /// <summary>
    /// Endpoint (with configuration) 
    /// </summary>
    internal Endpoint Endpoint { get; set; }
    /// <summary>
    /// Count of attempts before switch to next endpoint
    /// </summary>
    internal int? AttemptCount { get; set; }
    /// <summary>
    /// Wait interval between attempts of reconnect
    /// </summary>
    internal TimeSpan[] ReconnectDelay { get; set; }
    /// <summary>
    /// Additional random wait interval between attempts of reconnect
    /// </summary>
    internal int[] ReconnectDelayRange { get; set; }
    /// <summary>
    /// Channel timeout value for open/close operations
    /// </summary>
    internal TimeSpan? ChannelTimeout { get; set; }

    /// <summary>
    /// Sets count of attempts before switch to next endpoint
    /// </summary>
    /// <param name="attemptCount">count of attempts</param>
    public WarmStandbyChannelEndpointConfiguration SetAttemptCount(int? attemptCount)
    {
      AttemptCount = attemptCount;
      return this;
    }
    /// <summary>
    /// Sets the channel timeout value for open/close operations
    /// </summary>
    /// <param name="timeout">timeout value</param>
    public WarmStandbyChannelEndpointConfiguration SetChannelTimeout(TimeSpan? timeout)
    {
      ChannelTimeout = timeout;
      return this;
    }
    /// <summary>
    /// Sets reconnection delays for each cycle. The last value is default for all following cycles.
    /// </summary>
    /// <param name="delay">opened array of values</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelEndpointConfiguration SetReconnectDelays(params TimeSpan[] delay)
    {
      ReconnectDelay = delay;
      return this;
    }
    /// <summary>
    /// Sets reconnection delays for each cycle. The last value is default for all following cycles.
    /// </summary>
    /// <param name="delay">opened array of values</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelEndpointConfiguration SetReconnectDelays(params int[] delay)
    {
      if ((delay != null) && (delay.Length > 0))
      {
        ReconnectDelay = (from value in delay select TimeSpan.FromMilliseconds(value)).ToArray();
      }
      return this;
    }
    /// <summary>
    /// Sets additional reconnection delays for each cycle. The last value is default for all following cycles.
    /// </summary>
    /// <param name="delay">opened array of values</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelEndpointConfiguration SetReconnectDelaysRange(params int[] delay)
    {
      ReconnectDelayRange = delay;
      return this;
    }
    /// <summary>
    /// Default channel timeout
    /// </summary>
    /// <param name="timeout">timeout value</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelEndpointConfiguration SetChannelTimeout(int timeout)
    {
      ChannelTimeout = TimeSpan.FromMilliseconds(timeout);
      return this;
    }

    public object Clone()
    {
      var obj = this;
      return new WarmStandbyChannelEndpointConfiguration(obj.Endpoint.Clone() as Endpoint)
      {
        AttemptCount = obj.AttemptCount,
        ChannelTimeout = obj.ChannelTimeout,
        ReconnectDelay = obj.ReconnectDelay.CloneArray(),
        ReconnectDelayRange = obj.ReconnectDelayRange.CloneArray()
      };
    }
  }


  /// <summary>
  /// Configuration of WarmStandbyChannel class
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public class WarmStandbyChannelConfiguration : ICloneable
  {
    /// <summary>
    /// Reconnect tineout for first cycle
    /// </summary>
    public static int InitialFastReconnectTimeout = PsdkCustomization.CustomOption("WarmStandbyChannel.FastReconnectTimeout",100);
    /// <summary>
    /// Reconnect tineout for following cycles
    /// </summary>
    public static int InitialReconnectTimeout = PsdkCustomization.CustomOption("WarmStandbyChannel.ReconnectTimeout", 3000);
    /// <summary>
    /// Count of attempts before switch endpoint
    /// </summary>
    public static int InitialAttemptsCount = PsdkCustomization.CustomOption("WarmStandbyChannel.AttemptsCount", 1);
    /// <summary>
    /// Random interval
    /// </summary>
    public static int InitialDelayRange = PsdkCustomization.CustomOption("WarmStandbyChannel.DelayRange", 3000);
    /// <summary>
    /// Default constructor
    /// </summary>
    public WarmStandbyChannelConfiguration()
    {
      DefaultReconnectDelay = new TimeSpan[]{
          TimeSpan.FromMilliseconds(InitialFastReconnectTimeout), 
          TimeSpan.FromMilliseconds(InitialReconnectTimeout)
      };
      DefaultAttemptCount = InitialAttemptsCount;
      DefaultReconnectDelayRange = new int[]{ 0, InitialDelayRange };
      DefaultChannelTimeout = DuplexChannel.DefaultTimeout;
    }

    /// <summary>
    /// List of Endpoints with custom configuration 
    /// </summary>
    internal List<WarmStandbyChannelEndpointConfiguration> EndpointsConfig { get; set; }

    /// <summary>
    /// List of Endpoints with custom configuration 
    /// </summary>
    public List<Endpoint> Endpoints
    {
      get
      {
        if (EndpointsConfig == null) return null;
        return (from configuration in EndpointsConfig select configuration.Endpoint).ToList();
      }
    }
    /// <summary>
    /// Order of iterations' processing
    /// </summary>
    internal WarmStandbyChannelIterationOrder Order { get; set; }
    /// <summary>
    /// Default value of number of attempts before switch to next enpoint
    /// </summary>
    internal int DefaultAttemptCount { get; set; }
    /// <summary>
    /// Default value of delay between attempts of connecting
    /// </summary>
    internal TimeSpan[] DefaultReconnectDelay { get; set; }
    /// <summary>
    /// Default value of additional random delay between attempts of connecting
    /// </summary>
    internal int[] DefaultReconnectDelayRange { get; set; }
    /// <summary>
    /// Default value of a default channel timeout
    /// </summary>
    internal TimeSpan? DefaultChannelTimeout { get; set; }

    /// <summary>
    /// Default value of number of attempts before switch to next enpoint
    /// </summary>
    /// <param name="attemptCount">value of number of attempts before switch to next enpoint</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration SetAttemptCount(int attemptCount)
    {
      DefaultAttemptCount = attemptCount;
      return this;
    }
    /// <summary>
    /// Sets default order value
    /// </summary>
    /// <param name="order">order value</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration SetOrder(WarmStandbyChannelIterationOrder order)
    {
      Order = order;
      return this;
    }
    /// <summary>
    /// Sets default channel timeout
    /// </summary>
    /// <param name="delay">timeout value</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration SetChannelTimeout(TimeSpan? delay)
    {
      DefaultChannelTimeout = delay;
      return this;
    }
    /// <summary>
    /// Sets reconnection delays for each cycle. The last value is default for all following cycles.
    /// </summary>
    /// <param name="delay">opened array of values</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration SetReconnectDelays(params TimeSpan[] delay)
    {
      DefaultReconnectDelay = delay;
      return this;
    }
    /// <summary>
    /// Sets reconnection delays for each cycle. The last value is default for all following cycles.
    /// </summary>
    /// <param name="delay">opened array of values</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration SetReconnectDelays(params int[] delay)
    {
      if ((delay != null) && (delay.Length > 0))
      {
        DefaultReconnectDelay = (from value in delay select TimeSpan.FromMilliseconds(value)).ToArray();
      }
      return this;
    }
    /// <summary>
    /// Sets additional random reconnection delays for each cycle. The last value is default for all following cycles.
    /// </summary>
    /// <param name="delay">opened array of values</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration SetReconnectDelaysRange(params int[] delay)
    {
      DefaultReconnectDelayRange = delay;
      return this;
    }
    /// <summary>
    /// Add endpoints with default configuration
    /// </summary>
    /// <param name="endpoints">open aray of endpoints</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration AddEndpoints(params Endpoint[] endpoints)
    {
      if ((endpoints == null) || (endpoints.Length == 0)) return this;
      lock (this)
      {
        if (EndpointsConfig == null)
          EndpointsConfig = new List<WarmStandbyChannelEndpointConfiguration>();
        foreach (var endpoint in endpoints)
        {
           EndpointsConfig.Add(new WarmStandbyChannelEndpointConfiguration(endpoint));
        }
      }
      return this;
    }
    /// <summary>
    /// Add endpoints with custom configuration
    /// </summary>
    /// <param name="endpoints">open aray of endpoints</param>
    /// <returns>this instance</returns>
    public WarmStandbyChannelConfiguration AddEndpoints(params WarmStandbyChannelEndpointConfiguration[] endpoints)
    {
      if ((endpoints == null) || (endpoints.Length == 0)) return this;
      lock (this)
      {
        if (EndpointsConfig == null)
          EndpointsConfig = new List<WarmStandbyChannelEndpointConfiguration>();
        foreach (var endpoint in endpoints)
        {
          EndpointsConfig.Add(endpoint.Clone() as WarmStandbyChannelEndpointConfiguration);
        }
      }
      return this;
    }

    public object Clone()
    {
      var obj = this;
      return new WarmStandbyChannelConfiguration
      {
        DefaultAttemptCount = obj.DefaultAttemptCount,
        DefaultChannelTimeout = obj.DefaultChannelTimeout,
        DefaultReconnectDelay = obj.DefaultReconnectDelay.CloneArray(),
        DefaultReconnectDelayRange = obj.DefaultReconnectDelayRange.CloneArray(),
        EndpointsConfig = (obj.EndpointsConfig==null)?null:(from value in obj.EndpointsConfig select value.Clone() as WarmStandbyChannelEndpointConfiguration).ToList()
      };
    }

    private readonly SecureRandom _random = new SecureRandom();
    internal TimeSpan GetDelay(Endpoint endpoint, int cycle)
    {
      TimeSpan primaryDelay = cycle == 0
        ? TimeSpan.FromMilliseconds(InitialFastReconnectTimeout)
        : TimeSpan.FromMilliseconds(InitialReconnectTimeout);
      int delayRange = cycle == 0? 0 : InitialDelayRange;
      var config = EndpointsConfig == null
        ? null
        : EndpointsConfig.FirstOrDefault(configuration => configuration.Endpoint.Equals(endpoint));
      if (config != null)
      {
        primaryDelay = config.ReconnectDelay.GetValue(cycle, DefaultReconnectDelay, primaryDelay);
        delayRange = config.ReconnectDelayRange.GetValue(cycle, DefaultReconnectDelayRange, delayRange);
      }
      else if (DefaultReconnectDelay!=null)
      {
        primaryDelay = DefaultReconnectDelay.GetValue(cycle, null, primaryDelay);
        delayRange = DefaultReconnectDelayRange.GetValue(cycle, null, delayRange);
      }
      return primaryDelay.Add(TimeSpan.FromMilliseconds(_random.Next(delayRange)));
    }
    internal TimeSpan? GetTimeout(Endpoint endpoint, int cycle)
    {
      var config = EndpointsConfig == null 
        ? null
        : EndpointsConfig.FirstOrDefault(configuration => configuration.Endpoint.Equals(endpoint));
      if (config != null)
        return config.ChannelTimeout ?? DefaultChannelTimeout;
      return DefaultChannelTimeout;
    }
    internal int GetAttemptCount(Endpoint endpoint, int cycle)
    {
      if (cycle == 0) return 1;
      var config = EndpointsConfig == null
        ? null
        : EndpointsConfig.FirstOrDefault(configuration => configuration.Endpoint.Equals(endpoint));
      if (config != null)
        return config.AttemptCount ?? DefaultAttemptCount;
      return DefaultAttemptCount;
    }
  }
  #endregion Utility classes

  /// <summary>
  /// Abstract base class for provide basic functionality of IWarmStandbyChannel
  /// </summary>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public abstract class WarmStandbyChannelBase<T> : AbstractLogEnabled, IWarmStandbyChannel<T>
    where T : ClientChannel, new()
  {
    #region private data
    protected readonly object SyncLock = new object();
    private const string InvokerName = "WarmStandby";
    private IAsyncInvoker _invoker = InvokerFactory.NamedInvoker(InvokerName);
    private bool _isDefaultInvoker = true;
    private volatile T _channel;
    private IHandler _defaultHandler;
    private WarmStandbyChannelConfiguration _configuration = new WarmStandbyChannelConfiguration();
    #endregion private data
    #region creators
    /// <summary>
    /// Default constructor for lazy channel initialization with using default constructor
    /// </summary>
    protected WarmStandbyChannelBase()
      : this(null)
    {
    }
    /// <summary>
    /// Constructor with instance of client channel
    /// </summary>
    protected WarmStandbyChannelBase(T channel)
    {
      _channel = channel;
    }
    #endregion creators
    #region properties
    public bool IsStarted { get; protected set; }
    /// <summary>
    /// Configuration of WarmStandbyChannel
    /// </summary>
    public WarmStandbyChannelConfiguration Configuration
    {
      get { return _configuration; }
      set
      {
        _configuration = value != null
          ? value.Clone() as WarmStandbyChannelConfiguration
          : new WarmStandbyChannelConfiguration();
      }
    }
    public T Channel
    {
      get
      {
        if (_channel != null) return _channel;
        lock (SyncLock)
        {
          if (_channel != null) return _channel;
          var channel = new T();
          _channel = channel;
        }
        return _channel;
      }
    }

    /// <summary>
    /// Sets async invoker. 
    /// </summary>
    /// <param name="invoker">invoker</param>
    public IAsyncInvoker AsyncInvoker
    {
      protected get
      {
        lock (SyncLock)
        {
          return _invoker;
        }
      }
      set
      {
        bool releaseInvoker = false;
        lock (SyncLock)
        {
          if (_isDefaultInvoker)
          {
            if (value == null) return;
            releaseInvoker = true;
          }
          _isDefaultInvoker = value == null;
          _invoker = value ?? InvokerFactory.NamedInvoker(InvokerName);
        }
        if (releaseInvoker) InvokerFactory.ReleaseInvoker(InvokerName);
      }
    }
    /// <summary>
    /// Replaces the default handler.
    /// </summary>
    public IHandler Handler
    {
      protected get { return _defaultHandler; }
      set { _defaultHandler = value ?? CreateDefaultHnadler; }
    }
    #endregion properties
    #region public
    public virtual void Start()
    {
      if (IsStarted) return;
      lock (SyncLock)
      {
        if (IsStarted) return;
        SubscribeEvents(Channel);
        IsStarted = true;
      }
      var invoker = AsyncInvoker;
      if (invoker == null) return;
      invoker.Invoke((sender, args) => ProcessAction(args), this, null);
    }

    public virtual void Stop()
    {
      if (!IsStarted) return;
      lock (SyncLock)
      {
        if (!IsStarted) return;
        UnsubscribeEvents(Channel);
        IsStarted = false;
      }
    }
    #endregion public
    #region inner classes
    /// <summary>
    /// Event raised on any changing of state of WarmStandbyChannel
    /// </summary>
    /// <param name="warmStandbyChannel">host class</param>
    /// <param name="channel">active channel instance</param>
    /// <param name="code">event code</param>
    /// <param name="args">event arguments</param>
    public delegate void WarmStandbyChannelEvent(IWarmStandbyChannel<T> warmStandbyChannel, T channel, WarmStandbyChannelEventCode code, EventArgs args);

    /// <summary>
    /// This event is executed each time when the WarmStandbyChannel's state is changed
    /// </summary>
    public event WarmStandbyChannelEvent OnEvent;

    /// <summary>
    /// Describes a handler to get next action, which service should donext step
    /// </summary>
    public interface IHandler
    {
      /// <summary>
      /// Calculae next action based on existing context data
      /// </summary>
      /// <param name="context">Context of WarmStandbyChannel</param>
      /// <returns>instance of next action</returns>
      WarmStandbyChannelAction GetNextAction(Context context);
    }

    /// <summary>
    /// Describes the context of WarmStandbyChannel
    /// </summary>
    public class Context 
    {
      #region properties
      public IWarmStandbyChannel<T> WarmStandbyChannel { get; internal set; }
      public T Channel { get; internal set; }
      public EventArgs Arguments { get; internal set; } // it can be null if it is the first connection initiated by calling of WarmStandby.beginOpen()
      public Endpoint LastUsedEnpoint{ get; internal set; } // it's delegate for getEvent().getEndpoint(). it can be null if getEvent() returns null
      public int Reconnections { get; internal set; } // gets count of reconnection after
      public List<Endpoint> Enpoints { get; internal set; } // delagetes call of WarmStandby.getconfiguration().getEndpoints()
      public HashSet<Endpoint> CheckedEnpoints{ get; internal set; } // set of endpoint which were used unsuccessfully or were skipped in the current iterration cycle.
      public bool IsIterationCycleStart{ get; internal set; } // it returns true if a itteration cycle is starting
      public int IterationCycle{ get; internal set; } // 1...
      public Endpoint DefaultEnpoint{ get; internal set; } // it can be null if endpoints pool is empty
      public TimeSpan? DefaultTimeout{ get; internal set; }
      public TimeSpan DefaultDelay{ get; internal set; }
      #endregion properties

      #region helpers
      /// <summary>
      /// Returns default action. It does mean that handler suggests to approve configured strategy 
      /// </summary>
      /// <returns>Action instance</returns>
      public WarmStandbyChannelAction DefaultAction()
      {
        if (DefaultEnpoint == null)
        {
          return new WarmStandbyChannelAction(WarmsStandbyChannelActionCode.DoNothing, null,null,null);
        }
        if (DefaultEnpoint.Equals(LastUsedEnpoint))
        {
          return new WarmStandbyChannelAction(WarmsStandbyChannelActionCode.Reconnect, DefaultEnpoint, DefaultTimeout, DefaultDelay);
        }
        return new WarmStandbyChannelAction(WarmsStandbyChannelActionCode.Connect, DefaultEnpoint, DefaultTimeout, DefaultDelay);
      }

      /// <summary>
      /// Returns action to add new endpoint to configuration, or default action 
      /// </summary>
      /// <param name="endpoint">endpoint to be added</param>
      /// <returns>Action instance</returns>
      /// <exception cref="ArgumentException">If this endpoint is already in configuration</exception>
      public WarmStandbyChannelAction AddEndpoint(Endpoint endpoint)
      {
        if (Enpoints.Exists(endpoint1 => endpoint1.Equals(endpoint)))
          throw new ArgumentException("This endpoint is already contained in configuration","endpoint");
        return new WarmStandbyChannelAction(WarmsStandbyChannelActionCode.Add, endpoint, DefaultTimeout, DefaultDelay);
      }
      /// <summary>
      /// Returns action to add new endpoint with custom configuration to configuration
      /// </summary>
      /// <param name="endpointConfiguration">endpoint configuration to be added</param>
      /// <returns>Action instance</returns>
      /// <exception cref="ArgumentException">If this endpoint is already in configuration</exception>
      public WarmStandbyChannelAction AddEndpoint(WarmStandbyChannelEndpointConfiguration endpointConfiguration)
      {
        if (Enpoints.Exists(endpoint1 => endpoint1.Equals(endpointConfiguration.Endpoint)))
          throw new ArgumentException("This endpoint is already contained in configuration", "endpointConfiguration");
        return new WarmStandbyChannelAction(WarmsStandbyChannelActionCode.Add, null, DefaultTimeout, DefaultDelay)
        {
          EndpointConfiguration = endpointConfiguration
        };
      }
      /// <summary>
      /// Returns action to remove endpoint from configuration
      /// </summary>
      /// <param name="endpoint">endpoint to be removed</param>
      /// <returns>Action instance</returns>
      public WarmStandbyChannelAction RemoveEndpoint(Endpoint endpoint)
      {
        return new WarmStandbyChannelAction(WarmsStandbyChannelActionCode.Remove, endpoint, DefaultTimeout, DefaultDelay);
      }
      #endregion helpers

    }

    #endregion inner classes
    #region event handling
    /// <summary>
    /// Subscribes channel events
    /// </summary>
    /// <param name="channel">instance of ClientChannel</param>
    protected virtual void SubscribeEvents(ClientChannel channel)
    {
      channel.Closed += OnChannelClosed;
      channel.Opened += OnChannelOpened;
      channel.Error += OnChannelError;
    }
    /// <summary>
    /// Unsubscribes channel events
    /// </summary>
    /// <param name="channel">instance of ClientChannel</param>
    protected virtual void UnsubscribeEvents(ClientChannel channel)
    {
      channel.Closed -= OnChannelClosed;
      channel.Opened -= OnChannelOpened;
      channel.Error -= OnChannelError;
    }
    /// <summary>
    /// Handler for channel's 'Opened' event
    /// </summary>
    /// <param name="sender">Abstract channel</param>
    /// <param name="args">arguments</param>
    protected virtual void OnChannelOpened(object sender, EventArgs args)
    {
      FireEvent(WarmStandbyChannelEventCode.ChannelOpened, args, "[WarmStandbyChannelBase.OnChannelOpened]");
    }
    /// <summary>
    /// Handler for channel's 'Closed' event
    /// </summary>
    /// <param name="sender">Abstract channel</param>
    /// <param name="args">arguments</param>
    protected virtual void OnChannelClosed(object sender, EventArgs args)
    {
      FireEvent(WarmStandbyChannelEventCode.ChannelClosed, args, "[WarmStandbyChannelBase.OnChannelClosed]");
      var invoker = AsyncInvoker;
      if (invoker == null) return;
      invoker.Invoke((lSender, lArgs) => ProcessAction(lArgs), this, args);
    }
    /// <summary>
    /// Handler for channel's 'Error' event
    /// </summary>
    /// <param name="sender">Abstract channel</param>
    /// <param name="args">arguments</param>
    protected virtual void OnChannelError(object sender, EventArgs args)
    {
    }

    private class EventArguments : EventArgs
    {
      public WarmStandbyChannelBase<T> WarmStandby { get; set; }
      public T Channel { get; set; }
      public WarmStandbyChannelEventCode Code { get; set; }
      public EventArgs Args { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="code"></param>
    /// <param name="args"></param>
    /// <param name="descr"></param>
    protected void FireEvent(WarmStandbyChannelEventCode code, EventArgs args, String descr)
    {
      var invoker = AsyncInvoker;
      if (invoker==null) return;
      invoker.Invoke((sender, eventArgs) =>
      {
        var eventHandler = OnEvent;
        if (eventHandler == null) return;
        var arg = eventArgs as EventArguments;
        if (arg==null) return;
        if ((Logger != null) && (Logger.IsInfoEnabled))
          Logger.Info(descr + " Executing handler");
        foreach (var @delegate in eventHandler.GetInvocationList())
        {
          try
          {
            var handler = @delegate as WarmStandbyChannelEvent;
            if (handler == null) continue;
            handler(arg.WarmStandby, arg.Channel, arg.Code, arg.Args);
          }
          catch (Exception e)
          {
            if ((Logger != null) && (Logger.IsErrorEnabled))
              Logger.Error(descr+" Exception raised during execution ", e);
          }
        }
      },this, new EventArguments{Args = args, Channel = Channel, Code = code, WarmStandby = this});
    }
    #endregion event handling
    #region abstract
    /// <summary>
    /// Creates instance of default handler.
    /// </summary>
    protected abstract IHandler CreateDefaultHnadler { get; }
    /// <summary>
    /// Executes to process each action
    /// </summary>
    /// <param name="args">arguments</param>
    protected abstract void ProcessAction(EventArgs args);

    #endregion abstract
  }

  /// <summary>
  /// Default implementarion of IWarmStandbyChannel interface
  /// </summary>
  /// <typeparam name="T">Client channel derived class</typeparam>
  [Obsolete("Use Genesyslab.Platform.Standby instead")]
  public class WarmStandbyChannel<T> : WarmStandbyChannelBase<T> where T : ClientChannel, new()
  {
    private readonly IScheduler _scheduler = TimerFactory.Scheduler;
    private readonly HashSet<Endpoint> _checkedEnpoints = new HashSet<Endpoint>();
    private readonly SecureRandom _random = new SecureRandom();
    private int _iterationCycle = 0;
    private int _reconnectionCount = 0;
    private ITimerActionTicket _activeTimerTicket = null;

    protected override void OnEnableLogging(ILogger logger)
    {
      base.OnEnableLogging(logger);
      if (logger != null)
      {
        Channel.EnableLogging(logger.CreateChildLogger("[WarmStandbyChannel." + typeof (T).Name + "]"));
        var logEnabled = _scheduler as AbstractLogEnabled;
        if (logEnabled!=null) logEnabled.EnableLogging(logger.CreateChildLogger("[WarmStandbyChannel." + _scheduler.GetType().Name + "]"));
      }
    }

    #region override
    protected override IHandler CreateDefaultHnadler
    {
      get { return DefaultHandler.Instance; }
    }

    public override void Stop()
    {
      lock (SyncLock)
      {
        if ((IsStarted) && (_activeTimerTicket!=null))
        {
          _activeTimerTicket.Cancel();
          _activeTimerTicket = null;
        }
      }
      base.Stop();
    }

    /// <summary>
    /// Calculates next endpoint to be connected
    /// </summary>
    /// <param name="currentEndpoint">initial endpoint</param>
    /// <param name="endpoints">list of available endpoints</param>
    /// <returns>next endpoint</returns>
    protected virtual Endpoint SuggestNextEndpoint(Endpoint currentEndpoint, List<Endpoint> endpoints)
    {
      if ((endpoints==null) || (endpoints.Count == 0)) return null;
      if ((Configuration.GetAttemptCount(currentEndpoint, _iterationCycle) > _reconnectionCount) && (currentEndpoint!=null))
      {
        return currentEndpoint;
      }
      switch (Configuration.Order)
      {
        case WarmStandbyChannelIterationOrder.Consecutive:
        case WarmStandbyChannelIterationOrder.Priority:
        {
          var firstAvailable = endpoints.FirstOrDefault(endpoint => !_checkedEnpoints.Contains(endpoint));
          if (firstAvailable != null) return firstAvailable;
          lock (SyncLock)
          {
            _checkedEnpoints.Clear();
            _iterationCycle++;
          }
          return endpoints.FirstOrDefault();
        }
        case WarmStandbyChannelIterationOrder.Random:
        {
          var available = endpoints.Where(endpoint => !_checkedEnpoints.Contains(endpoint)).ToList();
          if (available.Count == 0)
          {
            lock (SyncLock)
            {
              _checkedEnpoints.Clear();
              _iterationCycle++;
            }
            available = endpoints;
          }
          return endpoints[_random.Next(available.Count)];
        }
      }
      return null;
    }

    private Context PrepareContext(EventArgs args)
    {
      var arg = args as ClosedEventArgs;
      if (arg != null)
      {
        lock (SyncLock)
        {
          _reconnectionCount++;
          if (arg.Endpoint != null)
            _checkedEnpoints.Add(arg.Endpoint);
        }
      }
      var endpoints = Configuration.Endpoints;
      var currentEndpoint = (args is ClosedEventArgs) ? (args as ClosedEventArgs).Endpoint : null;
      var nextEndpoint = SuggestNextEndpoint(currentEndpoint, endpoints);
      return new Context()
      {
        Arguments = args,
        WarmStandbyChannel = this,
        Channel = Channel,
        CheckedEnpoints = new HashSet<Endpoint>(_checkedEnpoints),
        LastUsedEnpoint = currentEndpoint,
        DefaultDelay = Configuration.GetDelay(nextEndpoint, _iterationCycle),
        DefaultTimeout = Configuration.GetTimeout(nextEndpoint, _iterationCycle),
        DefaultEnpoint = nextEndpoint,
        Enpoints = endpoints,
        IterationCycle = _iterationCycle,
        Reconnections = _reconnectionCount,
        IsIterationCycleStart = _checkedEnpoints.Count == 0
      };
    }

    private WarmStandbyChannelAction PrepareAction(Context context)
    {
      var handler = Handler;
      WarmStandbyChannelAction action = null;
      try
      {
        if ((Logger != null) && (Logger.IsDebugEnabled))
          Logger.Debug("[WarmStandbyChannel.ProcessAction] Execute handler. ");
        action = (handler == null) ? context.DefaultAction() : handler.GetNextAction(context);
      }
      catch (Exception e)
      {
        if ((Logger != null) && (Logger.IsErrorEnabled))
          Logger.Error("[Handler.GetNextAction] raises an exception: ", e);
        action = context.DefaultAction();
      }
      if ((Logger != null) && (Logger.IsDebugEnabled))
        Logger.DebugFormat("[WarmStandbyChannel.ProcessAction] use {0}",
          ((action == null) ? "action = null" : action.ToString()));
      return action;
    }
    protected override void ProcessAction(EventArgs args)
    {
      var context = PrepareContext(args);
      while (true)
      {
        var action = PrepareAction(context);
        if (action == null)
        {
          FireEvent(WarmStandbyChannelEventCode.ConnectionNotScheduled, null,
            "[WarmStandbyChannel.ProcessAction('ConnectionNotScheduled')]");
          return;
        }
        switch (action.Code)
        {
          case WarmsStandbyChannelActionCode.Connect:
          {
            FireEvent(WarmStandbyChannelEventCode.ConnectionScheduled, action,
              "[WarmStandbyChannel.ProcessAction('ConnectionScheduled')]");
            _reconnectionCount = 0;
            var delay = (long) (action.Delay ?? Configuration.GetDelay(null, _iterationCycle)).TotalMilliseconds;
            _activeTimerTicket = _scheduler.Schedule(delay, new ScheduledReconnectTimerAction(action, this));
            return;
          }
          case WarmsStandbyChannelActionCode.Reconnect:
          {
            FireEvent(WarmStandbyChannelEventCode.ConnectionScheduled, action,
              "[WarmStandbyChannel.ProcessAction('ConnectionScheduled')]");
            var delay = (long) (action.Delay ?? Configuration.GetDelay(null, _iterationCycle)).TotalMilliseconds;
            _activeTimerTicket = _scheduler.Schedule(delay, new ScheduledReconnectTimerAction(action, this));
            return;
          }
          case WarmsStandbyChannelActionCode.Stop:
          {
            Stop();
            return;
          }
          case WarmsStandbyChannelActionCode.Remove:
          {
            lock (SyncLock)
            {
              var conf = Configuration.EndpointsConfig.FirstOrDefault(
                  configuration => configuration.Endpoint.Equals(action.Endpoint));
              if (conf != null)
              {
                Configuration.EndpointsConfig.Remove(conf);
                context.Enpoints = Configuration.Endpoints;
              }
            }
            break;
          }
          case WarmsStandbyChannelActionCode.Add:
          {
            lock (SyncLock)
            {
              if (action.EndpointConfiguration != null)
                Configuration.AddEndpoints(action.EndpointConfiguration);
              else if (action.Endpoint!=null)
                Configuration.AddEndpoints(action.Endpoint);
              context.Enpoints = Configuration.Endpoints;
            }
            break;
          }
          case WarmsStandbyChannelActionCode.AddAndConnect:
          {
            lock (SyncLock)
            {
              if (action.EndpointConfiguration != null)
                Configuration.AddEndpoints(action.EndpointConfiguration);
              else if (action.Endpoint != null)
                Configuration.AddEndpoints(action.Endpoint);
              context.Enpoints = Configuration.Endpoints;
            }
            FireEvent(WarmStandbyChannelEventCode.ConnectionScheduled, action,
              "[WarmStandbyChannel.ProcessAction('ConnectionScheduled')]");
            _reconnectionCount = 0;
            var delay = (long)(action.Delay ?? Configuration.GetDelay(null, _iterationCycle)).TotalMilliseconds;
            _activeTimerTicket = _scheduler.Schedule(delay, new ScheduledReconnectTimerAction(action, this));
            return;
          }

        }
      }
    }

    private class ScheduledReconnectTimerAction : ITimerAction
    {
      private readonly WarmStandbyChannelAction _action;
      private readonly WarmStandbyChannel<T> _warmStandbyChannel;
      public ScheduledReconnectTimerAction(WarmStandbyChannelAction action, WarmStandbyChannel<T> warmStandbyChannel)
      {
        _action = action;
        _warmStandbyChannel = warmStandbyChannel;
      }
      public void OnTimer()
      {
        _warmStandbyChannel._activeTimerTicket.Cancel();
        var channel = _warmStandbyChannel.Channel;
        var timeout = channel.Timeout;
        channel.Endpoint = _action.Endpoint ?? channel.Endpoint;
        channel.Timeout = _action.Timeout ?? timeout;
        channel.BeginOpen();
        channel.Timeout = timeout;
      }
    }
    #endregion override
    #region inner classes
    private class DefaultHandler : IHandler
    {
      private DefaultHandler(){}
      private static volatile DefaultHandler _instance;
      internal static DefaultHandler Instance
      {
        get
        {
          if (_instance != null) return _instance;
          lock (typeof(DefaultHandler))
          {
            if (_instance != null) return _instance;
            _instance = new DefaultHandler();
          }
          return _instance;
        }
      }

      public WarmStandbyChannelAction GetNextAction(Context context)
      {
        return context.DefaultAction();
      }
    }
    #endregion inner classes


  }


  
}

//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

//===============================================================================



using System;
using System.Text;

using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.ApplicationBlocks.WarmStandby
{
    /// <summary>
    /// The <c>WarmStandbyConfiguration</c> class contains redundancy configuration options, 
    /// including:
    /// two server's URIs - one for the active URI, and a backup URI;
    /// the number of reconnection attempts to be made;
    /// timeout between the reconnection attempts (in milliseconds);
    /// and the number of primary/backup switchovers allowed.
    /// </summary>
    public class WarmStandbyConfiguration
    {
        #region Constants

        /// <summary>
        /// Maximum timeout/delay between channel reopening attempts
        /// (30 min in milliseconds)
        /// </summary>
        public const int MaxTimeout = 1800000;

        #endregion Constants

        #region Fields

        private Endpoint activeEp;
        private Endpoint standbyEp;
        private int? timeout;
        private short? attempts;
        private short? switchovers;
        private int? firstReconnectingTimeout;

        #endregion Fields

        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeEp">Client Channel's active Endpoint.</param>
        /// <param name="standbyEp">Client Channel's standby Endpoint.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        public WarmStandbyConfiguration(Endpoint activeEp, Endpoint standbyEp, int timeout, short attempts)
            : this(activeEp, standbyEp)
        {
            if (timeout < 0 || timeout > WarmStandbyConfiguration.MaxTimeout)
            {
                throw new ArgumentException("timeout is out of range","timeout");
            }
            if (attempts < 0)
            {
              throw new ArgumentException("attempts is out of range", "attempts");
            }

            this.timeout = timeout;
            this.attempts = attempts;
        }
        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeEp">Client Channel's active Endpoint.</param>
        /// <param name="standbyEp">Client Channel's standby Endpoint.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        public WarmStandbyConfiguration(Endpoint activeEp, Endpoint standbyEp, int? timeout, short? attempts)
          : this(activeEp, standbyEp)
        {
          if (timeout!=null)
          if (timeout < 0 || timeout > WarmStandbyConfiguration.MaxTimeout)
          {
            throw new ArgumentException("timeout is out of range", "timeout");
          }
          if (attempts!=null)
          if (attempts < 0)
          {
            throw new ArgumentException("attempts is out of range", "attempts");
          }

          this.timeout = timeout;
          this.attempts = attempts;
        }

        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeUri">Client Channel's active Uri.</param>
        /// <param name="standbyUri">Client Channel's standby Uri.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        [Obsolete("Deprecated. Use constructors with Endpoint parameters instead of Uri")]
        public WarmStandbyConfiguration(Uri activeUri, Uri standbyUri, int timeout, short attempts)
            : this(activeUri, standbyUri)
        {
            if (timeout < 0 || timeout > WarmStandbyConfiguration.MaxTimeout)
            {
              throw new ArgumentException("timeout is out of range", "timeout");
            }
            if (attempts < 0)
            {
              throw new ArgumentException("attempts is out of range", "attempts");
            }

            this.timeout = timeout;
            this.attempts = attempts;
        }

        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeEp">Client Channel's active Endpoint.</param>
        /// <param name="standbyEp">Client Channel's standby Endpoint.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        /// <param name="switchovers">the number of primary/backup switchovers</param>
        public WarmStandbyConfiguration(Endpoint activeEp, Endpoint standbyEp, int timeout, short attempts, short switchovers)
            : this(activeEp, standbyEp, timeout, attempts)
        {
            if (switchovers < 0)
            {
              throw new ArgumentException("switchovers is out of range", "switchovers");
            }

            this.switchovers = switchovers;
        }
        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeEp">Client Channel's active Endpoint.</param>
        /// <param name="standbyEp">Client Channel's standby Endpoint.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        /// <param name="switchovers">the number of primary/backup switchovers</param>
        public WarmStandbyConfiguration(Endpoint activeEp, Endpoint standbyEp, int? timeout, short? attempts, short? switchovers)
          : this(activeEp, standbyEp, timeout, attempts)
        {
          if (switchovers!=null)
          if (switchovers < 0)
          {
            throw new ArgumentException("switchovers is out of range", "switchovers");
          }

          this.switchovers = switchovers;
        }
        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeEp">Client Channel's active Endpoint.</param>
        /// <param name="standbyEp">Client Channel's standby Endpoint.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        /// <param name="switchovers">the number of primary/backup switchovers</param>
        /// <param name="firstReconnectTimeout">timeout of first fast reconnect</param>
        public WarmStandbyConfiguration(Endpoint activeEp, Endpoint standbyEp, int timeout, short attempts, short switchovers, int firstReconnectTimeout)
          : this(activeEp, standbyEp, timeout, attempts, switchovers)
        {
          if (firstReconnectTimeout < 0 || firstReconnectTimeout > WarmStandbyConfiguration.MaxTimeout)
          {
            throw new ArgumentException("firstReconnectTimeout is out of range", "firstReconnectTimeout");
          }

          this.firstReconnectingTimeout = firstReconnectTimeout;
        }
        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeEp">Client Channel's active Endpoint.</param>
        /// <param name="standbyEp">Client Channel's standby Endpoint.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        /// <param name="switchovers">the number of primary/backup switchovers</param>
        /// <param name="firstReconnectTimeout">timeout of first fast reconnect</param>
        public WarmStandbyConfiguration(Endpoint activeEp, Endpoint standbyEp, int? timeout, short? attempts, short? switchovers, int? firstReconnectTimeout)
          : this(activeEp, standbyEp, timeout, attempts, switchovers)
        {
          if (firstReconnectTimeout != null)
          if (firstReconnectTimeout < 0 || firstReconnectTimeout > WarmStandbyConfiguration.MaxTimeout)
          {
            throw new ArgumentException("firstReconnectTimeout is out of range", "firstReconnectTimeout");
          }

          this.firstReconnectingTimeout = firstReconnectTimeout;
        }

        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeUri">Client Channel's active Uri.</param>
        /// <param name="standbyUri">Client Channel's standby Uri.</param>
        /// <param name="timeout">timeout between the reconnection attempts.</param>
        /// <param name="attempts">number of reconnection attempts.</param>
        /// <param name="switchovers">the number of primary/backup switchovers</param>
        [Obsolete("Deprecated. Use constructors with Endpoint parameters instead of Uri")]
        public WarmStandbyConfiguration(Uri activeUri, Uri standbyUri, int timeout, short attempts, short switchovers)
            : this(activeUri, standbyUri, timeout, attempts)
        {
            if (switchovers < 0)
            {
                throw new ArgumentException("switchovers", "switchovers is out of range");
            }

            this.switchovers = switchovers;
        }

        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeUri">Client Channel's active Uri.</param>
        /// <param name="standbyUri">Client Channel's standby Uri.</param>
        [Obsolete("Deprecated. Use constructors with Endpoint parameters instead of Uri")]
        public WarmStandbyConfiguration(Uri activeUri, Uri standbyUri)
        {
            if (activeUri == null)
                throw new ArgumentNullException("activeUri", "activeUri is null.");
            if (standbyUri == null)
                throw new ArgumentNullException("standbyUri", "standbyUri is null.");

            this.activeEp = new Endpoint("primary", activeUri);
            this.standbyEp = new Endpoint("backup", standbyUri);
        }

        /// <summary>
        /// Creates a <c>WarmStandbyConfiguration</c> instance.
        /// </summary>
        /// <param name="activeEp">Client Channel's active Endpoint.</param>
        /// <param name="standbyEp">Client Channel's standby Endpoint.</param>
        public WarmStandbyConfiguration(Endpoint activeEp, Endpoint standbyEp)
        {
            if (activeEp == null)
                throw new ArgumentNullException("activeUri", "activeUri is null.");
            if (standbyEp == null)
                throw new ArgumentNullException("standbyUri", "standbyUri is null.");

            this.activeEp = activeEp;
            this.standbyEp = standbyEp;
        }

        #region Properties

        /// <summary>
        /// Gets the active Uri.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentNullException.#ctor(System.String,System.String)")]
        public Uri ActiveUri
        {
            get
            {
                return this.activeEp.Uri;
            }
        }

        /// <summary>
        /// Gets/Sets the active Endpoint.
        /// </summary>
        public Endpoint ActiveEndpoint
        {
            get
            {
                return this.activeEp;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value", "Value is null.");
                }

                this.activeEp = value;
            }
        }

        /// <summary>
        /// Gets the standby Uri.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentNullException.#ctor(System.String,System.String)")]
        public Uri StandbyUri
        {
            get
            {
                return this.standbyEp.Uri;
            }
        }

        /// <summary>
        /// Gets/Sets the standby Endpoint.
        /// </summary>
        public Endpoint StandbyEndpoint
        {
            get
            {
                return this.standbyEp;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value", "Value is null.");
                }
                this.standbyEp = value;
            }
        }

        /// <summary>
        /// Gets/Sets the timeout (in milliseconds) between the reconnection attempts.
        /// </summary>
        public int? Timeout
        {
            get { return this.timeout; }
            set
            {
                if (value != null)
                {
                    if (value.Value < 0 || value.Value > WarmStandbyConfiguration.MaxTimeout)
                    {
                        throw new ArgumentException("value", "value is out of range");
                    }
                }
                this.timeout = value;
            }
        }
        /// <summary>
        /// Gets/Sets the timeout (in milliseconds) of first fast reconnect.
        /// </summary>
        public int? FirstReconnectTimeout
        {
          get { return this.firstReconnectingTimeout; }
          set
          {
            if (value != null)
            {
              if (value.Value < 0 || value.Value > WarmStandbyConfiguration.MaxTimeout)
              {
                throw new ArgumentException("value is out of range", "value");
              }
            }
            this.firstReconnectingTimeout = value;
          }
        }

        /// <summary>
        /// Gets/Sets the number of reconnection attempts.
        /// </summary>
        public short? Attempts
        {
            get { return this.attempts; }
            set
            {
                if (value != null)
                {
                    if (value.Value < 0)
                    {
                        throw new ArgumentException("value", "value is out of range");
                    }
                }
                this.attempts = value;
            }
        }

        /// <summary>
        /// Gets/Sets the number of primary/backup switchovers. If this parameter is not set,
        /// or if it is set to null, then an unlimited number of switchovers are allowed.
        /// If this parameter is set to 0 then switchover will not happen.
        /// </summary>
        public short? Switchovers
        {
            get { return this.switchovers; }
            set { this.switchovers = value; }
        }

        #endregion Properties

        /// <summary>
        /// Creates a String that represents the current Object. 
        /// </summary>
        /// <returns>String that represents the current Object.</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.GetType().ToString());
            sb.Append(":\n");

            sb.AppendFormat("ActiveEp: {0}\n", this.activeEp.ToString());
            sb.AppendFormat("StandbyEp: {0}\n", this.standbyEp != null ? this.standbyEp.ToString() : "null");
            sb.AppendFormat("Timeout: {0}\n", (this.timeout==null)?"null":this.timeout.ToString());
            sb.AppendFormat("Attempts: {0}\n", (this.attempts == null) ? "null" : this.attempts.ToString());
            sb.AppendFormat("Switchovers: {0}\n", (this.switchovers==null)?"null":this.switchovers.ToString());
            sb.AppendFormat("FirstReconnectTimeout: {0}\n", (this.firstReconnectingTimeout==null)?"null":this.firstReconnectingTimeout.ToString());

            return sb.ToString();
        }
    }
}

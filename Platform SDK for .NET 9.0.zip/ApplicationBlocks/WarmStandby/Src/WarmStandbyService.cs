//===============================================================================
// Genesys Platform SDK Application Blocks
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.

//===============================================================================


using System;
using System.Text;
using System.Threading;

using Genesyslab.Platform.Commons;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;
using System.Diagnostics;


namespace Genesyslab.Platform.ApplicationBlocks.WarmStandby
{
    /// <summary>
    /// <c>WarmStandbyService</c> class realizes a redundancy configuration consisting of two servers: Primary and Backup, 
    /// where the Primary server operates in active mode and the Backup server in standby mode. 
    /// Only the Primary server accepts connections and message exchanges with the clients. 
    /// In case of the Primary server failure, the Backup server switches to active mode assuming the role 
    /// and behavior of the Primary server.
    /// </summary>
    public class WarmStandbyService : AbstractLogEnabled, IDisposable
    {
        #region Constants

        private const short DefaultAttempts = 3;
        private const int DefaultTimeout = 10000;
        private const string InvokerName = "WarmStandby";

        #endregion Constants
        #region Events

        /// <summary>
        /// The event <c>StateChanged</c> is raised upon <c>WarmStandbyService</c>'s state changes
        /// </summary>
        public event EventHandler StateChanged;
        /// <summary>
        /// The event <c>SwitchedOver</c> is raised upon <c>WarmStandbyService</c>'s Configuration Switchover
        /// </summary>
        public event EventHandler SwitchedOver;

        /// <summary>
        /// This call-back method is called in case of RegistrationException.
        /// It means that target server is available, but for some reason
        /// it does not allow the client connection. It may be caused by
        /// wrong login credentials, or some other exception while client
        /// registration procedure on opened connection.
        /// Usually it means that there is no need to try reconnect.
        /// 
        /// Custom code may use provided context to access WarmStandbyService instance,
        /// to get WarmStandbyConfiguration, and the client protocol connection.
        /// Also the context allows user to schedule next reconnect task,
        /// switchover, or stop service.
        /// <see cref="RegistrationException"/>
        /// </summary>
        /// <param name="context">failure context</param>
        /// <returns>true if the failure event is handled, or
        /// false if user wants to let the service to perform default
        /// operation for the event (stop the WarmStandby service)
        /// </returns>
        public delegate bool RegistrationFailureCallback(IWarmStandbyConnectionFailureContext context);

        /// <summary>
        /// This call-back method is called in case of connection failure
        /// (except RegistrationException).
        /// 
        /// Custom code may use provided context to access WarmStandbyService instance,
        /// to get WarmStandbyConfiguration, and the client protocol connection.
        /// Also the context allows user to schedule next reconnect task,
        /// switchover, or stop service.
        /// </summary>
        /// <param name="context">failure context</param>
        /// <returns>true if the failure event is handled, or
        /// false if user wants to let the service to perform default
        /// operation for the event
        /// </returns>
        public delegate bool ConnectionFailureCallback(IWarmStandbyConnectionFailureContext context);

        #endregion Events

        #region Fields

        private readonly ManualResetEvent _timeoutEvent = new ManualResetEvent(false);
        private Genesyslab.Platform.Commons.Threading.IAsyncInvoker _invoker = null;
        private readonly object _wsLock;
        private Timer _timeoutTimer;

        private ClientChannel _channel;
        private WarmStandbyConfiguration _configuration;
        private volatile WarmStandbyState _state;
        private short _attempt;
        private short _switchover;
        private volatile bool _isDisposed;
        private RegistrationFailureCallback _registrationFailureCallback = null;
        private ConnectionFailureCallback _connectionFailureCallback = null;

        #endregion Fields

        #region Properties

        /// <summary>
        /// Gets the Client Channel the <c>WarmStandbyService</c> is responsible for
        /// </summary>
        public ClientChannel Channel
        {
            get { return this._channel; }
        }

        /// <summary>
        /// Gets <c>WarmStandbyService</c> Configuration
        /// </summary>
        public WarmStandbyConfiguration Configuration
        {
            get { return this._configuration; }
        }
        /// <summary>
        /// Gets the <c>WarmStandbyService</c> State
        /// </summary>
        public WarmStandbyState State
        {
            get { return this._state; }
        }

        /// <summary>
        /// Gets current reconnection attempt value
        /// </summary>
        public short Attempt
        {
            get { return this._attempt; }
        }

        /// <summary>
        /// Gets current count of switchovers
        /// </summary>
        public short Switchover
        {
            get { return this._switchover; }
        }

        #endregion Properties

        /// <summary>
        /// Creates a <c>WarmStandbyService</c> instance
        /// </summary>
        /// <param name="channel">Client Channel the WarmStandby is responsible for</param>
        public WarmStandbyService(ClientChannel channel)
        {
            if (channel == null)
                throw new ArgumentNullException("channel", "channel is null.");

            this._wsLock = new object();

            this._channel = channel;
            this._state = WarmStandbyState.Off;
            this._attempt = 1;
            Channel.Closed += this.OnChannelClosed;
            Channel.Opened += this.OnChannelOpened;

            this._isDisposed = false;
        }

        /// <summary>
        /// Activates the <c>WarmStandbyService</c>
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        public void Start()
        {
            if (this._isDisposed)
            {
                throw new InvalidOperationException("Warm Standby is disposed.");
            }

            lock (this._wsLock)
            {
                if (this.State != WarmStandbyState.Off)
                    throw new InvalidOperationException("Warm Standby is already started.");
                if (this.Configuration == null)
                    throw new InvalidOperationException("Warm Standby's Configuration is not defined.");

                this._invoker = Genesyslab.Platform.Commons.Threading.InvokerFactory.NamedInvoker(WarmStandbyService.InvokerName);
                this._attempt = 1;
                this._switchover = 0;

                this._state = WarmStandbyState.Idle;

                this.RaiseStateChanged();
            }

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Started on channel {0}", this.Channel.Endpoint);
            }
        }

        /// <summary>
        /// Deactivates the <c>WarmStandbyService</c>
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)")]
        public void Stop()
        {
            if (this._isDisposed)
            {
                throw new InvalidOperationException("Warm Standby is disposed.");
            }

            lock (this._wsLock)
            {
                if (this.State == WarmStandbyState.Off)
                    throw new InvalidOperationException("Warm Standby is not started.");

                this._state = WarmStandbyState.Off;

                this.RaiseStateChanged();

                ReleaseInvoker();
            }

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Stopped on channel {0}", this.Channel.Endpoint);
            }
        }

        private void ReleaseInvoker()
        {
            if (_invoker != null)
            {
                if ((Logger!=null) && (Logger.IsDebugEnabled))
                  Logger.DebugFormat("Warmstandby releases invoker '{0}'",InvokerName);
                Genesyslab.Platform.Commons.Threading.InvokerFactory.ReleaseInvoker(WarmStandbyService.InvokerName);
                _invoker = null;
            }
        }

        /// <summary>
        /// Sets <c>WarmStandbyService</c> Configuration
        /// </summary>
        /// <param name="conf">Configuration to be applied</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.InvalidOperationException.#ctor(System.String)"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentNullException.#ctor(System.String,System.String)")]
        public void ApplyConfiguration(WarmStandbyConfiguration conf)
        {
            if (this._isDisposed)
            {
                throw new InvalidOperationException("Warm Standby is disposed.");
            }

            if (conf == null)
                throw new ArgumentNullException("conf", "configuration is null.");

            ApplyConfiguration(conf, 1);
        }

        /// <summary>
        /// Sets <c>WarmStandbyService</c> Configuration
        /// </summary>
        /// <param name="conf">Warm Standby Configuration to apply</param>
        /// <param name="reset">Indicates if the configuration needs to be reset</param>
        public void ApplyConfiguration(WarmStandbyConfiguration conf, bool reset)
        {
            if (this._isDisposed)
            {
                throw new InvalidOperationException("Warm Standby is disposed.");
            }

            if (conf == null)
                throw new ArgumentNullException("conf", "configuration is null.");

            short attempt = reset ? (short)1 : this._attempt;

            ApplyConfiguration(conf, attempt);

        }

        /// <summary>
        /// Sets user defined <see cref="RegistrationFailureCallback"/> procedure. 
        /// Callback will be called in cases of RegistrationException.
        /// </summary>
        /// <param name="callback">RegistrationFailureCallback</param>
        public void SetRegistrationFailureCallback(RegistrationFailureCallback callback)
        {
            _registrationFailureCallback = callback;
        }

        /// <summary>
        /// Sets user defined <see cref="ConnectionFailureCallback"/> procedure.
        /// Callback will be called in cases of connection failure.
        /// </summary>
        /// <param name="callback">ConnectionFailureCallback</param>
        public void SetConnectionFailureCallback(ConnectionFailureCallback callback)
        {
            _connectionFailureCallback = callback;
        }

        #region Internals

        private void ApplyConfiguration(WarmStandbyConfiguration conf, short attempt)
        {
            lock (this._wsLock)
            {
                int timeout = conf.Timeout == null ? (this._configuration != null ? this._configuration.Timeout.Value : DefaultTimeout) : conf.Timeout.Value;
                short attempts = conf.Attempts == null ? (this._configuration != null ? this._configuration.Attempts.Value : DefaultAttempts) : conf.Attempts.Value;
                this._configuration =
                    new WarmStandbyConfiguration(conf.ActiveEndpoint, conf.StandbyEndpoint, timeout, attempts);
                this._configuration.Switchovers = conf.Switchovers;
                this._configuration.FirstReconnectTimeout = (conf.FirstReconnectTimeout == null) ? null : new int?(conf.FirstReconnectTimeout.Value);
                try
                {
                    this._channel.Endpoint = this._configuration.ActiveEndpoint;
                }
                catch (ProtocolException ex)
                {
                    Logger.WarnFormat("WarmStandbyService can't update Endpoint for channel {0}: {1}", this.Channel.Endpoint, ex);
                }

                this._attempt = attempt;
            }

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Configuration on {0} is changed to {1}", this.Channel.Endpoint, Configuration);
            }
        }

        /// <summary>
        /// Switches over Active and Standby (servers) Urls
        /// </summary>
        internal void DoSwitchover()
        {
            Endpoint tempEp = this._configuration.ActiveEndpoint;
            this._configuration.ActiveEndpoint = this._configuration.StandbyEndpoint;
            this._configuration.StandbyEndpoint = tempEp;
            this._switchover++;
        }

        #region Channel EventHandlers

        /// <summary>
        /// Event Handler for the event triggered by the Client Channel when it gets into the Opened state
        /// </summary>
        private void OnChannelOpened(object sender, EventArgs eventArgs)
        {
            if (this._state == WarmStandbyState.Off)
                return;

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Processing channel {0} opened... State: {1}", this.Channel.Endpoint, this.State);
            }

            lock (this._wsLock)
            {
                //this.channel.Endpoint = this.configuration.ActiveEndpoint;//ER#297932061 "Warm Standby doesn�t work"
                this._attempt = 1;
                this._switchover = 0;

                if (this._state != WarmStandbyState.Idle)
                {
                    this._state = WarmStandbyState.Idle;
                    this.RaiseStateChanged();
                }
            }
        }

        /// <summary>
        /// Event Handler for event triggered when the Client Channel gets into the Closed state
        /// </summary>
        private void OnChannelClosed(object sender, EventArgs eventArgs)
        {
            if (this._state == WarmStandbyState.Off)
                return;

            string endpoint = "null";
            try
            {
                if (this._channel != null && this._channel.Endpoint != null)
                    endpoint = this._channel.Endpoint.ToString();
            }
            catch
            {
              endpoint = "<unknown endpoint>";
            }

            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("OnChannelClosed(...) {0} invoked...", endpoint);
            }

            ClosedEventArgs closedEventArgs = eventArgs as ClosedEventArgs;

            if (closedEventArgs == null) return;

            if ((closedEventArgs.Cause != null) && (!(closedEventArgs.Cause is ChannelEmergencyClosedException)))
            {
                this.ProcessConnectivityFailure(closedEventArgs);
            }
            else
            {
                if (Logger.IsInfoEnabled)
                {
                  Logger.InfoFormat("Channel {0}, {1}closing caused by a request...", endpoint,
                    (closedEventArgs.IsEmergencyClosed ? "emergency " : ""));
                }
                lock (this._wsLock)
                {
                    if (this._state == WarmStandbyState.Reconnecting)
                    {
                        this._state = WarmStandbyState.Idle;
                        this.RaiseStateChanged();
                    }
                }
            }
        }


        #endregion Channel EventHandlers

        #region Channel Failure Processing

        /// <summary>
        /// This function contains implementation of processing of a ClientChannel's connectivity failure
        /// </summary>
        /// <param name="eventArgs">A holder of channel's <c>Closed</c> event information</param>
        protected void ProcessConnectivityFailure(ClosedEventArgs eventArgs)
        {
            lock (this._wsLock)
            {
                if (this._state == WarmStandbyState.Off)
                    return;

                if (Logger.IsDebugEnabled)
                {
                    Logger.DebugFormat("Channel {0} failed to open, cause: {1}",
                                      this.Channel.Endpoint, eventArgs.Cause.ToString());

                    Logger.DebugFormat("Processing channel {0} closed (failure {1})... State: {2}",
                                      this.Channel.Endpoint, eventArgs, this.State);
                }

                WarmStandbyConnectionFailureContextImpl context =
                new WarmStandbyConnectionFailureContextImpl(this, eventArgs);

                try
                {
                    if (eventArgs.Cause is RegistrationException)
                    {
                        if (_registrationFailureCallback != null)
                        {
                            try
                            {
                                if (_registrationFailureCallback(context))
                                    return;
                            }
                            catch (Exception ex)
                            {
                                Logger.WarnFormat("Exception in user defined RegistrationFailureCallback at {0}: {1}",
                                    _configuration.ActiveEndpoint, ex);
                            }
                        }
                        DefaultRegistrationFailureCallback(context);
                        return;
                    }
                    if (_connectionFailureCallback != null)
                    {
                        try
                        {
                            if (_connectionFailureCallback(context))
                                return;
                        }
                        catch (Exception ex)
                        {
                            Logger.WarnFormat("Exception in user defined ConnectionFailureCallback at {0}: {1}",
                                _configuration.ActiveEndpoint, ex);
                        }
                    }
                    DefaultConnectionFailureCallback(context);
                }
                finally
                {
                    context.Invalidate();
                }
            }
        }

        private bool DefaultRegistrationFailureCallback(IWarmStandbyConnectionFailureContext context)
        {
            Logger.InfoFormat("Channel closing after registration failure: {0}",
                    context.ClosedEvent.Cause);
            context.DoStandbyOff();
            return true;
        }

        private bool DefaultConnectionFailureCallback(IWarmStandbyConnectionFailureContext context)
        {
            WarmStandbyService service = context.Service;
            WarmStandbyConfiguration config = service.Configuration;

            bool switchoverRequired = (service.Attempt > config.Attempts);
            bool waitForTimeout = (service.Attempt > 1);

            if (service.Switchover < 2)
            {
                switchoverRequired = true;
                waitForTimeout = false;
            }

            if (switchoverRequired)
            {
                short? cfgSwitchovers = config.Switchovers;
                if (cfgSwitchovers == null || service.Switchover < cfgSwitchovers)
                {
                  context.DoSwitchover();
                  if ((service.Switchover > 2) && (config.Attempts < 2))
                  {
                      waitForTimeout = true;
                  }
                  else
                  {
                    waitForTimeout = false;
                  }
                }
                else
                {
                    if (Logger.IsDebugEnabled)
                    {
                        Logger.Debug("Switchover " + service.Switchover + " of " + cfgSwitchovers
                                + ", WarmStandbyService is stopped");
                    }
                    context.DoStandbyOff();
                    return true;
                }
            }
            if (Logger.IsDebugEnabled)
            {
              Logger.Debug(String.Format("Starting reconnect: Switchover Number={0}, Atempt={1}, Switchover={3}, Wait={2}", 
                                          service.Switchover, service.Attempt, waitForTimeout, switchoverRequired));
            }
            int fastTimeout = ((service.Switchover<2) && (config.FirstReconnectTimeout != null)) ? config.FirstReconnectTimeout.Value: 100;
            context.ScheduleReconnect(waitForTimeout
                                      ? ((config.Timeout == null) ? DefaultTimeout : config.Timeout.Value)
                                      : fastTimeout);
            return true;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1500:VariableNamesShouldNotMatchFieldNames", MessageId = "state")]
        private void ReOpenChannel(object state)
        {
            lock (this._wsLock)
            {
                if (_timeoutTimer == null)
                {
                    Logger.Warn("Unexpected event(s) from channel. Several attempts of channel.Open()?");
                    return;
                }
                this._timeoutTimer.Dispose();
                this._timeoutTimer = null;
                if (this._state == WarmStandbyState.Off)
                    return;

                if (Logger.IsDebugEnabled)
                {
                    Logger.DebugFormat("Reopening the channel {0}, {1} of {2}",
                                      this._channel.Endpoint, this._attempt, this._configuration.Attempts);
                }

                ++this._attempt;
                this._state = WarmStandbyState.Reconnecting;

                this.RaiseStateChanged();
              Exception openException = null;
              try
              {
                this._channel.BeginOpen();
              }
              catch (PlatformException ex)
              {
                if (Logger.IsDebugEnabled)
                {
                  Logger.DebugFormat("Reopening the channel {0}, {1} of {2} failed, {3}",
                    this._channel.Endpoint, this._attempt - 1, this._configuration.Attempts,
                    ex.ToString());
                }
              }
              catch (Exception e)
              {
                if ((Logger!=null)&& (Logger.IsDebugEnabled))
                  Logger.DebugFormat("Reopening the channel {0}, {1} of {2} failed, {3}",
                    this._channel.Endpoint, this._attempt - 1, this._configuration.Attempts,
                    e.ToString());
                if ((Logger != null) && (Logger.IsWarnEnabled))
                  Logger.WarnFormat("Try to stop WarmStandbyService. Cause: {0}", e.ToString());
                openException = e;
              }
              if (openException!=null)
              try
              {
                Stop();
                if ((Logger != null) && (Logger.IsWarnEnabled))
                  Logger.WarnFormat("WarmStandbyService has stopped. Cause: {0}:{1}", openException.GetType().Name,openException.Message);
              }
              catch (Exception e)
              {
                if ((Logger != null) && (Logger.IsWarnEnabled))
                  Logger.WarnFormat("Error stop WarmStandbyService. Cause: {0}", e.ToString());
              }
            }
        }

        #endregion Channel Failure Processing

        #region WarmStandby RaiseEvents

        /// <summary>
        /// This event is raised by <c>WarmStandbyService</c> upon its state change(s)
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")]
        protected void RaiseStateChanged()
        {
            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Firing 'StateChange'. State:{0} Channel {1}.", this.State, this.Channel.Endpoint);
            }

            WarmStandbyEventArgs args = new WarmStandbyEventArgs(State);

            try
            {
                if (this.StateChanged != null)
                {
                    this._invoker.Invoke(this.StateChanged, this, args);
                }
            }
            catch (PlatformException ex)
            {
                if (Logger.IsDebugEnabled)
                {
                    Logger.Debug("StateChanged event firing has failed: " + ex.ToString());
                }
            }
        }

        /// <summary>
        /// This event is raised by <c>WarmStandbyService</c> upon Configuration Switchover
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")]
        protected void RaiseSwitchedOver()
        {
            if (Logger.IsDebugEnabled)
            {
                Logger.DebugFormat("Firing 'SwitchedOver'. Active:{0}, Standby:{1}.",
                                    this._configuration.ActiveEndpoint, this._configuration.StandbyEndpoint);
            }

            try
            {
                if (this.SwitchedOver != null)
                {
                    this._invoker.Invoke(this.SwitchedOver, this, null);
                }
            }
            catch (PlatformException ex)
            {
                if (Logger.IsDebugEnabled)
                {
                    Logger.Debug("SwitchedOver event firing has failed: " + ex.ToString());
                }
            }
        }


        #endregion WarmStandby RaiseEvents

        /// <summary>
        /// Disposes of the service. Implements the Basic Dispose Pattern.
        /// </summary>
        /// <param name="disposing">
        /// <c>false</c> indicates that the method was invoked from the finalizer,
        /// in this case reference objects should not be accessed.
        /// </param>
        protected virtual void Dispose(bool disposing)
        {
            lock (this._wsLock)
            {
                if (this._isDisposed)
                    return;

                if (disposing)
                {
                    if (_timeoutTimer != null)
                    {
                        this._timeoutTimer.Dispose();
                        this._timeoutEvent.Close();
                    }
                }

                if (State != WarmStandbyState.Off)
                {
                    Stop();
                }

                Channel.Closed -= this.OnChannelClosed;
                Channel.Opened -= this.OnChannelOpened;

                ReleaseInvoker();

                this._channel = null;

                this._isDisposed = true;
            }
        }

        #endregion Internals

        #region IDisposable Members

        /// <summary>
        /// Disposes of the service. Implements the Basic Dispose Pattern.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        internal class WarmStandbyConnectionFailureContextImpl : AbstractLogEnabled, IWarmStandbyConnectionFailureContext
        {
            private readonly ClosedEventArgs eventArgs;
            private bool invalidated = false;
            private readonly object sync = new object();
            private readonly WarmStandbyService service;

            public WarmStandbyConnectionFailureContextImpl(WarmStandbyService service, ClosedEventArgs eventArgs)
            {
                this.service = service;
                this.eventArgs = eventArgs;
            }

            public void Invalidate()
            {
                lock (sync)
                {
                    invalidated = true;
                }
            }

            private void ThrowIfInvalid()
            {
                if (invalidated)
                {
                    throw new InvalidOperationException(
                            "ConnectionFailureContext has been invalidated");
                }
            }

            public ClosedEventArgs ClosedEvent
            {
                get
                {
                    lock (sync)
                    {
                        ThrowIfInvalid();

                        return eventArgs;
                    }
                }
            }

            public WarmStandbyService Service
            {
                get
                {
                    lock (sync)
                    {
                        ThrowIfInvalid();

                        return service;
                    }
                }
            }

            public void DoSwitchover()
            {
                lock (sync)
                {
                    ThrowIfInvalid();

                    if (Logger.IsDebugEnabled)
                    {
                        Logger.DebugFormat("Switching over the configurations from {0} to {1}",
                              service.Configuration.ActiveEndpoint, service.Configuration.StandbyEndpoint);
                    }

                    service.DoSwitchover();
                    service._channel.TlsProperties.Enabled = false;
                    service._channel.Endpoint = service._configuration.ActiveEndpoint;
                    service._attempt = 1;
                    service.RaiseSwitchedOver();
                }
            }

            public void DoStandbyOff()
            {
                lock (sync)
                {
                    ThrowIfInvalid();

                    if (Logger.IsDebugEnabled)
                    {
                        Logger.DebugFormat("WarmStandby switched off for {0} <> {1}",
                              service.Configuration.ActiveEndpoint, service.Configuration.StandbyEndpoint);
                    }

                    service._attempt = 1;
                    service._switchover = 0;
                    service._state = WarmStandbyState.Off;
                    service.RaiseStateChanged();
                    service.ReleaseInvoker();
                }
            }

            public void ScheduleReconnect(int delayMillisec)
            {
                lock (sync)
                {
                    ThrowIfInvalid();

                    lock (service._wsLock)
                    {
                        if (service._timeoutTimer != null)
                        {
                            service._timeoutTimer.Dispose();
                            service._timeoutTimer = null;
                        }
                        service._state = WarmStandbyState.Waiting;
                        service.RaiseStateChanged();
                        service._timeoutTimer = new Timer(new TimerCallback(service.ReOpenChannel), null,
                                                 delayMillisec, Timeout.Infinite);
                    }
                }
            }
        }
    }
}

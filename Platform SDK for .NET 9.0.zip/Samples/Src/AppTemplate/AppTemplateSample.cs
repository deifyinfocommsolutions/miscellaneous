//===============================================================================
// Genesys Platform SDK Samples
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2015 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using System.Threading;
using Genesyslab.Platform.AppTemplate.Configuration;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols.Exceptions;
using Genesyslab.Platform.Configuration.Protocols.Types;
using Genesyslab.Platform.Standby;
using Genesyslab.Platform.Voice.Protocols;

namespace Genesyslab.Platform.Samples.AppTemplate
{
  ///<summary>
  /// The Application Template Application Block provides a way to read configuration options 
  /// for applications and to configure Platform SDK protocols.<br/>
  ///
  /// This samples shows:<br/>
  ///  - How to create already configured Endpoint for client connection <br/>
  ///  - How to create WarmStandby configuration<br/>
  ///</summary>
  public static class AppTemplateSample
  {
    public static void Main(params string[] args)
    {
      var properties = new Properties(args);
      ConfigServiceHelper confService = null;
      try
      {
        //get our CfgApplication			
        confService = new ConfigServiceHelper(properties);
        confService.OpenService();
        var application = confService.GetApplication(properties.GetProperty("application.name","default"));
        if (application == null)
        {
          Console.WriteLine("No application found...");
        }
        //create Application Template configuration holder.
        //Used by helpers to initialize Endpoints, Warm Standby, etc
        var appConfiguration = new GCOMApplicationConfiguration(application);
        //create Endpoint for connection to TServer.			
        var endppoint = CreateEndpoint(appConfiguration, CfgAppType.CFGTServer);
        if (endppoint != null)
        {
          var protocol = new TServerProtocol(endppoint);
          TestSingleConnect(protocol);
        }
        else
        {
          Console.WriteLine("T-Server connection is not found...");
        }
        //create WarmStandby configuration to open connection using WarmStandby service.
        //If no backup server specified in CME, WarmStandby configuration will contain single endpoint.
        WSConfig wsconfig = CreateWSConfig(appConfiguration, CfgAppType.CFGTServer);
        if (wsconfig != null)
        {
          var protocol = new TServerProtocol();
          var ws = new WarmStandby(protocol);
          ws.Configuration = wsconfig;
          TestWSConnect(ws);
        }
      }
      catch (ConfRegistrationException ex)
      {
        Console.WriteLine("Client registration failed: " + ex.ErrorDescription);
      }
      catch (Exception e)
      {
        Console.WriteLine("Exception: \n{0}", e);
      }
      finally
      {
        if (confService != null)
          confService.ReleaseConfigService();
      }


      Console.WriteLine("\n\nPress any key to exit...");
      Console.ReadKey(true);
    }

    #region scenarios
    /// <summary>
    /// Demonstrates connection of the channel to the target Server with parameters (stored in Endpoint), 
    /// that were retrieved from CfgApplication.
    /// </summary>
    /// <param name="channel">channel to connect</param>
    private static void TestSingleConnect(ClientChannel channel)
    {
      try
      {
        Endpoint epndpoint = channel.Endpoint;
        Uri uri = epndpoint != null ? epndpoint.Uri : null;
        Console.WriteLine("\nConnecting to server: " + uri);
        channel.Open();
        Console.WriteLine("Successfully connected!");
      }
      catch (Exception t)
      {
        Console.WriteLine("Failed to open connection, server unavailable...");
      }
      finally
      {
        if (channel != null)
        {
          channel.Close();
          Console.WriteLine("Disconnected.");
        }
      }

    }

    /// <summary>
    /// Demonstrates connection of the Warm Standby to the pair of target Servers with parameters (stored in WSConfig), 
    /// that were retrieved from CfgApplication.
    /// </summary>
    /// <param name="ws"></param>
    private static void TestWSConnect(WarmStandby ws)
    {
      try
      {
        Console.WriteLine("\n\nInitiate open with WarmStandby");
        ws.BeginOpen(null, null); // initiate open
        ws.Open(); // wait for open
        Console.WriteLine("Connected to server: " + ws.Channel.Endpoint.Uri);
        ws.BeginClose(null, null); // initiate closing
        Console.WriteLine("Disconnecting.");
        ws.Close(); // wait for close
        Console.WriteLine("Disconnected.");
        Console.WriteLine("\n\nInitiate open with WarmStandby");
        var iar = ws.BeginOpen(null, null); // initiate open
        ws.EndOpen(iar); // wait for open
        Console.WriteLine("Connected to server: " + ws.Channel.Endpoint.Uri);
        ws.BeginClose(null, null); // initiate closing
        Console.WriteLine("Disconnecting.");
        ws.Close(); // wait for close
        Console.WriteLine("Disconnected.");

        var @event = new ManualResetEvent(false);
        ws.ChannelOpened += (sender, args) =>
        {
          Console.WriteLine("Connected to server: " + ws.Channel.Endpoint.Uri);
          @event.Set();
        };
        Console.WriteLine("\n\nInitiate open with WarmStandby");
        ws.BeginOpen(null, null);
        if (!@event.WaitOne(10000))
        {
          Console.WriteLine("Failed to open connection, server unavailable.");
        }
        Console.WriteLine("Disconnecting.");
        ws.Close();
        Console.WriteLine("Disconnected.");
      }
      catch (Exception e)
      {
        Console.WriteLine("Failed to open connection, server unavailable.");
      }
    }

    #endregion scenarios
    #region utilites
    /// <summary>
    /// Creates fully configured Endpoint regarding settings, specified in Configuration Server.
    /// </summary>
    /// <param name="appConfiguration">application which here client connection is defined</param>
    /// <param name="serverType">type of the client connection</param>
    /// <returns>Endpoint</returns>
    private static Endpoint CreateEndpoint(GCOMApplicationConfiguration appConfiguration, CfgAppType serverType)
    {

      IGAppConnConfiguration connConfig = appConfiguration.GetAppServer(serverType);
      if (connConfig == null)
      {
        return null;
      }
      Endpoint targetEndpoint = ClientConfigurationHelper.CreateEndpoint(appConfiguration, connConfig,
        connConfig.TargetServerConfiguration);
      if (targetEndpoint != null)
      {
        Console.WriteLine(String.Format("Resolved Endpoint for {0}: \'{1}\'", serverType, targetEndpoint));

        var cfg = targetEndpoint.GetConfiguration();
        if (cfg != null)
          Console.WriteLine("Enpoint settings: \n{0}", cfg);
      }
      else
      {
        Console.WriteLine("Application has no client connections to " + serverType.ToString("F") +
                          " (see connections tab in CME)");
      }
      return targetEndpoint;
    }

    /// <summary>
    /// Creates WarmStandby Configuration which is ready for connection to the pair of servers.<br/>
    /// Configuration includes:<br/>
    ///    - WarmStandby timeout parameters<br/>
    ///    - Target endpoints<br/>
    ///    - Connection parameters (tls, string encoding, etc) <br/>
    /// </summary>
    /// <param name="appConfiguration">application where client connection to WS pair is defined</param>
    /// <param name="serverType">type of the client connection</param>
    /// <returns>WSConfig</returns>
    public static WSConfig CreateWSConfig(GCOMApplicationConfiguration appConfiguration, CfgAppType serverType)
    {
      var connConfig = appConfiguration.GetAppServer(serverType);
      if (connConfig == null)
      {
        Console.WriteLine("Application has no client connections to " + serverType.ToString("F") +
                          " (see connections tab in CME)");
        return null;
      }
      var wsconfig = ClientConfigurationHelper.CreateWarmStandbyConfigEx(appConfiguration, connConfig);
      if (wsconfig != null)
      {
        Console.WriteLine("Got WarmStandby Configuration: \n" + wsconfig);
      }

      return wsconfig;
    }

    #endregion utilites
  }
}

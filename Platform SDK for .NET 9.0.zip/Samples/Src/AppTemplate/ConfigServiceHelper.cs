//===============================================================================
// Genesys Platform SDK Samples
//===============================================================================

// Any authorized distribution of any copy of this code (including any related 
// documentation) must reproduce the following restrictions, disclaimer and copyright 
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name 
// (even as a part of another name), endorse and/or promote products derived from 
// this code without prior written permission from Genesys Telecommunications 
// Laboratories, Inc. 

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys 
// Developer License Agreement.  This code shall not be used, copied, and/or 
// distributed under any other license agreement.    

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC. 
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY 
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND 
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT 
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL 
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO 
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2015 - 2019 Genesys Telecommunications Laboratories, Inc. All rights reserved.


using System;
using System.Collections.Generic;
using System.Globalization;
using Genesyslab.Configuration;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols;
using Genesyslab.Platform.Configuration.Protocols.Types;

namespace Genesyslab.Platform.Samples.AppTemplate
{
  /// <summary>
  /// Helper class to read properties
  /// </summary>
  internal class Properties
  {
    private readonly List<string> _properties;
    internal Properties(params string[] properties)
    {
      if (properties==null) return;
      foreach (string property in properties)
      {
        var strings = property.Split(';');
        foreach (string s in strings)
        {
          if (_properties==null) _properties=new List<string>();
          _properties.Add(s.Trim());
        }
      }
    }

    private string GetValue(string property, string name)
    {
      var strings = property.Split('=');
      if (strings.Length!=2) return null;
      if (strings[0].Trim().ToLower(CultureInfo.InvariantCulture).Equals(name.Trim().ToLower()))
        return strings[1].Trim();
      return null;
    }
    internal string GetProperty(string name, string defValue)
    {
      if (_properties != null)
      {
        foreach (string property in _properties)
        {
          var value = GetValue(property, name);
          if (value != null) return value;
        }
      }
      return PsdkCustomization.CustomOption(name, defValue);
    }
    internal int GetProperty(string name, int defValue)
    {
      if (_properties != null)
      {
        foreach (string property in _properties)
        {
          var value = GetValue(property, name);
          if (value != null)
          {
            int res;
            if (Int32.TryParse(value, out res))
              return res;
          }
        }
      }
      return PsdkCustomization.CustomOption(name, defValue);
    }
  }

  /// <summary>
  /// Helper class to create, release Config Service and read Configuration Objects.
  /// </summary>
  internal class ConfigServiceHelper
  {
    private IConfService _service;

    private readonly String _host;
    private readonly int _port;
    private readonly String _userName;
    private readonly String _userPassword;
    private readonly String _applicationName;
    private readonly CfgAppType? _applicationType;

    /// <summary>
    /// Creates helper to communicate with Configuration Server.
    /// App.config file contains properties that specify Configuration Server 
    /// address and user credentials. 
    /// </summary>
    public ConfigServiceHelper(Properties properties)
    {
      _host = properties.GetProperty("config.server.host", null);
      _port = properties.GetProperty("config.server.port", -1);
      _userName = properties.GetProperty("config.server.user", null);
      _userPassword = properties.GetProperty("config.server.password", null);
      _applicationName = properties.GetProperty("application.name", null);
      try
      {
        _applicationType =
          (CfgAppType) Enum.Parse(typeof (CfgAppType),
            properties.GetProperty("application.type", null), true);
      }
      catch (Exception)
      {
        _applicationType = null;
      }
    }
    /// <summary>
    /// Creates helper to communicate with Configuration Server.
    /// </summary>
    /// <param name="host">Host name of Configuration server</param>
    /// <param name="port">Port of Configuration Server</param>
    /// <param name="userName">User name of Configuration Server's user</param>
    /// <param name="userPassword">User password of Configuration Server's user</param>
    /// <param name="applicationName">Name of application</param>
    /// <param name="applicationType">Type of application</param>
    public ConfigServiceHelper(string host, int port, string userName,
      string userPassword, string applicationName, CfgAppType applicationType)
    {
      _host = host;
      _port = port;
      _userName = userName;
      _userPassword = userPassword;
      _applicationName = applicationName;
      _applicationType = applicationType;
    }

    /// <summary>
    /// Creates IConfService object and opens connection to Configuration Server
    /// </summary>
    /// <exception cref="Exception">if IConfService wasn't created or Configuration Protocol wasn't opened.</exception>
    public void OpenService()
    {
      try
      {
        var protocol = new ConfServerProtocol(new Endpoint(_host, _port))
        {
          UserName = _userName,
          UserPassword = _userPassword,
          ClientName = _applicationName
        };
        if (_applicationType != null)
          protocol.ClientApplicationType = (int)_applicationType.Value;
        _service = ConfServiceFactory.CreateConfService(protocol);
        protocol.Open();

      }
      finally
      {
        if (_service != null)
        {
          var protocol = _service.Protocol;
          if (protocol.State != ChannelState.Opened)
          {
            ReleaseConfigService();
          }
        }
      }
    }

    /// <summary>
    /// Releases IConfService
    /// </summary>
    public void ReleaseConfigService()
    {
      try
      {
        if (_service != null)
        {
          var protocol = _service.Protocol;
          protocol.Close();
          ConfServiceFactory.ReleaseConfService(_service);
          _service = null;
        }
      }
      catch (Exception e)
      {
        Console.WriteLine("Exception occured while releasing Config Service\n{0}", e);
      }
    }
    /// <summary>
    /// Tries to get CfgApplication using CfgApplicationQuery
    /// </summary>
    /// <param name="name">name application name</param>
    /// <returns>CfgApplication</returns>
    /// <exception cref="Exception"></exception>
  	public CfgApplication GetApplication(String name)
    {
      if (String.IsNullOrEmpty(name)) return null;
      return new CfgApplicationQuery(_service){ Name = name }.ExecuteSingleResult();
	  }

  }
}

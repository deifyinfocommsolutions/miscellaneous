// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using Genesyslab.Platform.Samples.Common;

namespace Genesyslab.Platform.Samples.COMSample
{
  #region Common API specifications

  /// <summary>
  /// Event's codes constants
  /// </summary>
  public static class ComModelEventCodes
  {
    public const int ChannelClosed = 1;
    public const int ChannelOpened = 2;
    public const int ChannelError = 3;
    public const int ChannelMessage = 4;
    public const int InternalError = 5;

    public const int PersonCreated = 100;
    public const int PersonReaded = 101;
    public const int PersonUpdated = 102;
    public const int PersonDeleted = 103;
  }
  #endregion Common API specifications
  #region COM Model specifications
  /// <summary>
  /// Basic API functions 
  /// </summary>
  public interface IComModelBaseApi
  {
    /// <summary>
    /// Initializes connection's parameters
    /// </summary>
    /// <param name="host">Host name</param>
    /// <param name="port">Port number</param>
    /// <param name="clientName">Client's name</param>
    /// <param name="userName">User's name</param>
    /// <param name="password">User password. Further API may be some different in case of using sensitive data.</param>
    void Initialization(string host, int port, string clientName, string userName, string password);
    /// <summary>
    /// Opens client's connection to server
    /// </summary>
    void Open();
    /// <summary>
    /// Closes client's connection to server
    /// </summary>
    void Close();
  }
  /// <summary>
  /// CRUD API function
  /// </summary>
  public interface IComModelApi:IComModelBaseApi
  {
    /// <summary>
    /// Creates new person. If person with the same name already exists it will be deleted.
    /// </summary>
    /// <param name="firstName">First name of person</param>
    /// <param name="lastName">Last name of person</param>
    /// <param name="userName">Person's user name.</param>
    void CreatePerson(string firstName, string lastName, string userName);
    /// <summary>
    /// Reads person by its ID
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    void ReadPerson(int dbId);
    /// <summary>
    /// Reads person by its First Name
    /// </summary>
    /// <param name="name">Person's First Name value</param>
    void ReadPerson(string name);
    /// <summary>
    /// Updates person
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    /// <param name="firstName">New First name</param>
    /// <param name="lastName">New last name</param>
    void UpdatePerson(int dbId, string firstName, string lastName);
    /// <summary>
    /// Deletes person
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    void DeletePerson(int dbId);
    /// <summary>
    /// Deletes person
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    /// <param name="sync">Wait for delete if true, otherwise run asynchronously</param>
    void DeletePerson(int dbId, bool sync);
  }
  /// <summary>
  /// Common interface of COM model
  /// </summary>
  public interface IComModel : IComModelApi, IModel
  {}
  #endregion COM Model specifications
  #region COM View specifications
  /// <summary>
  /// Common interface of COM View
  /// </summary>
  public interface IComView: IViewApi, IView
  {}
  #endregion COM View specifications
  #region COM ViewModel specification
  /// <summary>
  /// Common interface of COM View-Model bridge
  /// </summary>
  public interface IComViewModel : IComModelApi, IViewApi, IViewModel
  {
  }
  #endregion COM ViewModel specification




}

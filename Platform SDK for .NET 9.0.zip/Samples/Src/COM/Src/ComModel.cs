// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Threading;
using Genesyslab.Configuration;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Configuration.Protocols;

namespace Genesyslab.Platform.Samples.COMSample
{
  /// <summary>
  /// Base class of COM model, implements intialization of service,
  /// Open/Close methods and channel's handlers. 
  /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/UsingtheCOMAB"/>
  /// </summary>
  public abstract class ComModelBase : IComModelBaseApi
  {
    private ILogger _logger;
    private ConfServerProtocol _client;
    private IConfService _service;

    /// <summary>
    /// Notifies ViewModel that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    protected void Notify(int code, int subCode, object data)
    {
      Notify(code,subCode, data, null);
    }
    /// <summary>
    /// Notifies ViewModel that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    /// <param name="descr">Event description</param>
    protected abstract void Notify(int code, int subCode, object data, string descr);

    protected IConfService Service { get { return _service; } }
    /// <summary>
    /// finalizer
    /// </summary>
    ~ComModelBase()
    {
      ReleaseService();
      if (_client != null)
      {
        if (_client.State!=ChannelState.Closed)
          _client.Close();
        _client.Dispose();
        _client = null;
      }
    }
    /// <summary>
    /// Method releases service
    /// </summary>
    private void ReleaseService()
    {
      if (_service != null)
      {
        ConfServiceFactory.ReleaseConfService(_service);
        _service = null;
      }
    }
    /// <summary>
    /// Assigns a logger to client channel
    /// </summary>
    /// <param name="logger">ILogger instance</param>
    public void EnableLogging(ILogger logger)
    {
      _logger = logger;
      if (_client != null)
        _client.EnableLogging(logger);
    }
    /// <summary>
    /// Initializes connection's and security parameters
    /// </summary>
    /// <param name="host">host name</param>
    /// <param name="port">port number</param>
    /// <param name="clientName">client's name</param>
    /// <param name="userName">user's name</param>
    /// <param name="password">user's password</param>
    public void Initialization(string host, int port, string clientName, string userName, string password)
    {
      _client = new ConfServerProtocol(new Endpoint(host, port))
      {
        ClientName = clientName,
        UserPassword = password,
        UserName = userName,
        ClientApplicationType = PsdkCustomization.CustomOption("Samples.CS.ClientType",19)
      };
      _client.ConfigureAddp();
      _service = ConfServiceFactory.CreateConfService(_client);
      _client.Opened += OnOpened;
      _client.Closed += OnClosed;
      if (_logger != null)
      {
        _client.EnableLogging(_logger);
        var srv = _service as AbstractLogEnabled;
        if (srv!=null) srv.EnableLogging(_logger.CreateChildLogger("COM.service"));
      }
    }
    /// <summary>
    /// Opens configuration server connection
    /// </summary>
    public void Open()
    {
      if (!CheckClientIsNull()) return;
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          _client.Open();
        }
        catch (Exception e)
        {
          Notify(ModelEventCodes.InternalError, 0, e);
          Notify(ModelEventCodes.ChannelClosed, 0, e);
        }
      });
    }
    /// <summary>
    /// Event handler of 'Opened' event
    /// </summary>
    /// <param name="sender">Client channel instance</param>
    /// <param name="args">OpenedEventArgs instance</param>
    private void OnOpened(object sender, EventArgs args)
    {
      Notify(ComModelEventCodes.ChannelOpened, 0, args);
    }
    /// <summary>
    /// Event handler of 'Closed' event
    /// </summary>
    /// <param name="sender">Client channel instance</param>
    /// <param name="args">ClosedEventArgs instance</param>
    private void OnClosed(object sender, EventArgs args)
    {
      ReleaseService();
      Notify(ComModelEventCodes.ChannelClosed, 0, args);
    }
    /// <summary>
    /// Closes configuration server connection
    /// </summary>
    public void Close()
    {
      if (!CheckClientIsNull()) return;
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          _client.Close();
        }
        catch (Exception e)
        {
          Notify(ComModelEventCodes.InternalError, 0, e);
        }
      });
    }
    /// <summary>
    /// service method, checks if client channel is created
    /// </summary>
    /// <returns>true if client channel is created otherwise returns false</returns>
    protected bool CheckClientIsNull()
    {
      if (_client == null)
      {
        Notify(ComModelEventCodes.InternalError, 0, new ArgumentException("Client is null"));
        return false;
      }
      return true;
    }
    /// <summary>
    /// service method, checks if client channel is opened
    /// </summary>
    /// <returns>true if client channel is opened otherwise returns false</returns>
    protected bool CheckClientIsOpened()
    {
      if (_client.State != ChannelState.Opened)
      {
        Notify(ComModelEventCodes.InternalError, 0, new ArgumentException("Client is not opened"));
        return false;
      }
      return true;
    }
  }

  /// <summary>
  /// Abstract class implements a little example of CRUD model
  /// </summary>
  public abstract class ComModelCrud : ComModelBase, IComModelApi
  {
    /// <summary>
    /// Creates person on configuration server
    /// </summary>
    /// <param name="firstName">First name of person</param>
    /// <param name="lastName">Last name of person</param>
    /// <param name="userName">User name of person</param>
    public void CreatePerson(string firstName, string lastName, string userName)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      var service = Service;
      if (service == null)
      {
        Notify(ComModelEventCodes.InternalError, 0, null, "ConfService is not initialized...");
        return;
      }
      // run in background
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          // create query to check if this person has already been created
          var query = new CfgPersonQuery(service) {FirstName = firstName};
          // retrieve all persons with given parameters
          var readedPersons = query.Execute();
          if ((readedPersons != null) && (readedPersons.Count > 0))
          {
            foreach (CfgPerson readedPerson in readedPersons)
            {
              // delete existing persons
              readedPerson.Delete();
              // notify to a view that person has been deleted
              Notify(ComModelEventCodes.PersonDeleted, 0, readedPerson);
            }
          }
          // create person
          var person = new CfgPerson(service) {FirstName = firstName, LastName = lastName, UserName = userName};
          person.SetTenantDBID(WellKnownDbids.EnvironmentDbid);
          var s = firstName + "_" + lastName;
          person.EmployeeID=(s.Length>63)?s.Substring(0,63):s;
          // save person on configuration server
          person.Save();
          // notify to view that new person has beed created
          Notify(ComModelEventCodes.PersonCreated, 0, person);
        }
        catch (Exception e)
        {
          // notify to a view that some error occured during execution
          Notify(ComModelEventCodes.InternalError, ComModelEventCodes.PersonCreated, e);
        }
      });
    }
    /// <summary>
    /// Reads a person by its BDID
    /// </summary>
    /// <param name="dbId">database unique object identifier</param>
    public void ReadPerson(int dbId)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      var service = Service;
      if (service == null)
      {
        Notify(ComModelEventCodes.InternalError, 0, null, "ConfService is not initialized...");
        return;
      }
      // run in background
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          // create query to read existing person
          var query = new CfgPersonQuery(service) { Dbid = dbId };
          // retrieve all persons with given parameters
          var readedPersons = query.Execute();
          if ((readedPersons != null) && (readedPersons.Count > 0))
          {
            foreach (CfgPerson readedPerson in readedPersons)
            {
              // notify to a view that person has been read
              Notify(ComModelEventCodes.PersonReaded, 0, readedPerson);
            }
          }
          else
          {
            // notify to a view that the reading of person with given parameters was unsuccessful
            Notify(ComModelEventCodes.PersonReaded, 0, null);
          }
        }
        catch (Exception e)
        {
          // notify to a view that some error occured during execution
          Notify(ComModelEventCodes.InternalError, ComModelEventCodes.PersonReaded, e);
        }
      });
    }
    public void ReadPerson(string name)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      var service = Service;
      if (service == null)
      {
        Notify(ComModelEventCodes.InternalError, 0, null, "ConfService is not initialized...");
        return;
      }
      // run in background
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          // create query to read existing person
          var query = new CfgPersonQuery(service) { FirstName = name };
          // retrieve all persons with given parameters
          var readedPersons = query.Execute();
          if ((readedPersons != null) && (readedPersons.Count > 0))
          {
            foreach (CfgPerson readedPerson in readedPersons)
            {
              // notify to a view that person has been read
              Notify(ComModelEventCodes.PersonReaded, 0, readedPerson);
            }
          }
          else
          {
            // notify to a view that person has been read
            Notify(ComModelEventCodes.PersonReaded, 0, null);
          }
        }
        catch (Exception e)
        {
          // notify to a view that some error occured during execution
          Notify(ComModelEventCodes.InternalError, ComModelEventCodes.PersonReaded, e);
        }
      });
    }
    /// <summary>
    /// Updates a person
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    /// <param name="firstName">New First name of person</param>
    /// <param name="lastName">New Last name of person</param>
    public void UpdatePerson(int dbId, string firstName, string lastName)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      var service = Service;
      if (service == null)
      {
        Notify(ComModelEventCodes.InternalError, 0, null, "ConfService is not initialized...");
        return;
      }
      // run in background
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          // create query to read existing person
          var query = new CfgPersonQuery(service) { Dbid = dbId };
          // retrieve all persons with given parameters
          var readedPersons = query.Execute();
          if ((readedPersons != null) && (readedPersons.Count > 0))
          {
            foreach (CfgPerson readedPerson in readedPersons)
            {
              // ipdate person's fields
              readedPerson.FirstName = firstName;
              readedPerson.LastName = lastName;
              // save person on configuration server
              readedPerson.Save();
              // notify to a view that person has been updated
              Notify(ComModelEventCodes.PersonUpdated, 0, readedPerson);
            }
          }
          else
          {
            // notify to a view that person has been updated
            Notify(ComModelEventCodes.PersonUpdated, 0, null);
            return;
          }
          // retrieve all persons with given parameters (verify changes)
          readedPersons = query.Execute();
          if ((readedPersons != null) && (readedPersons.Count > 0))
          {
            foreach (CfgPerson readedPerson in readedPersons)
            {
              // notify to a view that person has been read
              Notify(ComModelEventCodes.PersonReaded, 0, readedPerson);
            }
          }
          else
          {
            // notify to a view that person has been read
            Notify(ComModelEventCodes.PersonReaded, 0, null);
          }
        }
        catch (Exception e)
        {
          // notify to a view that some error occured during execution
          Notify(ComModelEventCodes.InternalError, ComModelEventCodes.PersonUpdated, e);
        }
      });
    }
    /// <summary>
    /// Delete person by id
    /// </summary>
    /// <param name="service">instance IConfService</param>
    /// <param name="dbId">unique database object identifier</param>
    private void DeletePerson(IConfService service, int dbId)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      try
      {
        // create query to read existing person
        var query = new CfgPersonQuery(service) { Dbid = dbId };
        // retrieve all persons with given parameters
        var readedPersons = query.Execute();
        if ((readedPersons != null) && (readedPersons.Count > 0))
        {
          foreach (CfgPerson readedPerson in readedPersons)
          {
            // delete person
            readedPerson.Delete();
            // notify to a view that the person has been deleted
            Notify(ComModelEventCodes.PersonDeleted, 0, readedPerson);
          }
        }
      }
      catch (Exception e)
      {
        // notify to a view that some error occured during execution
        Notify(ComModelEventCodes.InternalError, ComModelEventCodes.PersonDeleted, e);
      }
    }

    /// <summary>
    /// Deletes person by id
    /// </summary>
    /// <param name="dbId">unique database object identifier</param>
    public void DeletePerson(int dbId)
    {
      DeletePerson(dbId, false);
    }
    /// <summary>
    /// Deletes person by id
    /// </summary>
    /// <param name="dbId">unique database object identifier</param>
    /// <param name="sync">flag, if equals to true - operation should be asynchronous, otherwise - synchronous</param>
    public void DeletePerson(int dbId, bool sync)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      var service = Service;
      if (service == null)
      {
        Notify(ComModelEventCodes.InternalError, 0, null, "ConfService is not initialized...");
        return;
      }
      if (sync) 
        DeletePerson(service, dbId);
      else
        // run in background
        ThreadPool.QueueUserWorkItem(state => DeletePerson(service, dbId));
    }

  }
  /// <summary>
  /// COM AB sample moodel
  /// </summary>
  public class ComModel : ComModelCrud, IComModel
  {
    private IViewApi _view;
    /// <summary>
    /// Initializes relations between model and view
    /// </summary>
    /// <param name="view"></param>
    public void Initialization(IView view)
    {
      _view = view as IViewApi;
    }
    /// <summary>
    /// Notifies view about model's changes
    /// </summary>
    /// <param name="code">event code</param>
    /// <param name="subCode">event subcode</param>
    /// <param name="data">model data</param>
    /// <param name="descr">description of the change</param>
    protected override void Notify(int code, int subCode, object data, string descr)
    {
      if (_view!=null)
        _view.Notify(code, subCode, data, descr);
    }
  }
}

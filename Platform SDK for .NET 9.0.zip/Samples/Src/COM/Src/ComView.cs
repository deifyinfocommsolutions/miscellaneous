// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using Genesyslab.Configuration;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Protocols;

namespace Genesyslab.Platform.Samples.COMSample
{
  /// <summary>
  /// Implements presentation of data
  /// </summary>
  public sealed class ComView : SampleViewBase, IComView
  {
    public ComView(ApplicationContext appContext)
      : base(appContext)
    {
    }
    private new IComModelApi Model
    {
      get { return base.Model as IComModelApi; }
    }
    /// <summary>
    /// Creates form and assign logic 
    /// </summary>
    /// <returns>Sample form instance</returns>
    protected override SampleForm CreateForm()
    {
      return new ComViewForm(this);
    }

    #region form
    /// <summary>
    /// Inner class represents a form and logic of presentation
    /// </summary>
    private class ComViewForm : SampleForm
    {
      private readonly ComView _view;

      public ComViewForm(ComView view)
      {
        _view = view;
        InitializeComponent();
      }

      private RichTextBox _box;
      private ConsoleWrapper _console;
      private Label _dbIdLabel;
      private int? _personDbId;
      private String _personFirstName;
      private TextBox _personFirstNameBox;
      private String _personLastName;
      private TextBox _personLastNameBox;
      private String _personUserName;
      private TextBox _personUserNameBox;
      private String _csHostName;
      private int _csPort;
      private String _clientName;
      private String _userName;
      private String _userPassword;

      private Button _openButton;
      private Button _closeButton;

      private Button _createButton;
      private Button _readButton;
      private Button _readButton1;
      private Button _updateButton;
      private Button _deleteButton;

      /// <summary>
      /// Initializes view, creates controls, assigns handlers
      /// </summary>
      private void InitializeComponent()
      {
        SuspendLayout();
        // Handles an event of this form is closed
        Closed += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null)) return;
          if (_personDbId!=null)
            _view.Model.DeletePerson(_personDbId.Value, true);
          _view.Model.Close();
        };

        #region controls

        FormBorderStyle = FormBorderStyle.SizableToolWindow;
        Text = "COM AB sample";
        Width = 500;
        Height = 500;
        MinimumSize = new Size(500, 500);
        MaximumSize = new Size(800, 800);
        StartPosition = FormStartPosition.CenterScreen;
        var mainPanel = new Panel{
          BorderStyle = BorderStyle.Fixed3D,AutoSize = true,Dock = DockStyle.Fill,Parent = this
        };

        #region control panel

        var controlPanel = new Panel{
          Parent = mainPanel,BorderStyle = BorderStyle.Fixed3D,Padding = new Padding(4),TabIndex = 1,Width = 488,Dock = DockStyle.Fill
        };
        var groupBox = new GroupBox{
          Parent = controlPanel,Dock = DockStyle.Fill,Text = "Messages log",Margin = new Padding(3)
        };
        _box = new RichTextBox{
          Dock = DockStyle.Fill,Lines = new string[] {},Parent = groupBox
        };
        _console = new ConsoleWrapper(this, _box);

        #region person

        var personBox = new GroupBox{
          Parent = controlPanel,Dock = DockStyle.Top,Text = "Person properties",Margin = new Padding(3),Height = 88
        };
        personBox.Controls.Add(new Label{
          Text = "Person first name: ",Left = 4,Top = 20,Height = 20,Width = 116
        });
        _personFirstNameBox = new TextBox
        {
          Left = 124,Top = 14,Height = 20,Width = 100,Parent = personBox,Text = "Person_FirstName"
        };
        _personFirstNameBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          _personFirstName = source.Text;
        };
        _personFirstName = _personFirstNameBox.Text;
        personBox.Controls.Add(new Label{
          Text = "Person last name: ",Left = 4,Top = 40,Height = 20,Width = 116
        });
        _personLastNameBox = new TextBox{
          Left = 124,Top = 34,Height = 20,Width = 100,Parent = personBox,Text = "Person_LastName"
        };
        _personLastNameBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          _personLastName = source.Text;
        };
        _personLastName = _personLastNameBox.Text;
        personBox.Controls.Add(new Label{
          Text = "Person user name: ",Left = 4,Top = 60,Height = 20,Width = 116
        });
        _personUserNameBox = new TextBox{
          Left = 124,Top = 54,Height = 20,Width = 100,Parent = personBox,Text = "Person_UserName"
        };
        _personUserNameBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          _personUserName = source.Text;
        };
        _personUserName = _personUserNameBox.Text;

        _dbIdLabel = new Label{
          Text = "Person DBID: null",Left = 240,Top = 14,Height = 22,Parent = personBox,BorderStyle = BorderStyle.FixedSingle,
          TextAlign = ContentAlignment.MiddleCenter
        };

        #endregion person

        #region CS properties

        var clientBox = new GroupBox{
          Parent = controlPanel,Dock = DockStyle.Top,Text = "Connection properties",Margin = new Padding(3),Height = 132
        };
        var tBox = new TextBox{
          Left = 185,Top = 14,Height = 22,Width = 100,Parent = clientBox,Text = PsdkCustomization.CustomOption("Samples.CS.Host","localhost")
        };
        tBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          _csHostName = source.Text;
        };
        _csHostName = tBox.Text;
        clientBox.Controls.Add(new Label{
          Text = "Configuration server host name.....",Left = 4,Top = 20,Height = 22,Width = 180,
          BackColor = Color.Transparent
        });

        tBox = new TextBox{
          Left = 185,Top = 36,Height = 22,Width = 100,Parent = clientBox,
          Text = PsdkCustomization.CustomOption("Samples.CS.Port", 2020).ToString(CultureInfo.InvariantCulture)
        };
        tBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          int val;
          if (Int32.TryParse(source.Text, out val))
            _csPort = val;
        };
        clientBox.Controls.Add(new Label{
          Text = "Configuration server port................",Left = 4,Top = 42,Height = 22,Width = 180,
          BackColor = Color.Transparent
        });
        _csPort = Int32.Parse(tBox.Text);
        tBox = new TextBox{
          Left = 185,Top = 58,Height = 22,Width = 100,Parent = clientBox,Text = PsdkCustomization.CustomOption("Samples.CS.ClientName","default")
        };
        tBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          _clientName = source.Text;
        };
        clientBox.Controls.Add(new Label{
          Text = "Configuration server client name...",Left = 4,Top = 64,Height = 22,Width = 180,
          BackColor = Color.Transparent
        });
        _clientName = tBox.Text;

        tBox = new TextBox{
          Left = 185,Top = 80,Height = 22,Width = 100,Parent = clientBox,
          Text = PsdkCustomization.CustomOption("Samples.CS.UserName","default")
        };
        tBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          _userName = source.Text;
        };
        clientBox.Controls.Add(new Label{
          Text = "Configuration server user name.....",Left = 4,Top = 86,Height = 22,Width = 180,
          BackColor = Color.Transparent
        });
        _userName = tBox.Text;

        tBox = new TextBox{
          Left = 185,Top = 102,Height = 22,Width = 100,Parent = clientBox,Text = PsdkCustomization.CustomOption("Samples.CS.UserPassword",""),PasswordChar = '*'
        };
        tBox.TextChanged += (sender, args) =>
        {
          var source = (sender as TextBox);
          if (source == null) return;
          _userPassword = source.Text;
        };
        clientBox.Controls.Add(new Label{
          Text = "CS user password..........................",Left = 4,Top = 108,Height = 22,Width = 180,Parent = clientBox,
          BackColor = Color.Transparent
        });
        _userPassword = tBox.Text;

        #endregion CS properties

        #endregion control panel

        #region buttons

        var buttonsPanel = new Panel{
          Dock = DockStyle.Right,Width = 110,Parent = mainPanel,BorderStyle = BorderStyle.Fixed3D,TabIndex = 0
        };

        #endregion buttons

        _openButton = new Button
        {
          Left = 8,Top = 8,Height = 24,Width = 94,TextAlign = ContentAlignment.MiddleCenter,
          Text = "Open CS",Enabled = true,Parent = buttonsPanel
        };
        _openButton.Click += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null)) return;
          _openButton.Enabled = false;
          _view.Model.Initialization(_csHostName, _csPort, _clientName, _userName, _userPassword);
          _view.Model.Open();
        };
        _closeButton = new Button
        {
          Left = 8,Top = 32,Height = 24,Width = 94,TextAlign = ContentAlignment.MiddleCenter,
          Text = "Close CS",Enabled = false,Parent = buttonsPanel
        };
        _closeButton.Click += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null)) return;
          _closeButton.Enabled = false;
          if (_personDbId!=null)
            _view.Model.DeletePerson(_personDbId.Value, true);
          _personDbId = null;
          ShowDbId();
          _view.Model.Close();
        };

        _createButton = new Button
        {
          Left = 8,Top = 80,Height = 24,Width = 94,TextAlign = ContentAlignment.MiddleCenter,
          Text = "Create person",Enabled = false,Parent = buttonsPanel
        };
        _createButton.Click += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null)) return;
          _createButton.Enabled = false;
          var color = Console.ForegroundColor;
          Console.ForegroundColor = ConsoleColor.Yellow;
          Console.WriteLine("Try to create person with FirstName='{0}' & LastName='{1}' ",
            _personFirstName, _personLastName);
          Console.ForegroundColor = color;
          _view.Model.CreatePerson(_personFirstName, _personLastName, _personUserName);
        };
        _readButton = new Button
        {
          Left = 8,Top = 105,Height = 24,Width = 94,TextAlign = ContentAlignment.MiddleCenter,
          Text = "Read by DBID",Enabled = false,Parent = buttonsPanel
        };
        _readButton.Click += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null)) return;
          ConsoleColor color;
          if (_personDbId == null)
          {
            color = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Can't read person by dbId=null");
            Console.ForegroundColor = color;
            return;
          }
          color = Console.ForegroundColor;
          Console.ForegroundColor=ConsoleColor.Yellow;
          Console.WriteLine("Try to read person by dbId={0} ", _personDbId.Value);
          Console.ForegroundColor = color;
          _view.Model.ReadPerson(_personDbId.Value);
        };
        _readButton1 = new Button
        {
          Left = 8,Top = 130,Height = 24,Width = 94,TextAlign = ContentAlignment.MiddleCenter,
          Text = "Read by name",Enabled = false,Parent = buttonsPanel
        };
        _readButton1.Click += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null)) return;
          var color = Console.ForegroundColor;
          Console.ForegroundColor = ConsoleColor.Yellow;
          Console.WriteLine("Try to read person by FirstName='{0}' ", _personFirstName);
          Console.ForegroundColor = color;
          _view.Model.ReadPerson(_personFirstName);
        };
        _updateButton = new Button
        {
          Left = 8,Top = 155,Height = 24,Width = 94,TextAlign = ContentAlignment.MiddleCenter,
          Text = "Update person",Enabled = false,Parent = buttonsPanel
        };
        _updateButton.Click += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null) || (_personDbId == null)) return;
          _updateButton.Enabled = false;
          _deleteButton.Enabled = false;
          var color = Console.ForegroundColor;
          Console.ForegroundColor = ConsoleColor.Yellow;
          Console.WriteLine("Try to update person by dbId={0} with FirstName='{1}' & LastName='{2}' ", _personDbId.Value,
            _personFirstName, _personLastName);
          Console.ForegroundColor = color;
          _view.Model.UpdatePerson(_personDbId.Value, _personFirstName, _personLastName);
        };


        _deleteButton = new Button
        {
          Left = 8,Top = 180,Height = 24,Width = 94,TextAlign = ContentAlignment.MiddleCenter,
          Text = "Delete person",Enabled = false,Parent = buttonsPanel
        };
        _deleteButton.Click += (sender, args) =>
        {
          if ((_view == null) || (_view.Model == null) || (_personDbId==null)) return;
          _deleteButton.Enabled = false;
          var color = Console.ForegroundColor;
          Console.ForegroundColor = ConsoleColor.Yellow;
          Console.WriteLine("Try to delete person by dbId={0} ", _personDbId.Value);
          Console.ForegroundColor = color;
          _view.Model.DeletePerson(_personDbId.Value);
        };

        #endregion controls

        ResumeLayout(false);
      }
      /// <summary>
      /// Shows unique database identifier of created person
      /// </summary>
      private void ShowDbId()
      {
        if (_personDbId == null)
          _dbIdLabel.Text = "Person DBID: null";
        else
          _dbIdLabel.Text = "Person DBID: "+_personDbId.Value;
      }

      #endregion form
      /// <summary>
      /// Handles incoming viev-model messages.
      /// </summary>
      /// <param name="messageCode">code of message</param>
      protected override void ProcessMessage(int messageCode)
      {
        #region View-Model messages
        if (messageCode == WmConsts.WmRefreshView)
        {
          _console.Flush();
          return;
        }
        if (messageCode == WmConsts.WmRefreshModel)
        {
          var notification = GetNotification();
          if (notification == null) return;
          switch (notification.Code)
          {
            case ComModelEventCodes.ChannelOpened:
            {
              _openButton.Enabled = false;
              _closeButton.Enabled = true;
              _createButton.Enabled = true;
              _readButton.Enabled = true;
              _readButton1.Enabled = true;
              _updateButton.Enabled = false;
              _deleteButton.Enabled = false;
              Console.WriteLine("Connection to CS is opened.");
              return;
            }
            case ComModelEventCodes.ChannelClosed:
            {
              _openButton.Enabled = true;
              _closeButton.Enabled = false;
              _createButton.Enabled = false;
              _readButton.Enabled = false;
              _readButton1.Enabled = false;
              _updateButton.Enabled = false;
              _deleteButton.Enabled = false;
              _personDbId = null;
              ShowDbId();
              Console.WriteLine("Connection to CS is closed.");
              var args = notification.Data as ClosedEventArgs;
              if ((args != null) && (args.Cause!=null))
                Console.WriteLine(notification.Data);
              return;
            }
            case ComModelEventCodes.PersonCreated:
            {
              var person = notification.Data as CfgPerson;
              if (person != null)
              {
                Console.WriteLine("Created person: " + person);
                _personDbId = person.DBID;
                ShowDbId();
                _deleteButton.Enabled = true;
                _updateButton.Enabled = true;
                _createButton.Enabled = false;
              }
              else
              {
                _createButton.Enabled = true;
              }
              return;
            }
            case ComModelEventCodes.PersonReaded:
            {
              var person = notification.Data as CfgPerson;
              if (person != null)
              {
                _personFirstNameBox.Text = person.FirstName;
                _personLastNameBox.Text = person.LastName;
                _personUserNameBox.Text = person.UserName;
                Console.WriteLine("Read person: " + person);
              }
              else
              {
                Console.WriteLine("Person not found.... ");
              }
              return;
            }
            case ComModelEventCodes.PersonUpdated:
            {
              var person = notification.Data as CfgPerson;
              if (person != null)
              {
                Console.WriteLine("Updated person: " + person);
              }
              else
              {
                Console.WriteLine("Person not found.... ");
              }
              _updateButton.Enabled = true;
              _deleteButton.Enabled = true;
              return;
            }
            case ComModelEventCodes.PersonDeleted:
            {
              var person = notification.Data as CfgPerson;
              if (person != null)
              {
                Console.WriteLine("Deleted person: " + person);
                if (_personDbId != null)
                {
                  _personDbId = null;
                  ShowDbId();
                  _deleteButton.Enabled = false;
                  _updateButton.Enabled = false;
                  _createButton.Enabled = true;
                }
              }
              else
              {
                Console.WriteLine("Person not found.... ");
                _deleteButton.Enabled = true;
              }
              return;
            }
            case ComModelEventCodes.InternalError:
            {
              switch (notification.SubCode)
              {
                case ComModelEventCodes.PersonCreated:
                {
                  Console.WriteLine("Error create person: "+notification.Data);
                  break;
                }
                case ComModelEventCodes.PersonUpdated:
                {
                  Console.WriteLine("Error update person: " + notification.Data);
                  break;
                }
                case ComModelEventCodes.PersonReaded:
                {
                  Console.WriteLine("Error read person: " + notification.Data);
                  break;
                }
                case ComModelEventCodes.PersonDeleted:
                {
                  Console.WriteLine("Error delete person: " + notification.Data);
                  break;
                }
                default:
                {
                  if (notification.Data != null)
                  {
                    Console.WriteLine("Internal error event received: "+notification.Data);
                  }
                  else
                  {
                    Console.WriteLine("Unknown error...");
                  }
                  break;
                }
              }
              return;
            }
            default:
              return;
          }
        }
        #endregion View-Model messages
      }
    }
  }
}

// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using Genesyslab.Platform.Samples.Common;

namespace Genesyslab.Platform.Samples.COMSample
{
  /// <summary>
  /// COM view model implementation. Represents a bridge between model and view.
  /// Allows to change an implementations of a model and a view independently.
  /// </summary>
  public class ComViewModel : ViewModelBase, IComViewModel
  {
    private new IComModel Model
    {
      get { return base.Model as IComModel; }
    }
    private new IComView View
    {
      get { return base.View as IComView; }
    }
    /// <summary>
    /// Initializes connection's parameters
    /// </summary>
    /// <param name="host">Host name</param>
    /// <param name="port">Port number</param>
    /// <param name="clientName">Client's name</param>
    /// <param name="userName">User's name</param>
    /// <param name="password">User password. Further API may be some different in case of using sensitive data.</param>
    public void Initialization(string host, int port, string clientName, string userName, string password)
    {
      if (Model!=null)
        Model.Initialization(host, port, clientName,userName,password);
    }
    /// <summary>
    /// Opens client's connection to server
    /// </summary>
    public void Open()
    {
      if (Model != null) Model.Open();
    }
    /// <summary>
    /// Closes client's connection to server
    /// </summary>
    public void Close()
    {
      if (Model!=null) Model.Close();
    }
    /// <summary>
    /// Creates new person. If person with the same name already exists it will be deleted.
    /// </summary>
    /// <param name="firstName">First name of person</param>
    /// <param name="lastName">Last name of person</param>
    /// <param name="userName">Person's user name.</param>
    public void CreatePerson(string firstName, string lastName, string userName)
    {
      if (Model != null) Model.CreatePerson(firstName, lastName, userName);
    }
    /// <summary>
    /// Reads person by its ID
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    public void ReadPerson(int dbId)
    {
      if (Model!=null) Model.ReadPerson(dbId);
    }
    /// <summary>
    /// Reads person by its First Name
    /// </summary>
    /// <param name="name">Person's First Name value</param>
    public void ReadPerson(string name)
    {
      if (Model != null) Model.ReadPerson(name);
    }
    /// <summary>
    /// Updates person
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    /// <param name="firstName">New First name</param>
    /// <param name="lastName">New last name</param>
    public void UpdatePerson(int dbId, string firstName, string lastName)
    {
      if (Model!=null) Model.UpdatePerson(dbId,firstName,lastName);
    }
    /// <summary>
    /// Deletes person by id
    /// </summary>
    /// <param name="dbId">unique database object identifier</param>
    public void DeletePerson(int dbId)
    {
      DeletePerson(dbId, false);
    }
    /// <summary>
    /// Deletes person
    /// </summary>
    /// <param name="dbId">Unique database identifier</param>
    /// <param name="sync">Wait for delete if true, otherwise run asynchronously</param>
    public void DeletePerson(int dbId, bool sync)
    {
      if (Model!=null) Model.DeletePerson(dbId);
    }
    /// <summary>
    /// Notifies ViewModel that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    public void Notify(int code, int subCode, object data)
    {
      Notify(code,subCode,data,null);
    }
    /// <summary>
    /// Notifies ViewModel that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    /// <param name="descr">Event description</param>
    public void Notify(int code, int subCode, object data, string descr)
    {
      if (View != null) View.Notify(code, subCode, data, descr);
    }
    /// <summary>
    /// Opens presentation window in dialog mode.
    /// </summary>
    public void Run()
    {
      if (View!=null) View.Run();
    }
  }
}

// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.


using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Genesyslab.Configuration;
using Genesyslab.Platform.ClusterProtocol;
using Genesyslab.Platform.ClusterProtocol.LoadBalancer;
using Genesyslab.Platform.ClusterProtocol.Protocols;
using Genesyslab.Platform.Commons.Connection;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Protocols.Internal.Custom;
using Genesyslab.Platform.Contacts.Protocols.ContactServer.Requests;

namespace Genesyslab.Platform.Samples.ClusterProtocol
{
  ///<summary>
  /// This sample shows example how to use cluster protocol application block. <br/>
  /// <br/>
  /// This samples shows:<br/>
  ///   - How to create and configure a cluster protocol.<br/>
  ///   - How to write and set cluster protocol events handlers.<br/>
  ///   - How to open and close a cluster protocol.<br/>
  ///   - How to send messages to a cluster protocol.<br/>
  ///   - How to receive messages from a cluster protocol.<br/>
  ///   - How to make synchronous and asynchronous requests to a cluster protocol.<br/>
  ///</summary>
  public static class ClusterProtocolSample
  {
    public static void Main(params string[] args)
    {
      var ucsNProtocol = CreateClusterProtocol();
      if (!ConfigureClusterProtocol(ucsNProtocol))
      {
        Console.WriteLine("Can't read configuration");
        return;
      }
      ucsNProtocol.InternalChannelOpened += (sender, eventArgs) =>
      {
        var protocol = sender as IProtocol;
        if (protocol==null) return;
        Console.WriteLine("Connection to cluster node is opened. ProtocolId = {0}. Endpoint: {1}", protocol.ProtocolId,
          protocol.Endpoint);
      };
      ucsNProtocol.InternalChannelClosed += (sender, eventArgs) =>
      {
        var protocol = sender as IProtocol;
        if (protocol == null) return;
        var closeArgs = eventArgs as ClosedEventArgs;
        if (closeArgs == null) return;
        Console.WriteLine("Connection to cluster node is closed. ProtocolId = {0}. Endpoint: {1}", protocol.ProtocolId,
          closeArgs.Endpoint);
      };

      Example_FewSendsAndReceivingResponsesUsingMessageHandler(ucsNProtocol);
      Example_FewAsyncRequestsUsingAsyncResultWithCallback(ucsNProtocol);
      Example_FewAsyncRequestsUsingAsyncResultWithoutCallback(ucsNProtocol);
      Example_FewSyncRequests(ucsNProtocol);

      Console.WriteLine("Press any key to exit...");
      Console.ReadKey(true);
    }
    #region scenarios

    private static void Example_FewSendsAndReceivingResponsesUsingMessageHandler(UcsClusterProtocol ucsNProtocol)
    // Sends messages synchronously and receive responses using message handler;
    {
      Console.WriteLine("------------------------------------------------");
      Console.WriteLine("\nRequests asynchronously using message handler\n");
      Console.WriteLine("------------------------------------------------");
      const int countMessages = 8; 
      Console.WriteLine("Closing cluster protocol...");
      ucsNProtocol.Close();
      Console.WriteLine("Closed cluster protocol.");
      var requests = new Hashtable();
      var countDownLatch = new CountDownLatch(countMessages);
      EventHandler handler = (sender, args) =>
      {
        var arg = args as MessageEventArgs;
        if (arg==null) return;
        var response = arg.Message as AbstractMessage;
        if (response==null) return;
        var requestId = response.ReferenceId;
        if (requestId==null) return;
        var request = requests[requestId.Value] as AbstractMessage;
        ShowRequestResponseInfo(request, response);
        countDownLatch.CountDown();
      };
      ucsNProtocol.Received += handler;
      Console.WriteLine("Opening cluster protocol...");
      ucsNProtocol.Open();
      Console.WriteLine("Opened cluster protocol.");
      Console.WriteLine("Sends messages synchronously and receive responses using message handler");
      var refBuilder = ucsNProtocol.ReferenceBuilder;
      var action = new Action(() =>
      {
        var request = RequestGetVersion.Create();
        refBuilder.UpdateReference(request);
        var refId = request.ReferenceId;
        if (refId==null) return;
        try
        {
          requests[refId] = request;
          ucsNProtocol.Send(request);
        }
        catch (Exception e)
        {
          Console.WriteLine("Exception during send message: {0}",e);
          requests.Remove(refId);
          countDownLatch.CountDown();
        }
      });
      for (int i = 0; i < countMessages; i++) action();
      countDownLatch.Wait(10000);
      Console.WriteLine("Closing cluster protocol...");
      ucsNProtocol.Close();
      ucsNProtocol.Received -= handler;
      Console.WriteLine("Closed cluster protocol.");
    }
    private static void Example_FewAsyncRequestsUsingAsyncResultWithCallback(UcsClusterProtocol ucsNProtocol)
    // Async request with callback example
    {
      Console.WriteLine("---------------------------------------------------");
      Console.WriteLine("\nRequests asynchronously using async result\n");
      Console.WriteLine("---------------------------------------------------");
      Console.WriteLine("Opening cluster protocol...");
      ucsNProtocol.Open();
      Console.WriteLine("Opened cluster protocol.");

      const int countMessages = 8;
      var requests = new AbstractMessage[countMessages];
      var responses = new IMessage[countMessages];
      var asyncResults = new IAsyncResult[countMessages];
      var latch = new CountDownLatch(countMessages);
      for (int i = 0; i < countMessages; i++)
      {
        int index = i; // to prevent closure error of earlier C#
        requests[index] = RequestGetVersion.Create();
        asyncResults[index] = ucsNProtocol.BeginRequest(requests[index], ar =>
        {
          try
          {
            responses[index] = ucsNProtocol.EndRequest(ar);
          }
          catch (Exception e)
          {
            Console.WriteLine("Exception during request: {0}", e);
          }
          finally
          {
            latch.CountDown();
          }
        }, ucsNProtocol);
      }
      latch.Wait(10000);
      for (int i = 0; i < countMessages; i++)
      {
        ShowRequestResponseInfo(requests[i], responses[i]);
      }
      Console.WriteLine("Closing cluster protocol...");
      ucsNProtocol.Close();
      Console.WriteLine("Closed cluster protocol.");
    }
    private static void Example_FewAsyncRequestsUsingAsyncResultWithoutCallback(UcsClusterProtocol ucsNProtocol)
    // Async request without callback example
    {
      Console.WriteLine("--------------------------------------------------------------");
      Console.WriteLine("\nRequests asynchronously using async result without callback\n");
      Console.WriteLine("--------------------------------------------------------------");
      Console.WriteLine("Opening cluster protocol...");
      ucsNProtocol.Open();
      Console.WriteLine("Opened cluster protocol.");

      const int countMessages = 8;
      var requests = new AbstractMessage[countMessages];
      var asyncResults = new IAsyncResult[countMessages];
      var latch = new CountDownLatch(countMessages);
      for (int i = 0; i < countMessages; i++)
      {
        int index = i; // to prevent closure error of earlier C#
        requests[index] = RequestGetVersion.Create();
        asyncResults[index] = ucsNProtocol.BeginRequest(requests[index], null, null);
      }
      for (int i = 0; i < countMessages; i++)
      {
        ShowRequestResponseInfo(requests[i], ucsNProtocol.EndRequest(asyncResults[i]));
      }
      Console.WriteLine("Closing cluster protocol...");
      ucsNProtocol.Close();
      Console.WriteLine("Closed cluster protocol.");
    }
    private static void Example_FewSyncRequests(UcsClusterProtocol ucsNProtocol)
    // Synchronous request example
    {
      Console.WriteLine("-----------------------");
      Console.WriteLine("\nSynchronous requests\n");
      Console.WriteLine("-----------------------");
      Console.WriteLine("Opening cluster protocol...");
      ucsNProtocol.Open();
      Console.WriteLine("Opened cluster protocol.");

      const int countMessages = 4;
      for (int i = 0; i < countMessages; i++)
      {
        var request = RequestGetVersion.Create();
        var response = ucsNProtocol.Request(request);
        ShowRequestResponseInfo(request, response);
      }
      Console.WriteLine("Closing cluster protocol...");
      ucsNProtocol.Close();
      Console.WriteLine("Closed cluster protocol.");
    }

    #endregion scenarios
    #region utilites
    private class CountDownLatch
    {
      private int _counter;
      private readonly ManualResetEvent _event = new ManualResetEvent(false);

      public CountDownLatch(int count)
      {
        _counter = count;
      }

      public void CountDown()
      {
        if (Interlocked.Decrement(ref _counter) <= 0) _event.Set();
      }

      public void Wait(int milliSeconds)
      {
        _event.WaitOne(milliSeconds);
      }
    }
    private static UcsClusterProtocol CreateClusterProtocol()
    {
      var policy = new DefaultClusterProtocolPolicy();
      var loadBalancer = new DefaultClusterLoadBalancer();

      return new UcsClusterProtocolBuilder()
        .WithLoadBalancer(loadBalancer)
        .WithClusterProtocolPolicy(policy)
        .Build();
    }

    private static bool ConfigureClusterProtocol(UcsClusterProtocol ucsNProtocol)
    {
      var clientName = PsdkCustomization.CustomOption("ucs.clientName");
      if (clientName == null) return false;
      ucsNProtocol.ClientName = clientName;
      var appType = PsdkCustomization.CustomOption("ucs.clientApplicationType");
      if (appType == null) return false;
      ucsNProtocol.ClientApplicationType = appType;
      var nodes = PsdkCustomization.CustomOption("ucs.cluster.nodes");
      if (nodes == null) return false;
      var endpointsArray = ParseEndpoints(nodes);
      if (endpointsArray==null) return false;
      ucsNProtocol.SetNodesEndpoints(endpointsArray);
      return true;
    }

    private static IEnumerable<Endpoint> ParseEndpoints(String addresses)
    {
      if (addresses == null || addresses.Trim().Length == 0)
      {
        Console.WriteLine("UCS cluster nodes isn't specified");
        return null;
      }
      String[] uris = addresses.Split(',');
      var endpoints = new List<Endpoint>();
      foreach (String uri in uris)
      {
        Uri u;
        try
        {
          String str = (uri.StartsWith("tcp://") ? "" : "tcp://") + uri;
          u = new Uri(str);
        }
        catch (Exception e)
        {
          Console.WriteLine("Invalid cluster node uri: {0}. EXception: {1}", uri, e);
          return null;
        }
        var endpoint = new Endpoint(u);
        endpoints.Add(endpoint);
      }
      return endpoints;
    }

    private static void ShowRequestResponseInfo(AbstractMessage request, IMessage response)
    {
      Console.WriteLine(""
                        + "" + request.Name
                        + " -> " + (response == null ? "none" : response.Name)
                        + "   referenceId: " + request.ReferenceId
                        + "   protocolId: " + request.ProtocolId
                        + "   " + request.Endpoint
        );
    }
    #endregion utilites
  }
}

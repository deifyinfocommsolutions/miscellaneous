// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Genesyslab.Platform.Samples.Common
{
  #region Common API
  /// <summary>
  /// defines user events codes
  /// </summary>
  public static class WmConsts
  {
    private const int WmUser = 0x0400;
    public const int WmRefreshModel = WmUser + 1;
    public const int WmRefreshView = WmUser + 2;
  }
  #endregion
  /// <summary>
  /// Describes basic view functions
  /// </summary>
  public interface IViewApi
  {
    /// <summary>
    /// Notifies View that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    void Notify(int code, int subCode, object data);
    /// <summary>
    /// Notifies View that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    /// <param name="descr">Event description</param>
    void Notify(int code, int subCode, object data, string descr);
    /// <summary>
    /// Run application using this presentation window as main form.
    /// </summary>
    void Run();
  }

  public abstract class SampleViewBase : IViewApi, IView
  {
    private readonly ApplicationContext _appContext;
    private SampleForm _form;
    private IModel _model;
    protected IModel Model { get { return _model; } }

    protected SampleViewBase(ApplicationContext appContext)
    {
      _appContext = appContext;
    }
    /// <summary>
    /// Initializes a view to to enable communication with a model.
    /// </summary>
    /// <param name="model">IModel instance</param>
    public void Initialization(IModel model)
    {
      _model = model;
    }
    /// <summary>
    /// Notifies form that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    public void Notify(int code, int subCode, object data)
    {
      Notify(code, subCode, data, null);
    }
    /// <summary>
    /// Notifies form that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    /// <param name="addData">Event description</param>
    public void Notify(int code, int subCode, object data, string addData)
    {
      if (_form != null)
        _form.Notify(code, subCode, data, addData);
    }
    /// <summary>
    /// Opens presentation window in dialog mode.
    /// </summary>
    public void Run()
    {
      using (_form = CreateForm())
      {
        _appContext.MainForm = _form;
        Application.Run(_appContext);
        //_form.ShowDialog();
      }
      _form = null;
    }
    protected abstract SampleForm CreateForm();

    #region SampleForm
    /// <summary>
    /// Base class for PSDK Samples GUI form
    /// </summary>
    protected abstract class SampleForm : Form
    {
      private readonly Queue<NotifyObject> _notifyObjects = new Queue<NotifyObject>();
      protected SynchronizationContext SyncContext;

      /// <summary>
      /// Data transfer object to Windows Message
      /// </summary>
      protected class NotifyObject
      {
        public int Code;
        public int SubCode;
        public object Data;
        public String Description;
      }

      /// <summary>
      /// Form constructor
      /// </summary>
      protected SampleForm()
      {
        SyncContext = SynchronizationContext.Current;
        Shown += (sender, args) =>
        {
          var form = sender as Form;
          if (form != null)
          {
            form.Activate();
          }
        };
      }

      protected override void OnClosed(EventArgs e)
      {
        SyncContext = null;
        base.OnClosed(e);
      }

      protected void PostMessage(int messageCode)
      {
        if (SyncContext != null)
          SyncContext.Post(o => ProcessMessage(messageCode), this);
      }

      protected abstract void ProcessMessage(int messageCode);

      /// <summary>
      /// Notifies form that it has been changed
      /// </summary>
      /// <param name="code">Event code</param>
      /// <param name="subcode">Additional event code</param>
      /// <param name="data">Custom data</param>
      /// <param name="descr">Event description</param>
      internal void Notify(int code, int subcode, object data, string descr)
      {
        lock (_notifyObjects)
        {
          _notifyObjects.Enqueue(new NotifyObject { Code = code, Data = data, SubCode = subcode, Description = descr });
        }
        PostMessage(WmConsts.WmRefreshModel);
      }
      /// <summary>
      /// Notify Form that it should refresh view (console)
      /// </summary>
      internal void Notify()
      {
        PostMessage(WmConsts.WmRefreshView);
      }
      /// <summary>
      /// Gets notification from queue
      /// </summary>
      /// <returns>Notification object or null is queue is empty</returns>
      protected NotifyObject GetNotification()
      {
        lock (_notifyObjects)
        {
          if (_notifyObjects.Count == 0) return null;
          return _notifyObjects.Dequeue();
        }
      }
    }
    #endregion SampleForm
    #region Console wrapper
    /// <summary>
    /// Console wrapper to be used instead of default output console
    /// </summary>
    protected class ConsoleWrapper : TextWriter
    {
      private readonly TextWriter _out;
      private readonly SampleForm _outer;
      private readonly StringBuilder _sb = new StringBuilder();
      private readonly RichTextBox _box;
      private readonly bool _redirectOldConsole;
      /// <summary>
      /// Constructor. Replaces standard output. 
      /// </summary>
      /// <param name="outer">Form to be notified about any changes</param>
      /// <param name="box">RichTextBox to draw output data</param>
      public ConsoleWrapper(SampleForm outer, RichTextBox box):this(outer, box, false)
      {}

      /// <summary>
      /// Constructor. Replaces standard output. 
      /// </summary>
      /// <param name="outer">Form to be notified about any changes</param>
      /// <param name="box">RichTextBox to draw output data</param>
      /// <param name="redirectOldConsole">duplicate output to existed console</param>
      public ConsoleWrapper(SampleForm outer, RichTextBox box, bool redirectOldConsole)
      {
        _out = Console.Out;
        _outer = outer;
        _box = box;
        _redirectOldConsole = redirectOldConsole;
        Console.SetOut(this);
      }

      public override Encoding Encoding
      {
        get { return Encoding.Default; }
      }
      /// <summary>
      /// Overrided method Write(char) is base of outout to console.
      /// </summary>
      /// <param name="value">char to be written</param>
      public override void Write(char value)
      {
        if (_redirectOldConsole) _out.Write(value);
        lock (_sb) { _sb.Append(value); }
        _outer.Notify();
      }
      /// <summary>
      /// Flush data
      /// </summary>
      public override void Flush()
      {
        base.Flush();
        if (_sb.Length == 0) return;
        String text;
        lock (_sb)
        {
          text = _sb.ToString();
          _sb.Remove(0, _sb.Length);
        }
        if (_box != null)
        {
          _box.Text += text;
          _box.SelectionStart = _box.Text.Length;
          _box.ScrollToCaret();
        }
      }
    }
    #endregion Console wrapper

  }
}

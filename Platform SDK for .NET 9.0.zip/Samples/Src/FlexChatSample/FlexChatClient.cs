// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.


using System;
using System.Collections.Generic;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.WebMedia.Protocols;
using Genesyslab.Platform.WebMedia.Protocols.FlexChat;
using Genesyslab.Platform.WebMedia.Protocols.FlexChat.Events;
using Genesyslab.Platform.WebMedia.Protocols.FlexChat.Requests;

namespace Genesyslab.Platform.Samples.FlexChatSample
{
  static class FlexChatClient
  {
    private static FlexChatProtocol _flexChat;
    private const String Queue = "MM8.0:MultimediaSDK_Process";
    private static readonly Dictionary<String, ClientContext> ClientMap = new Dictionary<String, ClientContext>();

    private static void Main(string[] args)
    {
      if (args.Length < 2)
      {
        Console.WriteLine("Usage: FlexChatClient.exe hostName portNumber");
        return;
      }
      try
      {
        _flexChat = new FlexChatProtocol(new Endpoint(args[0], Int32.Parse(args[1])));

        const string nickNameOne = "AgentOne";
        const string nickNameTwo = "AgentTwo";

        //AutoRegister = true can be useful only for one client. 
        //In this case channel will automatically send RequestLogin and store userId/secureKey obtained from response in the protocol object.
        //However, in most cases one connection is used for many chat clients.
        //In this case, recommended way is:
        // - AutoRegister = false;
        // - send RequestLogin for each client explicitly
        // - store userId/secureKey and specify them explicitly in further chat requests.
        _flexChat.AutoRegister = false;
        _flexChat.Open();
        Console.WriteLine("Opened");

        //Login to chat, store userId/secureKey obtained in response
        LoginChat(nickNameOne);
        LoginChat(nickNameTwo);

        //Following method explicitly specify userId, secureKey in chat requests				
        //join
        JoinChat(nickNameOne);
        JoinChat(nickNameTwo);

        //write something to chat
        WriteIntoChat(nickNameOne, "Hello from " + nickNameOne);
        WriteIntoChat(nickNameTwo, "Hello from " + nickNameTwo);

        //logout
        LogoutChat(nickNameOne);
        LogoutChat(nickNameTwo);
      }
      catch (Exception e)
      {
        Console.WriteLine("Exception: {0}",e);
      }
      finally
      {
        _flexChat.Close();
        Console.WriteLine("Closed!");
      }
    }

	private static void LoginChat(string nickName) 
  {
    var status = _flexChat.Request(RequestLogin.Create(nickName, 0, null)) as EventStatus;	
		if(status!=null) {
      if (status.RequestResult.Equals(RequestResult.Success))
      {
				var context = new  ClientContext(nickName, status.UserId, status.SecureKey);								
				ClientMap.Add(nickName, context);
			}
		}
		else 		
			throw new Exception("Server didn't respond for login request.");	
		Console.WriteLine(nickName + " login: " + RequestResult.Success);
  }
	private static void LogoutChat(string nickName)
	{
	  ClientContext context;
    if (!ClientMap.TryGetValue(nickName, out context))
    {
      Console.WriteLine("Already logout.");
      return;
    }
	  RequestLogout logout = RequestLogout.Create(context.UserId, context.SecureKey,
	    context.Position.HasValue ? context.Position.Value : 0);
    var status = _flexChat.Request(logout) as EventStatus;
	  if(status!=null) {
      if (status.RequestResult.Equals(RequestResult.Success))
      {
				ClientMap.Remove(nickName);					
			}			
		}
		else 		
			throw new Exception("Server didn't respond for login request.");	
		
		Console.WriteLine(nickName + " logout: " + RequestResult.Success);
	}
	private static void JoinChat(string nickName){
		RequestResult? ret;
	  ClientContext context;
		if(!ClientMap.TryGetValue(nickName, out context)) {
			throw new Exception("User wasn't logged in!");
		}
		
		//Set userId and secure key explicitly
    var status = _flexChat.Request(RequestJoin.Create(context.UserId,
        context.SecureKey, null, Queue, null)) as EventStatus;
		if(status!=null) {								
			UpdateConext(nickName, status);												
			ret =  status.RequestResult;
		}
		else
			ret = RequestResult.Error;	
		
		Console.WriteLine(nickName + " join: " + ret);
	}

	private static void WriteIntoChat(string nickName, string message){
		RequestResult? ret;
	  ClientContext context;
		if(!ClientMap.TryGetValue(nickName,out context)) {
			throw new Exception("User wasn't logged in!");
		}
	  if (context.Position == null) ret = RequestResult.Error;
	  else
	  {
	    //Set userId and secure key explicitly		
	    RequestRefresh refresh = RequestRefresh.Create(context.UserId,
	      context.SecureKey, context.Position.Value, MessageText.Create(message));

	    var status = _flexChat.Request(refresh) as EventStatus;
      if (status!=null)
	    {
	      UpdateConext(nickName, status);
	      ret = status.RequestResult;
	    }
	  else
	    ret = RequestResult.Error;
	  }
	  Console.WriteLine(nickName + " write to chat: " + ret);
	}

  private static void UpdateConext(String nickname, EventStatus status)
  {
    ClientContext context;
    if (!ClientMap.TryGetValue(nickname, out context)) return;

    //store chat position and chat session
    FlexTranscript transcript = status.FlexTranscript;
    if (transcript != null)
    {
      String sId = transcript.SessionId;
      if (sId != null)
        context.Session = sId;
      context.Position = transcript.LastPosition;
    }

    //Optionally, update secure key. In current server implementation secureKey is persistent.
    context.SecureKey = status.SecureKey;
  }

	  //Store userId and secure key for logged in client
    private class ClientContext
    {
      private readonly String _nick;
      private readonly String _id;

      public ClientContext(String nickname, String userId, String secureKey)
      {
        _nick = nickname;
        _id = userId;
        SecureKey = secureKey;
      }

      public String UserId
      {
        get { return _id; }
      }

      public String SecureKey { get; set; }
      public int? Position { get; set; }
      public String Session { get; set; }

      public override String ToString()
      {
        return _nick;
      }
    }
  }
}

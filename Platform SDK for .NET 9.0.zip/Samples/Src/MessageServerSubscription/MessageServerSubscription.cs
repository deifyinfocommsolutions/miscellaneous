// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.


using System;
using System.Diagnostics;
using System.Threading;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Management.Protocols;
using Genesyslab.Platform.Management.Protocols.MessageServer;
using Genesyslab.Platform.Management.Protocols.MessageServer.Events;
using Genesyslab.Platform.Management.Protocols.MessageServer.Requests;
using Genesyslab.Platform.Management.Protocols.MessageServer.Requests.Subscription;

namespace Genesyslab.Platform.Samples.MessageServerSubscription
{
  static class MessageServerSubscription
  {
    private static String _host = String.Empty; // replace to valid server host
    private static int _port = -1; // replace to valid server port
    private static int _clientId; // replace to valid client ID
    private static int _clientType; // replace to valid client type
    private static string _clientHost; // replace to valid client host
    private static string _clientName; // replace to valid client name

    private static IMessage _lastIncomingMessage;
    private static readonly AutoResetEvent Event = new AutoResetEvent(false);

    /// <summary>
    /// Creates handler to process received messages on subscribed channel
    /// </summary>
    /// <param name="protocol">channel which has to be subscribed</param>
    private static void SetReceiveHandler(MessageServerProtocol protocol)
    {
      protocol.Received += (sender, args) =>
      {
        lock (typeof(Console))
        {
          var arg = args as MessageEventArgs;
          if (arg == null) return;
          _lastIncomingMessage = arg.Message;
          Event.Set();
          Console.ForegroundColor = ConsoleColor.Gray;
          var evSunscribtion = _lastIncomingMessage as EventSubscription;
          if (evSunscribtion != null)
          {
            Console.WriteLine("\n------------------ Subscription was created:");
            Console.WriteLine("    Subscription   = {0}", evSunscribtion.MessageType);
            Console.WriteLine("    Subscriber = {0}", evSunscribtion.SubscriberType);
            return;
          }
          var evLogMessage = _lastIncomingMessage as EventLogMessage;
          if (evLogMessage != null)
          {
            Console.WriteLine("\n------------------ Received notification on LogMessage:");
            Console.WriteLine("  Event      = {0}", evLogMessage);
          }
        }
      };
    }
    /// <summary>
    /// Creates protocol instance
    /// </summary>
    /// <param name="name">Endpoint's name</param>
    /// <returns></returns>
    private static MessageServerProtocol CreateAndOpenProtocol(string name)
    {
      var protocol = new MessageServerProtocol(new Endpoint(name, _host, _port))
      {ClientId = _clientId, ClientName = _clientName, ClientType = _clientType, ClientHost = _clientHost};

      protocol.Opened += (sender, args) =>
      {
        lock (typeof (Console))
        {
          Console.ForegroundColor = ConsoleColor.White;
          var channel = sender as AbstractChannel;
          if (channel != null)
            Console.WriteLine("Channel [{1}] state: {0}", channel.State, channel.Endpoint.ToString());
        }
      };
      protocol.Closed += (sender, args) =>
      {
        lock (typeof (Console))
        {
          Console.ForegroundColor = ConsoleColor.White;
          var channel = sender as AbstractChannel;
          if (channel != null)
            Console.WriteLine("Channel [{1}] state: {0}", channel.State, channel.Endpoint.ToString());
          Event.Set();
        }
      };
      protocol.Open();
      return protocol;
    }
    /// <summary>
    /// Closes protocol
    /// </summary>
    /// <param name="protocol">protocol which has to be closed</param>
    private static void CloseProtocol(MessageServerProtocol protocol)
    {
      protocol.Close();
      Event.WaitOne(3000);
    }
    /// <summary>
    /// Creates subscription on message server
    /// </summary>
    /// <param name="protocol">protocol which should be subscribed</param>
    private static void Subscribe(MessageServerProtocol protocol)
    {
      lock (typeof (Console))
      {
        // Create request to subscribe all events
        RequestSubscribeAll requestSubscribeAll = RequestSubscribeAll.Create();
        try
        {
          protocol.Send(requestSubscribeAll);
        }
        catch (ProtocolException e)
        {
          Console.ForegroundColor = ConsoleColor.Red;
          Console.WriteLine("[{2}] Exception: {0}:{1}", e.GetType(), e.Message, protocol.Endpoint);
        }
      }
      // waiting for received confirmation.
      Event.WaitOne(3000);
    }
    /// <summary>
    /// Unsubscribes protocol.
    /// </summary>
    /// <param name="protocol">protocol which has to be unsubscribed</param>
    private static void Unsubscribe(MessageServerProtocol protocol)
    {
      lock (typeof (Console))
      {
        RequestUnsubscribeAll requestUnsubscribeAll = RequestUnsubscribeAll.Create();
        try
        {
          protocol.Send(requestUnsubscribeAll);
          // do not wait for response
        }
        catch (ProtocolException e)
        {
          Console.ForegroundColor = ConsoleColor.Red;
          Console.WriteLine("[{2}] Exception: {0}:{1}", e.GetType(), e.Message, protocol.Endpoint);
        }
      }
    }
    /// <summary>
    /// Subscribes one protocol (and unsubscribe it at the end). 
    /// Sends log message into another one and waits for notification on subscribed protocol.
    /// Validates notification and prints validation result.
    /// </summary>
    /// <param name="subscriptionProtocol">protocol which has to be subscribed</param>
    /// <param name="initialProtocol">protocol which has to initiate log message</param>
    private static void TestSubscription(MessageServerProtocol subscriptionProtocol, MessageServerProtocol initialProtocol)
    {
      // subscribe protocol
      Subscribe(subscriptionProtocol);
      RequestLogMessage request = RequestLogMessage.Create();
      request.EntryCategory = LogCategory.Application;
      request.EntryId = 30302;
      request.EntryText = "alarm from test app";
      request.Level = LogLevel.Alarm;
      request.ClientHost = initialProtocol.ClientHost;
      request.Time = DateTime.Now.AddDays(-3);
      var attrs = new AttributeList
      {
        {"attr1", "val1"},
        {"attr2", "val2"},
      };
      request.Attributes = attrs;
      // send log message
      initialProtocol.Send(request);
      // wait for notification in another protocol through event handler
      Event.WaitOne(3000);
      var elm = _lastIncomingMessage as EventLogMessage;
      lock (typeof (Console))
      {
        Console.ForegroundColor = ConsoleColor.Yellow;
        if ((elm != null)
            && (elm.ClientId == initialProtocol.ClientId)
            && (elm.ClientHost == initialProtocol.ClientHost)
            && (elm.ClientName == initialProtocol.ClientName)
            && (elm.EntryCategory == request.EntryCategory)
            && (elm.EntryId == request.EntryId)
            && (elm.EntryText == request.EntryText)
            && (elm.Level == request.Level)
            && ((int)(elm.Time-request.Time).TotalMilliseconds==0)
            && (elm.Attributes.Equals(request.Attributes))
          )
          Console.WriteLine("Successful subscription");
        else
          Console.WriteLine("Unexpected event");
      }
      // unsubscribe protocol
      Unsubscribe(subscriptionProtocol);
    }
    /// <summary>
    /// prints message
    /// </summary>
    private static void WriteWrongParametersCountMessage()
    {
      Console.WriteLine("Arguments count mismatch. Usage: {0}.exe host:port clientName clientId clientType cientHost", Process.GetCurrentProcess().ProcessName);
      Console.WriteLine("Example: {0}.exe host:port TestClientName 12345 2 SomeClientHost", Process.GetCurrentProcess().ProcessName);
    }
    /// <summary>
    /// prints message
    /// </summary>
    private static void WriteWrongParametersMessage()
    {
      Console.WriteLine("Wrong arguments. Usage: {0}.exe host:port clientName clientId clientType cientHost", Process.GetCurrentProcess().ProcessName);
      Console.WriteLine("Example: {0}.exe host:port TestClientName 12345 2 SomeClientHost", Process.GetCurrentProcess().ProcessName);
    }
    /// <summary>
    /// Checks command line arguments.
    /// </summary>
    /// <returns>true if no errors, otherwise false</returns>
    private static bool CheckParameters()
    {
      var args = Environment.GetCommandLineArgs();
      if (args.Length != 6)
      {
        WriteWrongParametersCountMessage();
        return false;
      }
      if (!Int32.TryParse(args[3],out _clientId))
      {
        WriteWrongParametersMessage();
        return false;
      }
      if (!Int32.TryParse(args[4],out _clientType))
      {
        WriteWrongParametersMessage();
        return false;
      }
      _clientName = args[2];
      _clientHost = args[5];
      args = args[1].Split(':');
      if (args.Length != 2)
      {
        WriteWrongParametersMessage();
        return false;
      }
      _host = args[0];
      if (!Int32.TryParse(args[1],out _port))
      {
        WriteWrongParametersMessage();
        return false;
      }
      return true;
    }
    /// <summary>
    /// Entry point of application
    /// </summary>
    static void Main()
    {
      if (!CheckParameters()) return; // this line may be removed if parameters are initialized inside .cctor
      try
      {
        var subscriptionProtocol = CreateAndOpenProtocol("subscription");
        SetReceiveHandler(subscriptionProtocol);
        var initialProtocol = CreateAndOpenProtocol("initial");
        TestSubscription(subscriptionProtocol, initialProtocol);
        CloseProtocol(subscriptionProtocol);
        CloseProtocol(initialProtocol);
      }
      catch (Exception e)
      {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Unexpected exception:\n    {0}: {1}", e.GetType().Name, e.Message);
        while (e.InnerException != null)
        {
          e = e.InnerException;
          Console.WriteLine("--> {0}: {1}", e.GetType().Name, e.Message);
        }
      }
      Console.ForegroundColor = ConsoleColor.Gray;
    }
  }
}

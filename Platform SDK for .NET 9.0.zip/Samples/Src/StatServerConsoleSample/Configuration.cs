// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Configuration;
using Genesyslab.Platform.Reporting.Protocols.StatServer;

namespace Genesyslab.Platform.Samples.StatServerConsoleSample
{
  public class ConfigurationProfile : ConfigurationSection
  {
    [ConfigurationProperty("StatServer")]
    public ServerConfig ServerConfig
    {
      get { return ((ServerConfig)base["StatServer"]); }
    }
    [ConfigurationProperty("StatServerBackup")]
    public ServerConfig ServerBackupConfig
    {
      get { return ((ServerConfig)base["StatServerBackup"]); }
    }
    [ConfigurationProperty("StatisticObjects")]
    public StatisticObjectCollection StatisticObjects
    {
      get { return ((StatisticObjectCollection)(base["StatisticObjects"])); }
    }
  }
  public class ServerConfig : ConfigurationElement
  {
    [ConfigurationProperty("host", IsKey = true, IsRequired = true)]
    internal string Host
    {
      get{ return this["host"] as string; }
      set { this["host"] = value; }
    }
    [ConfigurationProperty("port", IsKey = true, IsRequired = true)]
    internal int Port
    {
      get { return (int) this["port"]; }
      set { this["port"] = value; }
    }
  }
  [ConfigurationCollection(typeof(StatisticObjectCfg), AddItemName = "StatisticObject")]
  public class StatisticObjectCollection : ConfigurationElementCollection
  {
    protected override ConfigurationElement CreateNewElement()
    {
      return new StatisticObjectCfg();
    }
    protected override object GetElementKey(ConfigurationElement element)
    {
      return ((StatisticObjectCfg)element).Tenant + "." + ((StatisticObjectCfg)element).ObjectId;
    }
    public StatisticObjectCfg this[int index]
    {
      get { return BaseGet(index) as StatisticObjectCfg; }
    }
  }
  public class StatisticObjectCfg : ConfigurationSection
  {
    [ConfigurationProperty("ObjectId", DefaultValue = "", IsRequired = true)]
    public string ObjectId
    {
      get { return this["ObjectId"] as String; }
      set { this["ObjectId"] = value; }
    }
    [ConfigurationProperty("Tenant", DefaultValue = "Statistics", IsRequired = true)]
    public string Tenant
    {
      get { return this["Tenant"] as String; }
      set { this["Tenant"] = value; }
    }
    [ConfigurationProperty("TenantPassword", DefaultValue = "", IsRequired = true)]
    public string TenantPassword
    {
      get { return this["TenantPassword"] as String; }
      set { this["TenantPassword"] = value; }
    }

    [ConfigurationProperty("ObjectType", DefaultValue = "Agent", IsRequired = true)]
    private string _objectType
    {
      get { return this["ObjectType"] as String; }
      set { this["ObjectType"] = value; }
    }
    public StatisticObjectType ObjectType
    {
      get
      {
        var value = _objectType;
        try
        {
          return (StatisticObjectType)Enum.Parse(typeof(StatisticObjectType), value);
        }
        catch (Exception e)
        {
          return StatisticObjectType.Agent;
        }
      }
      set { _objectType = value.ToString("F"); }
    }

    [ConfigurationProperty("Metric")]
    public MetricConfig MetricCfg
    {
      get { return this["Metric"] as MetricConfig; }
      set { this["Metric"] = value; }
    }
    [ConfigurationProperty("Notification")]
    public NotificationConfig Notification
    {
      get { return this["Notification"] as NotificationConfig; }
      set { this["Notification"] = value; }
    }
  }
  public class MetricConfig : ConfigurationElement
  {
    [ConfigurationProperty("IntervalType", DefaultValue = "SinceLogin", IsRequired = false)]
    private string _intervalType
    {
      get { return this["IntervalType"] as String; }
      set { this["IntervalType"] = value; }
    }
    public StatisticInterval IntervalType
    {
      get
      {
        var value = _intervalType;
        try
        {
          return (StatisticInterval)Enum.Parse(typeof(StatisticInterval), value);
        }
        catch (Exception e)
        {
          return StatisticInterval.SinceLogin;
        }
      }
    }
    [ConfigurationProperty("Category", DefaultValue = "TotalTime", IsRequired = false)]
    private string _category
    {
      get { return this["Category"] as String; }
      set { this["Category"] = value; }
    }
    public StatisticCategory Category
    {
      get
      {
        var value = _category;
        try
        {
          return (StatisticCategory)Enum.Parse(typeof(StatisticCategory), value);
        }
        catch (Exception e)
        {
          return StatisticCategory.TotalTime;
        }
      }
    }
    [ConfigurationProperty("Subject", DefaultValue = "AgentStatus", IsRequired = false)]
    private string _subject
    {
      get { return this["Subject"] as String; }
      set { this["Subject"] = value; }
    }
    public StatisticSubject Subject
    {
      get
      {
        var value = _subject;
        try
        {
          return (StatisticSubject)Enum.Parse(typeof(StatisticSubject), value);
        }
        catch (Exception e)
        {
          return StatisticSubject.AgentStatus;
        }
      }
    }
    [ConfigurationProperty("IntervalLength", DefaultValue = "3", IsRequired = true)]
    public int IntervalLength
    {
      get { return (int) this["IntervalLength"]; }
      set { this["IntervalLength"] = value; }
    }
  }
  public class NotificationConfig : ConfigurationElement
  {
    [ConfigurationProperty("Frequency", DefaultValue = "1", IsRequired = false)]
    public int Frequency
    {
      get { return (int)this["Frequency"]; }
      set { this["Frequency"] = value; }
    }
    [ConfigurationProperty("Insensitivity", DefaultValue = "0", IsRequired = false)]
    public int Insensitivity
    {
      get { return (int)this["Insensitivity"]; }
      set { this["Insensitivity"] = value; }
    }
    [ConfigurationProperty("Mode", DefaultValue = "Immediate", IsRequired = false)]
    private string _mode
    {
      get { return this["Mode"] as String; }
      set { this["Mode"] = value; }
    }
    public NotificationMode Mode
    {
      get
      {
        var value = _mode;
        try
        {
          return (NotificationMode)Enum.Parse(typeof(NotificationMode), value);
        }
        catch (Exception e)
        {
          return NotificationMode.Immediate;
        }
      }
    }
  }
}

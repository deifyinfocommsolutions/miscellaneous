// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;
using Genesyslab.Platform.Reporting.Protocols;
using Genesyslab.Platform.Reporting.Protocols.StatServer;
using Genesyslab.Platform.Reporting.Protocols.StatServer.Events;
using Genesyslab.Platform.Reporting.Protocols.StatServer.Requests;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.Samples.StatServerConsoleSample
{
  public static class EntryPoint
  {
    public static void Main()
    {
      new StatServerConsoleSample().ExecuteSample();
    }
  }

  /// <summary>
  /// Sample creates and subscribes statistic. 
  /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/StatServer"/>
  /// Sample also uses WarmStandby AB
  /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/UsingWarmStandbyAB"/> 
  /// </summary>
  public class StatServerConsoleSample
  {
    /// <summary>
    /// Async invoker which uses ThreadPool to delivery events.
    /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/ConnectingtoaServer#t-1"/>
    /// </summary>
    private class AsyncInvoker : IAsyncInvoker
    {
      public void Invoke(Delegate d, params object[] args)
      {
        ThreadPool.QueueUserWorkItem(s => d.DynamicInvoke(args), null);
      }

      public void Invoke(WaitCallback callback, object state)
      {
        ThreadPool.QueueUserWorkItem(s => callback(state), null);
      }

      public void Invoke(EventHandler handler, object sender, EventArgs args)
      {
        ThreadPool.QueueUserWorkItem(s => handler(sender, args), null);
      }
    }

    private readonly ConfigurationProfile _config =
      System.Configuration.ConfigurationManager.GetSection("ConfigurationProfile") as ConfigurationProfile;

    private readonly AsyncInvoker _invoker = new AsyncInvoker();
    private readonly StatServerProtocol _client;
    private readonly WarmStandby _warmStandby;
    private readonly Dictionary<int, int> _registeredStatistics = new Dictionary<int, int>();

    public StatServerConsoleSample()
    {
      _client = new StatServerProtocol {Invoker = _invoker};
      _warmStandby = new WarmStandby(_client,
        new Endpoint(_config.ServerConfig.Host, _config.ServerConfig.Port),
        new Endpoint(_config.ServerBackupConfig.Host, _config.ServerBackupConfig.Port));
      _client.Received += (o, args) =>
      {
        var arg = args as MessageEventArgs;
        if ((arg != null) && (arg.Message != null))
          ProcessInfo(arg.Message as EventInfo);
      };
    }

    public void ExecuteSample()
    {
      if (!OpenConnection()) return;
      SubscribeStatisticsNotifications();
      while (true)
      {
        if (Console.ReadKey(true).Key == ConsoleKey.Escape) break;
      }
      UnsubscribeStatisticsNotifications();
      CloseConnection();
    }

    private void ProcessInfo(EventInfo info)
    {
      if (info == null) return;
      lock (typeof (Console))
      {
        Console.WriteLine("[ThreadID: {0,2}]: {1} [ID: {2}]: {3}",
          Thread.CurrentThread.ManagedThreadId, DateTime.Now.ToString("HH:mm:ss.fff"),
          info.ReferenceId, info.IntValue);
      }
    }

    private bool OpenConnection()
    {
      try
      {
        _warmStandby.Open();
      }
      catch (Exception e)
      {
        Console.WriteLine("Error open connection: {0}", e);
        return false;
      }
      return true;
    }

    private void CloseConnection()
    {
      try
      {
        _warmStandby.Close();
      }
      catch (Exception e)
      {
        Console.WriteLine("Error close connection: {0}", e);
      }
    }

    private void SubscribeStatisticsNotifications()
    {
      for (int statCfgId = 0; statCfgId < _config.StatisticObjects.Count; statCfgId++)
      {
        var statCfg = _config.StatisticObjects[statCfgId];
        var statistic = StatisticObject.Create(statCfg.ObjectId, statCfg.ObjectType, statCfg.Tenant,
          statCfg.TenantPassword);
        var metric = StatisticMetricEx.Create();
        metric.MainMask = new DnActionsMask();
        metric.MainMask.SetAll();
        metric.RelativeMask = new DnActionsMask();
        metric.RelativeMask.ClearAll();
        metric.IntervalType = statCfg.MetricCfg.IntervalType;
        metric.IntervalLength = statCfg.MetricCfg.IntervalLength;
        metric.Category = statCfg.MetricCfg.Category;
        metric.Subject = statCfg.MetricCfg.Subject;
        var notification = Notification.Create(statCfg.Notification.Mode, statCfg.Notification.Frequency,
          statCfg.Notification.Insensitivity);
        // Request to server
        _client.BeginRequest(RequestOpenStatisticEx.Create(statistic, metric, notification), ar =>
        {
          try
          {
            var response = _client.EndRequest(ar);
            var err = response as EventError;
            // Handle error
            if (err != null)
            {
              Console.WriteLine("Error of statistic subscription: \n{0}", err);
              return;
            }
            var evt = response as EventStatisticOpened;
            // Statistic is opened
            if (evt != null)
            {
              Console.WriteLine("Success of statistic subscription: \n{0}", evt);
              _registeredStatistics.Add(evt.ReferenceId, (int) ar.AsyncState);
              return;
            }
            Console.WriteLine("Unexpected message is received: \n{0}", response);
          }
          catch (Exception exception)
          {
            Console.WriteLine("Unexpected exception: {0}", exception);
          }
        }, statCfgId);
      }
    }

    private void UnsubscribeStatisticsNotifications()
    {
      foreach (int statIndex in _registeredStatistics.Keys.ToList())
      {
        // Request to server
        try
        {
          var response = _client.Request(RequestCloseStatistic.Create(statIndex));
          var err = response as EventError;
          // Error handler
          if (err != null)
          {
            Console.WriteLine("Error of statistic unsubscription: \n{0}", err);
            continue;
          }
          var evt = response as EventStatisticClosed;
          // Statistic closed
          if (evt != null)
          {
            Console.WriteLine("Success of statistic unsubscription: \n{0}", evt);
            _registeredStatistics.Remove(statIndex);
            continue;
          }
          Console.WriteLine("Unexpected message received: \n{0}", response);
        }
        catch (Exception exception)
        {
          Console.WriteLine("Unexpected exception: {0}", exception);
        }
      }
    }
  }
}

// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Threading;
using Genesyslab.Platform.Reporting.Protocols;
using Genesyslab.Platform.Reporting.Protocols.StatServer;
using Genesyslab.Platform.Reporting.Protocols.StatServer.Events;
using Genesyslab.Platform.Reporting.Protocols.StatServer.Requests;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.Samples.StatServerSample
{
  /// <summary>
  /// GUI Sample creates and subscribes statistic. 
  /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/StatServer"/>
  /// Sample also uses WarmStandby AB
  /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/UsingWarmStandbyAB"/> 
  /// </summary>
  public partial class StatisticForm : Form
  {
    /// <summary>
    /// Async invoker which is adapted for using in GUI thread.
    /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/ConnectingtoaServer#t-1"/>
    /// </summary>
    private class SyncContextInvoker : IAsyncInvoker
    {
      private readonly SynchronizationContext _syncContext;

      public SyncContextInvoker()
      {
        _syncContext = SynchronizationContext.Current;
      }

      public void Invoke(Delegate d, params object[] args)
      {
        _syncContext.Post(s => d.DynamicInvoke(args), null);
      }

      public void Invoke(WaitCallback callback, object state)
      {
        _syncContext.Post(s => callback(state), null);
      }

      public void Invoke(EventHandler handler, object sender, EventArgs args)
      {
        _syncContext.Post(s => handler(sender, args), null);
      }
    }

    private SyncContextInvoker _invoker;
    private StatServerProtocol _client;
    private WarmStandby _warmStandby;
    private readonly ConfigurationProfile _config =
      System.Configuration.ConfigurationManager.GetSection("ConfigurationProfile") as ConfigurationProfile;
    private readonly Dictionary<int,int> _registeredStatistics = new Dictionary<int, int>();

    public StatisticForm()
    {
      InitializeComponent();
    }

    private void StatisticForm_Load(object sender, EventArgs e)
    {
      _invoker = new SyncContextInvoker();
      dataGridView1.RowCount = _config.StatisticObjects.Count;
      for (int i = 0; i < _config.StatisticObjects.Count; i++)
      {
        dataGridView1[1, i].Value = "Activate";
        dataGridView1[2, i].Value = "No";
        dataGridView1[3, i].Value = _config.StatisticObjects[i].ObjectId;
        dataGridView1[4, i].Value = _config.StatisticObjects[i].Tenant;
      }
    }

    private void ProcessMessage(IMessage msg)
    {
      var info = msg as EventInfo;
      if (info != null)
      {
        for (int i = 0; i < _config.StatisticObjects.Count; i++)
        {
          var regId = dataGridView1[0, i].Value;
          if (regId is int)
          {
            if (info.ReferenceId == (int) regId)
              UpdateValue(info.ReferenceId,i,info.IntValue,info.StringValue, System.Drawing.Color.DarkCyan);
          }
        }
      }
    }
    private void button1_Click(object sender, EventArgs e)
    {
      button1.Enabled = false;
      if (_warmStandby == null)
      {
        _client = new StatServerProtocol {Invoker = _invoker};
        _client.Received += (o, args) =>
        {
          var arg = args as MessageEventArgs;
          if ((arg != null) && (arg.Message != null))
            ProcessMessage(arg.Message);
        };
        button1.Text = "Connecting ...";
        _warmStandby = new WarmStandby(_client,
          new Endpoint(_config.ServerConfig.Host, _config.ServerConfig.Port),
          new Endpoint(_config.ServerBackupConfig.Host, _config.ServerBackupConfig.Port));
        _warmStandby.BeginOpen(ar =>
          _invoker.Invoke(o =>
          {
            try
            {
              _warmStandby.EndOpen(ar);
              button1.Text = "Disconnect";
            }
            catch (Exception exception)
            {
              _warmStandby = null;
              _client = null;
              MessageBox.Show(exception.Message, exception.GetType().Name);
            }
            button1.Enabled = true;
          }, null), null);
      }
      else
      {
        _warmStandby.BeginClose(ar =>
          _invoker.Invoke(o =>
          {
            try
            {
              _warmStandby.EndClose(ar);
            }
            catch (Exception exception)
            {
              MessageBox.Show(exception.Message, exception.GetType().Name);
            }
            button1.Text = "Connect";
            _warmStandby = null;
            _client = null;
            button1.Enabled = true;
            for (int i = 0; i < _config.StatisticObjects.Count; i++)
            {
              dataGridView1[1, i].Value = "Activate";
              dataGridView1[2, i].Value = "No";
            }
          }, null), null);
      }
    }

    private void UpdateValue(int id, int index, int intVal, string strVal, System.Drawing.Color color)
    {
      if (id<0)
        dataGridView1[0, index].Value = "";
      else
        dataGridView1[0, index].Value = id;
      dataGridView1[6, index].Value = strVal;
      dataGridView1[6, index].Style.BackColor = color;
      dataGridView1[5, index].Value = intVal;
      dataGridView1[5, index].Style.BackColor = color;

      var timer = new System.Windows.Forms.Timer{ Interval = 1000, Enabled = true };
      timer.Tick += (o, args) =>
      {
        timer.Enabled = false;
        dataGridView1[6, index].Style.BackColor = BackColor;
        dataGridView1[5, index].Style.BackColor = BackColor;
      };
    }

    /// <summary>
    /// Close existed subscription on statistic
    /// </summary>
    /// <param name="statCfgId">ID statistic's configuration</param>
    private void CloseStatistic(int statCfgId)
    {
      var statIndex = -1;
      foreach (KeyValuePair<int, int> pair in _registeredStatistics)
      {
        if (pair.Value == statCfgId)
        {
          statIndex = pair.Key;
        }
      }
      var button = dataGridView1[1, statCfgId] as DataGridViewButtonCell;
      // Unknown statistic  !!!
      if (statIndex < 0)
      {
        MessageBox.Show("Statistic not found", "Error");
        return;
      }
      _client.BeginRequest(RequestCloseStatistic.Create(statIndex), ar =>
      {
        try
        {
          var response = _client.EndRequest(ar);
          var err = response as EventError;
          // Error handler
          if (err != null)
          {
            if (button != null)
              button.Value = "Deactivate";
            UpdateValue(-1, statCfgId, err.IntValue, err.StringValue, System.Drawing.Color.Red);
            return;
          }
          var evt = response as EventStatisticClosed;
          // Statistic closed
          if (evt != null)
          {
            if (button != null)
              button.Value = "Activate";
            UpdateValue(-1, statCfgId, evt.IntValue, evt.StringValue, System.Drawing.Color.Lime);
            dataGridView1[2, statCfgId].Value = "No";
            _registeredStatistics.Remove(statIndex);
            return;
          }
          MessageBox.Show(response.ToString(), "Unexpected message received");
        }
        catch (Exception exception)
        {
          // Exception handler
          MessageBox.Show(exception.Message, exception.GetType().Name);
          if (button != null)
            button.Value = "Deactivate";
        }
      }, null);
    }


    /// <summary>
    /// Creates statistic object and subscribes on server to its updates.
    /// </summary>
    /// <param name="statCfgId">Index of statistic object in configuration</param>
    private void OpenStatistic(int statCfgId)
    {
      var button = dataGridView1[1, statCfgId] as DataGridViewButtonCell;

      var statCfg = _config.StatisticObjects[statCfgId];
      var statistic = StatisticObject.Create(statCfg.ObjectId, statCfg.ObjectType, statCfg.Tenant,
        statCfg.TenantPassword);
      var metric = StatisticMetricEx.Create();
      metric.MainMask = new DnActionsMask();
      metric.MainMask.SetAll();
      metric.RelativeMask = new DnActionsMask();
      metric.RelativeMask.ClearAll();
      metric.IntervalType = statCfg.MetricCfg.IntervalType;
      metric.IntervalLength = statCfg.MetricCfg.IntervalLength;
      metric.Category = statCfg.MetricCfg.Category;
      metric.Subject = statCfg.MetricCfg.Subject;
      var notification = Notification.Create(statCfg.Notification.Mode, statCfg.Notification.Frequency,
        statCfg.Notification.Insensitivity);
      //  Request to server
      _client.BeginRequest(RequestOpenStatisticEx.Create(statistic, metric, notification), ar =>
      {
        try
        {
          var response = _client.EndRequest(ar);
          var err = response as EventError;
          // Handle error
          if (err != null)
          {
            if (button != null)
              button.Value = "Activate";
            UpdateValue(-1, statCfgId, err.IntValue, err.StringValue, System.Drawing.Color.Red);
            return;
          }
          var evt = response as EventStatisticOpened;
          // Statistic is opened
          if (evt != null)
          {
            if (button != null)
              button.Value = "Deactivate";
            UpdateValue(evt.ReferenceId, statCfgId, evt.IntValue, evt.StringValue, System.Drawing.Color.Lime);
            dataGridView1[2, statCfgId].Value = "Yes";
            _registeredStatistics.Add(evt.ReferenceId, statCfgId);
            return;
          }
          MessageBox.Show(response.ToString(), "Unexpected message received");
        }
        catch (Exception exception)
        {
          // Handle exception
          MessageBox.Show(exception.Message, exception.GetType().Name);
          if (button != null)
            button.Value = "Activate";
        }
      }, null);
    }

    private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    {
      // Only buttons handle this event
      if (e.ColumnIndex == 1)
      {
        
        if ((_warmStandby == null) || (!_warmStandby.IsOpened))
        {
          MessageBox.Show("You should connect to server before", "Error");
          return;
        }
        if (_registeredStatistics.ContainsValue(e.RowIndex))
        {
          // Close statistic
          CloseStatistic(e.RowIndex);
        }
        else
        {
          // Open statistic
          OpenStatistic(e.RowIndex);
        }
      }
    }

    private void StatisticForm_FormClosed(object sender, FormClosedEventArgs e)
    {
      // close Warmstandby which should close client
      if (_warmStandby!=null)
      {
        _warmStandby.BeginClose(null,null);
      }
    }
  }
}

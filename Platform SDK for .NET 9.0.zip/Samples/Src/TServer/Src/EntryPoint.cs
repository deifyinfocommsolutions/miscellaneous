// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Logging;

namespace Genesyslab.Platform.Samples.TServerSample
{
  #region Application entry point
  /// <summary>
  /// Entry point of samples application
  /// </summary>
  public static class EntryPoint
  {
    /// <summary>
    /// Application entry point
    /// </summary>
    private static void Main()
    {
      var context = new ApplicationContext();
      ITssView tssView = null;
      ILogger logger = null;
      using (var configForm = new ConfigurationForm())
      {
        context.MainForm = configForm;
        Application.Run(context);
        if (configForm.Result == DialogResult.OK)
        {
          ITssModel model = null;
          switch (configForm.ModelIndex)
          {
            case 0:
              {
                model = new TssHandlerModel();
                break;
              }
            case 1:
              {
                model = new TssAsyncModel();
                break;
              }
            case 2:
              {
                model = new TssSyncModel();
                break;
              }
            default:
              return;
          }
          if (configForm.LoggerIndex==1)
          {
            logger = new TraceSourceLogger(new TraceSource("tserver.sample.root", SourceLevels.All));
          }
          tssView = new TssView(context);
          ITssViewModel tssViewModel = new TssViewModel();
          // binding components
          tssViewModel.Initialization(tssView);
          tssViewModel.Initialization(model);
          if (logger!=null)
            tssViewModel.EnableLogging(logger);
        }
      }
      // run GUI
      if (tssView != null)
        tssView.Run();
    }

    private class ConfigurationForm : Form
    {
      public DialogResult Result { get; private set; }
      public int ModelIndex = 1;
      public int LoggerIndex = 0;

      public ConfigurationForm()
      {
        FormBorderStyle = FormBorderStyle.FixedToolWindow;
        StartPosition = FormStartPosition.CenterScreen;
        SuspendLayout();
        InitializeView();
        ResumeLayout(false);
      }

      private void InitializeView()
      {
        Text = "TServerSample configuration";
        Width = 280;
        Height = 220;
        var mainPanel = new Panel
        {
          BorderStyle = BorderStyle.Fixed3D, AutoSize = true, Dock = DockStyle.Fill, Parent = this
        };
        var selectPanel = new Panel
        {
          BorderStyle = BorderStyle.Fixed3D, Parent = mainPanel, Dock = DockStyle.Fill,
          Margin = new Padding(4), Padding = new Padding(4)
        }; 
        var controlPanel = new Panel
        {
          BorderStyle = BorderStyle.Fixed3D, Parent = mainPanel, Dock = DockStyle.Bottom, Height = 32,
          Margin = new Padding(0)
        };
        var modelSelectBox = new GroupBox
        {
          Dock = DockStyle.Fill, Text = "Model selection", Parent = selectPanel, Padding = new Padding(4)
        };
        new RadioButton { Parent = modelSelectBox, Text = "Synchronous Model", AutoSize = true, Dock = DockStyle.Top, Tag = 2};
        new RadioButton { Parent = modelSelectBox, Text = "AsyncRequest pattern Model", AutoSize = true, Dock = DockStyle.Top, Tag = 1, Checked = true};
        new RadioButton { Parent = modelSelectBox, Text = "Handler Model (supports WarmStandby)", AutoSize = true, Dock = DockStyle.Top, Tag = 0};
        var loggerSelectBox = new GroupBox
        {
          Dock = DockStyle.Bottom, Height = 60, Text = "Logger selection", Parent = selectPanel, Padding = new Padding(4)
        };
        new RadioButton { Parent = loggerSelectBox, Text = "Trace logger", AutoSize = true, Dock = DockStyle.Top, Tag = 1 };
        new RadioButton { Parent = loggerSelectBox, Text = "No logger", AutoSize = true, Dock = DockStyle.Top, Tag = 0, Checked = true };
        var button = new Button
        { 
          Text = "Apply and run", Parent = controlPanel,
          Dock = DockStyle.Fill
        };
        button.Click += (sender, args) =>
        {
          Result = DialogResult.OK;
          var item = modelSelectBox.Controls.OfType<RadioButton>().FirstOrDefault(radioButton => radioButton.Checked && radioButton.Tag is int);
          ModelIndex = (item == null) ? -1 : (int)item.Tag;
          item = loggerSelectBox.Controls.OfType<RadioButton>().FirstOrDefault(radioButton => radioButton.Checked && radioButton.Tag is int);
          LoggerIndex = (item == null) ? -1 : (int)item.Tag;
          Close();
        };
        button = new Button
        {
          Width = controlPanel.Width>>1,Text = "Exit",Parent = controlPanel,Dock = DockStyle.Right
        };
        button.Click += (sender, args) => Close();
        controlPanel.Resize += (sender, args) => button.Width = controlPanel.Width >> 1;
      }
    }
  }
  #endregion Application entry point
}

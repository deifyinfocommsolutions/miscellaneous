// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System.Collections.Generic;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Voice.Protocols.TServer;

namespace Genesyslab.Platform.Samples.TServerSample
{
#region Common API
    /// <summary>
  /// Event Codes of T-Server's sample model
  /// </summary>
  public static class TssModelEventCodes
  {

    public const int AgentLogin = 100;
    public const int AgentLogout = 101;
    public const int AgentReady = 102;
    public const int AgentNotReady = 103;
    public const int ErrorLogIn = 104;
    public const int ErrorLogOut = 105;
    public const int ErrorSetReady = 106;
    public const int ErrorSetNotReady = 107;
    public const int RegisterDn = 108;
    public const int UnregisterDn = 109;
    public const int ErrorRegisterDn = 110;
    public const int ErrorUnregisterDn = 111;

  }
  #endregion Common API
  #region Model Specification
  /// <summary>
  /// T-Server sample model
  /// </summary>
  public interface ITssModelApi
  {
    /// <summary>
    /// Initializes connection's parameters
    /// </summary>
    /// <param name="host">Host name</param>
    /// <param name="port">Port number</param>
    /// <param name="clientName">Client's name</param>
    /// <param name="password">User password. Further API may be some different in case of using sensitive data.</param>
    void Initialization(string host, int port, string clientName, string password);
    /// <summary>
    /// Opens client's connection to server
    /// </summary>
    void Open();
    /// <summary>
    /// Closes client's connection to server
    /// </summary>
    void Close();
    /// <summary>
    /// Registers new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    void RegisterDn(string thisDn);
    /// <summary>
    /// Unregisters new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    void UnregisterDn(string thisDn);
    /// <summary>
    /// Request server to log on agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="agentID">Agent identifier</param>
    /// <param name="password">agent's password</param>
    /// <param name="reasons">Key-value collection of reason</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    void AgentLogin(string thisDn, AgentWorkMode agentWorkMode, string thisQueue,
      string agentID, string password, KeyValueCollection reasons, KeyValueCollection extensions);
    /// <summary>
    /// Request server to log out agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reason</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    void AgentLogout(string thisDn, string thisQueue,
      KeyValueCollection reasons, KeyValueCollection extensions);
    /// <summary>
    /// Request server to set agent ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reason</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    void SetAgentReady(string thisDn, AgentWorkMode agentWorkMode,
        string thisQueue, KeyValueCollection reasons, KeyValueCollection extensions);
    /// <summary>
    /// Request server to set agent not ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reason</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    void SetAgentNotReady(string thisDn, AgentWorkMode agentWorkMode,
        string thisQueue, KeyValueCollection reasons, KeyValueCollection extensions);
    /// <summary>
    /// Sets warmstandby configuration
    /// </summary>
    /// <param name="cfg">List of endpoint's description</param>
    void SetWarmStandby(List<WarmStandbyEndpointDescription> cfg);
    bool WarmStandbySupport { get; }
  }
  /// <summary>
  /// Common interface of T-Server model
  /// </summary>
  public interface ITssModel : ITssModelApi, IModel
  {}

  #endregion Model Specification
  #region View Specification
  /// <summary>
  /// Common interface of T-Server view
  /// </summary>
  public interface ITssView : IViewApi, IView
  {
  }
  #endregion View Specification
  #region ViewModel specification
  /// <summary>
  /// Common interface of bridge between model and a view
  /// </summary>
  public interface ITssViewModel : ITssModelApi, IViewApi, IViewModel
  {
  }

  #endregion ViewModel specification

  public class WarmStandbyEndpointDescription
  {
    public string Host { get; set; }
    public int Port { get; set; }
  }
}

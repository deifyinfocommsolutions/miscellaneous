// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Collections.Generic;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Connection.Configuration;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Voice.Protocols;
using Genesyslab.Platform.Voice.Protocols.TServer;
using Genesyslab.Platform.Voice.Protocols.TServer.Events;

namespace Genesyslab.Platform.Samples.TServerSample
{
  /// <summary>
  /// Common base class of T-Server model
  /// </summary>
  public abstract class TssAbstractModel: IModel
  {
    protected ITssView View;
    protected TServerProtocol Client;
    protected ILogger Logger { get; private set; }
    protected List<WarmStandbyEndpointDescription> WarmStandbyConfig = null;
    public virtual bool WarmStandbySupport{get { return false; }}
    /// <summary>
    /// Initializes relations between model and view
    /// </summary>
    /// <param name="view">IView implementation</param>
    public virtual void Initialization(IView view)
    {
      View = view as ITssView;
    }
    /// <summary>
    /// Configures client channel to use ADDP.
    /// </summary>
    public virtual IConnectionConfiguration CreateDefaultConfiguration()
    {
      // Creates and returns instance of IConnectionConfiguration 
      // with default parameters to use ADDP
      return new ManagedConnectionConfiguration(null)
      {
        UseAddp = true,
        AddpClientTimeout = 10, 
        AddpServerTimeout = 12, 
        AddpTraceMode = AddpTraceMode.Both
      };
    }
    /// <summary>
    /// Initializes T-Server client and WarmStandby service
    /// </summary>
    /// <param name="host">host of primary server</param>
    /// <param name="port">port</param>
    /// <param name="clientName">client name</param>
    /// <param name="password">password (obsolete parameter)</param>
    public virtual void Initialization(string host, int port, string clientName, string password)
    {
      // Initialization of T-Server client 
      Client = new TServerProtocol(new Endpoint(host, port, CreateDefaultConfiguration()))
      {
        ClientName = clientName,
        ClientPassword = password
      };
      if (Logger!=null) 
        Client.EnableLogging(Logger);
    }
    /// <summary>
    /// Sets logger to client
    /// </summary>
    /// <param name="logger">ILogger instance</param>
    public virtual void EnableLogging(ILogger logger)
    {
      Logger = logger;
      if (Client!=null)
        Client.EnableLogging(logger);
    }
    /// <summary>
    /// Sets warmstandby configuration
    /// </summary>
    /// <param name="cfg">List of descriptions of endponts</param>
    public void SetWarmStandby(List<WarmStandbyEndpointDescription> cfg)
    {
      if ((cfg == null) || (cfg.Count<2))// disable WarmStandby
      {
        WarmStandbyConfig = null;
      }
      else
      {
        WarmStandbyConfig = cfg;
      }
    }
    /// <summary>
    /// Returns description of error, which is contained inside EventError
    /// </summary>
    /// <param name="msg">message, which should contain error description</param>
    /// <returns>description of error, which is contained inside EventError or null if message is not EventError</returns>
    protected string GetErrorDescription(IMessage msg)
    {
      var err = msg as EventError;
      return err != null
          ? TServerEnumDescription.GetDescription(typeof(Genesyslab.Platform.Voice.Protocols.TServer.Errors),err.ErrorCode)
          : null;
    }

    /// <summary>
    /// service method, checks if client channel is created
    /// </summary>
    /// <returns>true if client channel is created otherwise returns false</returns>
    protected bool CheckClientIsNull()
    {
      if (Client == null)
      {
        View.Notify(ModelEventCodes.InternalError, 0, new ArgumentException("Client is null"));
        return false;
      }
      return true;
    }
    /// <summary>
    /// service method, checks if client channel is opened
    /// </summary>
    /// <returns>true if client channel is opened otherwise returns false</returns>
    protected bool CheckClientIsOpened()
    {
      if (Client.State != ChannelState.Opened)
      {
        View.Notify(ModelEventCodes.InternalError, 0, new InvalidOperationException("Client is not opened"));
        return false;
      }
      return true;
    }
  }
}

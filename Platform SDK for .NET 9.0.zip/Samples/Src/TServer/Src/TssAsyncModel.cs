// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Threading;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Voice.Protocols.TServer;
using Genesyslab.Platform.Voice.Protocols.TServer.Events;
using Genesyslab.Platform.Voice.Protocols.TServer.Requests.Agent;
using Genesyslab.Platform.Voice.Protocols.TServer.Requests.Dn;

namespace Genesyslab.Platform.Samples.TServerSample
{
  public class TssAsyncModel : TssAbstractModel,ITssModel
  {
    /// <summary>
    /// Class to deliver some messages which can be received without 
    /// of request or supplement an requested answer
    /// </summary>
    private class MessageReceiver : IMessageReceiverSupport
    {
      private readonly TssAsyncModel _model;

      internal MessageReceiver(TssAsyncModel model)
      {
        _model = model;
      }

      public void ClearInput(){}

      public int InputSize { get; set; }
      public void ReleaseReceivers(){}

      public IMessage Receive()
      {
        return null;
      }

      public IMessage Receive(TimeSpan timeout)
      {
        return null;
      }

      public void ProcessMessage(IMessage message)
      {
        _model.View.Notify(ModelEventCodes.ChannelMessage, 0, message);
      }
    }

    /// <summary>
    /// Asynchronous opens connection to the T-Server
    /// </summary>
    public void Open()
    {
      // work in background
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          if (!CheckClientIsNull()) return;
          Client.ResetReceiver();
          // set external receiver
          Client.SetReceiver(new MessageReceiver(this));
          Client.Open();
          if (View!=null)
            View.Notify(ModelEventCodes.ChannelOpened, 0, null);
        }
        catch (Exception e)
        {
          if (View!=null)
            View.Notify(ModelEventCodes.ChannelClosed, 0, e);
        }
      });
    }
    /// <summary>
    /// Asynchronous closes connection to the T-Server
    /// </summary>
    public void Close()
    {
      ThreadPool.QueueUserWorkItem(state =>
      {
        try
        {
          if (!CheckClientIsNull()) return;
          Client.Close();
          if (View != null)
            View.Notify(ModelEventCodes.ChannelClosed, 0, null);
        }
        catch (Exception e)
        {
          if (View != null)
            View.Notify(ModelEventCodes.ChannelClosed, 0, e);
        }
      });
    }

    /// <summary>
    /// Registers DN on server
    /// </summary>
    /// <param name="thisDn">DN name</param>
    public void RegisterDn(string thisDn)
    {
      if (!CheckClientIsNull())return;
      if (!CheckClientIsOpened()) return;
      // create request
      var req0 = RequestRegisterAddress.Create(thisDn, RegisterMode.ModePrivate, ControlMode.RegisterDefault, AddressType.DN);
      // asynchronous send the request and handle response in callback
      Client.BeginRequest(req0, ar0 =>
      {
        try
        {
          // wait for request will be completed
          ((ClientChannel)ar0.AsyncState).EndRequest(ar0);
          var res0 = ar0 as AsyncRequestResult;
          if (res0 == null) return;
          var eventRegistered = res0.Response as EventRegistered;
          if (eventRegistered != null)
          {
            // dn is registered
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.RegisterDn, eventRegistered);
          }
          else
          {
            // dn is not registered
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorRegisterDn, res0.Response, GetErrorDescription(res0.Response));
          }
        }
        catch (Exception e)
        {
          // an error occurred during processing
          View.Notify(ModelEventCodes.InternalError, 0, e);
        }
      }, Client);
    }
    /// <summary>
    /// Unregisters DN on server
    /// </summary>
    /// <param name="thisDn">DN name</param>
    public void UnregisterDn(string thisDn)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      // create request
      var req0 = RequestUnregisterAddress.Create(thisDn, ControlMode.RegisterDefault);
      // asynchronous send the request and handle response in callback
      Client.BeginRequest(req0, ar0 =>
      {
        try
        {
          // wait for request will be completed
          ((ClientChannel)ar0.AsyncState).EndRequest(ar0);
          var res0 = ar0 as AsyncRequestResult;
          if (res0 == null) return;
          var eventRegistered = res0.Response as EventUnregistered;
          if (eventRegistered != null)
          {
            // dn is unregistered
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.UnregisterDn, eventRegistered);
          }
          else
          {
            // dn is not unregistered
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorUnregisterDn, res0.Response, GetErrorDescription(res0.Response));
          }
        }
        catch (Exception e)
        {
          // an error occurred during processing
          View.Notify(ModelEventCodes.InternalError, 0, e);
        }
      }, Client);
    }
    /// <summary>
    /// Login agent on server
    /// </summary>
    /// <param name="thisDn">Name of DN</param>
    /// <param name="agentWorkMode">Work mode</param>
    /// <param name="thisQueue">Name of queue</param>
    /// <param name="agentID">ID of agent</param>
    /// <param name="password">password</param>
    /// <param name="reasons">KeyValue collection of reasons</param>
    /// <param name="extensions">KeyValue collection of extensions</param>
    public void AgentLogin(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, string agentID, string password,
      KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      // create request
      var req = RequestAgentLogin.Create(thisDn, agentWorkMode, thisQueue, agentID, password, reasons, extensions);
      // asynchronous send the request and handle response in callback
      Client.BeginRequest(req, ar =>
      {
        try
        {
          // wait for request will be completed
          ((ClientChannel)ar.AsyncState).EndRequest(ar);
          var res = ar as AsyncRequestResult;
          if (res == null) return;
          var eventAgentLogin = res.Response as EventAgentLogin;
          if (eventAgentLogin != null)
          {
            // agent is logged in
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogin, eventAgentLogin);
          }else
          {
            // agent is not logged in
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorLogIn, res.Response, GetErrorDescription(res.Response));
          }
        }
        catch (Exception e)
        {
          // an error occurred during processing
          View.Notify(ModelEventCodes.InternalError, 0, e);
        }
      }, Client);
    }
    /// <summary>
    /// Logout of agent 
    /// </summary>
    /// <param name="thisDn">DN's name</param>
    /// <param name="thisQueue">Queue's name</param>
    /// <param name="reasons">KeyValue collection of reasons</param>
    /// <param name="extensions">KeyValue collection of extensions</param>
    public void AgentLogout(string thisDn, string thisQueue, KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      // create request
      var req0 = RequestAgentLogout.Create(thisDn);
      // asynchronous send the request and handle response in callback
      Client.BeginRequest(req0, ar0 =>
      {
        try
        {
          // wait for request will be completed
          ((ClientChannel)ar0.AsyncState).EndRequest(ar0);
          var res0 = ar0 as AsyncRequestResult;
          if (res0 == null) return;
          var eventLogOut = res0.Response as EventAgentLogout;
          if (eventLogOut != null)
          {
            // agent is logged out
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogout, eventLogOut);
          }
          else
          {
            var eventQLogOut = res0.Response as EventQueueLogout;
            if (eventQLogOut!=null)
            {
              // queue is logged out
              View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogout, eventQLogOut);
            }
            else
            {
              // agent is not logged out
              View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorLogOut, res0.Response, GetErrorDescription(res0.Response));
            }
          }
        }
        catch (Exception e)
        {
          // an error occurred during processing
          View.Notify(ModelEventCodes.InternalError, 0, e);
        }
      }, Client);
    }
    /// <summary>
    /// Set agent ready
    /// </summary>
    /// <param name="thisDn">Name of DN</param>
    /// <param name="agentWorkMode">Work mode</param>
    /// <param name="thisQueue">Name of queue</param>
    /// <param name="reasons">KeyValue collection of reasons</param>
    /// <param name="extensions">KeyValue collection of extensions</param>
    public void SetAgentReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      // create request
      var req0 = RequestAgentReady.Create(thisDn, agentWorkMode, thisQueue, null, null);
      // asynchronous send the request and handle response in callback
      Client.BeginRequest(req0, ar0 =>
      {
        try
        {
          // wait for request will be completed
          ((ClientChannel)ar0.AsyncState).EndRequest(ar0);
          var res0 = ar0 as AsyncRequestResult;
          if (res0 == null) return;
          var evtReady = res0.Response as EventAgentReady;
          if (evtReady != null)
          {
            // setting agent ready was successful
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentReady, evtReady);
          }
          else
          {
            // setting agent ready was unsuccessful
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorSetReady, res0.Response, GetErrorDescription(res0.Response));
          }
        }
        catch (Exception e)
        {
          // an error occurred during processing
          View.Notify(ModelEventCodes.InternalError, 0, e);
        }
      }, Client);
    }
    /// <summary>
    /// Set agent not ready
    /// </summary>
    /// <param name="thisDn">Name of DN</param>
    /// <param name="agentWorkMode">Work mode</param>
    /// <param name="thisQueue">Name of queue</param>
    /// <param name="reasons">KeyValue collection of reasons</param>
    /// <param name="extensions">KeyValue collection of extensions</param>
    public void SetAgentNotReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      // create request
      var req0 = RequestAgentNotReady.Create(thisDn, agentWorkMode, thisQueue, null, null);
      // asynchronous send the request and handle response in callback
      Client.BeginRequest(req0, ar0 =>
      {
        try
        {
          // wait for request will be completed
          ((ClientChannel)ar0.AsyncState).EndRequest(ar0);
          var res0 = ar0 as AsyncRequestResult;
          if (res0 == null) return;
          var evtReady = res0.Response as EventAgentNotReady;
          if (evtReady != null)
          {
            // setting agent not ready was successful
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentNotReady, evtReady);
          }
          else
          {
            // setting agent not ready was unsuccessful
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorSetNotReady, res0.Response, GetErrorDescription(res0.Response));
          }
        }
        catch (Exception e)
        {
          // an error occurred during processing
          View.Notify(ModelEventCodes.InternalError, 0, e);
        }
      }, Client);
    }

  }
}

// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Standby;
using Genesyslab.Platform.Voice.Protocols.TServer;
using Genesyslab.Platform.Voice.Protocols.TServer.Events;
using Genesyslab.Platform.Voice.Protocols.TServer.Requests.Agent;
using Genesyslab.Platform.Voice.Protocols.TServer.Requests.Dn;

namespace Genesyslab.Platform.Samples.TServerSample
{
  /// <summary>
  /// This model communicates with server using Event handles mechanism.
  /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/EventHandling"/>
  /// </summary>
  public class TssHandlerModel : TssAbstractModel, ITssModel
  {
    private WarmStandby _warmStandby;
    public override bool WarmStandbySupport { get { return true; } }

    /// <summary>
    /// Handler of Channel's Opened event
    /// </summary>
    /// <param name="sender">Sender of event</param>
    /// <param name="args">Event Arguments</param>
    private void OnOpened(object sender, EventArgs args)
    {
      if (View != null)
        View.Notify(ModelEventCodes.ChannelOpened, 0, null);
      Console.WriteLine(">>>>>>>>>>>>>>>>>>>>> Opened <<<<<<<<<<<<<<<<<<<<<<<<<<");
    }
    /// <summary>
    /// Handler of Channel's Closed event
    /// </summary>
    /// <param name="sender">Sender of event</param>
    /// <param name="args">Event Arguments</param>
    private void OnClosed(object sender, EventArgs args)
    {
      var arg = args as ClosedEventArgs;
      if (arg == null)
      {
        var wsArg = args as WSClosedEvent;
        if (wsArg != null) arg = wsArg.ClosedEvent;
      }
      if (arg==null) return;
      if ((arg.Cause == null) || (_warmStandby == null)) 
        // channel is closed mannualy or warmstandby is not present, notify to view
      {
        if (View != null)
          View.Notify(ModelEventCodes.ChannelClosed, 0, arg.Cause);
        Console.WriteLine(">>>>>>>>>>>>>>>>>>>>> Closed <<<<<<<<<<<<<<<<<<<<<<<<<<");
      }
      if ((arg.Cause == null) && (_warmStandby != null)) 
        // channel is closed mannualy, stop warmstandby
      {
        _warmStandby.Close();
        _warmStandby = null;
        Client = null;
      }
    }

    /// <summary>
    /// Handler of Channel's Error event
    /// </summary>
    /// <param name="sender">Sender of event</param>
    /// <param name="args">Event Arguments</param>
    private void OnError(object sender, EventArgs args)
    {
      var arg = args as ErrorArgs;
      if (View != null)
        View.Notify(ModelEventCodes.ChannelError, 0, arg == null ? null : arg.Cause);
    }

    /// <summary>
    /// Channel's Received event handler
    /// </summary>
    /// <param name="sender">Sender of event</param>
    /// <param name="args">Event Arguments</param>
    private void OnMessageReceived(object sender, EventArgs args)
    {
      Console.WriteLine(">>>>>>>>>>>>>>>>>>>>> Received <<<<<<<<<<<<<<<<<<<<<<<<<<");
      var arg = args as MessageEventArgs;
      if ((arg==null) || (arg.Message==null)) return;
      switch (arg.Message.Id)
      {
        case EventRegistered.MessageId:
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.RegisterDn, arg.Message);
          break;
        }
        case EventUnregistered.MessageId:
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.UnregisterDn, arg.Message);
          break;
        }
        case EventAgentLogin.MessageId:
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogin, arg.Message);
          break;
        }
        case EventAgentLogout.MessageId:
        case EventQueueLogout.MessageId:
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogout, arg.Message);
          break;
        }
        case EventAgentReady.MessageId:
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentReady, arg.Message);
          break;
        }
        case EventAgentNotReady.MessageId:
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentNotReady, arg.Message);
          break;
        }
        default:
        {
          View.Notify(ModelEventCodes.ChannelMessage, 0, arg.Message, GetErrorDescription(arg.Message));
          break;
        }
      }
    }
    /// <summary>
    /// Opens connection. 
    /// If WarmStandby configuration exists, sample will use WarmStandby AB.
    /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/UsingWarmStandbyAB"/> 
    /// </summary>
    public void Open()
    {
      if (!CheckClientIsNull()) return;
      Client.Opened -= OnOpened;
      Client.Closed -= OnClosed;
      Client.Error -= OnError;
      Client.Received -= OnMessageReceived;


      Client.Error += OnError;
      Client.Received += OnMessageReceived;
      if ((WarmStandbyConfig != null) && (WarmStandbyConfig.Count >= 2))
      {
        _warmStandby = new WarmStandby(Client);
        if (Logger != null)
          _warmStandby.EnableLogging(Logger.CreateChildLogger("WarmStandby"));
        foreach (var endpointDescription in WarmStandbyConfig)
        {
          _warmStandby.Configuration.Endpoints.Add(new Endpoint(endpointDescription.Host, endpointDescription.Port));
        }
        _warmStandby.ChannelOpened += OnOpened;
        _warmStandby.ChannelDisconnected += OnClosed;
        _warmStandby.EndpointTriedUnsuccessfully += (sender, args) =>
        {
          var arg = args as WSTriedUnsuccessfullyEvent;
          if (arg!=null)
            Console.WriteLine("Failed connect to endpoint: {0}",arg.Endpoint);
          //if (View != null)
          //  View.Notify(ModelEventCodes.ChannelError, 0, arg == null ? null : arg.Cause);
        };
        _warmStandby.AllEndpointsTriedUnsuccessfully += (sender, args) =>
        {
          var arg = args as WSAllTriedUnsuccessfullyEvent;
          if (View != null)
          {
            View.Notify(ModelEventCodes.ChannelError, 0, arg == null ? null : "All endpoints tried unsuccessfully");
            View.Notify(ModelEventCodes.ChannelClosed, 0, null);
          }
        };
        _warmStandby.BeginOpen(null,null);
      }
      else
      {
        Client.Opened += OnOpened;
        Client.Closed += OnClosed;
        Client.BeginOpen();
      }
    }

    /// <summary>
    /// Closes client's connection to server
    /// </summary>
    public void Close()
    {
      if (!CheckClientIsNull()) return;
      if (_warmStandby != null)
      {
        _warmStandby.Close();
        _warmStandby = null;
        Client = null;
      }
      else
      {
        if (Client!=null)
          Client.BeginClose();
      }
    }

    /// <summary>
    /// Registers new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    public void RegisterDn(string thisDn)
    {
      if (!CheckClientIsNull())return;
      if (!CheckClientIsOpened()) return;
      Client.Send(RequestRegisterAddress.Create(thisDn, RegisterMode.ModePrivate, ControlMode.RegisterDefault, AddressType.DN));
    }

    /// <summary>
    /// Unregisters new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    public void UnregisterDn(string thisDn)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      Client.Send(RequestUnregisterAddress.Create(thisDn, ControlMode.RegisterDefault));
    }

    /// <summary>
    /// Request server to log on agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="agentID">Agent identifier</param>
    /// <param name="password">agent's password</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void AgentLogin(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, string agentID, string password,
      KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      Client.Send(RequestAgentLogin.Create(thisDn, agentWorkMode, thisQueue, agentID, password, reasons, extensions));
    }

    /// <summary>
    /// Request server to log out agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void AgentLogout(string thisDn, string thisQueue, KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      Client.Send(RequestAgentLogout.Create(thisDn));
    }

    /// <summary>
    /// Request server to set agent ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void SetAgentReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      Client.Send(RequestAgentReady.Create(thisDn, agentWorkMode, thisQueue, null, null));
    }

    /// <summary>
    /// Request server to set agent not ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void SetAgentNotReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      Client.Send(RequestAgentNotReady.Create(thisDn, agentWorkMode, thisQueue, null, null));
    }
  }
}

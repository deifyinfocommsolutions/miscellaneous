// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Voice.Protocols.TServer;
using Genesyslab.Platform.Voice.Protocols.TServer.Events;
using Genesyslab.Platform.Voice.Protocols.TServer.Requests.Agent;
using Genesyslab.Platform.Voice.Protocols.TServer.Requests.Dn;

namespace Genesyslab.Platform.Samples.TServerSample
{
  public class TssSyncModel : TssAbstractModel, ITssModel
  {
    /// <summary>
    /// Opens client's connection to server
    /// </summary>
    public void Open()
    {
      if (!CheckClientIsNull()) return;
      try
      {
        Client.Open();
        View.Notify(ModelEventCodes.ChannelOpened, 0, null);
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.ChannelClosed, 0, e);
      }
    }

    /// <summary>
    /// Closes client's connection to server
    /// </summary>
    public void Close()
    {
      if (!CheckClientIsNull()) return;
      try
      {
        Client.Close();
        View.Notify(ModelEventCodes.ChannelClosed, 0, null);
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.ChannelClosed, 0, e);
      }
    }

    /// <summary>
    /// Registers new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    public void RegisterDn(string thisDn)
    {
      if (!CheckClientIsNull())return;
      if (!CheckClientIsOpened()) return;
      try
      {
        var resp = Client.Request(RequestRegisterAddress.Create(thisDn, RegisterMode.ModePrivate, ControlMode.RegisterDefault, AddressType.DN));
        if (resp == null) return;
        var eventRegistered = resp as EventRegistered;
        if (eventRegistered != null)
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.RegisterDn, eventRegistered);
        }
        else
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorRegisterDn, resp, GetErrorDescription(resp));
        }
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.InternalError, 0, e);
      }
    }

    /// <summary>
    /// Unregisters new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    public void UnregisterDn(string thisDn)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      try
      {
        var resp = Client.Request(RequestUnregisterAddress.Create(thisDn, ControlMode.RegisterDefault));
        if (resp == null) return;
        var eventRegistered = resp as EventUnregistered;
        if (eventRegistered != null)
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.UnregisterDn, eventRegistered);
        }
        else
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorUnregisterDn, resp, GetErrorDescription(resp));
        }
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.InternalError, 0, e);
      }
    }

    /// <summary>
    /// Request server to log on agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="agentID">Agent identifier</param>
    /// <param name="password">agent's password</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void AgentLogin(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, string agentID, string password,
      KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      try{
        var resp = Client.Request(RequestAgentLogin.Create(thisDn, agentWorkMode, thisQueue, agentID, password, reasons, extensions));
        if (resp == null) return;
        var eventAgentLogin = resp as EventAgentLogin;
        if (eventAgentLogin != null)
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogin, eventAgentLogin);
        }
        else
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorLogIn, resp, GetErrorDescription(resp));
        }
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.InternalError, 0, e);
      }
    }

    /// <summary>
    /// Request server to log out agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void AgentLogout(string thisDn, string thisQueue, KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      try
      {
        var resp = Client.Request(RequestAgentLogout.Create(thisDn));
        if (resp == null) return;
        var eventLogOut = resp as EventAgentLogout;
        if (eventLogOut != null)
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogout, eventLogOut);
        }
        else
        {
          var eventQLogOut = resp as EventQueueLogout;
          if (eventQLogOut != null)
          {
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentLogout, eventQLogOut);
          }
          else
          {
            View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorLogOut, resp, GetErrorDescription(resp));
          }
        }
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.InternalError, 0, e);
      }
    }

    /// <summary>
    /// Request server to set agent ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void SetAgentReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      try
      {
        var resp = Client.Request(RequestAgentReady.Create(thisDn, agentWorkMode, thisQueue, null, null));
        if (resp == null) return;
        var evtReady = resp as EventAgentReady;
        if (evtReady != null)
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentReady, evtReady);
        }
        else
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorSetReady, resp, GetErrorDescription(resp));
        }
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.InternalError, 0, e);
      }
    }

    /// <summary>
    /// Request server to set agent not ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void SetAgentNotReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (!CheckClientIsNull()) return;
      if (!CheckClientIsOpened()) return;
      try
      {
        var resp = Client.Request(RequestAgentNotReady.Create(thisDn, agentWorkMode, thisQueue, null, null));
        if (resp == null) return;
        var evtReady = resp as EventAgentNotReady;
        if (evtReady != null)
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.AgentNotReady, evtReady);
        }
        else
        {
          View.Notify(ModelEventCodes.ChannelMessage, TssModelEventCodes.ErrorSetNotReady, resp, GetErrorDescription(resp));
        }
      }
      catch (Exception e)
      {
        View.Notify(ModelEventCodes.InternalError, 0, e);
      }
    }
  }
}

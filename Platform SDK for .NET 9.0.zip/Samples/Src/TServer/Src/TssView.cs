// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Security.Permissions;
using System.Threading;
using System.Windows.Forms;
using Genesyslab.Configuration;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Voice.Protocols.TServer;

namespace Genesyslab.Platform.Samples.TServerSample
{

  public class TssView : SampleViewBase, ITssView
  {
    public TssView(ApplicationContext appContext) : base(appContext)
    {
    }

    private new ITssModelApi Model { get { return base.Model as ITssModelApi; } }
    protected override SampleForm CreateForm()
    {
      return new TssSampleForm(this);
    }

    #region Form
    /// <summary>
    /// Configuration of Warmstandby input form
    /// </summary>
    private class TssWarmStandbyConfiguration : Form
    {
      private DataGridView _grid = null;
      private List<WarmStandbyEndpointDescription> _warmStandbyCfg = null;
      internal List<WarmStandbyEndpointDescription> WarmStandbyCfg
      {
        get { return _warmStandbyCfg; }
        set
        {
          _warmStandbyCfg = value;
          if (_grid==null) return;
          if (value == null)
          {
            _grid.Rows.Clear();
            return;
          }
          foreach (WarmStandbyEndpointDescription description in _warmStandbyCfg)
          {
            _grid.Rows.Add(new object[] {description.Host, description.Port});
          }
        }
      }
      internal TssWarmStandbyConfiguration()
      {
        InitializeView();
      }
      private void InitializeView()
      {
        #region form
        FormBorderStyle = FormBorderStyle.FixedToolWindow;
        Text = "WarmStandby configuration";
        Width = 400;
        Height = 300;
        StartPosition = FormStartPosition.CenterScreen;
        var mainPanel = new Panel
        {
          BorderStyle = BorderStyle.Fixed3D,
          AutoSize = true,
          Dock = DockStyle.Fill,
          Parent = this
        };
        #region grid
        _grid = new DataGridView()
        {
          Dock = DockStyle.Top,
          Height = 240,
          Parent = mainPanel, 
          AllowUserToOrderColumns = false,
        };
        _grid.RowTemplate = new DataGridViewRow();
        _grid.ColumnHeadersDefaultCellStyle.Font = new Font(
          _grid.ColumnHeadersDefaultCellStyle.Font.FontFamily, _grid.ColumnHeadersDefaultCellStyle.Font.Size, FontStyle.Bold);
        _grid.Columns.Add(new DataGridViewColumn
        {
          ValueType = typeof (string),HeaderText = "Host",Width = 100, Name = "HOST",
          CellTemplate = new DataGridViewTextBoxCell() {ValueType = typeof (String)}
        });
        _grid.Columns.Add(new DataGridViewColumn
        {
          ValueType = typeof(int), HeaderText = "Port", Width = 60, Name = "PORT",
          CellTemplate = new DataGridViewTextBoxCell() { ValueType = typeof(int) }
        });
        _grid.CellValidating += (sender, args) =>
        {
          if (_grid.Columns[args.ColumnIndex].Name == "PORT")
          {
            if (String.IsNullOrEmpty(args.FormattedValue as String)) return;
            int portValue;
            if (!Int32.TryParse(args.FormattedValue as String, out portValue) ||
                ((portValue <= 0) || (portValue >= 65535)))
            {
              args.Cancel = true;
            }
            if (_grid.CurrentCell != null)
              _grid.CurrentCell.Value = portValue;
          }
          else
          {
            _grid.CurrentCell.Value = args.FormattedValue;
          }
        };
        #endregion grid
        #region button
        var button = new Button
        {
          Left = 120, Width = 152, Top=244, Height = 24,
          TextAlign = ContentAlignment.MiddleCenter, Text = "Apply configuration",
          Parent = mainPanel
        };
        button.Click += (sender, args) =>
        {
          _warmStandbyCfg = null;
          for (int i = 0; i < _grid.RowCount; i++)
          {
            if (String.IsNullOrEmpty(_grid.Rows[i].Cells["HOST"].EditedFormattedValue as String)) continue;
            if (String.IsNullOrEmpty(_grid.Rows[i].Cells["PORT"].EditedFormattedValue as String)) continue;
            if (_warmStandbyCfg == null) _warmStandbyCfg = new List<WarmStandbyEndpointDescription>();
            _warmStandbyCfg.Add(new WarmStandbyEndpointDescription
            {
              Host = _grid.Rows[i].Cells["HOST"].Value as string,
              Port = Convert.ToInt32(_grid.Rows[i].Cells["PORT"].Value)
            });
          }
          this.DialogResult = DialogResult.OK;
          Close();
        };

        #endregion button

        #endregion form
      }
    }
    /// <summary>
    /// T-Server sample view form
    /// </summary>
    private class TssSampleForm : SampleForm
    {
      private readonly TssView _tssView;
      public TssSampleForm(TssView tssView)
      {
        _tssView = tssView;
        InitializeView();
      }


      private string _hostName;
      private int _port;
      private string _clientName;
      private string _clientPassword="";
      private RichTextBox _box;
      private CheckBox _connectedBox;
      private CheckBox _registeredBox;
      private CheckBox _loggedBox;
      private CheckBox _readyBox;
      private ConsoleWrapper _console;
      private Button _openButton;
      private Button _closeButton;
      private Button _registerButton;
      private Button _unregisterButton;
      private Button _logInButton;
      private Button _logOutButton;
      private Button _readyButton;
      private Button _notReadyButton;
      private Button _wsButton;
      private string _thisDn;
      private string _thisQueue;
      private string _agentId;
      private string _agentPwd="";
      private CheckBox _wsCheckBox;
      private List<WarmStandbyEndpointDescription> _warmStandbyCfg=null;

      private void InitializeView()
      {
        SuspendLayout();
        this.Closed += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _tssView.Model.Close();
        };
        #region form
        FormBorderStyle = FormBorderStyle.SizableToolWindow;
        Text = "T-Server sample";
        Width = 600;
        Height = 600;
        MinimumSize = new Size(600,600);
        MaximumSize = new Size(600, 1000);
        StartPosition = FormStartPosition.CenterScreen;
        var mainPanel = new Panel{
          BorderStyle = BorderStyle.Fixed3D, AutoSize = true, Dock = DockStyle.Fill, Parent = this
        };
        #region control panel
        var controlPanel = new Panel{
          Parent = mainPanel,
          BorderStyle = BorderStyle.Fixed3D, Padding = new Padding(4), //Margin = new Padding(4),
          TabIndex = 1,Width = 488, Dock = DockStyle.Fill
        };
        #region status
        var groupBox = new GroupBox{
          Parent = controlPanel, Dock = DockStyle.Fill, Text = "Status", Margin = new Padding(3),
          Height = 200
        };
        _box = new RichTextBox
        {
          Dock = DockStyle.Bottom, Height = 160, Lines = new string[]{}, Parent = groupBox
        };
        _console = new ConsoleWrapper(this, _box);
        groupBox.Resize += (sender, args) =>
        {
          _box.Height = (sender as GroupBox).Height - 40;
        };
        _connectedBox = new CheckBox
        {
          Left = 4, Width = 90, Top = 12, Height = 16,  Enabled = false, Parent = groupBox,
          Checked = false, Text = "Connected"
        };
        _registeredBox = new CheckBox
        {
          Left = 100, Width = 110, Top = 12, Height = 16,  Enabled = false, Parent = groupBox,
          Checked = false, Text = "DN Registered"
        };
        _loggedBox = new CheckBox
        {
          Left = 220, Width = 110, Top = 12, Height = 16,  Enabled = false, Parent = groupBox,
          Checked = false, Text = "Agent logged in"
        };
        _readyBox = new CheckBox
        {
          Left = 340, Width = 110, Top = 12, Height = 16,  Enabled = false, Parent = groupBox,
          Checked = false, Text = "Agent is ready"
        };
        #endregion status
        #region warmstandby
        groupBox = new GroupBox{
          Parent = controlPanel,Dock = DockStyle.Top,Text = "WarmStandby",Margin = new Padding(3),Height = 40,
          Visible = _tssView.Model.WarmStandbySupport
        };
        _wsButton = new Button
        {
          Left = 200, Top = 10,Width = 100,Height = 24, Enabled = false, Parent = groupBox,
          TextAlign = ContentAlignment.MiddleCenter, Text = "Configuration"
        };
        _wsButton.Click += (sender, args) =>
        {
          var form = new TssWarmStandbyConfiguration();
          form.WarmStandbyCfg = _warmStandbyCfg;
          if (form.ShowDialog() == DialogResult.OK)
          {
            // TODO: Handle WS configuration
            _warmStandbyCfg = form.WarmStandbyCfg;
            _tssView.Model.SetWarmStandby(_warmStandbyCfg);
          }
        };
        _wsCheckBox = new CheckBox
        {
          Top = 16, Left = 8, Width = 180, Height = 20, Text = "Enable WarmStandby", Parent = groupBox,
          Enabled = _tssView.Model.WarmStandbySupport
        };
        _wsCheckBox.CheckedChanged += (sender, args) =>
        {
          _wsButton.Enabled = _wsCheckBox.Checked;
          if (_wsCheckBox.Checked)
          {
            if (_warmStandbyCfg == null)
            {
              _warmStandbyCfg = new List<WarmStandbyEndpointDescription>
              {
                new WarmStandbyEndpointDescription {Host = _hostName, Port = _port}
              };
            }
            _tssView.Model.SetWarmStandby(_warmStandbyCfg);
          }
          else
          {
            _tssView.Model.SetWarmStandby(null);
          }
        };

        #endregion warmstandby

        #region agent
        groupBox = new GroupBox{
          Parent = controlPanel, Dock = DockStyle.Top, Text = "Agent properties", Margin = new Padding(3),
          Height = 80
        };
        new Label
        {
          Left = 4, Top = 20, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "DN", Parent = groupBox
        };
        new Label{
          Left = 240, Top = 20, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "Queue", Parent = groupBox, 
        };
        var edit = new TextBox(){
          Left = 120, Top = 12, Height = 20, Width = 100, Parent = groupBox, TabIndex = 0, Margin = new Padding(3),
        };
        edit.TextChanged += (sender, args) =>{
                                               var box = sender as TextBox;
                                               if (box != null) _thisDn = box.Text;
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.DN","100");
        edit = new TextBox{
          Left = 350,Top = 12,Height = 20,Width = 100,Parent = groupBox, TabIndex = 1, Margin = new Padding(3),
        };
        edit.TextChanged += (sender, args) =>
        {
          var box = sender as TextBox;
          if (box != null) _thisQueue = box.Text;
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.Queue","1010");
        new Label{
          Left = 4, Top = 44, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "Agent name", Parent = groupBox
        };
        new Label{
          Left = 240, Top = 44, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "Agent password", Parent = groupBox
        };
        edit = new TextBox(){
          Left = 120, Top = 36, Height = 20, Width = 100, Parent = groupBox, TabIndex = 0, Margin = new Padding(3)
        };
        edit.TextChanged += (sender, args) =>{
                                               var box = sender as TextBox;
                                               if (box != null) _agentId = box.Text;
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.AgentName","100");
        edit = new TextBox()
        {
          Left = 350, Top = 36, Height = 20, Width = 100, Parent = groupBox, TabIndex = 0, Margin = new Padding(3),
          PasswordChar = '*'
        };
        edit.TextChanged += (sender, args) =>{
                                               var box = sender as TextBox;
                                               if (box != null) _agentPwd = box.Text;
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.AgentPassword","");
        #endregion agent
        #region connection controls
        groupBox = new GroupBox{
          Dock = DockStyle.Top, Height = 68, Text = "Connection properties", Parent = controlPanel, Margin = new Padding(3),
          AutoSize = true
        };
        new Label
        {
          Left = 4, Top = 20, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "Host", Parent = groupBox
        };
        new Label{
          Left = 240, Top = 20, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "Port number", Parent = groupBox, 
        };
        edit = new TextBox(){
          Left = 120, Top = 12, Height = 20, Width = 100, Parent = groupBox, TabIndex = 0, Margin = new Padding(3),
        };
        edit.TextChanged += (sender, args) =>{
                                               var box = sender as TextBox;
                                               if (box != null) _hostName = box.Text;
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.Host", "localhost");
        edit = new TextBox{
          Left = 350,Top = 12,Height = 20,Width = 100,Parent = groupBox, TabIndex = 1, Margin = new Padding(3),
        };
        edit.TextChanged += (sender, args) =>
        {
          var box = sender as TextBox;
          if (box != null) Int32.TryParse(box.Text, out _port);
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.Port", 8710).ToString(CultureInfo.InvariantCulture);
        edit.KeyPress += (sender, args) =>
        {
          var box = sender as TextBox;
          if (box != null)
          {
            if ((args.KeyChar >= '0') && (args.KeyChar <= '9')) return;
            if ((args.KeyChar == 0x09) || (args.KeyChar == 0x0D) || (args.KeyChar==0x08)) return;
            args.Handled = true;
          }
        };
        new Label{
          Left = 4, Top = 44, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "Client name", Parent = groupBox
        };
        new Label{
          Left = 240, Top = 44, Height = 20, Width = 100, TextAlign = ContentAlignment.TopLeft,
          Text = "Client password", Parent = groupBox
        };
        edit = new TextBox(){
          Left = 120, Top = 36, Height = 20, Width = 100, Parent = groupBox, TabIndex = 0, Margin = new Padding(3)
        };
        edit.TextChanged += (sender, args) =>{
                                               var box = sender as TextBox;
                                               if (box != null) _clientName = box.Text;
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.ClientName","");
        edit = new TextBox()
        {
          Left = 350, Top = 36, Height = 20, Width = 100, Parent = groupBox, TabIndex = 0, Margin = new Padding(3),
          PasswordChar = '*'
        };
        edit.TextChanged += (sender, args) =>{
                                               var box = sender as TextBox;
                                               if (box != null) _clientPassword = box.Text;
        };
        edit.Text = PsdkCustomization.CustomOption("Samples.TServer.ClientPassword","");
        #endregion connection controls
        #endregion control panel
        #region buttons
        var buttonsPanel = new Panel{
          Dock = DockStyle.Right, Width = 110, Parent = mainPanel, BorderStyle = BorderStyle.Fixed3D, TabIndex = 0
        };
        _openButton = new Button()
        {
          Left = 8, Top = 8, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Open", Enabled = true, Parent = buttonsPanel
        };
        _openButton.Click += (sender, args) =>
        {
          if ((_tssView==null) || (_tssView.Model == null)) return;
          _openButton.Enabled = false;
          _tssView.Model.Initialization(_hostName, _port, _clientName, _clientPassword);
          _tssView.Model.Open();
        };
        _registerButton = new Button()
        {
          Left = 8, Top = 34, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Register DN", Enabled = false, Parent = buttonsPanel
        };
        _registerButton.Click += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _registerButton.Enabled = false;
          _tssView.Model.RegisterDn(_thisDn);
        };
        _logInButton = new Button
        {
          Left = 8, Top = 62, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Login", Enabled = false, Parent = buttonsPanel
        };
        _logInButton.Click += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _logInButton.Enabled = false;
          _tssView.Model.AgentLogin(_thisDn, AgentWorkMode.Unknown, _thisQueue, _agentId, _agentPwd, null, null);
        };
        _readyButton = new Button
        {
          Left = 8, Top = 90, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Agent ready", Enabled = false, Parent = buttonsPanel
        };
        _readyButton.Click += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _readyButton.Enabled = false;
          _tssView.Model.SetAgentReady(_thisDn, AgentWorkMode.Unknown, _thisQueue, null, null);
        };
        _notReadyButton = new Button
        {
          Left = 8, Top = 118, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Agent not ready", Enabled = false, Parent = buttonsPanel
        };
        _notReadyButton.Click += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _notReadyButton.Enabled = false;
          _tssView.Model.SetAgentNotReady(_thisDn, AgentWorkMode.Unknown, _thisQueue, null, null);
        };

        _logOutButton = new Button
        {
          Left = 8, Top = 146, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Logout", Enabled = false, Parent = buttonsPanel
        };
        _logOutButton.Click += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _logInButton.Enabled = false;
          _tssView.Model.AgentLogout(_thisDn, _thisQueue, null, null);
        };
        _unregisterButton = new Button()
        {
          Left = 8, Top = 174, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Unregister DN", Enabled = false, Parent = buttonsPanel
        };
        _unregisterButton.Click += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _unregisterButton.Enabled = false;
          _tssView.Model.UnregisterDn(_thisDn);
        };
        _closeButton = new Button()
        {
          Left = 8, Top = 202, Height = 24, Width = 94,
          TextAlign = ContentAlignment.MiddleCenter,
          Text = "Close", Enabled = false, Parent = buttonsPanel
        };
        _closeButton.Click += (sender, args) =>
        {
          if ((_tssView == null) || (_tssView.Model == null)) return;
          _closeButton.Enabled = false;
          _tssView.Model.Close();
        };
        #endregion buttons
        #endregion form
        ResumeLayout(false);
      }

      private void ProcessChannelMessageEvent(NotifyObject notification)
      {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Message received...{0}", ((notification.Data != null) ? "\n" + notification.Data : "null"));
        switch (notification.SubCode)
        {
          case TssModelEventCodes.RegisterDn:
          {
            _unregisterButton.Enabled = true;
            _registerButton.Enabled = false;
            _logInButton.Enabled = true;
            _logOutButton.Enabled = false;
            _registeredBox.Checked = true;
            break;
          }
          case TssModelEventCodes.ErrorRegisterDn:
          {
            _registerButton.Enabled = true;
            if (!String.IsNullOrEmpty(notification.Description))
              MessageBox.Show(notification.Description, "Error register DN", MessageBoxButtons.OK);
            break;
          }
          case TssModelEventCodes.UnregisterDn:
          {
            _unregisterButton.Enabled = false;
            _registerButton.Enabled = true;
            _logInButton.Enabled = false;
            _logOutButton.Enabled = false;
            _registeredBox.Checked = false;
            break;
          }
          case TssModelEventCodes.ErrorUnregisterDn:
          {
            _unregisterButton.Enabled = true;
            if (!String.IsNullOrEmpty(notification.Description))
              MessageBox.Show(notification.Description, "Error unregister DN", MessageBoxButtons.OK);
            break;
          }
          case TssModelEventCodes.AgentLogin:
          {
            _loggedBox.Checked = true;
            _logInButton.Enabled = false;
            _logOutButton.Enabled = true;
            _unregisterButton.Enabled = false;
            _readyButton.Enabled = true;
            break;
          }
          case TssModelEventCodes.ErrorLogIn:
          {
            _logInButton.Enabled = true;
            if (!String.IsNullOrEmpty(notification.Description))
              MessageBox.Show(notification.Description, "Error log in", MessageBoxButtons.OK);
            break;
          }
          case TssModelEventCodes.AgentLogout:
          {
            _loggedBox.Checked = false;
            _logInButton.Enabled = true;
            _logOutButton.Enabled = false;
            _unregisterButton.Enabled = true;
            _readyBox.Checked = false;
            _readyButton.Enabled = false;
            _notReadyButton.Enabled = false;
            break;
          }
          case TssModelEventCodes.ErrorLogOut:
          {
            _logOutButton.Enabled = true;
            if (!String.IsNullOrEmpty(notification.Description))
              MessageBox.Show(notification.Description, "Error log out", MessageBoxButtons.OK);
            break;
          }
          case TssModelEventCodes.AgentReady:
          {
            _readyBox.Checked = true;
            _loggedBox.Checked = true;
            _logInButton.Enabled = false;
            _logOutButton.Enabled = true;
            _unregisterButton.Enabled = false;
            _readyButton.Enabled = false;
            _notReadyButton.Enabled = true;
            break;
          }
          case TssModelEventCodes.ErrorSetReady:
          {
            _readyButton.Enabled = true;
            if (!String.IsNullOrEmpty(notification.Description))
              MessageBox.Show(notification.Description, "Error set ready", MessageBoxButtons.OK);
            break;
          }
          case TssModelEventCodes.AgentNotReady:
          {
            _readyBox.Checked = false;
            _logInButton.Enabled = false;
            _logOutButton.Enabled = true;
            _unregisterButton.Enabled = false;
            _readyButton.Enabled = true;
            _notReadyButton.Enabled = false;
            break;
          }
          case TssModelEventCodes.ErrorSetNotReady:
          {
            _notReadyButton.Enabled = true;
            if (!String.IsNullOrEmpty(notification.Description))
              MessageBox.Show(notification.Description, "Error set not ready", MessageBoxButtons.OK);
            break;
          }
        }
      }


      protected override void ProcessMessage(int messageCode)
      {
        if (messageCode == WmConsts.WmRefreshView)
          _console.Flush();
        if (messageCode == WmConsts.WmRefreshModel)
        {
          var notification = GetNotification();
          if (notification==null) return;
          switch (notification.Code)
          {
            case ModelEventCodes.ChannelClosed:
            {
              _registeredBox.Checked = false;
              _connectedBox.Checked = false;
              _loggedBox.Checked = false;
              _readyBox.Checked = false;
              _closeButton.Enabled = false;
              _openButton.Enabled = true;
              _logInButton.Enabled = false;
              _logOutButton.Enabled = false;
              _unregisterButton.Enabled = false;
              _registerButton.Enabled = false;
              _readyButton.Enabled = false;
              _notReadyButton.Enabled = false;
              _wsCheckBox.Enabled = true;
              _wsButton.Enabled = _wsCheckBox.Checked;
              if (notification.Data != null)
              {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine(String.Format("Channel can't be opened: {0}",
                  ((notification.Data != null) ? "\n" + notification.Data : "")));
              }
              else
              {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Channel closed...");
              }
              break;
            }
            case ModelEventCodes.ChannelOpened:
            {
              Console.ForegroundColor = ConsoleColor.White;
              Console.WriteLine("Channel opened...");
              _registeredBox.Checked = false;
              _connectedBox.Checked = true;
              _loggedBox.Checked = false;
              _readyBox.Checked = false;
              _openButton.Enabled = false;
              _closeButton.Enabled = true;
              _registerButton.Enabled = true;
              _unregisterButton.Enabled = false;
              _logInButton.Enabled = false;
              _logOutButton.Enabled = false;
              _readyButton.Enabled = false;
              _notReadyButton.Enabled = false;
              _wsCheckBox.Enabled = false;
              _wsButton.Enabled = false;
              break;
            }
            case ModelEventCodes.ChannelError:
            {
              Console.ForegroundColor = ConsoleColor.Yellow;
              Console.WriteLine("Channel error event received...{0}", ((notification.Data != null) ? "\n" + notification.Data : ""));
              break;
            }
            case ModelEventCodes.ChannelMessage:
            {
              ProcessChannelMessageEvent(notification);
              break;
            }
            case ModelEventCodes.InternalError:
            {
              Console.ForegroundColor = ConsoleColor.Red;
              Console.WriteLine("Internal error: {0}", ((notification.Data != null) ? "\n" + notification.Data : ""));
              break;
            }
          }
        }
      }
    }
    #endregion Form
  }
}

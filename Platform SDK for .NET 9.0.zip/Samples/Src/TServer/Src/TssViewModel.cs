// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Collections.Generic;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Platform.Voice.Protocols.TServer;

namespace Genesyslab.Platform.Samples.TServerSample
{
  public class TssViewModel : ViewModelBase, ITssViewModel
  {
    private new ITssModel Model
    {
      get { return base.Model as ITssModel; }
    }
    private new ITssView View
    {
      get { return base.View as ITssView; }
    }

    /// <summary>
    /// Notifies View that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    public void Notify(int code, int subCode, object data)
    {
      Notify(code, subCode, data, null);
    }
    /// <summary>
    /// Notifies View that it has been changed
    /// </summary>
    /// <param name="code">Event code</param>
    /// <param name="subCode">Additional event code</param>
    /// <param name="data">Custom data</param>
    /// <param name="addData">Event description</param>
    public void Notify(int code, int subCode, object data, string addData)
    {
      if (View != null) View.Notify(code, subCode, data, addData);
    }

    /// <summary>
    /// Opens presentation window in dialog mode.
    /// </summary>
    public void Run()
    {
      throw new NotSupportedException("This function available only in view.");
    }

    /// <summary>
    /// Initializes connection's parameters
    /// </summary>
    /// <param name="host">Host name</param>
    /// <param name="port">Port number</param>
    /// <param name="clientName">Client's name</param>
    /// <param name="password">User password. Further API may be some different in case of using sensitive data.</param>
    public void Initialization(string host, int port, string clientName, string password)
    {
      if (Model!=null) Model.Initialization(host, port, clientName, password);
    }

    /// <summary>
    /// Opens client's connection to server
    /// </summary>
    public void Open()
    {
      if (Model!=null) Model.Open();
    }

    /// <summary>
    /// Closes client's connection to server
    /// </summary>
    public void Close()
    {
      if (Model != null) Model.Close();
    }

    /// <summary>
    /// Registers new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    public void RegisterDn(string thisDn)
    {
      if (Model != null) Model.RegisterDn(thisDn);
    }

    /// <summary>
    /// Unregisters new DN on server
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    public void UnregisterDn(string thisDn)
    {
      if (Model != null) Model.UnregisterDn(thisDn);
    }

    /// <summary>
    /// Request server to log on agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="agentID">Agent identifier</param>
    /// <param name="password">agent's password</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void AgentLogin(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, string agentID, string password,
      KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (Model != null) Model.AgentLogin(thisDn,agentWorkMode, thisQueue,agentID, password, reasons, extensions);
    }

    /// <summary>
    /// Request server to log out agent
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void AgentLogout(string thisDn, string thisQueue, KeyValueCollection reasons, KeyValueCollection extensions)
    {
      if (Model != null) Model.AgentLogout(thisDn,  thisQueue, reasons, extensions);
    }

    /// <summary>
    /// Request server to set agent ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void SetAgentReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (Model != null) Model.SetAgentReady(thisDn, agentWorkMode, thisQueue, reasons, extensions);
    }

    /// <summary>
    /// Request server to set agent not ready
    /// </summary>
    /// <param name="thisDn">DN's name (number)</param>
    /// <param name="agentWorkMode">Agent's work mode</param>
    /// <param name="thisQueue">Queue's name (number)</param>
    /// <param name="reasons">Key-value collection of reasons</param>
    /// <param name="extensions">Key-value collection of extensions</param>
    public void SetAgentNotReady(string thisDn, AgentWorkMode agentWorkMode, string thisQueue, KeyValueCollection reasons,
      KeyValueCollection extensions)
    {
      if (Model != null) Model.SetAgentNotReady(thisDn, agentWorkMode, thisQueue, reasons, extensions);
    }

    /// <summary>
    /// Sets warmstandby configuration
    /// </summary>
    /// <param name="cfg">List of endpoint's description</param>
    public void SetWarmStandby(List<WarmStandbyEndpointDescription> cfg)
    {
      if (Model != null) Model.SetWarmStandby(cfg);
    }

    public bool WarmStandbySupport
    {
      get
      {
        if (Model == null) return false;
        return Model.WarmStandbySupport;
      }
    }
  }
}

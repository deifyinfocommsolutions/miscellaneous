// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Diagnostics;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using Genesyslab.Platform.Samples.Common;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Standby;

namespace Genesyslab.Platform.Samples.WarmStandbySample
{
  /// <summary>
  /// Sample shows one of possible scenarios and methods how to use new WarmStandby.
  /// <see cref="http://docs.genesys.com/Documentation/PSDK/8.5.x/Developer/UsingWarmStandbyAB"/> 
  /// </summary>
  public class WarmStandbySamples
  {
    public static void Main()
    {
      new WarmStandbySamples().ExecuteExample();
    }

    private void ExecuteExample()
    {
      SetUpConsole();
      SetUp();
      TestScenario();
      CleanUp();
    }

    
    private WarmStandbyTestServer _serverOk;
    private WarmStandbyTestServer _serverFail;
    private int _serverOkPort;
    private int _serverFailPort;

    [DllImport("User32.dll", SetLastError = true)]
    private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
    private static extern IntPtr SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int y, int cx, int cy, int wFlags);

    private void SetUpConsole()
    {
      Console.Title = "WarmStandby example";
      var hWnd = FindWindow(null, Console.Title);
      const int swpNosize = 0x1;
      const int hwndTopmost = -1;
      SetWindowPos(hWnd, hwndTopmost, 0, 0, 0, 0, swpNosize);
      Console.WindowWidth = Console.LargestWindowWidth-10;
      Console.WindowHeight = Console.LargestWindowHeight-10;
    }

    private void SetUp()
    {
      
      _serverOk = new WarmStandbyTestServer(1, 2, 3, 4);
      _serverOk.EnableLogging(new TraceSourceLogger(new TraceSource("server.ok.sample.root", SourceLevels.All)));
      _serverOk.Open();
      var ep = _serverOk.LocalEndPoint as IPEndPoint;
      if (ep != null) _serverOkPort = ep.Port;
      _serverFail = new WarmStandbyTestServer(-1, -1, -1, -1);
      _serverFail.EnableLogging(new TraceSourceLogger(new TraceSource("server.fail.sample.root", SourceLevels.All)));
      _serverFail.Open();
      ep = _serverFail.LocalEndPoint as IPEndPoint;
      if (ep != null) _serverFailPort = ep.Port;
      ConsoleWriteLine(ConsoleColor.Blue, "Created valid server at port: {0} and invalid server at port: {1}", _serverOkPort, _serverFailPort);
    }

    private void ConsoleWriteLine(ConsoleColor color,  string format, params object[] args)
    {
      lock (typeof (Console))
      {
        Console.ForegroundColor = color;
        Console.Write(DateTime.Now.ToString("HH:mm:ss.fff")+" | ");
        Console.WriteLine(format, args);
        Console.ResetColor();
      }
    }
    private void CleanUp()
    {
      _serverOk.Close();
      _serverFail.Close();
      ConsoleWriteLine(ConsoleColor.DarkGray, "\nPress any key to exit...");
      Console.ReadKey(true);
    }

    private void AssignWSHandlers(WarmStandby ws)
    {
      ws.EnableLogging(new TraceSourceLogger(new TraceSource("ws.sample.root", SourceLevels.All)));
      ws.EndpointTriedUnsuccessfully += (sender, args) =>
      {
        var arg = args as WSTriedUnsuccessfullyEvent;
        if (arg != null)
        {
          ConsoleWriteLine(ConsoleColor.Yellow, "Error connect to endpoint: {0}. Cause: {1}", arg.Endpoint, arg.Cause.Message);
        }
      };
      ws.AllEndpointsTriedUnsuccessfully += (sender, args) =>
      {
        var arg = args as WSAllTriedUnsuccessfullyEvent;
        if (arg != null)
        {
          ConsoleWriteLine(ConsoleColor.Magenta,"No available servers. Retry number: {0}. ", arg.RetryNumber);
        }
      };
      ws.ChannelOpened += (sender, args) =>
      {
        var arg = args as WSOpenedEvent;
        if (arg != null)
        {
          ConsoleWriteLine(ConsoleColor.Green,"Connected to endpoint: {0}. ", arg.Endpoint);
        }
      };
      ws.ChannelDisconnected += (sender, args) =>
      {
        var arg = args as WSDisconnectedEvent;
        if (arg != null)
        {
          ConsoleWriteLine(ConsoleColor.Red,"Disconnected from endpoint: {0}. ", arg.Endpoint);
        }
      };
    }


    private void TestScenario()
    {
      // No valid servers in endpoint's pool 
      var client = new WarmStandbyTestClient(4, 2);
      client.EnableLogging(new TraceSourceLogger(new TraceSource("client.sample.root", SourceLevels.All)));
      var ws = new WarmStandby(client, new Endpoint("FailServer","localhost", _serverFailPort), new Endpoint("FakeServer","0.0.0.1", 1))
      {
        Configuration = {BackupDelay = 3000, RetryDelay = new []{3000,5000,10000}}
      };
      var @event = new ManualResetEvent(false);
      AssignWSHandlers(ws);
      EventHandler wsOnAllEndpointsTriedUnsuccessfully=null;
      wsOnAllEndpointsTriedUnsuccessfully = (sender, args) =>
      {
        var arg = args as WSAllTriedUnsuccessfullyEvent;
        if ((arg != null) && (arg.RetryNumber>1))
        {
          ConsoleWriteLine(ConsoleColor.Blue, "Unsuccessful. Switch to another pool");
          ws.AllEndpointsTriedUnsuccessfully -= wsOnAllEndpointsTriedUnsuccessfully;
          ws.Configuration.SetEndpoints(new Endpoint("FailServer", "localhost", _serverFailPort), new Endpoint("ServerOk", "localhost", _serverOkPort));
          @event.Set();
        }
      };
      ws.AllEndpointsTriedUnsuccessfully += wsOnAllEndpointsTriedUnsuccessfully;
      ws.AutoRestore(true);
      @event.WaitOne();
      @event.Reset();

      // Connect with RegistrationException
      EventHandler wsTriedUnsuccessful = null;
      wsTriedUnsuccessful = (sender, args) =>
      {
        var arg = args as WSTriedUnsuccessfullyEvent;
        if ((arg != null) && (arg.Cause is RegistrationException))
        {
          ConsoleWriteLine(ConsoleColor.Blue, "Handle registration exception");
          client.RequestCode = 3;
          arg.Resume();
          ws.EndpointTriedUnsuccessfully -= wsTriedUnsuccessful;
          @event.Set();
        }
      };
      ws.EndpointTriedUnsuccessfully += wsTriedUnsuccessful;
      @event.WaitOne();
      @event.Reset();
      // Successful connect and disconnect
      
      EventHandler wsChannelDisconnected = null;
      wsChannelDisconnected = (sender, args) =>
      {
        ConsoleWriteLine(ConsoleColor.Blue, "Handle disconnected event");
        client.RequestCode = 1;
        ws.ChannelDisconnected -= wsChannelDisconnected;
        @event.Set();
      };
      ws.ChannelDisconnected += wsChannelDisconnected;
      @event.WaitOne();
      @event.Reset();

      // Successful connect 
      EventHandler wsChannelOpened = null;
      wsChannelOpened = (sender, args) =>
      {
        ConsoleWriteLine(ConsoleColor.Blue, "Handle opened event");
        ws.ChannelOpened -= wsChannelOpened;
        @event.Set();
      };
      ws.ChannelOpened += wsChannelOpened;
      @event.WaitOne();
      // Close warmstandby
      ws.Close();
    }

  }
}

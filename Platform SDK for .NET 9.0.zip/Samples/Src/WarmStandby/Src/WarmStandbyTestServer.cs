// Disclaimer: IMPORTANT:  This sample software is supplied to you by Genesys
// Telecommunications Laboratories Inc ("Genesys") in consideration of your agreement
// to the following terms, and your use, installation, modification or redistribution
// of this Genesys software constitutes acceptance of these terms.  If you do not
// agree with these terms, please do not use, install, modify or redistribute this
// Genesys software.
// 
// In consideration of your agreement to abide by the following terms, and subject
// to these terms, Genesys grants you a personal, non-exclusive license, under
// Genesys's copyrights in this original Genesys software (the "Genesys Software"), to
// use, reproduce, modify and redistribute the Genesys Software, with or without
// modifications, in source and/or binary forms; provided that if you redistribute
// the Genesys Software in its entirety and without modifications, you must retain
// this notice and the following text and disclaimers in all such redistributions
// of the Genesys Software.
// 
// Neither the name, trademarks, service marks or logos of Genesys Inc. may be used
// to endorse or promote products derived from the Genesys Software without specific
// prior written permission from Genesys.  Except as expressly stated in this notice,
// no other rights or licenses, express or implied, are granted by Genesys herein,
// including but not limited to any patent rights that may be infringed by your
// derivative works or by other works in which the Genesys Software may be
// incorporated.
// 
// The Genesys Software is provided by Genesys on an "AS IS" basis.  GENESYS MAKES NO
// WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
// WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE, REGARDING THE GENESYS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
// COMBINATION WITH YOUR PRODUCTS.
// 
// IN NO EVENT SHALL GENESYS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR
// DISTRIBUTION OF THE GENESYS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF
// CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF
// GENESYS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Copyright (C) 2015 - 2019 Genesys Inc. All Rights Reserved.

using System;
using System.Collections;
using System.Threading;
using Genesyslab.Platform.Commons.Protocols;
using Genesyslab.Platform.Commons.Protocols.Custom;
using Genesyslab.Platform.Commons.Protocols.Internal;
using Genesyslab.Platform.Commons.Threading;


namespace Genesyslab.Platform.Samples.WarmStandbySample
{
  /// <summary>
  /// This factory provides interface to create 
  /// messages without any relations to the determined protocol. 
  /// It is mandatory to be used on client and server side, which
  /// should have same implementations.
  /// </summary>
  internal class WarmStandbyTestServerMessageFactory : IMessageFactory
  {
    private static readonly Hashtable AttributesInfo = new Hashtable
      {
        {"ReferenceId", new AttributeInfo(typeof (int), "IATRCFG_REQUESTID", "2", false, false, true, false)},
      };
    private static readonly ProtocolDescription ProtDescription = new ProtocolDescription("WSTest", "WarmStandbyTestProtocol");

    public ProtocolDescription ProtocolDescription
    {
      get { return ProtDescription; }
    }
    public string ProtocolVersion { get { return "1.0"; } }
    public string GetMessageName(int id)
    {
      return ProtocolUnknownMessage.MessageName;
    }
    public IMessage CreateMessage(int id)
    {
      return ProtocolUnknownMessage.Create(id, AttributesInfo, "ReferenceId", ProtDescription);
    }
    public IMessage CreateMessage(int id, string name)
    {
      return ProtocolUnknownMessage.Create(id, AttributesInfo, "ReferenceId", ProtDescription);
    }
    public object ProtocolData { get; set; }
  }
  internal class WarmStandbyTestServer : ServerChannel
  {
    private const string InvokerName = "WarmStandbyTestServer";
    private readonly int _responseCode;
    private readonly int _requestCode;
    private readonly int _disconnectCode;
    private readonly int _wrongResponse;
    public WarmStandbyTestServer(int requestCode, int responseCode, int disconnectCode, int wrongResponse) 
      : base(new WildcardEndpoint(0), DuplexChannel.DefaultTimeout, new WarmStandbyTestServerMessageFactory())
    {
      _requestCode = requestCode;
      _responseCode = responseCode;
      _disconnectCode = disconnectCode;
      _wrongResponse = wrongResponse;
      Received += OnMessage;
      Invoker = InvokerFactory.NamedInvoker(InvokerName);
      ClientChannelOpened += (sender, args) =>
      {
        var arg = args as NewChannelEventArgs;
        if ((arg == null) || (arg.Channel == null)) return;
        arg.Channel.Invoker = InvokerFactory.NamedInvoker(InvokerName);
        arg.Channel.Closed += (o, eventArgs) => InvokerFactory.ReleaseInvoker(InvokerName);
      };
    }

    public override void Close()
    {
      base.Close();
      InvokerFactory.ReleaseInvoker(InvokerName);
    }

    private void OnMessage(object sender, EventArgs args)
    {
      var channel = sender as DuplexChannel;
      if (channel==null) return;
      var arg = args as MessageEventArgs;
      if (arg==null) return;
      var msg = arg.Message as ProtocolUnknownMessage;
      if (msg == null) return;
      if (msg.Id == _requestCode)
      {
        var response = ProtocolFactory.CreateMessage(_responseCode);
        if ((response is IReferenceable) && (msg is IReferenceable))
          (response as IReferenceable).UpdateReference((msg as IReferenceable).RetrieveReference());
        channel.Send(response);
        return;
      }
      if (msg.Id == _wrongResponse)
      {
        var response = ProtocolFactory.CreateMessage(_wrongResponse);
        if ((response is IReferenceable) && (msg is IReferenceable))
          (response as IReferenceable).UpdateReference((msg as IReferenceable).RetrieveReference());
        channel.Send(response);
        return;
      }
      if (msg.Id == _disconnectCode)
      {
        var response = ProtocolFactory.CreateMessage(_responseCode);
        if ((response is IReferenceable) && (msg is IReferenceable))
          (response as IReferenceable).UpdateReference((msg as IReferenceable).RetrieveReference());
        channel.Send(response);
        new Thread(() => {Thread.Sleep(3000); channel.Close();}).Start();
        return;
      }
      channel.Close();
    }
  }
  internal class WarmStandbyTestClient : ClientChannel
  {
    private class WSClientHandshake : ProtocolHandshakeStepBase
    {
      private int _responseCode;
      private int _requestCode;
      private IMessage _requestMessage;
      protected override IMessage GetRegistarationMessage()
      {
        return _requestMessage;
      }
      public override IProtocolHandshakeStep HandleResponse(IMessage response)
      {
        // Check for response message is correlated with request message
        if ((response is IReferenceable) && (_requestMessage is IReferenceable))
        {
          if (!((response as IReferenceable).RetrieveReference()
              .Equals((_requestMessage as IReferenceable).RetrieveReference())))
            throw new RegistrationException("Error message");
        }
        // Wrong message
        if (response.Id != _responseCode)
          throw new RegistrationException("Wrong code");
        return null;
      }
      public override IProtocolHandshakeStep Initialize(ClientChannel channel)
      {
        var clientChannel = channel as WarmStandbyTestClient;
        if (clientChannel != null)
        {
          _requestCode = clientChannel.RequestCode;
          _responseCode = clientChannel._responseCode;
          _requestMessage = clientChannel.MessageFactory.CreateMessage(_requestCode);
        }
        return base.Initialize(channel);
      }
    }

    private readonly int _responseCode;
    public WarmStandbyTestClient(int requestCode, int responseCode) 
      : base(new WarmStandbyTestServerMessageFactory(), null, new IntReferenceBuilder())
    {
      RequestCode = requestCode;
      _responseCode = responseCode;
    }
    /// <summary>
    /// Id of handshake message. 
    /// </summary>
    public int RequestCode { get; set; }

    protected override void OnOpened()
    {
      SetRegistrationStep(new WSClientHandshake()); // should be before call of the base class method 
      base.OnOpened();
    }
  }
}
